import json
import os
import statistics

import allure
from deepeval.metrics import GEval
from deepeval.models import AnthropicModel
from deepeval.test_case import LLMTestCase
from deepeval.test_case import LLMTestCaseParams
import pytest
from config import ANTHROPIC_API_KEY, PROMOTION_CACHE_FILE, JUDGE_STABILITY_THRESHOLD
from evals.metric.promotion_accuracy_metric import create_promotion_accuracy_metric

@pytest.mark.eval
def test_promotion_accuracy_variance():

    """
    Loads the highest-scoring cached promotion response
    and evaluates it multiple times to measure judge consistency.
    """

    # Configure Anthropic API access for DeepEval
    os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY

    # Cached response generated from the batch evaluation test
    cache_file = PROMOTION_CACHE_FILE


    # Load cached response that will be evaluated repeatedly
    # to determine whether the judge produces consistent scores.
    try:
        with open(cache_file, "r") as f:
            cached_data = json.load(f)

    except FileNotFoundError:
        pytest.fail(
            f"Cache file not found: {cache_file}\n"
            f"Run the batch evaluation first to generate the cache."
        )

    except json.JSONDecodeError:
        pytest.fail(
            f"Invalid JSON detected in {cache_file}.\n"
            f"Delete the cache file and re-run the batch evaluation."
        )


    # Validate the cache contains everything required
    # to recreate the original evaluation.
    required_fields = [
        "question",
        "actual_output",
        "expected_output",
        "original_score"
    ]

    for field in required_fields:
        assert field in cached_data, (
            f"Missing required field '{field}' in cache file."
        )


    # Reconstruct the original test case using cached data.
    test_case = LLMTestCase(
        input=cached_data["question"],
        actual_output=cached_data["actual_output"],
        expected_output=cached_data["expected_output"]
    )


    # Create the judge used for repeated scoring.
    judge_model = AnthropicModel(
        model="claude-sonnet-4-6",
        timeout=180
    )

    metric = create_promotion_accuracy_metric(judge_model)


    # Stores all judge scores from repeated evaluations.
    variance_scores = []

    # Stores score and reasoning for reporting purposes.
    run_details = []

    STABILITY_THRESHOLD = JUDGE_STABILITY_THRESHOLD
    NUM_RUNS = 5

    assert NUM_RUNS >= 2, (
        "Variance testing requires at least 2 runs."
    )


    # Execute the exact same evaluation multiple times.
    # The objective is not accuracy, but consistency.
    for run in range(NUM_RUNS):

        try:
            metric.measure(test_case)

            variance_scores.append(metric.score)

            run_details.append({
                "run": run + 1,
                "score": metric.score,
                "reason": metric.reason
            })

        except Exception as e:
            pytest.fail(
                f"Judge failed on run {run + 1}: {str(e)}"
            )


    # Calculate consistency statistics.
    avg_score = statistics.mean(variance_scores)
    min_score = min(variance_scores)
    max_score = max(variance_scores)
    std_dev = statistics.stdev(variance_scores)


    # Convert standard deviation into a human-readable
    # judge stability classification.
    if std_dev < 0.05:
        stability_status = "✅ STABLE"

    elif std_dev < 0.10:
        stability_status = "⚠️ MODERATELY STABLE"

    elif std_dev < 0.15:
        stability_status = "⚠️ ACCEPTABLE BUT CONCERNING"

    else:
        stability_status = "❌ UNSTABLE"


    # High-level variance summary for Allure.
    variance_summary = (
        f"Original Score: {cached_data['original_score']}\n"
        f"Scores: {variance_scores}\n"
        f"Average Score: {avg_score:.3f}\n"
        f"Min Score: {min_score:.3f}\n"
        f"Max Score: {max_score:.3f}\n"
        f"Std Dev: {std_dev:.3f}\n"
        f"Status: {stability_status}"
    )

    allure.attach(
        variance_summary,
        name="Variance Summary",
        attachment_type=allure.attachment_type.TEXT
    )


    # Create a consolidated view of all evaluation runs.
    run_summary_lines = []

    for detail in run_details:

        run_text = (
            f"Run: {detail['run']}\n"
            f"Score: {detail['score']:.2f}\n"
            f"Reason: {detail['reason']}\n"
            f"{'-' * 60}"
        )

        run_summary_lines.append(run_text)

    run_summary = "\n".join(run_summary_lines)

    allure.attach(
        run_summary,
        name="Run Results Summary",
        attachment_type=allure.attachment_type.TEXT
    )


    # Create detailed drill-down attachments for each execution.
    for detail in run_details:

        run_attachment = (
            f"Run: {detail['run']}\n\n"
            f"Score: {detail['score']:.2f}\n\n"
            f"Reason:\n{detail['reason']}"
        )

        allure.attach(
            run_attachment,
            name=f"Run {detail['run']}",
            attachment_type=allure.attachment_type.TEXT
        )


    # Fail the test when judge variance exceeds
    # the acceptable stability threshold.
    assert std_dev < STABILITY_THRESHOLD, (
        f"Judge too unstable. "
        f"Std Dev: {std_dev:.3f} "
        f"Threshold: {STABILITY_THRESHOLD} "
        f"Scores: {variance_scores}"
    )
