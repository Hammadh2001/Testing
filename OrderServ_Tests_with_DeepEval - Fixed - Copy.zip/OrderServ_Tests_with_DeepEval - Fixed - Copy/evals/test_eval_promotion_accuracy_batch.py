import json
import os
import pytest
import statistics

from deepeval.models import AnthropicModel
from deepeval.test_case import LLMTestCase
import requests

from config import ANTHROPIC_API_KEY, BASE_URL, PROMOTION_CACHE_FILE, PROMOTION_ACCURACY_BATCH_THRESHOLD
from evals.metric.promotion_accuracy_metric import create_promotion_accuracy_metric
from helpers.agent import chatbot_send_message, create_conversation
from helpers.eval_helpers import build_promotion_ground_truth, get_tool_output
import allure

os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY

PASS_THRESHOLD = PROMOTION_ACCURACY_BATCH_THRESHOLD


@pytest.mark.eval
def test_eval_promotion_accuracy():
    """
    Evaluates promotion accuracy across multiple user phrasings
    and validates that the assistant response matches the
    promotion data returned by the promotion tool.
    """

    test_questions = [
        "Do you have any promos?",
        "What deals are active?",
        "Any discounts today?",
        "Can you show me promotions?"
    ]

    batch_scores = []
    batch_details = []

    judge_model = AnthropicModel(model="claude-sonnet-4-6", timeout=180)
    metric = create_promotion_accuracy_metric(judge_model)

    logout_response = requests.post(f"{BASE_URL}/api/auth/logout")
    assert logout_response.status_code == 200

    auth_me_response = requests.get(f"{BASE_URL}/api/auth/me")
    assert auth_me_response.status_code == 200

    for question in test_questions:

        create_convo_response = create_conversation()
        assert create_convo_response.status_code == 201
        convID = create_convo_response.json()["conversationId"]

        promo_response = chatbot_send_message(convID, question)
        assert promo_response.status_code == 200

        response_json = promo_response.json()
        assistant_text = response_json["assistantText"]

        tool_output = get_tool_output(response_json, "get_promotions")

        assert tool_output is not None, (
            f"get_promotions tool was not invoked for question: {question}"
        )
        assert "promotions" in tool_output, (
            f"promotions key missing in tool output: {tool_output}"
        )

        promotion_text = build_promotion_ground_truth(tool_output["promotions"])

        test_case = LLMTestCase(
            input=question,
            actual_output=assistant_text,
            expected_output=promotion_text
        )

        try:
            metric.measure(test_case)
        except Exception as e:
            pytest.fail(f"Judge evaluation failed for '{question}': {str(e)}")

        if metric.score < PASS_THRESHOLD:
            print(f"Question: {question} | Score: {metric.score:.2f}")

        status = (
            "✅ PASS"
            if metric.score >= PASS_THRESHOLD
            else "❌ FAIL"
        )

        batch_scores.append(metric.score)
        batch_details.append({
            "question": question,
            "status": status,
            "score": metric.score,
            "reason": metric.reason,
            "response": assistant_text,
            "ground_truth": promotion_text
        })

    assert len(batch_scores) == len(test_questions), (
        f"Expected {len(test_questions)} evaluations "
        f"but got {len(batch_scores)}"
    )

    avg_score = statistics.mean(batch_scores)
    min_score = min(batch_scores)
    max_score = max(batch_scores)
    std_dev = statistics.stdev(batch_scores) if len(batch_scores) > 1 else 0

    batch_summary = (
        f"Tests Run: {len(batch_scores)}\n"
        f"Scores: {batch_scores}\n"
        f"Pass Threshold: {PASS_THRESHOLD}\n"
        f"Average Score: {avg_score:.3f}\n"
        f"Min Score: {min_score:.3f}\n"
        f"Max Score: {max_score:.3f}\n"
        f"Std Dev: {std_dev:.3f}"
    )

    allure.attach(
        batch_summary,
        name="Batch Summary",
        attachment_type=allure.attachment_type.TEXT
    )

    question_summary_lines = []
    for detail in batch_details:
        question_text = (
            f"Question: {detail['question']}\n"
            f"Status: {detail['status']}\n"
            f"Score: {detail['score']:.2f}\n"
            f"Reason:\n {detail['reason']}\n"
            f"{'-' * 70}\n"
        )
        question_summary_lines.append(question_text)

    allure.attach(
        "\n".join(question_summary_lines),
        name="Question Results Summary",
        attachment_type=allure.attachment_type.TEXT
    )

    for detail in batch_details:
        per_question_attachment = (
            f"Question: {detail['question']}\n\n"
            f"Score: {detail['score']:.2f}\n\n"
            f"Status: {detail['status']}\n\n"
            f"Reason:\n{detail['reason']}\n\n"
            f"Response:\n{detail['response']}\n\n"
            f"Ground Truth:\n{detail['ground_truth']}"
        )
        allure.attach(
            per_question_attachment,
            name=f"Questions - {detail['question']}",
            attachment_type=allure.attachment_type.TEXT
        )

    best_detail = max(batch_details, key=lambda d: d["score"])
    cached_response = {
        "question": best_detail["question"],
        "actual_output": best_detail["response"],
        "expected_output": best_detail["ground_truth"],
        "original_score": best_detail["score"]
    }

    with open(PROMOTION_CACHE_FILE, "w") as f:
        json.dump(cached_response, f, indent=2)

    assert all(score >= PASS_THRESHOLD for score in batch_scores), (
        f"Scores below threshold: {batch_scores}"
    )
