import os
import pytest
import allure

from deepeval.models import AnthropicModel
from deepeval.test_case import LLMTestCase

from config import ANTHROPIC_API_KEY, PROMOTION_ACCURACY_SINGLE_THRESHOLD
from evals.metric.promotion_accuracy_metric import create_promotion_accuracy_metric
from helpers.agent import chatbot_send_message
from helpers.eval_helpers import build_promotion_ground_truth, get_tool_output

os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY


@pytest.mark.eval
def test_eval_promotion_accuracy(guest_pickup_session):
    """
    Evaluates promotion accuracy for a single promotion question
    and validates that the assistant response matches the
    promotion data returned by the promotion tool.
    """

    convID = guest_pickup_session
    question = "do you have any deals or promotions?"

    promo_response = chatbot_send_message(convID, question)
    assert promo_response.status_code == 200

    response_json = promo_response.json()
    assistant_text = response_json["assistantText"]

    tool_output = get_tool_output(response_json, "get_promotions")

    assert tool_output is not None, "get_promotions tool was not invoked"
    assert "promotions" in tool_output, (
        f"promotions key missing in tool output: {tool_output}"
    )

    promotion_text = build_promotion_ground_truth(tool_output["promotions"])

    judge_model = AnthropicModel(model="claude-sonnet-4-6", timeout=180)
    metric = create_promotion_accuracy_metric(judge_model)

    test_case = LLMTestCase(
        input=question,
        actual_output=assistant_text,
        expected_output=promotion_text
    )

    try:
        metric.measure(test_case)
    except Exception as e:
        pytest.fail(f"Judge evaluation failed: {str(e)}")

    status = (
        "✅ PASS"
        if metric.score >= PROMOTION_ACCURACY_SINGLE_THRESHOLD
        else "❌ FAIL"
    )

    if metric.score < PROMOTION_ACCURACY_SINGLE_THRESHOLD:
        print(f"Question: {question} | Score: {metric.score:.2f}")

    evaluation_summary = (
        f"Question: {question}\n"
        f"Status: {status}\n"
        f"Pass Threshold: {PROMOTION_ACCURACY_SINGLE_THRESHOLD}\n"
        f"Score: {metric.score:.3f}\n"
        f"Reason: {metric.reason}"
    )

    allure.attach(
        evaluation_summary,
        name="Promotion Accuracy Summary",
        attachment_type=allure.attachment_type.TEXT
    )

    detailed_attachment = (
        f"Question:\n{question}\n\n"
        f"Status:\n{status}\n\n"
        f"Score:\n{metric.score:.3f}\n\n"
        f"Reason:\n{metric.reason}\n\n"
        f"Response:\n{assistant_text}\n\n"
        f"Ground Truth:\n{promotion_text}"
    )

    allure.attach(
        detailed_attachment,
        name="Promotion Accuracy Details",
        attachment_type=allure.attachment_type.TEXT
    )

    assert metric.score >= PROMOTION_ACCURACY_SINGLE_THRESHOLD, (
        f"Promotion accuracy score "
        f"{metric.score:.3f} "
        f"below threshold {PROMOTION_ACCURACY_SINGLE_THRESHOLD}"
    )
