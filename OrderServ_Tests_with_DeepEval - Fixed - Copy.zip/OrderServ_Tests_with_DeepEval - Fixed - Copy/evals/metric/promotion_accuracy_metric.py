from deepeval.metrics import GEval
from deepeval.test_case import LLMTestCaseParams
from config import PROMOTION_ACCURACY_BATCH_THRESHOLD


def create_promotion_accuracy_metric(judge_model):
    return GEval(
        name="Promotion Accuracy",
        evaluation_steps=[
            "Check if the actual output explicitly states or implies a promotion has ALREADY been applied to the cart/order, using words like 'already applied', 'already active in your cart', or 'this discount has been added'. Do NOT flag standard promotional listing language like 'here's what's on offer', 'deals available', or 'want me to apply/unlock this' — that is expected, correct phrasing for presenting unavailable promotions to a guest.",
            "Check if the actual output invents any promotion (name or coupon) that does not appear anywhere in the expected output.",
            "Check if the actual output omits any promotion from the expected output where is_applicable=true.",
            "For each promotion mentioned, check if AT LEAST ONE valid qualifying item from its 'requires' list is mentioned. It is NOT required to mention every alternative qualifying item."
        ],
        evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT, LLMTestCaseParams.EXPECTED_OUTPUT],
        model=judge_model,
        threshold=PROMOTION_ACCURACY_BATCH_THRESHOLD
    )
