import os

from deepeval.metrics import GEval
from deepeval.models import AnthropicModel
from deepeval.test_case import LLMTestCase
from deepeval.test_case import LLMTestCaseParams
from config import BASE_URL, ANTHROPIC_API_KEY
from evals.metric.promotion_accuracy_metric import create_promotion_accuracy_metric
from helpers.agent import chatbot_send_message, create_conversation
from helpers.eval_helpers import build_promotion_ground_truth, get_tool_output
import requests

os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY

def eval_promotion_accuracy():

    logout_response = requests.post(f"{BASE_URL}/api/auth/logout")
    assert logout_response.status_code == 200

    create_convo_response = create_conversation()
    assert create_convo_response.status_code == 201
    convID = create_convo_response.json()["conversationId"]

    promo_response = chatbot_send_message(convID, "do you have any deals or promotions?")
    assert promo_response.status_code == 200

    response_json = promo_response.json()
    assistant_text = response_json["assistantText"]

    tool_output = get_tool_output(response_json, "get_promotions")
    promotion_text = build_promotion_ground_truth(tool_output["promotions"])

    judge_model = AnthropicModel(model="claude-sonnet-4-6", timeout=180)
    metric = create_promotion_accuracy_metric(judge_model)

    test_case = LLMTestCase(
        input="do you have any deals or promotions?",
        actual_output=assistant_text,
        expected_output=promotion_text
    )

    metric.measure(test_case)

    print(f"Score: {metric.score}")
    print(f"Reason: {metric.reason}")

if __name__ == "__main__":
    eval_promotion_accuracy()
