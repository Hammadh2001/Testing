def build_promotion_ground_truth(promotions_list):
    lines = []
    for promotion in promotions_list:
        requirements = ", ".join(promotion["missing_requirements"])
        item_names = [item["name"] for item in promotion["qualifying_items"]]
        line = (
            promotion["coupon_code"]
            + " | "
            + promotion["title"]
            + " | "
            + promotion["description"]
            + " | "
            + str(promotion["is_applicable"])
            + " | "
            + requirements
            + " | "
            + ", ".join(item_names)
        )
        lines.append(line)
    return "\n".join(lines)


def get_tool_output(response_json, tool_name):
    for tool in response_json.get("toolContext", []):
        if tool.get("toolName") == tool_name:
            return tool.get("toolOutput")
    return None
