# Changes — OrderServ_Tests_with_DeepEval

This document records every change made to address the issues listed in [IMPROVEMENTS.md](IMPROVEMENTS.md).

---

## §1 🔴 Fixed: `login_pickup_session` fixture scope restored to `module`

**File:** `conftest.py`

**What changed:** The fixture's `scope` was changed back from `"function"` to `"module"`.

**Why:** `test_login_pickup.py`, `test_multi_eval1.py`, and `test_multi_turn_substitution_addon.py` all share state across test functions via module-level globals and sequential API calls. With `scope="function"`, pytest created a brand-new login session and empty cart for every individual test function, so `test_checkout` was talking to an empty cart and all downstream assertions failed. Reverting to `scope="module"` restores a single shared session across all tests in each file — matching the way those tests were written.

**Note on the store/service pin:** The `create_conversation(service="pickup", store="952")` call added alongside the scope change is kept. It was a separate, intentional change that does not affect scope.

---

## §4 & §5 🟠 Fixed: Duplicated ground-truth and tool-output logic extracted to a shared helper

**New file:** `helpers/eval_helpers.py`

**What changed:** Two functions were extracted from the copy-pasted code in `evals/test_eval_promotion_accuracy.py`, `evals/test_eval_promotion_accuracy_batch.py`, and `evals/eval_promotion_accuracy_v2.py` (now in `scripts/`):

- `build_promotion_ground_truth(promotions_list) -> str`  
  Converts a promotions list from the `get_promotions` tool output into the normalized pipe-delimited text string used as the DeepEval ground truth.

- `get_tool_output(response_json, tool_name) -> dict | None`  
  Searches `response_json["toolContext"]` for a tool matching `tool_name` and returns its `toolOutput`. Returns `None` if the tool was not called. Uses `.get()` consistently to avoid `KeyError` on malformed entries.

**Files updated:** `evals/test_eval_promotion_accuracy.py`, `evals/test_eval_promotion_accuracy_batch.py`, `evals/eval_promotion_accuracy_v2.py` (in `scripts/`).

**Before (each file had ~20 lines of identical logic):**
```python
tool_output = None
for tool in tool_context:
    if tool.get("toolName") == "get_promotions":
        tool_output = tool.get("toolOutput")
        break

promotion_lines = []
for promotion in promotions_list:
    requirements = ", ".join(promotion["missing_requirements"])
    item_names = []
    for item in promotion["qualifying_items"]:
        item_names.append(item["name"])
    qualifying_items_text = ", ".join(item_names)
    line = promotion["coupon_code"] + " | " + promotion["title"] + ...
    promotion_lines.append(line)
promotion_text = "\n".join(promotion_lines)
```

**After (one line each):**
```python
tool_output = get_tool_output(response_json, "get_promotions")
promotion_text = build_promotion_ground_truth(tool_output["promotions"])
```

---

## §6 🟡 Fixed: Threshold magic numbers centralized in `config.py`

**File changed:** `config.py` (constants added), `evals/metric/promotion_accuracy_metric.py`, `evals/test_eval_promotion_accuracy.py`, `evals/test_eval_promotion_accuracy_batch.py`, `evals/test_eval_promotion_accuracy_variance.py`.

**What changed:** Three named constants were added to `config.py`, replacing scattered magic numbers:

| Constant | Value | Reason |
|---|---|---|
| `PROMOTION_ACCURACY_BATCH_THRESHOLD` | `0.7` | Per-question minimum for batch eval; also the metric's internal GEval threshold. Tighter because multiple phrasings reduce noise. |
| `PROMOTION_ACCURACY_SINGLE_THRESHOLD` | `0.6` | Single-question eval. Slightly relaxed — one data point is inherently noisier. |
| `JUDGE_STABILITY_THRESHOLD` | `0.15` | Maximum acceptable std dev across repeated judge runs on the same input. |

All eval files now import and use these constants instead of inline literals.

---

## §7 🟡 Fixed: Anthropic API key moved out of source code

**File changed:** `config.py`

**What changed:**
```python
# Before (hardcoded plaintext)
ANTHROPIC_API_KEY = "sk-ant-api03-HoWTn3cr__G48..."

# After (read from environment)
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
```

`BASE_URL` is similarly now read from `ORDERSERV_BASE_URL` with a localhost default:
```python
BASE_URL = os.environ.get("ORDERSERV_BASE_URL", "http://localhost:8050")
```

**New file:** `.env.example` — documents which environment variables are needed and how to set them. Copy it to `.env` (excluded from version control) and fill in real values.

**Action required:** The key that was previously committed in plaintext (`sk-ant-api03-HoWTn3cr...`) should be **rotated immediately** in the Anthropic console — a revoked key cannot be misused even if someone finds the old commit.

**Running evals after this change:**
```bash
# Option A: export before running
export ANTHROPIC_API_KEY=sk-ant-...
pytest evals/

# Option B: inline
ANTHROPIC_API_KEY=sk-ant-... pytest evals/

# Option C: .env file + python-dotenv (requires adding python-dotenv to requirements.txt)
```

---

## §8 🟡 Fixed: `@pytest.mark.eval` marker registered

**New file:** `pytest.ini`

```ini
[pytest]
markers =
    eval: DeepEval-based LLM quality evaluation (slower, calls Claude as judge)
```

This eliminates the `PytestUnknownMarkWarning` printed on every eval run and allows `--strict-markers` to be used safely.

---

## §9 🟡 Fixed: Dead and draft files moved out of discoverable test tree

**Files moved to `scripts/`:**

| Old path | New path | Reason |
|---|---|---|
| `evals/eval_promotion_accuracy.py` | `scripts/eval_promotion_accuracy.py` | Standalone script without `test_` prefix; superseded by the pytest version. Kept as reference. |
| `evals/eval_promotion_accuracy_v2.py` | `scripts/eval_promotion_accuracy_v2.py` | Same — standalone script, not a pytest test. Updated to use the new helpers before moving. |
| `tests/test_login_promotion_pickup.py` | `scripts/debug_login_promotion_pickup.py` | Manual debug script using a different hardcoded account (`_002`). Renamed to make its non-test nature obvious. |

**File deleted:**

| Path | Reason |
|---|---|
| `evals/init__.py` | Empty file with a typo in the name (missing leading/trailing underscores). Did nothing. |

---

## §10 🟡 Fixed: Unpinned dependencies now have explicit versions

**File changed:** `requirements.txt`

| Package | Before | After |
|---|---|---|
| `deepeval` | unpinned | `==4.1.7` |
| `anthropic` | unpinned | `==0.121.0` |
| `allure-pytest` | unpinned | `==2.16.0` |

Versions reflect what was installed and verified working at the time of this change. Pin to a different version if your environment uses something newer — the important thing is that it is pinned.

---

## What was NOT changed

- **§2 — Cross-test state via module globals:** `test_login_pickup.py`, `test_login_delivery.py`, and `test_order_history.py` still use module-level globals to pass state between test functions. §1's fix (restoring `scope="module"`) makes this work correctly again, so the state-sharing pattern is no longer actively broken. Rewriting these tests to be fully self-contained is a larger refactor and was deferred.

- **§3 — No fixture teardown / cleanup:** The fixtures still have no `yield`-based teardown. Adding conversation or order cleanup requires knowing which backend APIs support deletion, and that investigation was out of scope for this pass. The hardcoded order number `#1639` in `test_order_history.py` was also left in place.
