import os
from dotenv import load_dotenv

load_dotenv()

BASE_URL = os.environ.get("ORDERSERV_BASE_URL", "http://localhost:8050")
RETURNING_USER_EMAIL = "kfc_au_orders_001@gmail.com"
STATIC_OTP = "1277"

# Data
PROMOTION_CACHE_FILE = "data/cached_promotion_response.json"

# DeepEval eval thresholds — documented so the differences are intentional, not accidental.
# Batch eval applies this per question and is also the metric's internal GEval threshold.
PROMOTION_ACCURACY_BATCH_THRESHOLD = 0.7
# Single-question eval uses a slightly relaxed bar (one data point is inherently noisier).
PROMOTION_ACCURACY_SINGLE_THRESHOLD = 0.6
# Maximum acceptable std dev across repeated judge runs on identical input.
JUDGE_STABILITY_THRESHOLD = 0.15

# Read from environment — set ANTHROPIC_API_KEY before running evals.
# If this key was previously committed in plaintext, rotate it immediately.
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
