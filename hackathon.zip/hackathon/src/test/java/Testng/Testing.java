package Testng;

import java.io.IOException;

import Resource.Excel;
import Resource.TestngListener;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Function.Cruise;
import Function.CruisePage;
import Function.Hotel;
import Resource.resource;

@Listeners(TestngListener.class)
public class Testing extends resource {

	static Hotel h;
	static Cruise c;
	static CruisePage cp;
	  static Excel excelWriter = new Excel(); // Create a single instance of Excel1

	@Test(priority = 1)
	public void search() throws IOException, InterruptedException {

		h = new Hotel(driver);
		c = new Cruise(driver);
		cp = new CruisePage(driver);

		try {
			WebElement alertElement = driver
					.findElement(By.xpath("//button[@type='button' and @aria-label='Close tooltip']"));
			alertElement.click();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("NO alert");
		}

		Hotel h = new Hotel(driver);
		h.search();

	}

	@Test(priority = 2)
	public void alert() {
		h.alert();

	}

	@Test(priority = 3)

	public void holidayHomes() {
		h.holidayHomes();

	}

	@Test(priority = 4)
	public void noOfPeople() throws InterruptedException {
		h.noOfPeople();
		//h.noOfPeople();

	}

	@Test(priority = 5)
	public void eleveator_lift() {
		h.elevator_lift();

	}

	@Test(priority = 6)
	public void ratings() {
		h.ratings();

	}

	@Test(priority = 7)
	public void tourDate() {
		h.tourDate();

	}

	@Test(priority = 8)
	public void nameCost() {
		String[] ns = h.hotel_name();
		String[] tc = h.totalHotelCost();
		h.printMessage(ns, tc);
		
		// Write the data to Excel
		  h.writeDataToExcel(excelWriter);
	        excelWriter.saveToFile("C:\\Users\\2282530\\Downloads\\1\\1\\CalculateTripCost\\Excel\\Data.xlsx");

	}

	@Test(priority = 9)
	public void cruiseBtn() {
		c.cruise();

	}

	@Test(priority = 10)
	public void cruiseLine() {
		c.cruiseLine();

	}

	@Test(priority = 11)
	public void cruiseSearch() {
		c.clickSearch();

	}

	@Test(priority = 12)
	public void cruiseDetails() {
		cp.switchWindow();
		cp.details();
		cp.writeDetailsToExcel(excelWriter);
        excelWriter.saveToFile("C:\\Users\\2282530\\Downloads\\1\\1\\CalculateTripCost\\Excel\\Data.xlsx");

	}
	
	@Test(priority = 13)
	public void browserClose() {
		driver.quit();
	}

}
