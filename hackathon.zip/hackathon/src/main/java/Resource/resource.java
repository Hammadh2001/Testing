package Resource;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.BeforeSuite;

import io.github.bonigarcia.wdm.WebDriverManager;

public class resource {

	public WebDriver driver;

	@SuppressWarnings("deprecation")
	@BeforeSuite
	public WebDriver initializeBrowser() throws IOException {

		Properties properties = new Properties();
		FileInputStream input = new FileInputStream(
				System.getProperty("user.dir") + "\\src\\main\\java\\Resource\\GlobalData.properties");
		properties.load(input);
		String browser = properties.getProperty("browser");
		// String city=properties.getProperty("city");

		if (browser.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();

		} else if (browser.equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();

		}

		driver.manage().window().maximize();	
		driver.get("https://www.tripadvisor.in/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		return driver;
	}
	
	
	public String getScreenShot(String testcaseName,WebDriver driver) throws IOException {
		
		TakesScreenshot ts=(TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		File file =new File(System.getProperty("user.dir")+ "//Report_Screenshot//" + testcaseName + ".png");
		FileUtils.copyFile(source, file);
		return System.getProperty("user.dir")+"//Report_Screenshot//" + testcaseName + ".png";
		
	}
	

}
