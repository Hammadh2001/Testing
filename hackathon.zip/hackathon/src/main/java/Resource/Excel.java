package Resource;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

 

import java.io.FileOutputStream;

 

public class Excel {

 

    private Workbook workbook;

 

    public Excel() {
        workbook = new XSSFWorkbook();
    }

 

    public void writeHotelDataToExcel(String[] hotelNames, String[] totalCosts) {
        Sheet hotelSheet = workbook.createSheet("Hotel Data");

 

        // Create a header row
        Row headerRow = hotelSheet.createRow(0);
        headerRow.createCell(0).setCellValue("Hotel Name");
        headerRow.createCell(1).setCellValue("Cost per Night");
        headerRow.createCell(2).setCellValue("Total Cost");

 

        for (int i = 0; i < hotelNames.length; i++) {
            Row row = hotelSheet.createRow(i + 1);
            String nameString = hotelNames[i];
            String totalString = totalCosts[i];

 

            // Split the nameString to get the hotel name and cost per night separately
            String[] nameAndCost = nameString.split(" : ");
            String hotelName = nameAndCost[0];
            String costPerNight = nameAndCost[1];

 

            row.createCell(0).setCellValue(hotelName);
            row.createCell(1).setCellValue(costPerNight);
            row.createCell(2).setCellValue(totalString);
        }
    }

 

    public void writeCruiseDetailsToExcel(String cruiseDetails) {
        Sheet cruiseSheet = workbook.createSheet("Cruise Details");

 

        // Create a header row
        Row headerRow = cruiseSheet.createRow(0);
        headerRow.createCell(0).setCellValue("Category");
        headerRow.createCell(1).setCellValue("Value");

 

        String passengers = extractValue(cruiseDetails, "Passengers: (.*?)\\s+\\|");
        String crew = extractValue(cruiseDetails, "Crew: (.*?)\\s+");
        String passengersToCrew = extractValue(cruiseDetails, "Passengers to crew: (.*?)\\s+");
        String launched = extractValue(cruiseDetails, "Launched: (.*?)$");

 

        int rowIndex = 1;

 

        Row passengersRow = cruiseSheet.createRow(rowIndex++);
        passengersRow.createCell(0).setCellValue("Passengers");
        passengersRow.createCell(1).setCellValue(passengers);

 

        Row crewRow = cruiseSheet.createRow(rowIndex++);
        crewRow.createCell(0).setCellValue("Crew");
        crewRow.createCell(1).setCellValue(crew);

 

        Row passengersToCrewRow = cruiseSheet.createRow(rowIndex++);
        passengersToCrewRow.createCell(0).setCellValue("Passengers to crew");
        passengersToCrewRow.createCell(1).setCellValue(passengersToCrew);

 

        Row launchedRow = cruiseSheet.createRow(rowIndex);
        launchedRow.createCell(0).setCellValue("Launched");
        launchedRow.createCell(1).setCellValue(launched);
    }

 

    public void saveToFile(String filePath) {
        try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
            workbook.write(fileOut);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

 

    private String extractValue(String data, String regexPattern) {
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(regexPattern);
        java.util.regex.Matcher matcher = pattern.matcher(data);
        if (matcher.find()) {
            return matcher.group(1).trim();
        }
        return "";
    }
}