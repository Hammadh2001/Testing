package Function;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Abstract.Reuse;
import Resource.Excel;

public class Hotel extends Reuse {

    WebDriver driver;

    public Hotel(WebDriver driver) {

        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);

    }

    @FindBy(xpath = "//input[@placeholder='Where to?']")
    WebElement searchBox;

    @FindBy(xpath = "//*[contains (text(), 'Nairobi')]")
    WebElement searchOption;

    @FindBy(xpath = "//a[@class='XUWut Ra _S z _Z w o v _Y Wh k _T wSSLS' and @href='/VacationRentals-g294207-Reviews-Nairobi-Vacation_Rentals.html']")
    static WebElement holidayHomes;

    @FindBy(xpath = "(//button[@aria-haspopup='dialog'])[2] | (//button[@aria-haspopup='listbox'])[1]")
    WebElement capacity;

    @FindBy(xpath = "(//*[@class='MnqWg Gy S5 _S _H _W u j'])[2]")
    WebElement noOfPeople;

    @FindBy(xpath = "(//*[@class='rmyCe _G B- z _S c Wc wSSLS jWkoZ sOtnj'])[2]")
    WebElement apply;
    
    @FindBy(xpath = "//button[@aria-label='Enter the date range.']")
    WebElement dates;

    @FindBy(xpath = "(//div[contains(text(),'Show all')])[1]")
    WebElement showAll;

    @FindBy(xpath = "//input[@id='amenities.27']/following-sibling::span[@class='PMWyE _W I j u R2 _S']")
    WebElement lift;

    @FindBy(xpath = "//span[contains(text(),'Apply')]")
    WebElement ammenitiesApply;

    @FindBy(xpath = "(//span[@class='NK'])[1]")
    WebElement rating;

    @FindBy(xpath = "//span[contains(text(),'Traveller Rating')]")
    WebElement travellerRating;

    @FindBy(xpath = "//div[@role='gridcell' and @aria-label='26 August 2023']")
    WebElement checkin;

    @FindBy(xpath = "//div[@role='gridcell' and @aria-label='30 August 2023']")
    WebElement checkout;

    @FindBy(xpath = "//a[@class='ToVyw b S7 W o q' and @target='_blank']")
    List<WebElement> hotelNames;

    @FindBy(xpath = "//div[@class='iCUJC b']")
    List<WebElement> perNightCost;

    @FindBy(xpath = "//div[@class='MvXmI']")
    List<WebElement> totalCost;

    public void search() throws IOException {

        Properties properties1 = new Properties();
        FileInputStream input = new FileInputStream(
                System.getProperty("user.dir") + "\\src\\main\\java\\Resource\\GlobalData.properties");
        properties1.load(input);
        String city1 = properties1.getProperty("city");

        searchBox.click();
        searchBox.sendKeys(city1);

        reuseVisi(searchOption);
        searchOption.click();

    }

    public void alert() {
        try {
            WebElement alertElement = driver
                    .findElement(By.xpath("//button[@type='button' and @aria-label='Close tooltip']"));
            alertElement.click();
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println("NO alert");
        }
    }

    public void holidayHomes() {
        reuseVisi(holidayHomes);
        holidayHomes.click();
    }

    public void noOfPeople() throws InterruptedException {
        try {

            Thread.sleep(3000);
            capacity.click();

            Thread.sleep(3000);
            for (int i = 0; i < 2; i++) {
                noOfPeople.click();
            }
            Thread.sleep(3000);
            apply.click();
        } catch (StaleElementReferenceException e) {
        	
        	 capacity.click();

             Thread.sleep(3000);
             for (int i = 0; i < 2; i++) {
                 noOfPeople.click();
             }
             Thread.sleep(3000);
             apply.click();
        }
    }

    public void elevator_lift() {

        showAll.click();
        reuseVisi(lift);
        lift.click();

        reuseVisi(ammenitiesApply);
        ammenitiesApply.click();

    }

    public void ratings() {

        rating.click();
        reuseVisi(travellerRating);
        travellerRating.click();

    }

    public void tourDate() {
        dates.click();
        checkin.click();
        checkout.click();
    }

    public String[] hotel_name() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String ns[] = new String[3];
        for (int i = 0; i < 3; i++) {
            String nameString = hotelNames.get(i).getText();
            String costString = perNightCost.get(i).getText();
            ns[i] = nameString + " : " + costString + " cost per night. ";

        }
        return ns;
    }

    public String[] totalHotelCost() {
        String[] ns = new String[3];

        for (int i = 0; i < 3; i++) {
            String totalString = totalCost.get(i).getText();
            String[] tCost = totalString.split(" /");
            ns[i] = "Total Cost of Hotels :" + tCost[0];
        }
        return ns;
    }

    public void printMessage(String[] ns, String[] tc) {
        for (int i = 0; i < ns.length; i++) {
            System.out.println(ns[i] + " " + tc[i]);
        }
    }
    
    public void writeDataToExcel(Excel excelWriter) {
        String[] ns = hotel_name();
        String[] tc = totalHotelCost();

 

        excelWriter.writeHotelDataToExcel(ns, tc);
    }

}
