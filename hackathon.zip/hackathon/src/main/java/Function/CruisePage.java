package Function;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import Abstract.Reuse;
import Resource.Excel;

public class CruisePage extends Reuse{


    WebDriver driver;
    public CruisePage(WebDriver driver) {

        super(driver);
        this.driver=driver;
        PageFactory.initElements(driver, this);

    }

    @FindBy(xpath = "//div[@class='szsLm']")
    WebElement cruiseDetails;

    public void switchWindow() {
        Set<String> winSet=driver.getWindowHandles();
        Iterator<String>itr=winSet.iterator();
        itr.next();
        String cruiseWindow=itr.next();
        driver.switchTo().window(cruiseWindow);
    }



    public void details() {
        String detString= cruiseDetails.getText();
        System.out.println(detString);
    }
    
    public void writeDetailsToExcel(Excel excelWriter) {
        String detString = cruiseDetails.getText();
        excelWriter.writeCruiseDetailsToExcel(detString);
    }

}
