package Function;

import java.util.List;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Abstract.Reuse;

public class Cruise extends Reuse {

    WebDriver driver;

    public Cruise(WebDriver driver) {

        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "(//a[@class='EJavG'])[7]")
    WebElement cruiseBtn;

    @FindBy(xpath = "(//button[@aria-haspopup='listbox'])[1]")
    WebElement cruiseLine;

    @FindBy(xpath = "//span[@class='biGQs _P fOtGX']")
    List<WebElement> availableCruises;

    @FindBy(xpath = "//button[@type='button' and contains(text(),'Search')]")
    WebElement search;

    public void cruise() {
        cruiseBtn.click();
    }

    public void cruiseLine() {
        cruiseLine.click();

        try {
            for (WebElement name : availableCruises) {
                if (name.getText().equals("Celebrity Cruises")) {
                    name.click();

                }
            }
        } catch (StaleElementReferenceException e) {
            for (WebElement name : availableCruises) {
                if (name.getText().equals("Celebrity Cruises")) {
                    name.click();

                }
            }
        }
    }

    public void clickSearch() {
        reuseClick(search);
        search.click();
    }

}
