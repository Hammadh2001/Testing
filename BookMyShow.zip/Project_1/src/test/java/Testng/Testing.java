package Testng;

import Function.LoginPage;
import Function.Shopping;
import Resource.Resource;
import org.testng.annotations.Test;

import java.io.IOException;

public class Testing extends Resource {

    static LoginPage l;
    static Shopping s;

    @Test(priority = 1)
    public void login() throws IOException {

        l = new LoginPage(driver);
        s = new Shopping(driver);

        l.login();

    }

    @Test(priority = 2)
    public void addProdToCarts() throws InterruptedException {

        s.shopProducts();

    }

}
