package Function;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class Shopping {

    WebDriver driver;
    @FindBy(xpath = "//div[@class='inventory_item_name']")
    List<WebElement> products;
    @FindBy(xpath = "//button[@class='btn btn_primary btn_small btn_inventory']")
    List<WebElement> addToCart;

    public Shopping(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void shopProducts() throws InterruptedException {

        for (int i = 0; i < products.size(); i++) {

            WebElement prod = products.get(i);
            String productsName = prod.getText();

            //WebElement prodCart = addToCart.get(i);

            if (productsName.contains("Backpack") || productsName.contains("Jacket")
                    || productsName.contains("Onesie")) {
                  WebElement prodCart = addToCart.get(i);

                prodCart.click();


                System.out.println(productsName);

            }

        }

    }

}
