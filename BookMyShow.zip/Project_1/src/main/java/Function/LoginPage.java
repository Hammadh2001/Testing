package Function;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LoginPage {

    WebDriver driver;

    public LoginPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath="//input[@name='user-name']")
    WebElement user;

    @FindBy(xpath = "//input[@name='password']")
    WebElement pass;

    @FindBy(xpath = "//input[@class='submit-button btn_action']")
    WebElement loginBtn;

    public void login() throws IOException {

        Properties prop = new Properties();
        FileInputStream input = new FileInputStream(
                System.getProperty("user.dir") + "\\src\\main\\java\\Resource\\Data.properties");
        prop.load(input);

        String userName = prop.getProperty("username");
        String passWord = prop.getProperty("password");

        user.sendKeys(userName);
        pass.sendKeys(passWord);

        loginBtn.click();



    }

}
