package com.tripadvisor.utilities;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TripAdvisorExcel {
	FileOutputStream fos;
	XSSFWorkbook workbook = new XSSFWorkbook();

	public void writeHotelNames(List<String> hotelNames, List<String> totalPrice, List<String> pricePerNight){
		XSSFSheet sheet = workbook.createSheet("Hotels");
		Row r = sheet.createRow(0);
		r.createCell(0).setCellValue("List of Hotels");
		Row row = sheet.createRow(1);
		Cell hotelHeader = row.createCell(0);
		hotelHeader.setCellValue("Hotel Names");
		Cell totalPriceHeader = row.createCell(1);
		totalPriceHeader.setCellValue("Total Price");
		Cell perNightHeader = row.createCell(2);
		perNightHeader.setCellValue("Price per night");
		
		for (int i = 0; i < 3 ; i++) {
			Row rows = sheet.createRow(i+2);
			rows.createCell(0).setCellValue(hotelNames.get(i));
			rows.createCell(1).setCellValue(totalPrice.get(i));
			rows.createCell(2).setCellValue(pricePerNight.get(i));
		}
		
		for (int i = 0; i < 3; i++) {
		    sheet.autoSizeColumn(i); 
		}

		try {
			fos = new FileOutputStream(System.getProperty("user.dir") + "\\test-excel\\tripadvisor.xlsx");
			workbook.write(fos);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	public void writeCruisesDetails(List<String>cruisesDetails, List<String> languages) {
		XSSFSheet sheet = workbook.createSheet("Cruises");
		Row row1 = sheet.createRow(0);
		row1.createCell(0).setCellValue("Cruise Details");
		Row row2 = sheet.createRow(1);
		row2.createCell(0).setCellValue("Passengers Count");
		row2.createCell(1).setCellValue("Crew Count");
		row2.createCell(2).setCellValue("Launched Year");
		Row row3 = sheet.createRow(2);
		for(int i = 0; i < cruisesDetails.size();i++) {
			row3.createCell(i).setCellValue(cruisesDetails.get(i));
		}
		int rowNum = 4;
		for(int i = 0  ; i <languages.size() ; i++ ) {
			sheet.createRow(rowNum).createCell(0).setCellValue(languages.get(i));
			rowNum++;
		}
		
		for (int i = 0; i < 3; i++) {
		    sheet.autoSizeColumn(i); 
		}
		try {
			fos = new FileOutputStream(System.getProperty("user.dir") + "\\test-excel\\tripadvisor.xlsx");
			workbook.write(fos);
			workbook.close();
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
