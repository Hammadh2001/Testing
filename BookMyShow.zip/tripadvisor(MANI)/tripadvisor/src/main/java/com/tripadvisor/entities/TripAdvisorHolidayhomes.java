package com.tripadvisor.entities;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.tripadvisor.parent.TripAdvisorBase;

public class TripAdvisorHolidayhomes extends TripAdvisorBase {

	public TripAdvisorHolidayhomes(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//span[text() = '2']/parent::button")
	public WebElement guestsBtn;

	@FindBy(xpath = "//button[@title = 'increase']/preceding-sibling::div/span")
	public WebElement guestsDisplay;

	@FindBy(xpath = "//button[@title = 'increase']")
	public WebElement addBtn;

	@FindBy(xpath = "//span[text() = 'Apply']/parent::button")
	public WebElement applyBtn;

	@FindBy(xpath = "//span[text() = 'Enter dates']/parent::button")
	public WebElement enterDatesBtn;

	@FindBy(xpath = "//div[@role = 'grid'][1]/h2")
	public WebElement displayMonth1;

	@FindBy(xpath = "//div[@role = 'grid'][2]/h2")
	public WebElement displayMonth2;

	@FindBy(xpath = "//button[@aria-label = 'Next month']")
	public WebElement nextBtn;

	@FindBy(xpath = "//button[@aria-label = 'Tripadvisor Sort: Tripadvisor Sort']")
	public WebElement sortBtn;

	@FindBy(xpath = "//button[@aria-label = 'Tripadvisor Sort: Tripadvisor Sort']/following-sibling::div/ul/li[4]/span")
	public WebElement travellerRatingBtn;

	@FindBy(xpath = "//div[@id=':component_2-R3ikp9cl:']/div/div[2]/button")
	public WebElement showAll;

	@FindBy(id = "amenities.27_label")
	public WebElement liftCheckBox;

	@FindBy(xpath = "//span[text() = 'Apply']/parent::button")
	public WebElement applyAmenities;

	@FindBys(@FindBy(xpath = "//h2/a"))
	public List<WebElement> hotelNames;

	@FindBys(@FindBy(className = "MvXmI"))
	public List<WebElement> totalPrice;

	@FindBys(@FindBy(className = "iCUJC"))
	public List<WebElement> pricePerNight;

	@FindBy(xpath = "//span[text() = 'Cruises']/parent::a")
	public WebElement cruiseBtn;

	public void selectDates(ExtentTest logger) {

		scrollIntoView(enterDatesBtn);
		logger.info("Dates has been identified");
		enterDatesBtn.click();
		logger.pass("Dates button has been clicked");
		explicitWait(displayMonth1);

		Date date = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		Date checkInDate = calendar.getTime();
		calendar.add(Calendar.DAY_OF_YEAR, 5);
		Date checkOutDate = calendar.getTime();

		logger.info("Check in date has been identified : " + checkInDate.toString());
		checkInOut(checkInDate);
		logger.pass("Check in date has been selected");
		logger.info("Check out date has been identified : " + checkOutDate.toString());
		checkInOut(checkOutDate);
		logger.pass("Check out date has been selected");
		screenShot(logger, "checkinout");
	}

	public void checkInOut(Date date) {

		try {
			String checkInMonth = new SimpleDateFormat("MMMM").format(date);
			String checkInYear = new SimpleDateFormat("yyyy").format(date);
			String checkInDate = new SimpleDateFormat("d").format(date);
			String checkInMonthYear = checkInMonth + " " + checkInYear;
			String checkIn = checkInDate + " " + checkInMonthYear;

			while (true) {
				if (checkInMonthYear.equals(displayMonth1.getText().trim())
						|| checkInMonthYear.equals(displayMonth2.getText().trim())) {
					driver.findElement(By.xpath("//div[@aria-label = '" + checkIn + "' and @aria-disabled = 'false'] "))
							.click();
					break;
				}
				nextBtn.click();
				nextBtn.click();
			}
		} catch (Exception e) {
		}

	}

	public void addGuests(ExtentTest logger) {
		try {
			int count = Integer.parseInt(getDataFromProperties("count"));
			logger.info("Guests Button has been identified");
			guestsBtn.click();
			logger.info("Guests Button clicked");
			explicitWait(addBtn);
			String guestsCt = guestsDisplay.getText().trim();
			int guestsCount = Integer.parseInt(guestsCt);
			for (int i = guestsCount; i < count; i++) {
				addBtn.click();
			}
			screenShot(logger, "guests");
			applyBtn.click();
			logger.pass(count + "Guests has been added");
		} catch (Exception e) {
			logger.fail(e.getMessage());
		}
	}

	public void sortRating(ExtentTest logger) {
		try {
			logger.info("Sorting button has been identified");
			sortBtn.click();
			logger.info("Sorting button has been clicked");
			explicitWait(travellerRatingBtn);
			screenShot(logger, "sort");
			//travellerRatingBtn.click();
			logger.pass("Sorted based on traveler's ratings");

		} catch (Exception e) {
			logger.fail(e.getMessage());
		}
	}

	public void liftAmenities(ExtentTest logger) {
		try {
			showAll.click();
			scrollIntoView(liftCheckBox);
			logger.info("Lift/Amenities Checklist has been identified");
			liftCheckBox.click();
			logger.info("Lift/Amenities Checklist has been clicked");
			screenShot(logger, "filters");
			applyAmenities.click();
			logger.pass("Filters applied for lift/amenities");
		} catch (Exception e) {
			logger.fail(e.getMessage());
		}

	}

	public List<String> getHotleNames(ExtentTest logger) {
		List<String> hotelNameList = new ArrayList<String>();
		try {
			logger.info("Wait has been applied till all the hotels are visible");
			//explicitWaitClickable(hotelNames.get(0));
			Thread.sleep(5000);
			logger.info("List of hotels has been listed");
			for (int i = 0; i < 3; i++) {
				hotelNameList.add(hotelNames.get(i).getText().trim());
			}
			logger.pass("Retrieved all the hotel names from the search results");
			screenShot(logger, "hotels");
		} catch (Exception e) {
			logger.fail(e.getMessage());
		}
		return hotelNameList;

	}

	public List<String> getTotalPrice(ExtentTest logger) {
		List<String> totalPriceList = new ArrayList<String>();
		try {
			logger.info("Total Price has been listed");
			for(int i = 0 ; i < 3 ; i ++) {
				totalPriceList.add(totalPrice.get(i).getText().trim());
			}
			logger.pass("Retrieved Total Price for 5 nights");
		} catch (Exception e) {
			logger.fail(e.getMessage());
		}
		return totalPriceList;

	}

	public List<String> getPricePerNight(ExtentTest logger) {
		List<String> PricePerNightList = new ArrayList<String>();
		try {
			logger.info("Price per night has been listed");
			for (int i = 0; i < 3; i++) {
				PricePerNightList.add(pricePerNight.get(i).getText().trim());
			}
			logger.pass("Retrieved Price per night");
		} catch (Exception e) {
			logger.fail(e.getMessage());
		}
		return PricePerNightList;
	}

	public TripAdvisorCruises navigateCruise(ExtentTest logger) {
		scrollIntoView(cruiseBtn);
		logger.info("Cruise Button has been identified");
		cruiseBtn.click();
		logger.info("Cruise Button has been clicked");
		return PageFactory.initElements(driver, TripAdvisorCruises.class);
	}

}
