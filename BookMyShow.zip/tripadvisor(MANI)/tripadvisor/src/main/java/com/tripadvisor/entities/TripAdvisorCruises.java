package com.tripadvisor.entities;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.tripadvisor.parent.TripAdvisorBase;

public class TripAdvisorCruises extends TripAdvisorBase {

	public TripAdvisorCruises(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(id = "global-nav-cruises")
	public WebElement cruiseBtn;

	@FindBy(xpath = "//*[@id='component_1']/div/div[2]/div/div[1]/div/button")
	public WebElement cruiseLineBtn;

	@FindBy(xpath = "//span[text() = 'Marella Cruises (formerly Thomson Cruises)']")
	public WebElement marellaCruises;

	@FindBy(xpath = "//*[@id='component_1']/div/div[2]/div/div[2]/div/button")
	public WebElement cruiseShipBtn;

	@FindBy(xpath = "//span[text() = 'Marella Explorer 2']")
	public WebElement marellaExplorer2;

	@FindBy(xpath = "//button[text() = 'Search']")
	public WebElement searchBtn;

	String parentWindow;
	Set<String> windowhandles;
	String childWindow;

	public void selectCruiseLine(ExtentTest logger) {
		try {
			getTitle("Cruises - Cheap Cruise Holidays: 2023 Destinations & Ports - Tripadvisor", logger);
			scrollIntoView(cruiseBtn);
			logger.info("Cruise Line Button has been identified");
			cruiseLineBtn.click();
			logger.info("Cruise Line Button has been clicked");
			explicitWait(marellaCruises);
			logger.info("List of Cruise line is displayed");
			marellaCruises.click();
			logger.pass("Marella Cruises has been selected");
		} catch (Exception e) {
			logger.fail(e.getMessage());
		}
	}

	public void selectCruiseShip(ExtentTest logger) {
		try {
			explicitWaitClickable(cruiseShipBtn);
			logger.info("Cruise ship Button has been identified");
			cruiseShipBtn.click();
			logger.info("Cruise ship Button has been clicked");
			explicitWait(marellaExplorer2);
			logger.info("List of Cruise ships is displayed");
			marellaExplorer2.click();
			logger.pass("Marella Explorer 2 cruise has been selected");
		} catch (Exception e) {
			logger.fail(e.getMessage());
		}
	}

	public TripAdvisorShip searchAndSwitchWindow(ExtentTest logger) {
		try {
			explicitWait(marellaExplorer2);
			logger.info("Search button has been identified");
			explicitWaitClickable(searchBtn);
			parentWindow = driver.getWindowHandle();
			screenShot(logger, "cruises");
			searchBtn.click();
			logger.pass("Search button has been clicked");
			windowhandles = driver.getWindowHandles();
			
			for (String windowHandle : windowhandles) {
				if (!windowHandle.equals(parentWindow)) {
					driver.switchTo().window(windowHandle);
					logger.pass("Window has been switched to cruise ships Marella explorer 2");
				}
			}
			childWindow = driver.getWindowHandle();
			screenShot(logger, "marellaExplorer");
		} catch (Exception e) {
			logger.fail(e.getMessage());
		}
		return PageFactory.initElements(driver, TripAdvisorShip.class);
	}

}
