package com.tripadvisor.entities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.tripadvisor.parent.TripAdvisorBase;

public class TripAdvisorIndex extends TripAdvisorBase {

	public TripAdvisorIndex(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//input[@placeholder='Where to?']")
	public WebElement search;
	// *[@id='typeahead_results']/a[4]
	@FindBy(xpath = "//div[text() = 'Nairobi']/parent::div/parent::a")
	public WebElement result;

	public TripAdvisorExplore search(ExtentTest logger) {
		try {
			String destination = getDataFromProperties("explore");
				search.click();
				logger.info("Search Box has been identifed");
				search.sendKeys(destination);
				logger.pass(destination + " has been entered inside the texbox successfully");
				explicitWait(result);
				result.click();
				logger.info(destination + " link has been clicked");
				screenShot(logger, destination);
		} catch (Exception e) {
			logger.fail(e.getMessage());
		}
		return PageFactory.initElements(driver, TripAdvisorExplore.class);
	}

}
