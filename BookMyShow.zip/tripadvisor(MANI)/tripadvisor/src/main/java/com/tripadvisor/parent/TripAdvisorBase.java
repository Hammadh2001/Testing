package com.tripadvisor.parent;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;
import com.tripadvisor.entities.TripAdvisorIndex;
import com.tripadvisor.utilities.TripAdvisorScreenShot;

public class TripAdvisorBase {

	public WebDriver driver;
	//public TripAdvisorBase() {
	//}

	public TripAdvisorBase(WebDriver driver) {
		this.driver = driver;
	}

	public TripAdvisorIndex invokeBrowser(ExtentTest logger) {

		try{
			String browserName = getDataFromProperties("browser");
			String url = getDataFromProperties("url");
			if (browserName.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver",
						System.getProperty("user.dir") + "\\Driver\\chromedriver.exe");
				driver = new ChromeDriver();
			} else if (browserName.equalsIgnoreCase("edge")) {
				System.setProperty("webdriver.edge.driver",
						System.getProperty("user.dir") + "\\Driver\\msedgedriver.exe");
				driver = new EdgeDriver();
			}
			logger.info("Browser has been opened");
			driver.manage().window().maximize();
			logger.info("Window has been maximized");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
			logger.info("Url has been entered");
			driver.get(url);
			getTitle(
					"Tripadvisor: Over a billion reviews & contributions for Hotels, Attractions, Restaurants, and more",
					logger);
			screenShot(logger, "Homepage");

		} catch (Exception e) {
			logger.fail(e.getMessage());
		}
		return PageFactory.initElements(driver, TripAdvisorIndex.class);
	}

	public void explicitWait(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public void explicitWait(List<WebElement> elements) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfAllElements(elements));
	}

	public void explicitWaitClickable(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	

	public void screenShot(ExtentTest logger,String name) {
		try {
			String scrnshot = TripAdvisorScreenShot.takeScreenshot(driver,
					TripAdvisorScreenShot.generateScreenshotName(name));
			logger.info("Attaching screenshot : " + name);
			logger.addScreenCaptureFromPath(scrnshot);
		} catch (IOException e) {
			logger.fail(e.getMessage());
		}
	}

	public void scrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true)", element);
	}

	public void getTitle(String expected, ExtentTest logger) {
		SoftAssert Assert = new SoftAssert();
		if (driver.getTitle().equals(expected)) {
			logger.pass("Navigated to " + expected + " webpage");
			Assert.assertTrue(true);
		} else {
			logger.fail("Expected : " + expected + " landed on : " + driver.getTitle());
			Assert.assertTrue(false);
		}
		Assert.assertAll();
	
	}
	
	public String getDataFromProperties(String key) {
		String value = null;
		try (FileInputStream fis = new FileInputStream(
				System.getProperty("user.dir") + "\\src\\main\\resources\\config.properties")) {
			Properties prop = new Properties();
			prop.load(fis);
			value = prop.getProperty(key);
		}
		catch(Exception e) {
			
		}
		return value;
	}

	public void quitBrowser(ExtentTest logger) {
		try {
		logger.info("Browser is closing");
		driver.quit();
		}
		catch(Exception e) {
			logger.fail(e.getMessage());
		}
	}
	
	public void negativeScenario(ExtentTest logger , String name) {
		try {
		logger.info("Browser is closing");
		screenShot(logger, name);
		driver.quit();
		}
		catch(Exception e) {
			logger.fail(e.getMessage());
		}
	}

}
