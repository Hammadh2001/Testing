package Resources;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
public class Report {

    public static ExtentReports extentReports(){

        String path = System.getProperty("user.dir") + "//Report_Screenshot//ExtentReport.html";
        ExtentSparkReporter spark = new ExtentSparkReporter(path);
        spark.config().setReportName("Re_Learn_TestNG_OnlineShopping");
        spark.config().setDocumentTitle("Test Results");

        ExtentReports reports = new ExtentReports();
        reports.attachReporter(spark);

        return reports;


    }

}
