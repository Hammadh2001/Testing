package Resources;


import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.BeforeSuite;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

public class Resource {

    public WebDriver driver;

    @BeforeSuite
    public WebDriver initializeDriver() throws IOException {

        Properties prop =new Properties();
        FileInputStream input = new FileInputStream(System.getProperty("user.dir")+ "\\src\\main\\java\\Resources\\Data.properties");
        prop.load(input);

        String browser = prop.getProperty("browser");

//        WebDriverManager.chromedriver().setup();
//        driver = new ChromeDriver();

        if (browser.equalsIgnoreCase("edge")) {
            WebDriverManager.edgedriver().setup();
            driver = new EdgeDriver();
        }else {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
        }
        driver.manage().window().maximize();

        driver.get("https://www.saucedemo.com/");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(7));

        return driver;

    }

    public String screenShotCaptureMeth(String testCaseName , WebDriver driver) throws IOException  {
        
        TakesScreenshot ts = (TakesScreenshot)driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        File input = new File(System.getProperty("user.dir") + "//Report_Screenshot//" +testCaseName+".png");
        FileUtils.copyFile(source,input);
        
        return System.getProperty("user.dir") + "//Report_Screenshot//" + testCaseName + ".png";

    }

}
