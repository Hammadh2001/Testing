package Function;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class InfoPage {

    WebDriver driver;
    public InfoPage(WebDriver driver){

        this.driver = driver;
        PageFactory.initElements(driver , this);

    }

    @FindBy(xpath = "//Input[@id='first-name']")
    WebElement firstName;

    @FindBy(xpath = "//Input[@id='last-name']")
    WebElement lastName;

    @FindBy(xpath = "//Input[@id='postal-code']")
    WebElement postalCode;

    @FindBy(xpath = "//Input[@id='continue']")
    WebElement continueBtn;

    public void infos(){

        firstName.sendKeys("Hammadh");
        lastName.sendKeys("Ahmed");
        postalCode.sendKeys("123");

        continueBtn.click();

    }



}
