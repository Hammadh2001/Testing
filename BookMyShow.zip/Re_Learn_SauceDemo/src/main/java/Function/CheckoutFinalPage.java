package Function;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class CheckoutFinalPage {

    WebDriver driver;
    public CheckoutFinalPage(WebDriver driver){

        this.driver = driver;
        PageFactory.initElements(driver,this);

    }

    @FindBy(xpath = "//div[@class='inventory_item_name']")
    List<WebElement> finalProductsName;

    public List<String> checkoutPageProdNames(){

        List<String> finalProdNames = new ArrayList<>();

        for (WebElement element:finalProductsName){

            finalProdNames.add(element.getText());

        }

        return finalProdNames;

    }

    public void assertProductsNames(List<String> method1){

        List<String> method2 = checkoutPageProdNames();

        Assert.assertEquals(method1,method2 , "Wrong Products Selected");
        System.out.println("Product name matches");

    }






}
