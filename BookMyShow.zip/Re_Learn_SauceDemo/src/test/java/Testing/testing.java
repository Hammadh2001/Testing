package Testing;

import Function.*;
import Resources.Resource;
import Resources.TestNG_Listener;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.util.List;

@Listeners(TestNG_Listener.class)
public class testing extends Resource {

     static LoginPage l;
     static ShoppingPage s;
     static Cart c;
     static InfoPage i ;
     static CheckoutFinalPage cf;
     static List<String> shopProdNames;

    @Test(priority = 1)
    public void login() {

        l = new LoginPage(driver);
        l.login();

    }

    @Test(priority = 2)
    public void shopping(){

        s = new ShoppingPage(driver);
        //s.productsNames();
        shopProdNames = s.productsNames();

    }

    @Test(priority = 3)
    public void cart(){

        c = new Cart(driver);
        c.checkout();

    }

    @Test(priority = 4)
    public void info(){

        i = new InfoPage(driver);
        i.infos();

    }

    @Test(priority = 5)
    public void finale(){

        cf = new CheckoutFinalPage(driver);
        cf.checkoutPageProdNames();
        cf.assertProductsNames(shopProdNames);
        //System.out.println(shopProdNames.size());

    }









}
