package Files;


import io.restassured.path.json.JsonPath;

public class ComplexJson {

    public static void main(String[] args) {

        JsonPath j = new JsonPath(Payload.complexJson());

//1. Print No of courses returned by API
//
//2.Print Purchase Amount
//
//3. Print Title of the first course
//
//4. Print All course titles and their respective Prices
//
//5. Print no of copies sold by RPA Course
//
//6. Verify if Sum of all Course prices matches with Purchase Amount

        int numCourse = j.getInt("courses.size()");
        System.out.println(numCourse);

        int purchaseAmt = j.getInt("dashboard.purchaseAmount");
        System.out.println(purchaseAmt);

        String firstTitle = j.getString("courses[0].title");
        System.out.println(firstTitle);

        System.out.println("/////////////////");


        int finalPrice = 0;

        for (int i=0;i<numCourse;i++){

            String titles = j.getString("courses["+i+"].title");
            int prices = j.getInt("courses["+i+"].price");
            int totalCopies = j.getInt("courses["+i+"].copies");

            int pricesofCourse = prices*totalCopies;
            finalPrice +=pricesofCourse;


            if (titles.equals("RPA")){
                int rpaCopy = j.getInt("courses["+i+"].copies");
                System.out.println("the rpa copies are "+rpaCopy);
            }


            System.out.println("Course is : "+titles+" and the price is : "+prices);

        }



        System.out.println(finalPrice);

        if (purchaseAmt == finalPrice){
            System.out.println("Both prices are same");
        }


    }


}
