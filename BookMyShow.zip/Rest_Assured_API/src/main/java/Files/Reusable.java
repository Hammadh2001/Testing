package Files;

import io.restassured.path.json.JsonPath;

public class Reusable {

    public static JsonPath rawJson(String response){

        JsonPath js = new JsonPath(response);
        return js;



    }

}
