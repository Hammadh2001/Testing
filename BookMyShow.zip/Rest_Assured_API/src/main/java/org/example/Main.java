package org.example;

import Files.Payload;
import Files.Reusable;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import org.testng.Assert;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class Main {
    public static void main(String[] args) {

        //given - all input details (query param,header,body)
        //when - submit API (resource,type)
        //then - validate response
//post METHOD
        RestAssured.baseURI = "https://rahulshettyacademy.com";
        String response = given().log().all().queryParam("key","qaclick123").header("Content-Type","application/json")
                .body(Payload.addBodyFile())
                .when().post("maps/api/place/add/json")
                .then().assertThat().statusCode(200)
                .body("scope",equalTo("APP"))
                .header("Server" , "Apache/2.4.52 (Ubuntu)").extract().response().asString();

        System.out.println(response);

        JsonPath json = new JsonPath(response);

        String placeId = json.getString("place_id");
        System.out.println(placeId);
//PUT METHOD
        String newAddress = "Summer walk, Africa";

        given().log().all().queryParam("key","qaclick123").header("Content-Type","application/json")
                .body("{\n" +
                        "\"place_id\":\""+placeId+"\",\n" +
                        "\"address\":\""+newAddress+"\",\n" +
                        "\"key\":\"qaclick123\"\n" +
                        "}")
                .when().put("maps/api/place/update/json")
                .then().assertThat().log().all().statusCode(200)
                .body("msg" , equalTo("Address successfully updated"));

//GET
        String getResponse = given().log().all().queryParam("key","qaclick123").queryParam("place_id" , placeId)
                .when().get("maps/api/place/get/json")
                .then().assertThat().log().all().statusCode(200).extract().response().asString();

 //       JsonPath js1 = new JsonPath(getResponse);

       JsonPath js1 =  Reusable.rawJson(getResponse);

        String responseAddress = js1.get("address");

        System.out.println(responseAddress);

        Assert.assertEquals(newAddress , responseAddress);


        }
    }
