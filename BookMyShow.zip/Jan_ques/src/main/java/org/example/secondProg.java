package org.example;

public class secondProg {
    public static void main(String[] args) {

        String sent = "hello i am hammadh";

        int a=sent.length();
        System.out.println(a);
    //    String finale;

        for(int i=a-1;i>=0;i--){

            System.out.print(sent.charAt(i));

        }

    }

}
