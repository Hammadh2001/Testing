package org.example;

import java.util.Arrays;
import java.util.Collections;

public class NewMain {

    public static void main(String[] args) {

        Integer[] a = {22,31,04};

        String[] b = new String[a.length];

        for(int i=0;i<a.length;i++){
            b[i] = String.format("%02d",a[i]);

        }

 //       System.out.println(Arrays.toString(b));

        Arrays.sort(b, Collections.reverseOrder());
        System.out.println(Arrays.toString(b));

        StringBuilder builder = new StringBuilder();
        for (String z:b) {
            builder.append(z);
        }

        System.out.println(builder);



    }


}
