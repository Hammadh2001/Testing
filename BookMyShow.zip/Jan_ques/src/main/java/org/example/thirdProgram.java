package org.example;

public class thirdProgram {

    public static void main(String[] args) {

        String a = "Rise and Shine";

        String[] b = a.split(" ");




        for(int i =0;i<b.length;i++){

            StringBuilder builder = new StringBuilder(b[i]);
            builder.reverse();
            System.out.print(builder);
            System.out.print(" ");

            String ab= "hello";

            String bc = "hi my name is "+ab+" and i am from";

            System.out.println(bc);


        }



    }

}
