package org.example;

import java.util.Arrays;
import java.util.Collections;
import java.util.stream.IntStream;

//Arrays.sort(a, Collections.reverseOrder());
//
//        System.out.println(Arrays.toString(a));

public class Main {

    public static void main(String[] args) {
        int[] a = {24,31,04};

        int max = 0;
        int[] temp = new int[3];

        for(int i = 0 ; i<a.length ; i++){

            if(a[i]>max){
                max = a[i];
            }

        }
        System.out.println(max);

        for(int i = 0 ; i<a.length ; i++){

            if(max<a[i] && a[i]!=max) {

                max=a[i];

            }else if( a[i]!=max){
                temp[i] = a[i];

            }

        }

        System.out.println(Arrays.toString(temp));

        int[] finalArray = new int[a.length+1];

        System.out.println(finalArray.length);

        finalArray[0] = max;
        for (int i = 0 ; i < temp.length ; i++){

            finalArray[1+i] = temp[i];

        }
        System.out.println("/////////" + Arrays.toString(finalArray) + "//////////");
        System.out.println("-------------------------------------------");
        int index = 0;
        for(int i=0;i<finalArray.length;i++){

            if(finalArray[i]==0){
                index=i;
            }

        }
        System.out.println(index);

        int[] finalvalueArray = new int[finalArray.length-1];

        System.out.println(finalvalueArray.length);

        for (int i =0, j=0 ;i<finalArray.length;i++){
            if(i==index){
                continue;
            }else {
                finalvalueArray[j++]=finalArray[i];
            }
        }

        System.out.println(Arrays.toString(finalvalueArray));

        System.out.println("-------------------------------------------");

        StringBuilder finalOutput= new StringBuilder();
        for (int elements : finalvalueArray) {

            finalOutput.append(elements);
        }

        System.out.println(finalOutput);







    }
}