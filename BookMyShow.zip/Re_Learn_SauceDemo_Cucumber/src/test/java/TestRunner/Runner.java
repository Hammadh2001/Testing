package TestRunner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = {"src\\test\\java\\Feature\\SauceDemo.feature"},
        dryRun = false,
        glue = {"TestSauceDemo", "Resources"},
        snippets = CucumberOptions.SnippetType.CAMELCASE,
        monochrome = true,
        plugin = {"pretty", "html:report\\rep.html",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}

)
public class Runner extends AbstractTestNGCucumberTests {


}
