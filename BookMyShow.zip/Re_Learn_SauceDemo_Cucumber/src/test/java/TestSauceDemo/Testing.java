package TestSauceDemo;

import Functions.*;
import Resources.Hooks;
import Resources.Resource;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.List;

public class Testing extends Resource {

    static LoginPage l ;
    static ShoppingPage s;
    static Cart c;
    static InfoPage i;
    static CheckoutFinalPage cf;
    static List<String> shopProdNames;
    static Hooks hooks;

    public void driverInitialize() throws IOException {

        initializeDrover();

    }

    @Given("I check the title and I login using {string} and {string}")
    public void i_check_the_title_and_i_login_using_and(String string, String string2) throws IOException {

       driverInitialize();

        l = new LoginPage(driver);
        l.getTitle();
        l.login(string,string2);


     //   System.out.println("------" + string + "-----" + string2);

    }
    @Given("I select {string} and {string} in the cart page")
    public void i_select_and_in_the_cart_page(String string, String string2) {

        s = new ShoppingPage(driver);

        shopProdNames=s.productsNames(string , string2);

    }
    @Given("I click checkout on My Cart page")
    public void i_click_checkout_on_my_cart_page() {

        c = new Cart(driver);

        c.checkout();

    }
    @Then("I enter my {string} , {string} and {string} in Your Information page")
    public void i_enter_my_and_in_your_information_page(String string, String string2, String string3) {

        i = new InfoPage(driver);

        i.infos(string , string2 , string3);

    }
    @Then("Click finish on the Final page")
    public void click_finish_on_the_final_page() {

        cf = new CheckoutFinalPage(driver);

        cf.finalProductsNames();
        cf.assertProdNames(shopProdNames);

    }



}
