package Functions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;

public class LoginPage {

    WebDriver driver;
    public LoginPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "//input[@id='user-name']")
    WebElement userName;

    @FindBy(xpath = "//input[@id='password']")
    WebElement password;

    @FindBy(xpath = "//input[@id='login-button']")
    WebElement loginBtn;

    public void getTitle(){

        String websiteTitle = driver.getTitle();

        Assert.assertEquals(websiteTitle , "Swag Labs" , "The title doesnt match");

        System.out.println("The title matches");

    }

    public void login(String username , String pass){

        userName.sendKeys(username);
        password.sendKeys(pass);
        loginBtn.click();

//        int Integer = 24;
//        char String ='I';
//        System.out.println("\\\\\\\\\\\\\\\\\\\\");
//        System.out.print(Integer);
//        System.out.print(String);
//        System.out.println("\\\\\\\\\\\\\\\\\\\\");

    }



}
