package Functions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.List;

public class ShoppingPage {

    WebDriver driver;
    public ShoppingPage(WebDriver driver){

        this.driver = driver;
        PageFactory.initElements(driver,this);

    }

    @FindBy(xpath = "//div[@class='inventory_item_name ']")
    List<WebElement> products;

    @FindBy(xpath = "//Button[@class='btn btn_primary btn_small btn_inventory ']")
    List<WebElement> addToCart;

    @FindBy(xpath = "//a[@class='shopping_cart_link']")
    WebElement cartBtn;

    public List<String> productsNames(String prod1 , String prod2){

        int prodCartCount = 0;
        List<String> shopProdNames = new ArrayList<>();

        for(int i=0 ; i< products.size();i++){

            String prodName = products.get(i).getText();

            if (prodName.contains(prod1) || prodName.contains(prod2)){

                shopProdNames.add(prodName);
                addToCart.get(prodCartCount).click();

            }else {

                prodCartCount++;

            }

        }

        cartBtn.click();
        return  shopProdNames;

    }

}
