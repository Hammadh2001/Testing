package Functions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class CheckoutFinalPage {


    WebDriver driver;
    public CheckoutFinalPage(WebDriver driver){

        this.driver = driver;
        PageFactory.initElements(driver,this);

    }

    @FindBy(xpath = "//div[@class='inventory_item_name']")
    List<WebElement> finalProductsName;

    public List<String> finalProductsNames(){

        List<String> checkoutPagesName = new ArrayList<>();

        for (WebElement element:finalProductsName){

            checkoutPagesName.add(element.getText());
            
        }

        return checkoutPagesName;

    }

    public void assertProdNames(List<String> shoppingPageNames){

        Assert.assertEquals(finalProductsNames(),shoppingPageNames,"The products are different");

        System.out.println("-------------The Products Match-------------");

    }

}
