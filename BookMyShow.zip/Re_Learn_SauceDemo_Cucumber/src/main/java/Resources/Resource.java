package Resources;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Resource {

    public static WebDriver driver;

    public void initializeDrover() throws IOException {

        Properties prop = new Properties();
        FileInputStream input = new FileInputStream(System.getProperty("user.dir") + "\\src\\main\\java\\Resources\\data.properties");
        prop.load(input);

        String browser = prop.getProperty("browser");

        if (browser.equalsIgnoreCase("edge")) {
            WebDriverManager.edgedriver().setup();
            driver = new EdgeDriver();
        }else {

            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();

        }

            driver.manage().window().maximize();
            driver.get("https://www.saucedemo.com/");

    }



}
