package StepDefinition;

import io.cucumber.java.Before;

import java.io.IOException;

public class Hooks {

    @Before("@DeletePlace")
    public void beforeScenario() throws IOException {

        Testing testing = new Testing();
        if (Testing.placeID == null) {
            testing.add_place_payload_with_and("hamdh", "No.26, Chennai", "japan");
            testing.user_calls_with_http_request("addPlaceAPI", "POST");
            testing.verify_place_id_created_maps_to_using("hamdh", "getPlaceAPI");

        }
    }

}
