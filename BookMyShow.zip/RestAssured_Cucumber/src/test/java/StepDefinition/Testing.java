package StepDefinition;

import static org.junit.Assert.*;

import Resources.ApiResources;
import Resources.Test_Data;
import Resources.Utils;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import java.io.IOException;

import static io.restassured.RestAssured.given;

public class Testing extends Utils {

    ResponseSpecification response;
    RequestSpecification req;
    Response res;
    Test_Data data = new Test_Data();
    static String placeID;

    @Given("Add place payload with {string} {string} and {string}")
    public void add_place_payload_with_and(String name, String address, String language) throws IOException {

        req = given().spec(requestSpecification())
                .body(data.addData(name, address, language));

    }

    @When("user calls {string} with http {string} request")
    public void user_calls_with_http_request(String resource, String methodName) {

        ApiResources resourcesOfApi = ApiResources.valueOf(resource);
        System.out.println(resourcesOfApi.getResource());

        response = new ResponseSpecBuilder().expectStatusCode(200)
                .expectContentType(ContentType.JSON).build();

        if (methodName.equalsIgnoreCase("POST"))
            res = req.when().post(resourcesOfApi.getResource());
        else if (methodName.equalsIgnoreCase("GET"))
            res = req.when().get(resourcesOfApi.getResource());
        else if (methodName.equalsIgnoreCase("DELETE"))
            res = req.when().delete(resourcesOfApi.getResource());

//                .then().spec(response).extract().response();

        System.out.println(res);

    }

    @Then("the API call got success with status code {int}")
    public void the_api_call_got_success_with_status_code(Integer int1) {

        assertEquals(res.getStatusCode(), 200);

    }

    @Then("{string} in response body is {string}")
    public void in_response_body_is(String key, String value) {

//        String responsePath = res.asString();
//        JsonPath js = new JsonPath(responsePath);
//        assertEquals(js.get(key),value);

        assertEquals(jsonGetter(res, key), value);

    }

    @Then("verify place_Id created maps to {string} using {string}")
    public void verify_place_id_created_maps_to_using(String expectedName, String resource) throws IOException {

        placeID = jsonGetter(res, "place_id");
        req = given().spec(requestSpecification()).queryParam("place_id", placeID);

        user_calls_with_http_request(resource, "GET");

        String actualName = jsonGetter(res, "name");
        assertEquals(actualName, expectedName);

    }

    @Given("DeletePlace Payload")
    public void delete_place_payload() throws IOException {

        req = given().spec(requestSpecification())
                .body(data.deletePlace(placeID));

    }

}
