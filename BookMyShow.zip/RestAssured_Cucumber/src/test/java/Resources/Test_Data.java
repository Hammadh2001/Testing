package Resources;

import Pojo_Json_Serialize.AddJson;
import Pojo_Json_Serialize.LocationJson;

import java.util.ArrayList;
import java.util.List;

public class Test_Data {

    public AddJson addData(String name , String address , String language){

        AddJson add = new AddJson();

        add.setAccuracy(50);
        add.setName(name);
        add.setPhone_number("1234567890");
        add.setAddress(address);
        add.setWebsite("hamdh.com");
        add.setLanguage(language);

        List<String> typesList = new ArrayList<>();
        typesList.add("abc");
        typesList.add("efg");

        add.setTypes(typesList);

        LocationJson loc = new LocationJson();
        loc.setLat(-38.123456);
        loc.setLng(40.123456);

        add.setLocation(loc);

        return add;

    }

    public String deletePlace(String placeid){

        return "{\r\n    \"place_id\": \""+placeid+"\"\r\n}";

    }

}
