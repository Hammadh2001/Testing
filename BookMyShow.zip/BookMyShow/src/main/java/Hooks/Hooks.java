package Hooks;

import Fuctions.BaseUI;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Hooks extends BaseUI {



    @After
    public void afterScenario(Scenario scenario) {

//        driver = (WebDriver) result.getTestClass().getRealClass().getField("driver")
//                .get(result.getInstance());

        if (scenario.isFailed()) {
            captureScreenshot("failed_scenario",BaseUI.driver);
        }

    }
}

