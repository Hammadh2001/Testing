package Fuctions;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MainPage extends BaseUI {

    WebDriver driver;



    public MainPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//span[@class='biGQs _P ttuOS' and text()='Sign in']")
    WebElement signIn;

    @FindBy(xpath = "//iframe[@title='regcontroller']")
    WebElement iFrame;

    @FindBy(xpath = "//span[contains(text(),'Continue with email')]")
    WebElement continueToMail;

    @FindBy(xpath = "//input[@id='regSignIn.email']")
    WebElement mailBtn;

    @FindBy(xpath = "//input[@id='regSignIn.password']")
    WebElement passBtn;

    @FindBy(xpath = "//button[@class='ui_button primary coreRegPrimaryButton  regSubmitBtnEvent']")
    WebElement signInBtn;

    @FindBy(xpath = "(//input[@type='search'])[2] | //input[@type='search']")
    WebElement searchBtn;

    @FindBy(xpath = "//div[text()='Manali']/following-sibling::div/div[text()='Himachal Pradesh, India']")
    WebElement locXpath;

    public void signInClick() throws InterruptedException {

      Thread.sleep(3000);
      signIn.click();

    }

    public void switchToFrame(){


        driver.switchTo().frame(iFrame);

    }

    public void registerAct(String mail,String password) throws InterruptedException {

        continueToMail.click();

        mailBtn.sendKeys(mail);
        passBtn.sendKeys(password);

        Thread.sleep(3000);
        signInBtn.click();
        Thread.sleep(5000);

    }

    public void searchLocation(String loc) throws InterruptedException {

        Thread.sleep(3000);
        searchBtn.click();
        Thread.sleep(3000);
        searchBtn.sendKeys(loc);
        locXpath.click();


    }





}
