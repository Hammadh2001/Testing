package Fuctions;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class Hotel extends BaseUI {

    WebDriver driver;
    @FindBy(xpath = "//div[@data-automation='checkin']")
    WebElement date;
    @FindBy(xpath = "//div[@aria-label='20 November 2023']")
    WebElement checkIn;
    @FindBy(xpath = "//div[@aria-label='26 November 2023']")
    WebElement checkOut;
    @FindBy(xpath = "//button[@class='bqhCp u z sglCU wjpdQ']")
    WebElement people;
    @FindBy(xpath = "(//div[@class='kPQaf q'])[3]")
    WebElement people2;
    @FindBy(xpath = "//span[@class='biGQs _P ttuOS' and text()='Update']")
    WebElement update;
    @FindBy(xpath = "(//span[@class='PMWyE _W I j u R2 _S'])[6]")
    WebElement luxury;
    @FindBy(xpath = "//div[@class='qeraN _T qMONr iOIte iJfMg GuiKl rcibp FKwyn']")
    List<WebElement> hotelList;

    @FindBy(xpath = "//div[@class='MzOcE f u j']")
    List<WebElement> viewDeals;

    @FindBy(xpath = "(//div[@class='MzOcE f u j'])[1]")
    WebElement view11;

    public Hotel(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void dates() throws InterruptedException {

        Thread.sleep(3000);
        date.click();
        Thread.sleep(3000);
        checkIn.click();
        Thread.sleep(3000);
        checkOut.click();
        Thread.sleep(3000);
        people2.click();
        update.click();



    }

    public void filter() throws InterruptedException {

        luxury.click();
        Thread.sleep(6000);

    }

    public void hotelSelect() {

        view11.click();

    }

}