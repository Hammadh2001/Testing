package Fuctions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.Iterator;
import java.util.Set;

public class HotelSelection {

    WebDriver driver;

    @FindBy(xpath = "//a[@class='uitk-link uitk-link-align-right uitk-link-layout-default uitk-link-medium']")
    WebElement selectHotel;

    public HotelSelection(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void switchWindow(){

        Set<String> win = driver.getWindowHandles();
        Iterator<String> itr = win.iterator();
        itr.next();
        String newWindow = itr.next();
        driver.switchTo().window(newWindow);

    }


    public void hotelSelect() throws InterruptedException {

        Thread.sleep(5000);
        selectHotel.click();

    }

}
