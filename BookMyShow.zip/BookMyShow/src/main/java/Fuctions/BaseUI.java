package Fuctions;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

public class BaseUI {


    public static WebDriver driver;

    public void setupDriver() throws IOException {

        Properties prop = new Properties();
        FileInputStream input = new FileInputStream(
                System.getProperty("user.dir") + "\\src\\main\\java\\Resource\\Data.properties");
        prop.load(input);

        String browser = prop.getProperty("browser");

        if (browser.equalsIgnoreCase("chrome")) {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
        } else if (browser.equalsIgnoreCase("edge")) {
            WebDriverManager.edgedriver().setup();
            driver = new EdgeDriver();
        }

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

    }

    public void navigateToUrl(){
        driver.get("https://www.tripadvisor.in/");
    }

    public void verifyTitle() {
        String title=driver.getTitle();

        Assert.assertEquals(title,
                "Tripadvisor: Over a billion reviews & contributions for Hotels, Attractions, Restaurants, and more");
        System.out.println("The title matches");

    }

    public void captureScreenshot(String fileName , WebDriver driver) {
        try {
                TakesScreenshot ts = (TakesScreenshot) driver;
                File source = ts.getScreenshotAs(OutputType.FILE);
                File destination = new File(System.getProperty("user.dir") + "//cucumber-report//" + fileName + ".png");
                FileHandler.copy(source, destination);
                System.out.println("Screenshot saved to: " + destination.getAbsolutePath());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }





}
