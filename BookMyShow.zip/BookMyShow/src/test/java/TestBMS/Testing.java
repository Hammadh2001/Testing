package TestBMS;

import Fuctions.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

import java.io.IOException;


public class Testing extends BaseUI {

    static MainPage m;
    static LocPage l;
    static Hotel h;
    static HotelSelection hs;


    @Given("I Check the Title")
    public void iCheckTheTitle() throws IOException {
        setupDriver();
        navigateToUrl();
        verifyTitle();



    }

    @Given("I sign using {string} and {string}")
    public void iSignUsingAnd(String mail , String pass) throws InterruptedException {
        System.out.println("Hii");

        m = new MainPage(driver);
        m.signInClick();
        m.switchToFrame();
        m.registerAct(mail,pass);


    }


    @Given("I Check my Location {string} and click hotel")
    public void iCheckLocation(String loc) throws InterruptedException {
        System.out.println("Hii");

        m.searchLocation(loc);

        l = new LocPage(driver);
        l.hotelClick();

    }

    @Given("I Enter the requirements")
    public void iSelectACity() throws InterruptedException {
        System.out.println("Hii");

        h = new Hotel(driver);
        h.dates();
        h.filter();
        h.hotelSelect();

    }

    @Then("I select a hotel")
    public void iSelectAHotel() throws InterruptedException {
        System.out.println("Hii");

        hs=new HotelSelection(driver);
        hs.switchWindow();
        hs.hotelSelect();

    }



}
