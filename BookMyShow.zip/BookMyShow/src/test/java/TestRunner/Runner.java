package TestRunner;



import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(
        features = {"src\\test\\java\\Feature\\BMS.feature"},
        dryRun = false,
        glue = "TestBMS",
        snippets = CucumberOptions.SnippetType.CAMELCASE,
        monochrome = true,
        plugin = {"pretty", "html:cucumber-report\\rep.html"}

)

public class Runner extends AbstractTestNGCucumberTests {
}
