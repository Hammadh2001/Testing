# Improvement Notes — OrderServ_Tests_with_DeepEval

This is a critical look at the current test suite: what's fragile, what's actively broken right now, and what approach should change. Companion to [ARCHITECTURE.md](ARCHITECTURE.md), which explains what the code *does*; this file is about what's *wrong* with how it does it.

Severity key: 🔴 Broken/urgent · 🟠 Real risk · 🟡 Cleanup / best-practice

---

## 🔴 1. `login_pickup_session` fixture scope change breaks `test_login_pickup.py`

In `conftest.py`, `login_pickup_session` was changed from `scope="module"` to `scope="function"`, and now pins `service="pickup", store="952"` instead of letting the backend default.

`tests/test_login_pickup.py` was written assuming the **old** behavior — one shared conversation reused across the whole file:

```
test_promo_ask        → asks about promos (no state needed)
test_add_promoItem    → adds 3 Wicked Wings + applies 50% off promo
test_checkout         → expects appliedPromotion is not None   (depends on previous test)
test_place_order      → expects state == "paid"                (depends on previous test)
test_verify_order     → looks up the order placed above         (depends on previous test)
```

With `scope="function"`, pytest tears down and **rebuilds a brand-new login + empty conversation for every single test function**. `test_checkout` no longer sees the item/promo added in `test_add_promoItem` — it's talking to a fresh, empty cart — so its assertions will fail. Same for everything downstream.

**This means the file is currently either failing or (worse) silently passing on the wrong basis** — worth actually running it to confirm which.

**Fix — pick one:**
- Revert `login_pickup_session` to `scope="module"` (if the store/service pin was the only intended change, apply that without touching scope), **or**
- If function-scoped fixtures are wanted (e.g. for test isolation / parallel-safety, see §3), rewrite `test_login_pickup.py` so each test builds its own full sequence inside itself (like `test_multi_eval1.py` already does), instead of relying on state leaking between test functions.

Don't do neither — a fixture scope decision needs to match how the tests that consume it are actually written.

---

## 🟠 2. Cross-test state via global variables

`test_login_pickup.py`, `test_login_delivery.py`, and `test_order_history.py`'s sibling files use **module-level global variables** (`orderID`, `storeID`, `itemID`, `name`, `email`, `phone`, ...) to pass data from one test function to the next.

Why this is a problem:
- It **only works if pytest runs the tests in file order**, which is default behavior but not guaranteed (test selection flags, `pytest-randomly`, `-k`, parallel runners like `pytest-xdist` will all break it).
- It makes each test function silently **not a unit test** — you can't run `test_place_order` alone; it depends on invisible prior execution.
- It's exactly the kind of coupling that made the fixture-scope change in §1 catastrophic instead of just "a bit slower."

**Better approach:** build the full journey inside **one** test function (or one fixture that returns all the accumulated state), the way `test_multi_eval1.py` and `test_multi_turn_substitution_addon.py` already do it with a `messages = [...]` loop. This also makes the multi-turn eval files a better model to follow than the older `tests/` journey files.

---

## 🟠 3. Real backend, real account, no isolation, no cleanup

Every test — functional and eval — hits a real running OrderServ instance and, for logged-in flows, the **same fixed account** (`RETURNING_USER_EMAIL = "kfc_au_orders_001@gmail.com"`, or `_002` in the leftover script). None of the guest-flow tests clean up the conversations they create, and most order-placing tests never cancel the order afterward (only `test_login_delivery.py` cancels; `test_login_pickup.py` and `test_multi_eval1.py`/`test_multi_turn_substitution_addon.py` place real orders and leave them).

Consequences:
- The test account's order history keeps growing with test data forever — `test_order_history.py` even depends on a **specific hardcoded order number (`#1639`)** existing in that history, which is brittle: if that account's history is ever pruned, rotated, or the environment reset, that test breaks with no obvious cause.
- Running the suite concurrently (e.g. two people running it at once, or a CI matrix) against the same account/store will race — two conversations mutating the same account's promo/cart state at the same time is not safe with the current design.
- There's no `pytest` teardown (`yield` + cleanup in fixtures) anywhere — every fixture just returns state and never cleans up.

**Better approach:** where the backend allows it, cancel/delete what a test created in a fixture teardown (`yield conv_id; <cleanup>`), and stop hardcoding order numbers as pass/fail conditions — assert on *shape* (e.g. "history contains at least one order with today's items") rather than a specific ID that depends on execution history.

---

## 🟠 4. Massive duplication of the "build ground truth from tool output" logic

The exact same ~20-line block — iterate `promotions_list`, join `qualifying_items`, build a `coupon_code | title | description | is_applicable | ...` string — is copy-pasted near-verbatim across:
- `evals/eval_promotion_accuracy_v2.py`
- `evals/test_eval_promotion_accuracy.py`
- `evals/test_eval_promotion_accuracy_batch.py`

If the promotion data shape changes (a field gets renamed, a new field is added that should be checked), it now has to be fixed in three places, and it's easy to fix two and miss one.

**Better approach:** extract a single `build_promotion_ground_truth(promotions_list) -> str` helper into `helpers/` (or a new `evals/helpers.py`) and have all three files call it.

---

## 🟠 5. No shared "ask the bot and extract tool output" helper for evals

Every eval file re-implements the same pattern: send a message, pull `assistantText`, loop `toolContext` looking for a specific `toolName`, assert it was found. This is functionally identical logic duplicated 5+ times with copy-paste drift (e.g. some use `tool["toolName"]`, others `tool.get("toolName")` — inconsistent defensiveness against missing keys).

**Better approach:** add something like `helpers/agent.py::get_tool_output(response_json, tool_name)` and reuse it everywhere. This also creates one place to fix if the backend response shape changes.

---

## 🟡 6. Inconsistent, seemingly arbitrary thresholds

Pass thresholds for what is conceptually the same "promotion accuracy" check vary across files for no stated reason:
- `evals/metric/promotion_accuracy_metric.py` default: `0.7`
- `evals/test_eval_promotion_accuracy.py`: asserts `>= 0.6`
- `evals/test_eval_promotion_accuracy_batch.py`: `PASS_THRESHOLD = 0.7`
- `evals/test_eval_promotion_accuracy_variance.py` stability threshold: `0.15` std dev

Nothing documents *why* one test accepts 0.6 and another demands 0.7 for what's supposed to be the same rubric. This makes it impossible for a new team member to know whether a threshold is a deliberate calibration or a typo.

**Better approach:** centralize thresholds as named constants (e.g. in `config.py` or the metric module) with a one-line comment on why each differs, instead of magic numbers scattered per file.

---

## 🟡 7. Secrets and environment configuration

- `ANTHROPIC_API_KEY` is a live key hardcoded in `config.py` in plaintext (flagged already in `ARCHITECTURE.md` — repeating here because it's the single highest-impact fix available and it's still not done).
- `BASE_URL`, `TENANT_ID`, and `UAT_URL` are hardcoded across `config.py` and `helpers/orders.py` with no environment-switching mechanism (dev/UAT/prod). If this suite ever needs to run against a different environment, someone has to hand-edit source files.

**Better approach:** move all of these into environment variables (with `os.environ.get(...)`, defaulting to local values for convenience) or a `.env` file loaded via `python-dotenv`, excluded from version control via `.gitignore`. Rotate the currently-exposed Anthropic key regardless.

---

## 🟡 8. Unregistered pytest marker

`@pytest.mark.eval` is applied throughout `evals/` but there is no `pytest.ini`, `pyproject.toml`, or `setup.cfg` anywhere in the project registering it. Every eval run currently prints a `PytestUnknownMarkWarning`. Harmless today, but it also means `pytest --strict-markers` (a good practice to turn on) would fail the whole suite immediately.

**Better approach:** add a `pytest.ini`:
```ini
[pytest]
markers =
    eval: DeepEval-based LLM quality evaluation (slower, calls Claude as judge)
```

---

## 🟡 9. Draft / dead files left in the tree

- `evals/eval_promotion_accuracy.py` and `evals/eval_promotion_accuracy_v2.py` — standalone scripts, superseded by the pytest versions, not picked up by `pytest` at all (no `test_` prefix).
- `tests/test_login_promotion_pickup.py` — a manual debug script sitting in `tests/`, not a real pytest test, uses a different hardcoded test email than everything else.
- `evals/init__.py` — empty, misnamed (missing leading/trailing underscores to be `__init__.py`), does nothing.

**Better approach:** delete these, or if they're kept intentionally as reference/scratch material, move them to a clearly-named `scripts/` or `drafts/` folder outside `tests/`/`evals/` so pytest discovery and human readers aren't confused about what's actually part of the suite.

---

## 🟡 10. No CI / no reproducible dependency versions

- `requirements.txt` pins `requests`, `pytest`, `pytest-html`, `pytest-sugar` exactly, but leaves `deepeval`, `anthropic`, and `allure-pytest` **unpinned**. A `deepeval` upgrade could silently change scoring behavior or break the `AnthropicModel`/`GEval` API this project depends on, with no way to know which version was "known good."
- There's no CI workflow file (e.g. `.github/workflows/`) in this folder — presumably tests are only ever run manually. If that's intentional (e.g. CI lives elsewhere), fine, but worth confirming; if not, this suite has no safety net catching the kind of regression described in §1 automatically.

**Better approach:** pin `deepeval`, `anthropic`, and `allure-pytest` to specific versions once a known-good combination is confirmed, and consider wiring at least the `tests/` (non-LLM) suite into CI, since it doesn't require live Claude API calls to run and would catch things like the fixture-scope regression immediately.

---

## Summary — if you only fix three things

1. **Fix or redesign `test_login_pickup.py` around the new `login_pickup_session` scope** (§1) — this is the one actively broken thing right now.
2. **Rotate and externalize the Anthropic API key** (§7) — this is the one actual security exposure.
3. **Extract the duplicated ground-truth-building and tool-output-extraction logic** (§4, §5) — this is the one thing that will keep costing time on every future change to the promotion/tool response shape.
