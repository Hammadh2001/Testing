import requests
from config import BASE_URL

def chatbot_send_message(convID,text,session=None):
    if session is not None:
        response = session.post(f"{BASE_URL}/api/agent/chat/{convID}/turn", 
                                   json={
                                       "text": text
                                   })
    else:    
        response = requests.post(f"{BASE_URL}/api/agent/chat/{convID}/turn", 
                                    json={
                                        "text": text
                                    })
    return response

def create_conversation(service=None,store=None,session=None):
    body={}
    if service is not None:
        body["service"] = service
        body["store_id"] = store
    
    if session is not None:
        create_convo_response = session.post(f"{BASE_URL}/api/agent/chat", json=body)
    else:
        create_convo_response = requests.post(f"{BASE_URL}/api/agent/chat", json=body) 
      
    return create_convo_response

