import requests
from config import BASE_URL,STATIC_OTP

def login(session,username):

    login_respone = session.post(f"{BASE_URL}/api/auth/login",
                json={
                    "username": username
                })

    loginID=login_respone.json()["loginId"]

    otp_response = session.post(f"{BASE_URL}/api/auth/otp",
                json={
                    "loginId": loginID,
                    "otp": STATIC_OTP
                })

    assert otp_response.json()["ok"] == True
    
    return session