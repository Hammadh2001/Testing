import requests
import secrets

UAT_URL = "https://uat-kfc-apac-olo-api.cognizantorderservnxtgen.com"
LOCAL_URL = "http://localhost:8050"
TENANT_ID = "afd3813afa364270bfd33f0a8d77252d"

def get_order_details(session,orderID):

    token = session.cookies.get("kfc_session")
    headers = {
        "Content-Type": "application/json",
        "Authorization" : f"Bearer {token}",
        "x-tenant-id": TENANT_ID,
        "User-Agent": "PostmanRuntime/7.44.0",
        "x-correlation-session-id": secrets.token_hex(16),
        "x-correlation-request-id": secrets.token_hex(16),
        # "x-correlation-session-id": "lpg6od35748rjmf4jk440j3ndkddf84",
        # "x-correlation-request-id": "jfo94jkfr9rf440kfi9r44nfnf0032ngrf",
    }

    response = requests.get(f"{UAT_URL}/dev/v1/orders/{orderID}",headers=headers,verify=False,timeout=20)
    return response

def cancel_order(session,orderID):

    headers = {
        "User-Agent": "PostmanRuntime/7.44.0",
    }

    response = session.post(f"{LOCAL_URL}/api/orders/{orderID}/cancel",headers=headers,verify=False,timeout=20)
    return response
