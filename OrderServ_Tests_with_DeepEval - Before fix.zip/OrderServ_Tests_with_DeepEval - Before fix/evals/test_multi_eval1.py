import pytest
from deepeval.metrics import ConversationCompletenessMetric
from deepeval.models import AnthropicModel
from deepeval.test_case import Turn, ConversationalTestCase
import os

from config import ANTHROPIC_API_KEY
from helpers.agent import chatbot_send_message

os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY

@pytest.mark.eval
def test_conversation_completeness_order_flow(login_pickup_session):
    """
    Multi-turn eval: does the AI satisfy every user intent
    across a full order-placement conversation?
    """

    PASS_THRESHOLD = 0.7

    # STEP 1: Login (reusing existing fixture)
    session,convID = login_pickup_session

    # STEP 2: Add Turn and Messages
    turns = []

    messages = [
    "do you have any deals or promotions?",
    "add standalone 3 Wicked Wings and apply the 50% off deal",
    "yes go ahead and place the order, my name is Test User and phone is 0423451871",
    "Yes, place the order."
    ]

    # STEP 3: Create a loop to add the inputs and create a transcript list

    for message in messages:
    
        response = chatbot_send_message(convID,message,session=session)
        assert response.status_code == 200
        ai_msg = response.json()["assistantText"]

        turns.append(Turn(role="user", content=message))
        turns.append(Turn(role="assistant", content=ai_msg))

    # STEP 4: Build the ConversationalTestCase
    convo_test_case = ConversationalTestCase(
        turns=turns,
        scenario=(
            "An authenticated pickup customer wants to discover a promotion, "
            "add a qualifying item, apply the promotion, and place an order."
        ),
        expected_outcome=(
            "The qualifying item is added, the promotion remains applied, "
            "the required customer details are captured, and the order "
            "reaches the intended final state."
        )
    )

    # STEP 5: Judge + metric
    judge_model = AnthropicModel(model="claude-sonnet-4-6", timeout=180)
    metric = ConversationCompletenessMetric(threshold=PASS_THRESHOLD, model=judge_model)

    # STEP 6: Measure
    try:
        metric.measure(convo_test_case)
    except Exception as e:
        pytest.fail(
            f"Conversation completeness judge failed: {str(e)}"
        )

    # STEP 7: Log
    print(f"\n=== Conversation Completeness ===")
    for i, turn in enumerate(turns):
        print(f"{turn.role}: {turn.content}")
    print(f"\nScore: {metric.score}")
    print(f"Reason: {metric.reason}")

    # STEP 8: Assert
    assert metric.score >= PASS_THRESHOLD, f"Conversation completeness {metric.score} below {PASS_THRESHOLD}"