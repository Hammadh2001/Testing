import os
import pytest
import allure

from deepeval.metrics import AnswerRelevancyMetric
from deepeval.models import AnthropicModel
from deepeval.test_case import LLMTestCase

from config import ANTHROPIC_API_KEY
from helpers.agent import chatbot_send_message


os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY


@pytest.mark.eval
def test_eval_answer_relevancy(guest_pickup_session):

    """
    Evaluates whether the assistant's response is relevant
    to the user's question using DeepEval's AnswerRelevancyMetric.
    """

    # Fixture provides a guest-user conversation.
    convID = guest_pickup_session

    # User question used for answer relevancy evaluation.
    user_question = "Can I order for pickup at Dee Why?"

    # Send question to chatbot.
    response = chatbot_send_message(
        convID,
        user_question
    )

    assert response.status_code == 200

    # Extract assistant response.
    response_json = response.json()

    ai_response = response_json["assistantText"]

    # Create the judge used by DeepEval.
    judge_model = AnthropicModel(
        model="claude-sonnet-4-6",
        timeout=180
    )

    PASS_THRESHOLD = 0.7

    # Pre-built DeepEval metric that checks whether
    # the response actually answers the user's question.
    metric = AnswerRelevancyMetric(
        threshold=PASS_THRESHOLD,
        model=judge_model
    )

    # Assemble evaluation test case.
    test_case = LLMTestCase(
        input=user_question,
        actual_output=ai_response
    )

    # Execute evaluation while separating judge failures
    # from chatbot-quality failures.
    try:
        metric.measure(test_case)

    except Exception as e:
        pytest.fail(
            f"Judge evaluation failed: {str(e)}"
        )

    # Determine evaluation status for reporting.
    status = (
        "✅ PASS"
        if metric.score >= PASS_THRESHOLD
        else "❌ FAIL"
    )

    print(
        f"Answer Relevancy | "
        f"Score={metric.score:.3f} | "
        f"Status={status}"
    )

    # Lightweight console message for failures only.
    if metric.score < PASS_THRESHOLD:
        print(
            f"Answer Relevancy Failed | "
            f"Score={metric.score:.2f}"
        )

    # High-level summary attachment.
    evaluation_summary = (
        f"Question: {user_question}\n"
        f"Status: {status}\n"
        f"Pass Threshold: {PASS_THRESHOLD}\n"
        f"Score: {metric.score:.3f}\n"
        f"Reason: {metric.reason}"
    )

    allure.attach(
        evaluation_summary,
        name="Answer Relevancy Summary",
        attachment_type=allure.attachment_type.TEXT
    )

    # Detailed debugging attachment.
    evaluation_details = (
        f"Question:\n{user_question}\n\n"
        f"Status:\n{status}\n\n"
        f"Score:\n{metric.score:.3f}\n\n"
        f"Reason:\n{metric.reason}\n\n"
        f"Assistant Response:\n{ai_response}"
    )

    allure.attach(
        evaluation_details,
        name="Answer Relevancy Details",
        attachment_type=allure.attachment_type.TEXT
    )

    # Final validation.
    assert metric.score >= PASS_THRESHOLD, (
        f"Answer relevancy score "
        f"{metric.score:.3f} "
        f"below threshold {PASS_THRESHOLD}"
    )