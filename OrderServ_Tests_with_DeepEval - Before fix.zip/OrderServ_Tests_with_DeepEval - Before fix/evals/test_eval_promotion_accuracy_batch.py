import json
import os
import pytest
import statistics
from deepeval.metrics import GEval
from deepeval.models import AnthropicModel
from deepeval.test_case import LLMTestCase
from deepeval.test_case import LLMTestCaseParams
import requests
from config import ANTHROPIC_API_KEY, BASE_URL, PROMOTION_CACHE_FILE
from evals.metric.promotion_accuracy_metric import create_promotion_accuracy_metric
from helpers.agent import chatbot_send_message, create_conversation
import allure

cache_file = PROMOTION_CACHE_FILE
os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY

@pytest.mark.eval
def test_eval_promotion_accuracy():

    """
    Evaluates promotion accuracy across multiple user phrasings
    and validates that the assistant response matches the
    promotion data returned by the promotion tool.
    """

    # Different promotion-related question variants used to
    # measure prompt robustness rather than a single phrasing.
    test_questions = [
        "Do you have any promos?",
        "What deals are active?",
        "Any discounts today?",
        "Can you show me promotions?"
    ]

    # Stores question-level scores for batch statistics.
    batch_scores = []

    # Stores detailed evaluation results for reporting,
    # debugging and future analysis.
    batch_details = []

    # Create the judge used by DeepEval to evaluate responses.
    judge_model = AnthropicModel(
        model="claude-sonnet-4-6",
        timeout=180
    )

    # Minimum acceptable promotion accuracy score.
    PASS_THRESHOLD = 0.7

    # Shared promotion accuracy metric used across all evaluations.
    metric = create_promotion_accuracy_metric(judge_model)

    # Ensure the test starts in a guest-user state.
    logout_response = requests.post(f"{BASE_URL}/api/auth/logout")
    assert logout_response.status_code == 200

    auth_me_response = requests.get(f"{BASE_URL}/api/auth/me")
    assert auth_me_response.status_code == 200

    # Evaluate each phrasing independently using a fresh conversation.
    for question in test_questions:

        # Create a new conversation to avoid context contamination
        # between evaluation runs.
        create_convo_response = create_conversation()
        assert create_convo_response.status_code == 201

        convID = create_convo_response.json()["conversationId"]

        # Ask the promotion question and retrieve the assistant response.
        promo_response = chatbot_send_message(convID, question)
        assert promo_response.status_code == 200

        response_json = promo_response.json()

        assistant_text = response_json["assistantText"]

        tool_context = response_json.get("toolContext", [])

        # Extract promotion tool output used to build ground truth.
        tool_output = None

        for tool in tool_context:
            if tool.get("toolName") == "get_promotions":
                tool_output = tool.get("toolOutput")
                break

        # Promotion retrieval is mandatory for this evaluation.
        assert tool_output is not None, (
            f"get_promotions tool was not invoked for question: {question}"
        )

        # Validate the expected schema before building ground truth.
        assert "promotions" in tool_output, (
            f"promotions key missing in tool output: {tool_output}"
        )

        promotions_list = tool_output["promotions"]

        # Build expected output dynamically from live tool results.
        promotion_lines = []

        # Convert each promotion into a normalized text format for evaluation.
        for promotion in promotions_list:

            requirements = ", ".join(
                promotion["missing_requirements"]
            )

            item_names = []

            for item in promotion["qualifying_items"]:
                item_names.append(item["name"])

            qualifying_items_text = ", ".join(item_names)

            line = (
                promotion["coupon_code"]
                + " | "
                + promotion["title"]
                + " | "
                + promotion["description"]
                + " | "
                + str(promotion["is_applicable"])
                + " | "
                + requirements
                + " | "
                + qualifying_items_text
            )

            promotion_lines.append(line)

        # Final ground-truth payload used by DeepEval.
        promotion_text = "\n".join(promotion_lines)

        # Assemble the DeepEval test case.
        test_case = LLMTestCase(
            input=question,
            actual_output=assistant_text,
            expected_output=promotion_text
        )

        # Execute evaluation and distinguish judge failures
        # from chatbot-quality failures.
        try:
            metric.measure(test_case)

        except Exception as e:
            pytest.fail(
                f"Judge evaluation failed for '{question}': {str(e)}"
            )

        # Lightweight console output for failed questions.
        # Detailed debugging information is stored in Allure.
        if metric.score < PASS_THRESHOLD:
            print(
                f"Question: {question} | "
                f"Score: {metric.score:.2f}"
            )

        # Determine question-level evaluation status.
        status = (
            "✅ PASS"
            if metric.score >= PASS_THRESHOLD
            else "❌ FAIL"
        )

        # Store batch statistics data.
        batch_scores.append(metric.score)

        # Store detailed results for reporting and debugging.
        batch_details.append({
            "question": question,
            "status": status,
            "score": metric.score,
            "reason": metric.reason,
            "response": assistant_text,
            "ground_truth": promotion_text
        })

    # Verify all intended evaluations completed successfully.
    assert len(batch_scores) == len(test_questions), (
        f"Expected {len(test_questions)} evaluations "
        f"but got {len(batch_scores)}"
    )

    # Batch-level quality and consistency metrics.
    avg_score = statistics.mean(batch_scores)

    min_score = min(batch_scores)

    max_score = max(batch_scores)

    std_dev = (
        statistics.stdev(batch_scores)
        if len(batch_scores) > 1
        else 0
    )

    # High-level batch summary used for reporting and trend analysis.
    batch_summary = (
        f"Tests Run: {len(batch_scores)}\n"
        f"Scores: {batch_scores}\n"
        f"Pass Threshold: {PASS_THRESHOLD}\n"
        f"Average Score: {avg_score:.3f}\n"
        f"Min Score: {min_score:.3f}\n"
        f"Max Score: {max_score:.3f}\n"
        f"Std Dev: {std_dev:.3f}"
    )

    # Attach overall batch statistics to Allure.
    allure.attach(
        batch_summary,
        name="Batch Summary",
        attachment_type=allure.attachment_type.TEXT
    )

    # Build consolidated question-level evaluation summary.
    question_summary_lines = []

    for detail in batch_details:

        question_text = (
            f"Question: {detail['question']}\n"
            f"Status: {detail['status']}\n"
            f"Score: {detail['score']:.2f}\n"
            f"Reason:\n {detail['reason']}\n"
            f"{'-' * 70}\n"
        )

        question_summary_lines.append(question_text)

    question_summary = "\n".join(question_summary_lines)

    # Attach summary of all evaluated question variants.
    allure.attach(
        question_summary,
        name="Question Results Summary",
        attachment_type=allure.attachment_type.TEXT
    )

    # Create detailed drill-down artifacts for each question.
    for detail in batch_details:

        per_question_attachment = (
            f"Question: {detail['question']}\n\n"
            f"Score: {detail['score']:.2f}\n\n"
            f"Status: {detail['status']}\n\n"
            f"Reason:\n{detail['reason']}\n\n"
            f"Response:\n{detail['response']}\n\n"
            f"Ground Truth:\n{detail['ground_truth']}"
        )

        allure.attach(
            per_question_attachment,
            name=f"Questions - {detail['question']}",
            attachment_type=allure.attachment_type.TEXT
        )

    # Cache the highest-scoring response so it can be reused
    # by the judge variance/stability evaluation.
    best_detail = max(
        batch_details,
        key=lambda detail: detail["score"]
    )

    cached_response = {
        "question": best_detail["question"],
        "actual_output": best_detail["response"],
        "expected_output": best_detail["ground_truth"],
        "original_score": best_detail["score"]
    }

    # Persist the best response for future variance testing.
    with open(cache_file, "w") as f:
        json.dump(cached_response, f, indent=2)

    # Final batch assertion.
    # Every prompt variation must satisfy the minimum threshold.
    assert all(
    score >= PASS_THRESHOLD
    for score in batch_scores
    ), (
        f"Scores below threshold: {batch_scores}"
    )
