import os
import pytest
import allure

from deepeval.models import AnthropicModel
from deepeval.test_case import LLMTestCase

from config import ANTHROPIC_API_KEY
from evals.metric.promotion_accuracy_metric import (
    create_promotion_accuracy_metric,
)
from helpers.agent import chatbot_send_message


os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY


@pytest.mark.eval
def test_eval_promotion_accuracy(guest_pickup_session):

    """
    Evaluates promotion accuracy for a single promotion question
    and validates that the assistant response matches the
    promotion data returned by the promotion tool.
    """

    # Fixture provides a guest-user conversation.
    convID = guest_pickup_session

    # Single promotion question being evaluated.
    question = "do you have any deals or promotions?"

    # Ask the promotion question and retrieve the response.
    promo_response = chatbot_send_message(convID, question)

    assert promo_response.status_code == 200

    response_json = promo_response.json()

    assistant_text = response_json["assistantText"]

    tool_context = response_json.get("toolContext", [])

    # Extract promotion tool output used to generate ground truth.
    tool_output = None

    for tool in tool_context:
        if tool.get("toolName") == "get_promotions":
            tool_output = tool.get("toolOutput")
            break

    # Promotion retrieval is mandatory for this evaluation.
    assert tool_output is not None, (
        "get_promotions tool was not invoked"
    )

    # Validate expected schema before proceeding.
    assert "promotions" in tool_output, (
        f"promotions key missing in tool output: {tool_output}"
    )

    promotions_list = tool_output["promotions"]

    # Build expected output dynamically using live promotion data.
    promotion_lines = []

    for promotion in promotions_list:

        requirements = ", ".join(
            promotion["missing_requirements"]
        )

        item_names = []

        for item in promotion["qualifying_items"]:
            item_names.append(item["name"])

        qualifying_items_text = ", ".join(item_names)

        line = (
            promotion["coupon_code"]
            + " | "
            + promotion["title"]
            + " | "
            + promotion["description"]
            + " | "
            + str(promotion["is_applicable"])
            + " | "
            + requirements
            + " | "
            + qualifying_items_text
        )

        promotion_lines.append(line)

    # Final ground-truth payload used by DeepEval.
    promotion_text = "\n".join(promotion_lines)

    # Create the DeepEval judge.
    judge_model = AnthropicModel(
        model="claude-sonnet-4-6",
        timeout=180
    )

    PASS_THRESHOLD = 0.6

    # Shared promotion-accuracy metric.
    metric = create_promotion_accuracy_metric(
        judge_model
    )

    # Assemble DeepEval test case.
    test_case = LLMTestCase(
        input=question,
        actual_output=assistant_text,
        expected_output=promotion_text
    )

    # Execute evaluation while separating judge failures
    # from chatbot-quality failures.
    try:
        metric.measure(test_case)

    except Exception as e:
        pytest.fail(
            f"Judge evaluation failed: {str(e)}"
        )

    # Determine evaluation status.
    status = (
        "✅ PASS"
        if metric.score >= PASS_THRESHOLD
        else "❌ FAIL"
    )

    # Lightweight console notification for failures.
    if metric.score < PASS_THRESHOLD:
        print(
            f"Question: {question} | "
            f"Score: {metric.score:.2f}"
        )

    # High-level evaluation summary.
    evaluation_summary = (
        f"Question: {question}\n"
        f"Status: {status}\n"
        f"Pass Threshold: {PASS_THRESHOLD}\n"
        f"Score: {metric.score:.3f}\n"
        f"Reason: {metric.reason}"
    )

    # Executive-style summary attachment.
    allure.attach(
        evaluation_summary,
        name="Promotion Accuracy Summary",
        attachment_type=allure.attachment_type.TEXT
    )

    # Detailed debugging evidence.
    detailed_attachment = (
        f"Question:\n{question}\n\n"
        f"Status:\n{status}\n\n"
        f"Score:\n{metric.score:.3f}\n\n"
        f"Reason:\n{metric.reason}\n\n"
        f"Response:\n{assistant_text}\n\n"
        f"Ground Truth:\n{promotion_text}"
    )

    allure.attach(
        detailed_attachment,
        name="Promotion Accuracy Details",
        attachment_type=allure.attachment_type.TEXT
    )

    # Final validation.
    assert metric.score >= PASS_THRESHOLD, (
        f"Promotion accuracy score "
        f"{metric.score:.3f} "
        f"below threshold {PASS_THRESHOLD}"
    )