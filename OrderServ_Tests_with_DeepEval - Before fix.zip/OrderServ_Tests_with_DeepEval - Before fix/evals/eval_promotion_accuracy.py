import os
from config import BASE_URL, RETURNING_USER_EMAIL, ANTHROPIC_API_KEY
from evals.metric.promotion_accuracy_metric import create_promotion_accuracy_metric
from helpers.agent import chatbot_send_message, create_conversation
import requests
from deepeval.models import AnthropicModel
from deepeval.metrics import GEval
from deepeval.test_case import LLMTestCase
from deepeval.test_case import LLMTestCaseParams

# Set API key for DeepEval
os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY


def eval_promotion_accuracy():
    """
    Eval: When AI lists promotions, does it accurately represent tool data?
    
    Setup: Create a guest conversation and ask about promotions.
    Extract: The AI's response + the get_promotions toolContext
    Judge: Did AI accurately represent is_applicable status and qualifying items?
    """
    
    # Setup: Create guest session (logout + auth me + create conversation)
    session = requests.Session()
    
    logout_response = requests.post(f"{BASE_URL}/api/auth/logout")
    assert logout_response.status_code == 200
    
    auth_me_response = requests.get(f"{BASE_URL}/api/auth/me")
    assert auth_me_response.status_code == 200
    
    create_convo_response = create_conversation()
    assert create_convo_response.status_code == 201
    convID = create_convo_response.json()["conversationId"]
    
    # Ask about promotions
    promo_response = chatbot_send_message(convID, "do you have any deals or promotions?")
    
    assert promo_response.status_code == 200
    response_json = promo_response.json()
    assistant_text = response_json["assistantText"]
    tool_context = response_json.get("toolContext", [])
    
    # Extract tool output
    tool_output = None
    for tool in tool_context:
        if tool["toolName"] == "get_promotions":
            tool_output = tool["toolOutput"]
            break
    
    assert tool_output is not None, "No get_promotions tool call found in response"
    
    # Build ground truth from tool output
    promotions_list = tool_output.get("promotions", [])
    ground_truth = f"""
    Available promotions:
    {chr(10).join([f"- {p['title']} ({p.get('description', '')}): is_applicable={p['is_applicable']}, requires {p.get('qualifying_items', [])}, missing_requirements={p.get('missing_requirements', [])}" for p in promotions_list])}
    """
    
    # Create the eval metric
    judge_model = AnthropicModel(
        model="claude-sonnet-4-6",
        timeout=180
    )

    metric = create_promotion_accuracy_metric(judge_model)

#     metric = GEval(
#         name="Promotion Accuracy",
#         criteria="""
#         The AI should accurately communicate promotions to the customer. Specifically:
#         1. The AI should NOT claim a promotion is 'active' or 'currently applied' if is_applicable=false in the tool data
#         2. The AI should NOT invent promotions that don't exist in the tool data
#         3. The AI should NOT omit promotions that are actually applicable (is_applicable=true)
#         4. For qualifying items, mentioning at least ONE valid way to unlock a promo is sufficient — the AI does not need to list every alternative qualifying item
#         Mentioning unavailable promotions and explaining how to unlock them (e.g. "add X to unlock this deal") is GOOD, helpful behavior and should NOT be penalized as falsely claiming the promo is active.
#         """,
#         evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT, LLMTestCaseParams.EXPECTED_OUTPUT],
#         model=judge_model,
#         threshold=0.6
# )
    
    # Create test case
    test_case = LLMTestCase(
        input="What promotions are available?",
        actual_output=assistant_text,
        expected_output=ground_truth
    )
    
    print("\n--- ACTUAL AI RESPONSE ---")
    print(assistant_text)
    print("\n--- GROUND TRUTH (from toolOutput) ---")
    print(ground_truth)

    # Run the eval
    metric.measure(test_case)
    
    print(f"\n{'='*60}")
    print(f"EVAL: Promotion Accuracy")
    metric.measure(test_case)
    print(f"Score: {metric.score}")
    print(f"Reason: {metric.reason}")
    print(f"{'='*60}\n")
    
    return metric


if __name__ == "__main__":
    eval_promotion_accuracy()