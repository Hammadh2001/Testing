import pytest
from deepeval.metrics import ConversationCompletenessMetric, ToolUseMetric, ConversationalGEval
from deepeval.models import AnthropicModel
from deepeval.test_case import Turn, ConversationalTestCase, ToolCall
from deepeval.test_case import MultiTurnParams
import os

from config import ANTHROPIC_API_KEY
from helpers.agent import chatbot_send_message, create_conversation
import requests

os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY

@pytest.mark.eval
def test_multi_turn_substitution_addon_flow(login_pickup_session):
    """
    Multi-turn eval: substitution + addon discovery.
    Tests: ConversationCompletenessMetric, ToolUseMetric, ConversationalGEval.
    Real transcript with actual tool calls captured.
    """

    PASS_THRESHOLD = 0.7

     # STEP 1: Reuse login fixture
    session, convID = login_pickup_session

    turns = []
    messages = [
    "Can you suggest an alternative to Wicked Wings?",
    "Add 1 Piece of Chicken to my order.",
    "Add Liquid Gold Zinger® Box - Large to my order.",
    "yes go ahead and place the order, my name is Test User and phone is 0423451871",
    "Yes, place the order."
    ]

    # STEP 2: Create a loop to add the inputs and create a transcript list

    for message in messages:

        user_msg = message
        response = chatbot_send_message(convID, user_msg, session=session)
        assert response.status_code == 200
        
        ai_msg = response.json()["assistantText"]
        tool_context = response.json().get("toolContext", [])
        
        tool_calls = []
        for tool in tool_context:
            tool_calls.append(
                ToolCall(
                    name=tool.get("toolName"),
                    input_parameters=tool.get("toolInput", {})
                )
            )
        
        turns.append(Turn(role="user", content=user_msg))
        turns.append(Turn(role="assistant", content=ai_msg, tools_called=tool_calls))

    # Hard assertion: order must be placed
    last_assistant_turn = turns[-1]
    last_tool_names = [
        tc.name
        for tc in (last_assistant_turn.tools_called or [])
    ]

    assert "place_order" in last_tool_names, (
        "Final assistant response did not call place_order"
    )
            

    # STEP 3: Build ConversationalTestCase
    convo_test_case = ConversationalTestCase(
        turns=turns,
        scenario="A logged-in customer wants to find an alternative to a spicy item, then discover and add addons to their order.",
        expected_outcome=(
            "The AI suggests alternatives, adds items correctly, "
            "maintains accurate totals, collects customer details, "
            "provides checkout information, and places the order "
            "successfully after explicit customer confirmation."
        )
    ) 

    # STEP 4: Create judge
    judge_model = AnthropicModel(model="claude-sonnet-4-6", timeout=180)

    # STEP 5: Create metrics

    completeness_metric = ConversationCompletenessMetric(threshold=PASS_THRESHOLD, model=judge_model)
    
    tool_use_metric = ToolUseMetric(
        threshold=PASS_THRESHOLD,
        model=judge_model,
        available_tools=[
            ToolCall(name="set_store", description="Switch to a different store or service mode. Resets the cart."),
            ToolCall(name="set_dietary_profile", description="Record the customer's dietary requirements and allergens."),
            ToolCall(name="search_menu", description="Search the catalog for items."),
            ToolCall(name="add_to_cart", description="Add an item to the cart; refuses dietary violations."),
            ToolCall(name="remove_from_cart", description="Remove an item line from the cart."),
            ToolCall(name="remove_promotion", description="Remove the currently-applied promotion while keeping items."),
            ToolCall(name="set_item_quantity", description="Change the quantity of an item already in the cart."),
            ToolCall(name="suggest_addons", description="Propose up to 2 complementary add-on items."),
            ToolCall(name="find_substitutes", description="Find up to 2 substitutes fitting the dietary profile."),
            ToolCall(name="view_cart", description="View current cart contents."),
            ToolCall(name="set_customer", description="Set customer details (name, phone, etc.)."),
            ToolCall(name="present_checkout_summary", description="Show checkout summary."),
            ToolCall(name="place_order", description="Place the order."),
            ToolCall(name="get_promotions", description="Get available promotions."),
            ToolCall(name="apply_promotion", description="Apply a promotion/coupon to the cart."),
            ToolCall(name="get_order_history", description="Retrieve past order history."),
            ToolCall(name="list_nearby_stores", description="List nearby stores for pickup or delivery."),
        ]
    )

    tool_driven_geval = ConversationalGEval(
        name="Tool-Driven Behavior",
        evaluation_steps=[
            "Check whether the assistant invoked tools proactively (e.g., find_substitutes when asked for alternatives) rather than just answering verbally.",
            "Check whether the assistant invoked the appropriate tools for each user intent (search for alternatives, add_to_cart for additions, suggest_addons for recommendations).",
            "Check whether tool invocations actually influenced the assistant's responses (e.g., the suggestions offered came from the tool output, not generic knowledge).",
            "Check whether the assistant maintained consistency between tool-provided data and what it told the user (e.g., exact prices, item names, cart totals)."
        ],
        evaluation_params=[MultiTurnParams.ROLE,MultiTurnParams.CONTENT, MultiTurnParams.TOOLS_CALLED],
        model=judge_model,
        threshold=PASS_THRESHOLD
    )

    # STEP 6: Measure all three metrics
    try:
        completeness_metric.measure(convo_test_case)
    except Exception as e:
        pytest.fail(f"Completeness metric failed: {str(e)}")
    
    try:
        tool_use_metric.measure(convo_test_case)
    except Exception as e:
        pytest.fail(f"Tool use metric failed: {str(e)}")
    
    try:
        tool_driven_geval.measure(convo_test_case)
    except Exception as e:
        pytest.fail(f"Tool-driven GEval failed: {str(e)}")
    
    # STEP 7: Log all results
    print(f"\n=== Multi-Turn Substitution + Addon Flow ===")
    print(f"\nTranscript:")
    for i, turn in enumerate(turns):
        print(f"{turn.role}: {turn.content}")
        if turn.tools_called:
            print(f"  [Tools: {[tc.name for tc in turn.tools_called]}]")
    
    print(f"\n=== Conversation Completeness ===")
    print(f"Score: {completeness_metric.score}")
    print(f"Reason: {completeness_metric.reason}")
    
    print(f"\n=== Tool Use ===")
    print(f"Score: {tool_use_metric.score}")
    print(f"Reason: {tool_use_metric.reason}")
    
    print(f"\n=== Tool-Driven Behavior (Custom GEval) ===")
    print(f"Score: {tool_driven_geval.score}")
    print(f"Reason: {tool_driven_geval.reason}")

    # STEP 8: Asserts
    assert completeness_metric.score >= PASS_THRESHOLD, f"Completeness {completeness_metric.score} below {PASS_THRESHOLD}"
    assert tool_use_metric.score >= PASS_THRESHOLD, f"Tool use {tool_use_metric.score} below {PASS_THRESHOLD}"
    assert tool_driven_geval.score >= PASS_THRESHOLD, f"Tool-driven behavior {tool_driven_geval.score} below {PASS_THRESHOLD}"