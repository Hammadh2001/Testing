import json
import os

import allure
from deepeval.metrics import HallucinationMetric
from deepeval.models import AnthropicModel
from deepeval.test_case import LLMTestCase
import pytest
from config import ANTHROPIC_API_KEY
from helpers.agent import chatbot_send_message

os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY

@pytest.mark.eval
def test_eval_hallucination(guest_pickup_session):

    """
    Evaluates whether the assistant introduces information
    that is not supported by the available context.
    """

    # Fixture provides a guest-user conversation.
    convID = guest_pickup_session

    # User question used for hallucination evaluation.

  #  user_question = "Can I order for pickup at Dee Why?"
    user_question = (
        "What deals are available and do any of them come with free delivery?"
    )

    # Send question to chatbot.
    response = chatbot_send_message(
        convID,
        user_question
    )

    assert response.status_code == 200

    # Extract assistant response.
    response_json = response.json()

    ai_response = response_json["assistantText"]
    tool_context = response_json.get("toolContext",[])
    context = [
        json.dumps(
            tool_context,
            indent=2,
            ensure_ascii=False
        )
    ]

    assert tool_context,(
        "No tool context available for hallucination evaluation."
    )

    # Create the judge used by DeepEval.
    judge_model = AnthropicModel(
        model="claude-sonnet-4-6",
        timeout=180
    )

    HALLUCINATION_THRESHOLD = 0.7

    # Pre-built DeepEval metric that checks whether
    # the assistant invents information not supported by context.

    metric = HallucinationMetric(
        threshold=HALLUCINATION_THRESHOLD,
        model=judge_model
    )

    # Assemble evaluation test case.
    test_case = LLMTestCase(
        input=user_question,
        actual_output=ai_response,
        context=context
    )

    # Execute evaluation while separating judge failures
    # from chatbot-quality failures.
    try:
        metric.measure(test_case)

    except Exception as e:
        pytest.fail(
            f"Judge evaluation failed: {str(e)}"
        )

    # Determine evaluation status for reporting.
    status = (
        "✅ PASS"
        if metric.success
        else "❌ FAIL"
    )

    print(
        f"Hallucination | "
        f"Question='{user_question}' | "
        f"Score={metric.score:.3f} "
        f"(lower is better) | "
        f"Status={status}"
    )

    # Lightweight console message for failures only.
    if not metric.success:
        print(
            f"Hallucination Failed | "
            f"Score={metric.score:.2f}"
        )

    # High-level summary attachment.
    evaluation_summary = (
        f"Question: {user_question}\n"
        f"Status: {status}\n"
        f"Pass Threshold: {HALLUCINATION_THRESHOLD}\n"
        f"Score: {metric.score:.3f}\n"
        f"Reason: {metric.reason}"
    )

    allure.attach(
        evaluation_summary,
        name="Hallucination Summary",
        attachment_type=allure.attachment_type.TEXT
    )

    # Detailed debugging attachment.
    evaluation_details = (
        f"Question:\n{user_question}\n\n"
        f"Status:\n{status}\n\n"
        f"Score:\n{metric.score:.3f}\n\n"
        f"Reason:\n{metric.reason}\n\n"
        f"Assistant Response:\n{ai_response}\n\n"
        f"Evaluation Context:\n{context[0]}"
    )

    allure.attach(
        evaluation_details,
        name="Hallucination Details",
        attachment_type=allure.attachment_type.TEXT
    )

    # Final validation.
    assert metric.success, (
        f"Hallucination detected. "
        f"Score: {metric.score:.3f}"
    )