# OrderServ_Tests_with_DeepEval — Architecture Guide

This document explains the full structure of this test automation project: what every folder and file does, how the pieces connect, and how to run things. It is written for someone who has never opened this folder before.

---

## 1. What this project is

This is a **Python test-automation suite** for the **OrderServ** chatbot/ordering API (a KFC ordering assistant, referred to as "the agent" or "the bot"). It has two kinds of checks:

1. **Functional API tests** (`tests/` folder) — normal `pytest` tests that hit real HTTP endpoints (login, chat, orders, promotions) and assert on status codes and JSON fields, the same way you'd test any REST API.
2. **AI response quality evaluations** (`evals/` folder) — uses the **DeepEval** framework to have another LLM (Claude, via the Anthropic API) act as a "judge" that scores whether the chatbot's natural-language replies are accurate, relevant, and not hallucinating (e.g., "did the bot correctly describe the promotions instead of making something up?").

Both kinds of tests talk to the **same running OrderServ backend**, expected to be available at `http://localhost:8050` (a local instance of the OrderServ service must be running for these tests to work).

---

## 2. Top-level folder structure

```
OrderServ_Tests_with_DeepEval/
├── config.py              # Central configuration: URLs, test credentials, API keys
├── conftest.py            # Shared pytest fixtures (session/login/conversation setup)
├── requirements.txt       # Python package dependencies
├── data/                  # Cached test data used between eval runs
│   └── cached_promotion_response.json
├── helpers/                # Reusable functions that wrap API calls
│   ├── agent.py            # Chatbot conversation API calls
│   ├── auth.py              # Login / OTP API calls
│   └── orders.py            # Order lookup / cancel API calls (hits UAT + local API)
├── evals/                  # DeepEval-based AI quality evaluations
│   ├── metric/
│   │   └── promotion_accuracy_metric.py   # Custom scoring rubric (GEval) for promotions
│   ├── eval_promotion_accuracy.py         # Standalone script version (not a pytest test)
│   ├── eval_promotion_accuracy_v2.py      # Standalone script, cleaner ground-truth builder
│   ├── test_eval_answer_relevancy.py      # Pytest: is the bot's answer relevant to the question?
│   ├── test_eval_promotion_accuracy.py    # Pytest: single-question promotion accuracy check
│   ├── test_eval_promotion_accuracy_batch.py    # Pytest: runs 4 promo questions, averages scores, caches best one
│   ├── test_eval_promotion_accuracy_variance.py # Pytest: re-scores the cached response 5x to check judge consistency
│   ├── test_eval_faithfulness.py          # Pytest: is the AI's reply grounded in its own tool output? (DeepEval FaithfulnessMetric)
│   ├── test_eval_hallucination.py         # Pytest: does the AI invent info not present in context? (DeepEval HallucinationMetric)
│   ├── test_multi_eval1.py                # Pytest: multi-turn order flow, scored with ConversationCompletenessMetric
│   └── test_multi_turn_substitution_addon.py # Pytest: multi-turn substitution/addon flow, scored with 3 metrics incl. tool-call correctness
├── tests/                  # Plain functional/API pytest tests
│   ├── test_auth_negative.py       # Login/OTP failure-path tests
│   ├── test_guest_pickup.py        # Guest user, pickup order, full order flow
│   ├── test_guest_delivery.py      # Guest user, delivery order (partial flow, some tests commented out)
│   ├── test_login_pickup.py        # Logged-in user, pickup, full order + verify via UAT order API
│   ├── test_login_delivery.py      # Logged-in user, delivery, full order + cancel/refund flow
│   ├── test_login_promotion_pickup.py  # Standalone script (not pytest) — manual login smoke test
│   ├── test_order_history.py       # Order history lookup, for both logged-in and guest users
│   └── test_promo_negative.py      # Negative promotion tests (invalid apply, duplicate apply)
├── venv/                   # Local Python virtual environment (not part of the source, ignore)
├── .deepeval/              # DeepEval's own cache/telemetry folder (auto-generated, ignore)
├── .pytest_cache/          # Pytest's own cache folder (auto-generated, ignore)
├── allure-results/         # Raw Allure result files (JSON), generated when tests run with allure-pytest (auto-generated, ignore)
└── __pycache__/            # Compiled Python bytecode caches (auto-generated, ignore)
```

Folders you can safely ignore when reading the codebase: `venv/`, `.deepeval/`, `.pytest_cache/`, and any `__pycache__/` folder (these are generated automatically by Python/pytest/deepeval and contain no hand-written logic).

---

## 3. Core configuration files

### `config.py`
The single source of truth for constants used everywhere else in the project:

| Variable | Purpose |
|---|---|
| `BASE_URL` | `http://localhost:8050` — the local OrderServ API all tests hit |
| `RETURNING_USER_EMAIL` | A pre-registered test account email used for "logged in" test scenarios |
| `STATIC_OTP` | `"1277"` — a fixed one-time-password that the local/test environment accepts for any login, so tests don't need to read a real OTP from email/SMS |
| `PROMOTION_CACHE_FILE` | Path to `data/cached_promotion_response.json`, used by the promotion batch/variance evals |
| `ANTHROPIC_API_KEY` | The Claude API key used by DeepEval to run its LLM-judge evaluations |

> ⚠️ **Security note:** `ANTHROPIC_API_KEY` is currently hardcoded in plaintext in `config.py`. This means anyone with access to this folder (or a future git commit of it) has the live API key. This should be moved to an environment variable or a `.env` file that is excluded from version control, and the exposed key should be rotated (revoked and replaced) as a precaution.

Every other file that needs the base URL, test user, OTP, or API key imports it from here — this is why you'll see `from config import BASE_URL` at the top of almost every file.

### `conftest.py`
Pytest automatically loads this file and makes everything in it available to any test file in the project without needing an import. It defines four **fixtures** — reusable setup blocks that prepare a "conversation session" before a test runs:

| Fixture | What it sets up |
|---|---|
| `guest_pickup_session` | Logs out any existing session, confirms not authenticated, starts a new **guest** chatbot conversation for **pickup** (default service). Returns the `conversationId`. |
| `guest_delivery_session` | Same as above but explicitly requests the **delivery** service. |
| `login_pickup_session` | Logs in as `RETURNING_USER_EMAIL` (via `helpers/auth.py`), then starts a chatbot conversation at `service="pickup"`, `store="952"` using that authenticated `requests.Session`. Returns `(session, conversationId)`. **`scope="function"`** — see warning below. |
| `login_delivery_session` | Same idea as `login_pickup_session` but for delivery, at `store="7777"`. Returns `(session, conversationId)`. `scope="module"`. |

`guest_pickup_session`, `guest_delivery_session`, and `login_delivery_session` are `scope="module"`, meaning the setup runs **once per test file**, and every test function within that file reuses the same conversation/session. This is why tests in those files are written to run in a specific order, building on each other's state (add item → apply promo → checkout → place order).

> ⚠️ **`login_pickup_session` was changed to `scope="function"`.** Under function scope, pytest tears down and **recreates a brand-new login + conversation for every single test function**, instead of sharing one conversation across a file. This silently breaks any test file that assumes the cart/promo/checkout state built up by an earlier test in the same file is still there for a later test — see [`tests/test_login_pickup.py`](#tests-login_pickup-broken-by-fixture-scope-change) below and §9.

Any test function that takes one of these fixture names as a parameter (e.g., `def test_foo(guest_pickup_session):`) automatically gets that setup run first by pytest.

### `requirements.txt`
Python packages needed to run everything:
- `requests` — HTTP client used for all API calls
- `pytest`, `pytest-html`, `pytest-sugar` — test runner + nicer console/HTML output
- `deepeval` — the LLM-evaluation framework used in `evals/`
- `anthropic` — Anthropic's SDK (used by `deepeval` under the hood to call Claude as the judge model)
- `allure-pytest` — plugin for generating Allure-style HTML test reports

Install with:
```bash
pip install -r requirements.txt
```

---

## 4. `helpers/` — shared API wrapper functions

These are small functions that wrap raw HTTP calls so that test files don't repeat boilerplate. Every test file imports from here instead of calling `requests` directly for these specific operations.

### `helpers/auth.py`
```python
login(session, username)
```
Performs the two-step login flow used by this app:
1. `POST /api/auth/login` with a username/email → returns a `loginId`.
2. `POST /api/auth/otp` with that `loginId` and the fixed `STATIC_OTP` ("1277") → completes login.
Asserts the OTP call succeeded, then returns the same `requests.Session` object (now carrying the auth cookie) so the caller can keep making authenticated calls with it.

### `helpers/agent.py`
The two core functions for talking to the chatbot:
```python
create_conversation(service=None, store=None, session=None)
```
`POST /api/agent/chat` — starts a new chat conversation. If `service`/`store` are given, it requests that service type (e.g. "delivery") at that store; otherwise the backend defaults (pickup). If a `session` (logged-in) is passed, the conversation is tied to that authenticated user; otherwise it's a guest conversation.

```python
chatbot_send_message(convID, text, session=None)
```
`POST /api/agent/chat/{convID}/turn` — sends a user message (like `"add 3 wicked wings"`) into an existing conversation and returns the bot's response, which includes:
- `assistantText` — the bot's natural-language reply
- `snapshot` — the full current state of the conversation (cart, applied promotion, customer info, order state, etc.)
- `toolContext` — a log of any backend "tools" the AI invoked to answer (e.g. `get_promotions`), including their raw output — this is what the `evals/` tests use as ground truth to check the AI didn't hallucinate.

### `helpers/orders.py`
Used only in the **login** order-flow tests (`test_login_pickup.py`, `test_login_delivery.py`) to verify an order after it's placed, and to cancel it:
```python
get_order_details(session, orderID)
```
Calls the **UAT environment** directly (`UAT_URL`, a different host than the local `BASE_URL`) at `GET /dev/v1/orders/{orderID}`, using the session's auth cookie as a Bearer token plus a hardcoded `TENANT_ID` and randomly generated correlation IDs. This is a cross-checking call against the "real" backend order record, independent of the local chat API, to confirm the order was actually created correctly downstream.

```python
cancel_order(session, orderID)
```
Calls the **local** API (`LOCAL_URL`) at `POST /api/orders/{orderID}/cancel` to cancel/refund an order that was just placed, so tests can also verify the refund flow.

---

## 5. `tests/` — functional API tests (plain pytest)

These test the actual ordering behavior end-to-end against the running backend. Most files represent one **user journey**, and tests within a file usually depend on state built up by earlier tests in the same file (they share a session/conversation via the module-scoped fixture).

| File | Journey it tests |
|---|---|
| `test_auth_negative.py` | Login/OTP failure paths: wrong OTP, unregistered email, expired login ID, unauthenticated `/auth/me`. No fixtures needed — each test is self-contained. |
| `test_guest_pickup.py` | Full guest pickup journey: ask about promos → add item + apply 50% off promo → checkout → force checkout → place order. Validates discount math (`subTotal - discountCents == totalCents`). |
| `test_guest_delivery.py` | Guest delivery journey: ask about promos → try to add a promo item. The checkout/place-order steps exist but are **commented out** (not currently run) — likely still in progress or blocked by a known issue. |
| `test_login_pickup.py` <a name="tests-login_pickup-broken-by-fixture-scope-change"></a> | Logged-in pickup journey: add promo item → checkout → place order → **verify the order in the UAT backend** via `get_order_details`. **Currently broken** by the `login_pickup_session` scope change (see §6.1/§9): each test function now starts a fresh, empty conversation, so `test_checkout` and `test_place_order` no longer see the item/promo added by the previous test and will fail their assertions (`appliedPromotion is not None`, `state == "paid"`, etc.). |
| `test_login_delivery.py` | Logged-in delivery journey — the most complete file: add item → ask promos → add promo item → checkout → **place order twice** (`test_try_place_order` then `test_place_order` — looks like it double-submits to check idempotency/state) → verify order → **cancel order** → verify the order shows `refund-initiated` status. Uses module-level globals (`orderID`, `storeID`, etc.) to pass data between test functions in order. |
| `test_login_promotion_pickup.py` | **Not a pytest test** — a standalone script (no `test_` functions, no asserts framed as pytest) that just performs a login and prints the `/auth/me` response. Looks like a manual debugging/smoke-test script left in the folder, not part of the automated suite. |
| `test_order_history.py` | Order history feature: logged-in user can see history and look up a specific order by number; history filtering by "last 12 months" returns at least as many results as default; **guest** users are blocked and told to sign in. Each test independently calls `login_pickup_session`, so the `scope="function"` change doesn't break this file the way it breaks `test_login_pickup.py` — but it does mean a fresh login + conversation is created for every test here too (slower, and depends on order `#1639` already existing in the test account's history on the backend). |
| `test_promo_negative.py` | Negative/edge cases for promotions: applying a promo with no qualifying item in the cart should NOT apply it (even when "forced"); applying the same promo twice should not double the discount. |

**Important quirk:** because most fixtures are `scope="module"` and tests reuse global variables, **tests within a file generally must run in the order they're defined** (pytest does this by default) — e.g. in `test_login_delivery.py`, `test_place_order` depends on `test_checkout` having already set `storeID`/`itemID`. Running a single test from the middle of one of these files in isolation will likely fail.

---

## 6. `evals/` — AI response quality evaluations (DeepEval)

This is a different category of testing: instead of checking "did the API return the right status code," these check "did the **AI's natural language response** correctly and safely represent the underlying data, without making things up?" This matters for a chatbot because the AI decides what to say in freeform text, and could technically say something inaccurate even if the backend data is correct.

### How DeepEval fits in
[DeepEval](https://github.com/confident-ai/deepeval) is a library for testing LLM outputs. The pattern used throughout `evals/`:
1. Send a real message to the chatbot (via `helpers/agent.py`).
2. Grab the bot's text reply (`assistantText`) AND the raw tool data it used to generate that reply (`toolContext`).
3. Build an `expected_output` ("ground truth") string directly from the raw tool data — this is what the AI *should* have said.
4. Hand both to a **judge LLM** (Claude, via `AnthropicModel`) using a `GEval` metric with custom scoring instructions.
5. The judge returns a `score` (0–1) and a `reason` explaining it; the test asserts the score meets a threshold.

All eval files set `os.environ["ANTHROPIC_API_KEY"] = ANTHROPIC_API_KEY` at import time, since DeepEval's `AnthropicModel` reads the key from the environment rather than accepting it as a plain argument.

### `evals/metric/promotion_accuracy_metric.py`
Defines the **reusable scoring rubric** shared by every promotion-accuracy eval:
```python
create_promotion_accuracy_metric(judge_model)
```
Returns a `GEval` metric named `"Promotion Accuracy"` with a threshold of `0.7`, and four explicit evaluation steps for the judge to follow:
1. Flag the AI if it claims a promo is *already applied* when it isn't (but don't penalize normal "here's what's on offer" language).
2. Flag the AI if it invents a promotion that doesn't exist in the real data.
3. Flag the AI if it omits a promotion that IS actually applicable.
4. Require the AI to mention at least one valid way to qualify for a promo (not necessarily all options).

Because this function is imported by five different files, changing the rubric here changes it everywhere consistently.

### `evals/eval_promotion_accuracy.py` and `evals/eval_promotion_accuracy_v2.py`
These are **standalone scripts**, not pytest tests (no `test_` prefix on the function, though they can still be run directly: `if __name__ == "__main__":`). Both do the same core thing — ask the bot about promotions and score its accuracy — but `v2` is a cleaner rewrite:
- `v1` builds the ground truth as a descriptive paragraph and includes commented-out old `GEval` criteria (kept for reference/history).
- `v2` builds the ground truth as compact `|`-separated lines (`coupon_code | title | description | is_applicable | requirements | qualifying_items`) and drops the extra assertions from v1.

These appear to be **exploratory/draft versions** used while developing the final pytest versions below — they are not run automatically by `pytest` (since pytest only auto-discovers files/functions starting with `test_`).

### `evals/test_eval_answer_relevancy.py`
A pytest test using DeepEval's **built-in** `AnswerRelevancyMetric` (no custom rubric needed) to check that when a guest asks *"Can I order for pickup at Dee Why?"*, the bot's answer is actually relevant to that question. Uses the `guest_pickup_session` fixture from `conftest.py`. Threshold: `0.7`.

### `evals/test_eval_promotion_accuracy.py`
The pytest version of the promotion-accuracy check for a **single** question ("do you have any deals or promotions?"), using the `guest_pickup_session` fixture and the shared `create_promotion_accuracy_metric`. Threshold: `0.6`.

### `evals/test_eval_promotion_accuracy_batch.py`
A more thorough version: asks **four different phrasings** of the promotions question ("Do you have any promos?", "What deals are active?", etc.) using fresh guest conversations each time (does NOT use the fixture — sets up guest state manually), scores each one, and:
- Asserts every individual score is above threshold (`0.7`).
- Prints a statistical summary (average/min/max/standard deviation across the 4 questions).
- **Writes the best-scoring result to `data/cached_promotion_response.json`** — this cache is what the next file (variance test) reads.

### `evals/test_eval_promotion_accuracy_variance.py`
Doesn't call the chatbot at all. Instead, it **reloads the cached response** written by the batch test above and re-runs the *same* judge evaluation on it **5 times in a row**. The point isn't to test the chatbot — it's to test **how consistent the judge LLM itself is** when scoring the exact same input repeatedly. It computes the standard deviation across the 5 runs and fails if it's `>= 0.15` (i.e., if the judge is too "flaky" to be trusted). This is a meta-test of the evaluation framework's own reliability.

> **Dependency order:** `test_eval_promotion_accuracy_variance.py` will fail with "Cache file not found" if `test_eval_promotion_accuracy_batch.py` has never been run, since it depends on `data/cached_promotion_response.json` existing.

### `evals/init__.py`
An empty file. Note it's named `init__.py`, **not** `__init__.py` — so it does **not** function as a Python package initializer (that's likely a typo/leftover from when the folder was set up, and Python treats `evals/` as a namespace package regardless due to how modern Python/pytest handles imports).

### `data/cached_promotion_response.json`
The cache file described above — contains the best-scoring question/answer/ground-truth/score from the last run of the batch eval. Consumed only by the variance test.

### `evals/test_eval_faithfulness.py`
Pytest test using DeepEval's built-in **`FaithfulnessMetric`**. Sends "What deals are available?" via the `guest_pickup_session` fixture, then checks whether the AI's reply stays grounded in its own `toolContext` (passed to DeepEval as `retrieval_context`) rather than drifting from what the tools actually returned. Threshold `0.7`. Uses `allure.attach(...)` to attach a summary and full transcript to the Allure report (this is what populates `allure-results/`).

### `evals/test_eval_hallucination.py`
Pytest test using DeepEval's built-in **`HallucinationMetric`**. Asks "What deals are available and do any of them come with free delivery?" and checks whether the AI states anything **not supported** by the tool context (passed as `context`, not `retrieval_context` — Hallucination and Faithfulness metrics use different DeepEval field names for a similar idea). Note: for this metric, **lower score is better** (it measures contradiction/unsupported-claim rate), and `metric.success` — not a raw score comparison — is what should be asserted on; the code here does exactly that. Also attaches results to Allure.

### `evals/test_multi_eval1.py`
The first **multi-turn** conversational eval — instead of judging a single question/answer pair, it drives a whole 4-message order-placing conversation (ask promos → add item + apply promo → checkout → place order) through `login_pickup_session`, records every turn as a DeepEval `Turn`, and wraps them in a `ConversationalTestCase`. Scored with **`ConversationCompletenessMetric`**: did the AI satisfy every user intent across the whole conversation, not just the last message? Threshold `0.7`.

### `evals/test_multi_turn_substitution_addon.py`
The most advanced eval in the project. Drives a 5-message conversation (ask for a substitute → add two items → checkout → place order) through `login_pickup_session`, and — unlike `test_multi_eval1.py` — also captures the **tool calls** the AI made at each turn (`toolContext` → `ToolCall` objects attached to each `Turn`). It then asserts three things:
1. A hard `assert` that the final turn actually called the `place_order` tool (not just that the AI *said* it placed the order).
2. **`ToolUseMetric`** — did the AI call the right tools (e.g. `find_substitutes`, `add_to_cart`) for each user intent, given a full list of the 17 tools the real chatbot exposes?
3. A custom **`ConversationalGEval`** ("Tool-Driven Behavior") — did tool output actually influence what the AI said, and did the AI stay consistent with tool data (prices, names, totals)?

This file is also the best single reference for the full list of tools the OrderServ chatbot backend exposes (see the `available_tools=[...]` list inside it) — useful context for anyone extending the other tests.

---

## 7. How everything connects (data flow)

```
config.py  ──────────────┐  (URLs, credentials, API key)
                          ▼
helpers/auth.py  ─── login() ───┐
helpers/agent.py ─── create_conversation(), chatbot_send_message() ───┐
helpers/orders.py ─── get_order_details(), cancel_order() ───┐        │
                          │                                  │        │
                          ▼                                  ▼        ▼
conftest.py  (fixtures combine the helpers into ready-made sessions)
                          │
          ┌───────────────┴───────────────┐
          ▼                               ▼
   tests/*.py                      evals/test_*.py
   (assert on API JSON              (assert on AI-judged
    status/fields directly)          quality scores via
                                      evals/metric/*.py + DeepEval
                                      + Anthropic Claude judge)
                                            │
                                            ▼
                              data/cached_promotion_response.json
                              (written by batch eval, read by variance eval)
```

---

## 8. How to run the tests

From inside this folder, with the virtual environment activated and dependencies installed:

```bash
# Run everything
pytest

# Run only functional API tests
pytest tests/

# Run only AI-quality evals
pytest evals/ -m eval

# Run a single file
pytest tests/test_guest_pickup.py

# Generate an HTML report
pytest --html=report.html --self-contained-html

# Generate Allure results, then view the Allure report
pytest --alluredir=allure-results
allure serve allure-results
```

**Prerequisite:** the OrderServ backend must already be running locally and reachable at `http://localhost:8050` (as set in `config.py`), since none of these tests mock the API — they all make real HTTP calls.

**Note on test order:** because several files rely on module-scoped fixtures and shared state between test functions (see §5), avoid running individual test functions out of order/in isolation within `test_login_pickup.py`, `test_login_delivery.py`, `test_guest_pickup.py`, or `test_guest_delivery.py` — run the whole file.

---

## 9. Known issues / things to flag to the team

- **`config.py` hardcodes a live Anthropic API key in plaintext.** Still present. Should be moved to an environment variable / `.env` file excluded from git, and the exposed key rotated.
- **`login_pickup_session` fixture scope change (`module` → `function`) breaks `tests/test_login_pickup.py`.** That file's tests rely on sharing one cart/conversation across `test_promo_ask` → `test_add_promoItem` → `test_checkout` → `test_place_order` → `test_verify_order`. With `scope="function"`, each test now gets a brand-new empty conversation, so later tests will fail (e.g. `test_checkout` expects `appliedPromotion is not None`, but nothing was ever added to *its own* fresh cart). Either revert this fixture to `scope="module"`, or rewrite `test_login_pickup.py` so each test is self-contained. See a full write-up in `IMPROVEMENTS.md`.
- **`tests/test_login_promotion_pickup.py`** is a leftover manual/debug script, not an actual pytest test (no `test_` function). Consider deleting it or moving it out of `tests/`.
- **`evals/init__.py`** is misnamed (should be `__init__.py`) — currently inert either way.
- **`evals/eval_promotion_accuracy.py` and `eval_promotion_accuracy_v2.py`** are draft/manual scripts superseded by the pytest versions — likely safe to remove.
- Several checkout/place-order steps in `tests/test_guest_delivery.py` are commented out — this journey is incomplete compared to its `test_guest_pickup.py` counterpart.
- **`@pytest.mark.eval` is used throughout `evals/` but is never registered** (no `pytest.ini`/`pyproject.toml`/`setup.cfg` exists anywhere in the project) — every eval test run prints a `PytestUnknownMarkWarning`.

For a deeper structural/process critique (not just individual bugs), see **[IMPROVEMENTS.md](IMPROVEMENTS.md)**.
