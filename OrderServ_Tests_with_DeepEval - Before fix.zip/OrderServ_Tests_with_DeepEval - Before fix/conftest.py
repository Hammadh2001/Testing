import pytest
import requests
from helpers.auth import login
from helpers.agent import create_conversation
from config import BASE_URL,RETURNING_USER_EMAIL


@pytest.fixture(scope="module")
def guest_pickup_session():

    logout_response = requests.post(f"{BASE_URL}/api/auth/logout")
    assert logout_response.status_code == 200

    auth_me_response = requests.get(f"{BASE_URL}/api/auth/me")
    assert auth_me_response.status_code == 200
    assert auth_me_response.json()["authenticated"] == False

    create_convo_response = create_conversation()
    assert create_convo_response.status_code == 201
    assert create_convo_response.json()["conversationId"] is not None
    assert create_convo_response.json()["state"] == "gathering"
    convID = create_convo_response.json()["conversationId"]

    return convID

@pytest.fixture(scope="module")
def guest_delivery_session():

    logout_response = requests.post(f"{BASE_URL}/api/auth/logout")
    assert logout_response.status_code == 200

    auth_me_response = requests.get(f"{BASE_URL}/api/auth/me")
    assert auth_me_response.status_code == 200
    assert auth_me_response.json()["authenticated"] == False

    create_convo_response = create_conversation("delivery")
    assert create_convo_response.status_code == 201
    assert create_convo_response.json()["conversationId"] is not None
    assert create_convo_response.json()["state"] == "gathering"
    convID = create_convo_response.json()["conversationId"]

    return convID

@pytest.fixture(scope="function")
def login_pickup_session():

    session = requests.session()
    login_session = login(session,RETURNING_USER_EMAIL)
    #create_convo_response = create_conversation(session=login_session)
    create_convo_response = create_conversation(service="pickup",store="952",session=login_session)
    assert create_convo_response.status_code == 201
    assert create_convo_response.json()["conversationId"] is not None
    assert create_convo_response.json()["state"] == "gathering"
    assert create_convo_response.json()["customer"]["name"] is not None
    assert create_convo_response.json()["customer"]["email"] is not None

    convID = create_convo_response.json()["conversationId"]
    return login_session,convID

@pytest.fixture(scope="module")
def login_delivery_session():

    session = requests.session()
    login_session = login(session,RETURNING_USER_EMAIL)
    create_convo_response = create_conversation(service="delivery",store="7777",session=login_session)
    assert create_convo_response.status_code == 201
    assert create_convo_response.json()["conversationId"] is not None
    assert create_convo_response.json()["state"] == "gathering"
    assert create_convo_response.json()["service"] == "delivery"
    assert create_convo_response.json()["customer"]["name"] is not None
    assert create_convo_response.json()["customer"]["email"] is not None

    convID = create_convo_response.json()["conversationId"]
    return login_session,convID
