import pytest
from helpers.agent import chatbot_send_message

def test_promo_ask(guest_delivery_session):
    convID = guest_delivery_session
    promo_ask_response = chatbot_send_message(convID,"do you have any deals or promotions?")

    promo_ask_snapshot = promo_ask_response.json()["snapshot"]
    assert promo_ask_response.status_code == 200
    assert promo_ask_response.json()["assistantText"] is not None
    assert promo_ask_snapshot["state"] == "gathering"
    assert promo_ask_snapshot["appliedPromotion"] is None

    print(promo_ask_response.status_code)
    print(promo_ask_response.json()["assistantText"])

def test_add_promoItem(guest_delivery_session):
    convID = guest_delivery_session
    add_promoItem_response = chatbot_send_message(convID,"add a double chocolate mousse and apply the free delivery promo to it")

    add_promo_snapshot = add_promoItem_response.json()["snapshot"]

    lineItems = add_promo_snapshot["cart"]["lines"]
    wickedItem = None
    for items in lineItems:
        if "mousse" in items["name"].lower():
            wickedItem = items

    assert add_promoItem_response.status_code == 200
    assert add_promo_snapshot["appliedPromotion"] is None
    assert wickedItem is not None

# def test_checkout(guest_delivery_session):
#     convID = guest_delivery_session
#     checkout_response = chatbot_send_message(convID,"yes go ahead and place the order, my name is Test User and phone is 0423451871")

#     checkout_snapshot = checkout_response.json()["snapshot"]
#     assert checkout_response.status_code == 200
#     assert checkout_snapshot["state"] == "gathering"
#     assert checkout_snapshot["appliedPromotion"] is not None

# def test_force_checkout(guest_delivery_session):
#     convID = guest_delivery_session
#     force_checkout_response = chatbot_send_message(convID,"just go ahead and place it anyway with the promo, name is Test User phone 0423451871")

#     force_checkout_snapshot = force_checkout_response.json()["snapshot"]
#     assert force_checkout_response.status_code == 200
#     assert force_checkout_snapshot["state"] == "confirming"
#     assert force_checkout_snapshot["appliedPromotion"] is not None

#     print("Step 5 State:", force_checkout_snapshot["state"])

# def test_place_order(guest_delivery_session):
#     convID = guest_delivery_session
#     place_order_response = chatbot_send_message(convID,"Yes, place the order.")

#     place_order_snapshot = place_order_response.json()["snapshot"]
#     assert place_order_response.status_code == 200
#     assert place_order_snapshot["state"] != "paid"
#     assert place_order_snapshot["orderId"] is None
#     assert place_order_snapshot["appliedPromotion"] is not None

#     print("Step 6 State:", place_order_snapshot["state"])
#     print("Step 6 orderId:", place_order_snapshot["orderId"])

