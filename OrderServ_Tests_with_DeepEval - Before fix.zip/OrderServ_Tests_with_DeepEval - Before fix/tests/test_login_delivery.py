from helpers.orders import get_order_details,cancel_order
from helpers.agent import chatbot_send_message

orderID = None
storeID = None
service = None
itemID = []
name = None
email = None
phone = None
reference_number = None
total_cents_placed = None

def test_add_item(login_delivery_session):
    session,convID = login_delivery_session
    add_item_response = chatbot_send_message(convID,"add any one Zinger burger for delivery",session=session)

    promo_ask_snapshot = add_item_response.json()["snapshot"]
    assert add_item_response.status_code == 200
    assert add_item_response.json()["assistantText"] is not None
    assert promo_ask_snapshot["state"] == "gathering"
    assert promo_ask_snapshot["appliedPromotion"] is None
    assert convID == promo_ask_snapshot["conversationId"]
    print(add_item_response.json())

    lineItems = promo_ask_snapshot["cart"]["lines"]

    assert len(lineItems) == 1

    item = lineItems[0]

    assert "zinger" in item["name"].lower(),(
        f"Expected to contain name 'Zinger' but got '{item['name']}'"
    )
    assert item["qty"] == 1, (
        f"Expected quantity 1, got {item['qty']}"
    )
    
def test_promo_ask(login_delivery_session):
    session,convID = login_delivery_session
    promo_ask_response = chatbot_send_message(convID,"do you have any deals or promotions?",session=session)

    promo_ask_snapshot = promo_ask_response.json()["snapshot"]
    assert promo_ask_response.status_code == 200
    assert promo_ask_response.json()["assistantText"] is not None
    assert promo_ask_snapshot["state"] == "gathering"
    assert promo_ask_snapshot["appliedPromotion"] is None
    assert convID == promo_ask_snapshot["conversationId"]

    print(promo_ask_response.status_code)
    print(promo_ask_response.json()["assistantText"])

def test_add_promoItem(login_delivery_session):

    global itemID
    session,convID = login_delivery_session
    add_promoItem_response = chatbot_send_message(convID,"add 3 wicked wings and apply the 50% off deal",session=session)

    add_promo_snapshot = add_promoItem_response.json()["snapshot"]

    # totalCents = add_promo_snapshot["appliedPromotion"]["totalCents"]
    # subTotal = add_promo_snapshot["cart"]["subTotalCents"] 
    # discountCents = add_promo_snapshot["appliedPromotion"]["discountCents"]
    # itemPrice = subTotal-discountCents 

    # print("subTotal:", subTotal)
    # print("discountCents:", discountCents)
    # print("totalCents:", totalCents)
    # print("Text :",  add_promoItem_response.json()["assistantText"])
    # print(add_promoItem_response.json())

    lineItems = add_promo_snapshot["cart"]["lines"]
    wickedItem = None
    for items in lineItems:
        if "wicked" in items["name"].lower():
            wickedItem = items

    assert add_promoItem_response.status_code == 200
    assert add_promo_snapshot["appliedPromotion"] is not None
    # assert itemPrice == totalCents
    assert wickedItem is not None

def test_checkout(login_delivery_session):

    global storeID,service,name,email,phone,itemID

    session,convID = login_delivery_session
    checkout_response = chatbot_send_message(convID,"no thanks just place the order my phone is 0423451871",session=session)

    checkout_snapshot = checkout_response.json()["snapshot"]
    assert checkout_response.status_code == 200
    assert checkout_snapshot["state"] == "confirming"
    assert checkout_snapshot["customer"]["phone"] == "0423451871"
    assert checkout_snapshot["appliedPromotion"] is not None

    storeID = checkout_snapshot["storeId"]
    service = checkout_snapshot["service"]
    name = checkout_snapshot["customer"]["name"]
    email = checkout_snapshot["customer"]["email"]
    phone = checkout_snapshot["customer"]["phone"]

    lineItems = checkout_snapshot["cart"]["lines"]

    itemID.clear()
    for item in lineItems:
        itemID.append(item["itemId"])

def test_try_place_order(login_delivery_session):

    global orderID,reference_number,total_cents_placed
    session,convID = login_delivery_session
    place_order_response = chatbot_send_message(convID,"Yes, place the order.",session=session)

    place_order_snapshot = place_order_response.json()["snapshot"]
    assert place_order_response.status_code == 200
    assert place_order_snapshot["state"] == "confirming"
    assert place_order_snapshot["orderId"] is None
    # assert place_order_snapshot["appliedPromotion"] is None   "Remove itt--------------"
    assert place_order_snapshot["referenceNumber"] is None

def test_place_order(login_delivery_session):

    global orderID,reference_number,total_cents_placed
    session,convID = login_delivery_session
    place_order_response = chatbot_send_message(convID,"Yes, place the order.",session=session)

    place_order_snapshot = place_order_response.json()["snapshot"]
    assert place_order_response.status_code == 200
    assert place_order_snapshot["state"] == "paid"
    assert place_order_snapshot["orderId"] is not None
    assert place_order_snapshot["appliedPromotion"] is None

    orderID = place_order_snapshot["orderId"]
    assert place_order_snapshot["referenceNumber"] == place_order_snapshot["placedOrderNumber"]
    reference_number = place_order_snapshot["referenceNumber"]
    total_cents_placed = place_order_snapshot["placedTotalCents"]

    print("Step 6 State:", place_order_snapshot["state"])
    print("Step 6 orderId:", orderID)

def test_verify_order(login_delivery_session):

    session,_ = login_delivery_session
    order_response = get_order_details(session,orderID)

    print("-----------------------------------")
   # print(order_response.json())

    assert order_response.json()["id"] == orderID
    assert order_response.json()["store"]["storeId"] == storeID
    assert order_response.json()["service"] == service
    assert order_response.json()["referenceNumber"] == reference_number

    
    first_name = order_response.json()["customer"]["firstName"]
    last_name = order_response.json()["customer"]["lastName"]

    assert f"{first_name} {last_name}" == name
    assert order_response.json()["customer"]["email"] == email
    assert order_response.json()["customer"]["phoneNumber"] == phone

    foodLines = order_response.json()["foodLines"]
    
    for item in itemID:
        assert any(
            line["item"]["id"] == item
            for line in foodLines
        ), f"Item ID {item} not present in order report"

    assert order_response.json()["total"] == total_cents_placed
   # assert order_response.json()["status"] == "sent-to-pos-completed"

def test_cancel_order(login_delivery_session):

    session,_=login_delivery_session
    cancel_order_response = cancel_order(session,orderID)

    print(cancel_order_response.json())

    assert cancel_order_response.json()["ok"] == True
    assert cancel_order_response.json()["status"] == "refund-initiated"

def test_verify_canceled_order(login_delivery_session):

    session,_ = login_delivery_session
    order_response = get_order_details(session,orderID)

    print("-----------------------------------")
   # print(order_response.json())

    assert order_response.json()["id"] == orderID
    assert order_response.json()["store"]["storeId"] == storeID
    assert order_response.json()["service"] == service
    assert order_response.json()["referenceNumber"] == reference_number

    
    first_name = order_response.json()["customer"]["firstName"]
    last_name = order_response.json()["customer"]["lastName"]

    assert f"{first_name} {last_name}" == name
    assert order_response.json()["customer"]["email"] == email
    assert order_response.json()["customer"]["phoneNumber"] == phone

    foodLines = order_response.json()["foodLines"]
    
    for item in itemID:
        assert any(
            line["item"]["id"] == item
            for line in foodLines
        ), f"Item ID {item} not present in order report"

    assert order_response.json()["total"] == total_cents_placed
    
    
# Refund-specific validations
    assert order_response.json()["status"] == "refund-initiated"
    assert order_response.json()["cancelReason"] == "default"

    assert (order_response.json()["paymentReferences"][0]["paymentStatus"] == "refund-initiated")



    


