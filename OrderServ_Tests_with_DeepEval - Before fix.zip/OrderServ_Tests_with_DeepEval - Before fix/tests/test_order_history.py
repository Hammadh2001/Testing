from helpers.agent import chatbot_send_message

def test_logged_in_order_history(login_pickup_session):
    session, convID = login_pickup_session

    history_response = chatbot_send_message(convID, "show me my order history", session=session)
    history_snapshot = history_response.json()["snapshot"]

    assert history_response.status_code == 200
    assert history_response.json()["assistantText"] is not None
    assert history_snapshot["state"] == "gathering"
    assert history_snapshot["customer"]["name"] != ""

    lookup_response = chatbot_send_message(convID, "tell me more about order 1639", session=session)
    lookup_snapshot = lookup_response.json()["snapshot"]
    lookup_text = lookup_response.json()["assistantText"].lower()

    assert lookup_response.status_code == 200
    assert "1639" in lookup_response.json()["assistantText"]
    assert "not found" not in lookup_text
    assert "couldn't find" not in lookup_text
    assert lookup_snapshot["state"] == "gathering"


def test_logged_in_history_older_than_12_months(login_pickup_session):
    session, convID = login_pickup_session

    recent_response = chatbot_send_message(convID, "show me my order history", session=session)
    recent_count = recent_response.json()["assistantText"].count("#")

    response = chatbot_send_message(convID, "show me my order history from the last 12 months", session=session)
    snapshot = response.json()["snapshot"]
    year_count = response.json()["assistantText"].count("#")

    assert response.status_code == 200
    assert response.json()["assistantText"] is not None
    assert snapshot["state"] == "gathering"
    assert year_count >= recent_count


def test_guest_order_history_blocked(guest_pickup_session):
    convID = guest_pickup_session

    response = chatbot_send_message(convID, "show me my order history")
    snapshot = response.json()["snapshot"]

    assert response.status_code == 200
    assert response.json()["assistantText"] is not None
    assert snapshot["state"] == "gathering"

    text = response.json()["assistantText"].lower()
    assert "sign in" in text or "log in" in text or "signed in" in text