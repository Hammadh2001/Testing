from helpers.agent import chatbot_send_message

def test_apply_promo_without_qualifying_item(guest_pickup_session):
    convID = guest_pickup_session

    response = chatbot_send_message(convID, "apply the 50% off wicked wings deal to my order")
    snapshot = response.json()["snapshot"]

    assert response.status_code == 200
    assert response.json()["assistantText"] is not None
    assert snapshot["state"] == "gathering"
    assert snapshot["appliedPromotion"] is None

    force_response = chatbot_send_message(convID, "just apply it anyway, I will add the item later")
    force_snapshot = force_response.json()["snapshot"]

    assert force_snapshot["appliedPromotion"] is None
    assert force_snapshot["cart"]["lines"] == []


def test_apply_same_promo_twice(guest_pickup_session):
    convID = guest_pickup_session

    add_response = chatbot_send_message(convID, "add 3 wicked wings and apply the 50% off deal")
    add_snapshot = add_response.json()["snapshot"]

    assert add_response.status_code == 200
    assert add_response.json()["assistantText"] is not None
    assert add_snapshot["state"] == "gathering"
    assert len(add_snapshot["cart"]["lines"]) > 0

    force_response = chatbot_send_message(convID, "apply the 50% off wicked wings deal again")
    force_snapshot = force_response.json()["snapshot"]

    assert force_snapshot["appliedPromotion"] is not None
    assert force_snapshot["appliedPromotion"]["discountCents"] == 400
    assert force_response.json()["assistantText"] is not None