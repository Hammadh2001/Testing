import requests
from config import BASE_URL

def test_wrong_otp_returns_401():

    login_response = requests.post(f"{BASE_URL}/api/auth/login", json={"username": "jeba@gmail.com"})
    loginID = login_response.json()["loginId"]

    otp_response = requests.post(f"{BASE_URL}/api/auth/otp", json={"loginId": loginID, "otp": "1278"})

    assert otp_response.status_code == 401
    assert "OTP expired or incorrect" in otp_response.json()["detail"]
    assert "set-cookie" not in otp_response.headers

def test_login_unregistered_email():
    login_response = requests.post(f"{BASE_URL}/api/auth/login", json={"username": "notregistered@fake.com"})
    assert login_response.status_code == 200
    loginID = login_response.json()["loginId"]

    otp_response = requests.post(f"{BASE_URL}/api/auth/otp", json={"loginId": loginID, "otp": "1277"})

    assert otp_response.status_code == 401
    assert "OTP expired or incorrect" in otp_response.json()["detail"]

def test_expired_login_id():
    otp_response = requests.post(f"{BASE_URL}/api/auth/otp", json={"loginId": "7225c78c-8d33-4555-8808-e4a43166dad2", "otp": "1277"})
    assert otp_response.status_code == 401
    assert "login session expired" in otp_response.json()["detail"]

def test_auth_me_no_cookie():
    response = requests.get(f"{BASE_URL}/api/auth/me")
    data = response.json()

    assert response.status_code == 200
    assert data["authenticated"] == False
    assert "email" not in data
    assert "sub" not in data