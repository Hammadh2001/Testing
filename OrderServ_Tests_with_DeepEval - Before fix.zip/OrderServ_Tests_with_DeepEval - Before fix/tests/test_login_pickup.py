from helpers.orders import get_order_details
from helpers.agent import chatbot_send_message

orderID = None
storeID = None
service = None
itemID = None
name = None
email = None
phone = None
reference_number = None
total_cents_placed = None

def test_promo_ask(login_pickup_session):
    session,convID = login_pickup_session
    promo_ask_response = chatbot_send_message(convID,"do you have any deals or promotions?",session=session)

    promo_ask_snapshot = promo_ask_response.json()["snapshot"]
    assert promo_ask_response.status_code == 200
    assert promo_ask_response.json()["assistantText"] is not None
    assert promo_ask_snapshot["state"] == "gathering"
    assert promo_ask_snapshot["appliedPromotion"] is None
    assert convID == promo_ask_snapshot["conversationId"]

    print(promo_ask_response.status_code)
    print(promo_ask_response.json()["assistantText"])

def test_add_promoItem(login_pickup_session):

    global itemID
    session,convID = login_pickup_session
    add_promoItem_response = chatbot_send_message(convID,"add 3 wicked wings and apply the 50% off deal",session=session)

    add_promo_snapshot = add_promoItem_response.json()["snapshot"]
    totalCents = add_promo_snapshot["appliedPromotion"]["totalCents"]
    subTotal = add_promo_snapshot["cart"]["subTotalCents"] 
    discountCents = add_promo_snapshot["appliedPromotion"]["discountCents"]
    itemPrice = subTotal-discountCents 

    print("subTotal:", subTotal)
    print("discountCents:", discountCents)
    print("totalCents:", totalCents)
    print("Text :",  add_promoItem_response.json()["assistantText"])
    print(add_promoItem_response.json())

    lineItems = add_promo_snapshot["cart"]["lines"]
    wickedItem = None
    for items in lineItems:
        if "wicked" in items["name"].lower():
            wickedItem = items
            itemID = items["itemId"]

    assert add_promoItem_response.status_code == 200
    assert add_promo_snapshot["appliedPromotion"] is not None
    assert itemPrice == totalCents
    assert wickedItem is not None

def test_checkout(login_pickup_session):

    global storeID,service,name,email,phone

    session,convID = login_pickup_session
    checkout_response = chatbot_send_message(convID,"no thanks just place the order my phone is 0423451871",session=session)

    checkout_snapshot = checkout_response.json()["snapshot"]
    assert checkout_response.status_code == 200
    assert checkout_snapshot["state"] == "confirming"
    assert checkout_snapshot["customer"]["phone"] == "0423451871"
    assert checkout_snapshot["appliedPromotion"] is not None

    storeID = checkout_snapshot["storeId"]
    service = checkout_snapshot["service"]
    name = checkout_snapshot["customer"]["name"]
    email = checkout_snapshot["customer"]["email"]
    phone = checkout_snapshot["customer"]["phone"]

def test_place_order(login_pickup_session):

    global orderID,reference_number,total_cents_placed
    session,convID = login_pickup_session
    place_order_response = chatbot_send_message(convID,"Yes, place the order.",session=session)

    place_order_snapshot = place_order_response.json()["snapshot"]
    assert place_order_response.status_code == 200
    assert place_order_snapshot["state"] == "paid"
    assert place_order_snapshot["orderId"] is not None
    assert place_order_snapshot["appliedPromotion"] is None

    orderID = place_order_snapshot["orderId"]
    reference_number = place_order_snapshot["referenceNumber"]
    total_cents_placed = place_order_snapshot["placedTotalCents"]

    print("Step 6 State:", place_order_snapshot["state"])
    print("Step 6 orderId:", orderID)
    
def test_verify_order(login_pickup_session):

    session,_ = login_pickup_session
    order_response = get_order_details(session,orderID)

    print("-----------------------------------")
    print(order_response.json())

    assert order_response.json()["id"] == orderID
    assert order_response.json()["store"]["storeId"] == storeID
    assert order_response.json()["service"] == service
    assert order_response.json()["referenceNumber"] == reference_number

    
    first_name = order_response.json()["customer"]["firstName"]
    last_name = order_response.json()["customer"]["lastName"]

    assert f"{first_name} {last_name}" == name
    assert order_response.json()["customer"]["email"] == email
    assert order_response.json()["customer"]["phoneNumber"] == phone

    foodLines = order_response.json()["foodLines"]
    
    assert any(
        line["item"]["id"] == itemID
        for line in foodLines
    ), f"Item ID {itemID} not present in order report"

    assert order_response.json()["total"] == total_cents_placed
    assert order_response.json()["status"] == "sent-to-pos-completed"
    




