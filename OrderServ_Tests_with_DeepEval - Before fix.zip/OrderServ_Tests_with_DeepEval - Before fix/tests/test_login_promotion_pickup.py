import requests

session = requests.session()
BASE_URL = "http://localhost:8050"

login_respone = session.post(f"{BASE_URL}/api/auth/login",
             json={
                 "username": "kfc_au_orders_002@gmail.com"
             })

loginID=login_respone.json()["loginId"]
print(loginID)

otp_response = session.post(f"{BASE_URL}/api/auth/otp",
             json={
                   "loginId": loginID,
                   "otp": "1277"
             })

assert otp_response.json()["ok"] == True

authME_response = session.get(f"{BASE_URL}/api/auth/me")
print(authME_response.json())