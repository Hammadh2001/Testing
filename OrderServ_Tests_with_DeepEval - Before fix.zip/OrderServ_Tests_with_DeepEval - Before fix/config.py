BASE_URL = "http://localhost:8050"
RETURNING_USER_EMAIL = "kfc_au_orders_001@gmail.com"
STATIC_OTP = "1277"

#Data
PROMOTION_CACHE_FILE = "data/cached_promotion_response.json"

# DeepEval
ANTHROPIC_API_KEY = 