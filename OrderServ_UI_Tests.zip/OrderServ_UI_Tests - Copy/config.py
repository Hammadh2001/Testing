import os
from dotenv import load_dotenv

load_dotenv()

# The UI (frontend dev server). Backend API lives at API_BASE_URL — the UI talks to it internally,
# but tests use API_BASE_URL directly for setup/teardown (login/logout) the same way the API suite does.
BASE_URL = os.environ.get("ORDERSERV_UI_BASE_URL", "http://localhost:5273")
API_BASE_URL = os.environ.get("ORDERSERV_API_BASE_URL", "http://localhost:8050")

RETURNING_USER_EMAIL = "kfc_au_orders_001@gmail.com"
STATIC_OTP = "1277"

# The chat widget's default store (287) currently rejects Wicked Wings / Wicked
# Boneless adds — confirmed live, not a test bug. Store 952 (same one the API
# suite's login_pickup_session fixture already pins) works correctly. See
# ARCHITECTURE.md §8 for the full investigation.
WORKING_STORE_ID = os.environ.get("ORDERSERV_WORKING_STORE_ID", "952")

HEADLESS = os.environ.get("HEADLESS", "true").lower() != "false"
