import pytest

from config import API_BASE_URL, BASE_URL, RETURNING_USER_EMAIL, STATIC_OTP, WORKING_STORE_ID
from pages.chat_widget import ChatWidget
from pages.home_page import HomePage
from pages.login_page import LoginPage


@pytest.fixture(scope="session")
def base_url():
    """Overrides pytest-playwright's base_url fixture so page.goto('/') resolves here."""
    return BASE_URL


def _logout(page):
    """Reset auth state via the API directly — same approach conftest.py in the API
    suite uses (requests.post .../auth/logout), just issued through Playwright's
    request context instead of the `requests` library."""
    page.request.post(f"{API_BASE_URL}/api/auth/logout")


@pytest.fixture
def guest_pickup_chat(page):
    """UI equivalent of the API suite's guest_pickup_session fixture.

    Switches to WORKING_STORE_ID (952) immediately after opening chat — the chat
    always starts on store 287 by default, and store 287 currently rejects Wicked
    Wings / Wicked Boneless adds (a real backend/inventory issue, confirmed live;
    see ARCHITECTURE.md §8). Store 952 is the same store the API suite's
    login_pickup_session fixture already pins for the same reason."""
    _logout(page)
    home = HomePage(page)
    home.goto()
    chat = ChatWidget(page)
    chat.open()
    chat.switch_store(WORKING_STORE_ID)
    return chat


@pytest.fixture
def guest_delivery_chat(page):
    """UI equivalent of guest_delivery_session. There is no separate delivery/pickup
    toggle in the UI (unlike the API's service=\"delivery\" param) — service is
    negotiated conversationally, so tests using this fixture should ask for delivery
    in their first chat message.

    Deliberately does NOT switch to WORKING_STORE_ID: that store (952) is a
    pickup-oriented test store (confirmed live — delivery item adds fail there),
    while the chat's default store (287) handles these non-promo delivery items
    fine. The store-287 problem is specific to Wicked Wings/Boneless items."""
    _logout(page)
    home = HomePage(page)
    home.goto()
    chat = ChatWidget(page)
    chat.open()
    return chat


@pytest.fixture
def login_pickup_chat(page):
    """UI equivalent of login_pickup_session: signs in as the returning test user,
    opens the chat widget, then switches to WORKING_STORE_ID (see guest_pickup_chat)."""
    _logout(page)
    home = HomePage(page)
    home.goto()
    home.open_sign_in()
    LoginPage(page).sign_in(RETURNING_USER_EMAIL, STATIC_OTP)
    page.wait_for_selector(HomePage.SIGN_IN_BUTTON)
    chat = ChatWidget(page)
    chat.open()
    chat.switch_store(WORKING_STORE_ID)
    return chat


@pytest.fixture
def login_delivery_chat(page):
    """UI equivalent of login_delivery_session. See guest_delivery_chat note above —
    ask for delivery in the first chat message. Also does NOT switch stores, for the
    same reason guest_delivery_chat doesn't."""
    _logout(page)
    home = HomePage(page)
    home.goto()
    home.open_sign_in()
    LoginPage(page).sign_in(RETURNING_USER_EMAIL, STATIC_OTP)
    page.wait_for_selector(HomePage.SIGN_IN_BUTTON)
    chat = ChatWidget(page)
    chat.open()
    return chat
