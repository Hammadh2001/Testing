# OrderServ_UI_Tests — Architecture Guide

This is the UI counterpart to [`OrderServ_Tests_with_DeepEval`](../OrderServ_Tests_with_DeepEval/ARCHITECTURE.md). Where that project drives the OrderServ chatbot through raw HTTP calls, this project drives the **same chatbot through the real browser UI** at `http://localhost:5273`, using [Playwright](https://playwright.dev/python/) + `pytest`.

It deliberately mirrors that project's structure and journeys so anyone familiar with one can read the other:

| API project | UI project | Role |
|---|---|---|
| `config.py` | `config.py` | URLs, test account, OTP |
| `conftest.py` fixtures (`guest_pickup_session`, ...) | `conftest.py` fixtures (`guest_pickup_chat`, ...) | Pre-built session/page state per journey |
| `helpers/agent.py`, `helpers/auth.py` | `pages/chat_widget.py`, `pages/login_page.py`, `pages/home_page.py`, `pages/cart_panel.py` | Reusable interaction logic (Page Object Model) |
| `tests/test_*.py` | `tests/test_*.py` | Same journeys, same file names, driven through the UI instead of `requests` |

---

## 1. Folder structure

```
OrderServ_UI_Tests/
├── config.py            # UI base URL, API base URL, test account, OTP
├── conftest.py           # pytest-playwright fixtures: guest/login x pickup/delivery
├── pytest.ini             # registers the "eval" marker
├── requirements.txt        # pytest, pytest-playwright, python-dotenv, allure-pytest
├── .env.example            # template for local overrides
├── .gitignore
├── pages/                   # Page Object Model — the UI equivalent of helpers/
│   ├── home_page.py          # header: sign-in entry point, cart entry point
│   ├── login_page.py          # email + OTP two-step sign-in form
│   ├── chat_widget.py          # the "Ask the Colonel" AI chat panel — the core interaction surface
│   └── cart_panel.py            # the "Your cart" side panel
└── tests/
    ├── test_auth_negative.py     # wrong OTP / unregistered email → real error banner shown
    ├── test_guest_pickup.py       # guest pickup: promo ask → add+apply promo → checkout → place order
    ├── test_guest_delivery.py      # guest delivery: promo ask → add promo item
    ├── test_login_pickup.py         # logged-in pickup: promo ask → add+apply promo → checkout → place order
    ├── test_login_delivery.py        # logged-in delivery: add item → add+apply promo → checkout
    ├── test_order_history.py          # logged-in history lookup; guest history blocked
    └── test_promo_negative.py          # apply promo with no qualifying item; apply same promo twice
```

---

## 2. What the app under test actually is

Navigating to `http://localhost:5273` loads a KFC ordering storefront. The interesting part for this project is the **"Ask the Colonel"** chat widget (floating "Order with AI" button, bottom-right) — this is the UI front-end for the exact same backend the API suite hits directly (`http://localhost:8050/api/agent/chat/...`). Typing a message into the chat and getting a reply is the UI equivalent of `helpers/agent.py::chatbot_send_message()`.

Real DOM structure discovered by inspecting the running app (not guessed):

```html
<button class="kfc-chat-fab" aria-label="Open chat / Close chat">...</button>
<div class="kfc-chat-panel" role="dialog" aria-label="KFC AI ordering assistant">
  <input class="kfc-chat-input" placeholder="Tell me what you'd like…">
  <button class="kfc-chat-send">Send</button>
  <div class="kfc-msg kfc-msg--user"><div class="kfc-msg-bubble">...</div></div>
  <div class="kfc-msg kfc-msg--assistant"><div class="kfc-msg-bubble">...</div></div>
</div>
<aside class="kfc-sidebar" aria-label="Your cart">
  <div class="kfc-sidebar-empty">Your cart is empty...</div>
  <div class="kfc-cart-subtotal"><span>Subtotal</span><strong>$0.00</strong></div>
</aside>
```

Sign-in is a separate two-step page (`.kfc-signin` header button → email input → `Send OTP` → OTP input → `Verify & Sign in`), using the exact same fixed OTP (`1277`) and test account (`kfc_au_orders_001@gmail.com`) as the API suite — because it's the same backend auth flow, just filled in through a form instead of a JSON body.

**Real error banner confirmed by testing a wrong OTP live:**
```html
<div class="kfc-pay-error">OTP expired or incorrect — please try again</div>
```
This is the exact string [`test_auth_negative.py`](tests/test_auth_negative.py) asserts on — not guessed.

---

## 3. `config.py`

| Variable | Purpose |
|---|---|
| `BASE_URL` | The UI dev server, `http://localhost:5273` by default (env: `ORDERSERV_UI_BASE_URL`) |
| `API_BASE_URL` | The backend API, `http://localhost:8050` by default (env: `ORDERSERV_API_BASE_URL`) — used only for the logout call in fixtures (see below), everything else goes through the browser |
| `RETURNING_USER_EMAIL`, `STATIC_OTP` | Same fixed test account and OTP as the API suite (same backend, same account) |
| `HEADLESS` | Whether Playwright runs headless (`true` by default); set `HEADLESS=false` to watch the browser |

Loaded via `python-dotenv`, same pattern as the (now-fixed) API project.

---

## 4. `conftest.py` — fixtures

Playwright's own `pytest-playwright` plugin provides the `page` fixture (a fresh browser page per test function) and a `base_url` fixture. This project overrides `base_url` to point at the UI, and adds four fixtures that mirror the API suite's:

| Fixture | Mirrors | What it does |
|---|---|---|
| `guest_pickup_chat` | `guest_pickup_session` | Logs out via a direct API call (`page.request.post(.../auth/logout)` — same trick the API `conftest.py` uses, just through Playwright's request context instead of `requests`), loads the home page, opens the chat widget |
| `guest_delivery_chat` | `guest_delivery_session` | Same, for delivery-flavored tests |
| `login_pickup_chat` | `login_pickup_session` | Logs out, signs in as the returning test user via the real login form, opens the chat widget |
| `login_delivery_chat` | `login_delivery_session` | Same, for delivery-flavored tests |

**Deliberate design difference from the API suite:** these fixtures are `scope="function"` (Playwright's `page` fixture is inherently function-scoped — a fresh browser page per test), and **every test in this project is self-contained** — each test sends its own full sequence of chat messages to reach the state it needs, rather than relying on a previous test function in the same file having already run. This sidesteps the exact fragility flagged in the API project's [`IMPROVEMENTS.md` §1 and §2](../OrderServ_Tests_with_DeepEval/IMPROVEMENTS.md) (module-scoped fixtures + cross-test global state breaking when run out of order or in isolation). It costs a bit of redundant typing per test (e.g. `test_place_order` re-sends the add-item and checkout messages before placing the order) but every test can be run alone and in any order.

**No service/store toggle in the UI:** the API's `create_conversation(service="delivery", store="...")` sets those explicitly in the request body. The UI has no equivalent structured field — the chatbot infers pickup vs. delivery from what you type. So `guest_delivery_chat`/`login_delivery_chat` tests simply open with "I'd like delivery..." in their first message instead.

---

## 5. `pages/` — Page Object Model (the UI's `helpers/`)

### `pages/home_page.py`
Header interactions: `open_sign_in()`, `open_cart()`, and state checks `is_signed_in_as(email)` / `is_guest()` (reads the `.kfc-signin` button's `title` attribute, which holds the signed-in user's email, or falls back to "Sign In" text for guests).

### `pages/login_page.py`
Drives the two-step sign-in form: `enter_email()` → clicks `Send OTP` → `enter_otp()` → clicks `Verify & Sign in`. `sign_in(email, otp)` does both steps in one call. `error_message()` / `has_error()` read the `.kfc-pay-error` banner for negative-path tests.

### `pages/chat_widget.py`
The core interaction surface — the UI equivalent of `helpers/agent.py`:
- `open()` / `close()` — toggle the floating `.kfc-chat-fab` button (checks its `aria-label` first, so calling `open()` on an already-open chat is a no-op)
- `send(text)` — types into `.kfc-chat-input`, clicks `.kfc-chat-send`, and **waits for a new assistant bubble to appear** (`page.wait_for_function` polling the assistant-message count) rather than a fixed sleep — this is what makes the tests reliable against the AI's variable response time
- `last_assistant_message()` / `last_user_message()` — read the most recent `.kfc-msg-bubble` text
- `click_suggestion(pattern)` — clicks a dynamic quick-action button (e.g. "Apply the '50% off on wicked wings' offer...") by regex match on its visible text, for tests that want to use the bot's own suggested actions instead of typing a full sentence

### `pages/cart_panel.py`
The "Your cart" sidebar: `open()`/`close()`, `is_empty()` (checks for `.kfc-sidebar-empty`), `subtotal_text()`.

---

## 6. `tests/` — journeys, mirrored from the API suite

| File | Mirrors (API) | UI journey |
|---|---|---|
| `test_auth_negative.py` | `tests/test_auth_negative.py` | Wrong OTP and unregistered-email both show `.kfc-pay-error` "OTP expired or incorrect"; guest state shows "Sign In" in the header |
| `test_guest_pickup.py` | `tests/test_guest_pickup.py` | Ask about promos → add+apply promo (verified via cart panel, not just chat text) → checkout → place order |
| `test_guest_delivery.py` | `tests/test_guest_delivery.py` | Same idea, phrased for delivery |
| `test_login_pickup.py` | `tests/test_login_pickup.py` | Confirms signed-in state via the header, then promo ask → add+apply → checkout → place order |
| `test_login_delivery.py` | `tests/test_login_delivery.py` | Add item for delivery → add+apply promo → checkout |
| `test_order_history.py` | `tests/test_order_history.py` | Logged-in history lookup (asserts an order reference `#...` is present); guest history request is blocked with a sign-in prompt |
| `test_promo_negative.py` | `tests/test_promo_negative.py` | Applying a promo with no qualifying item leaves the cart empty; applying the same promo twice doesn't double up (asserted via the bot's own wording, since the UI doesn't expose discount cents directly the way the API's JSON snapshot does) |

**Note on assertion style:** the API suite can assert on exact JSON fields (`discountCents == 400`, `state == "paid"`). The UI only exposes what's rendered on screen — chat text and cart totals — so these tests assert on visible signals instead (cart emptiness, subtotal, and keyword checks on the assistant's reply). This is inherently a bit fuzzier than the API assertions; if the chatbot's phrasing changes, some of these keyword checks may need adjusting. Where precision matters most (e.g., real dollar amounts), prefer reading `CartPanel.subtotal_text()` over parsing chat prose.

---

## 7. Running the tests

```bash
pip install -r requirements.txt
playwright install chromium   # one-time browser download

# Prerequisite: OrderServ backend running at localhost:8050, UI dev server running at localhost:5273

pytest                          # run everything, headless
HEADLESS=false pytest -k pickup  # watch a subset run in a visible browser

# HTML report
pytest --html=report.html --self-contained-html
```

---

## 8. Current run results, a confirmed real bug, and how it was resolved

This suite has actually been run end-to-end against the live app repeatedly (not just written and assumed to work), and iterated on based on real failures. Current result: **17 of 18 tests pass consistently**; the 18th fails intermittently for a documented reason (see below).

### The real bug: store 287 rejects Wicked Wings / Wicked Boneless

The chat widget's default conversation always starts on **store 287**, and that store was found to reject every attempt to add Wicked Wings or 6 Pieces Wicked Boneless — confirmed independently across three separate sessions (guest, logged-in, where it surfaced as `"Invalid customer Id"`) with the assistant reporting it plainly:
> *"store 287 is rejecting the wings items themselves. Want me to switch to store 5 (UAT demo) so I can add the wings and apply the deal?"*

Since every promotion in this environment (`50% off Wicked Wings`, `Test_MenuDayPart_Product`, `UAT_10for10HandC`) is keyed to Wicked Wings/Boneless items, this blocked **every** promo-related test — both here and, presumably, in the API suite if it happened to hit store 287.

**Investigated and fixed:** the header's "Set Location" store picker does **not** actually change the chat's store — both stores offered there create a conversation with `storeId: "287"` regardless of which one you pick (confirmed via network inspection). The only way found to change it is asking the assistant directly in chat: `"switch to store {id}"`. Store **952** (the same store the API suite's `login_pickup_session` fixture already pins, for the same underlying reason) works correctly and was confirmed live: item added, 50% discount applied, cart total updated correctly.

This is now wired into `ChatWidget.switch_store()` and called from the **pickup** fixtures (`guest_pickup_chat`, `login_pickup_chat`) right after opening chat. It is deliberately **not** called from the delivery fixtures — store 952 turned out to be pickup-only; delivery item adds (chocolate mousse, Zinger burger) work fine on the default store 287, since that store's problem is specific to wings items, not delivery in general.

**Still worth reporting to whoever owns the OrderServ backend:** store 287 (the assistant's own default) can't fulfill its own advertised promotions. Store 952 is a workaround for testing, not a fix.

### The remaining intermittent failure

`test_login_pickup.py::test_add_promoItem_and_checkout` occasionally fails because the assistant sometimes answers an ambiguous add-item request with a clarifying question (*"did you want 3× packs or just one pack?"*) instead of adding directly — genuine LLM non-determinism, the same reason the API suite uses DeepEval "judge" scoring rather than hard assertions for AI-generated text. The wording sent by every test was made explicit ("add **one pack of** 3 Wicked Wings...") and a one-shot disambiguation retry was added (if the cart is still empty after the first message, send a follow-up clarifying it's one pack, then re-check) — this fixed the guest-flow version of the same test and most runs of the logged-in version, but not every run. If this test fails, **re-run it before assuming something broke** — check the assistant's actual reply first (it'll be a clarifying question, not an error).

### Other things found and fixed while building this

- **Brittle "error"/"sorry" keyword assertions were removed.** Early versions of these tests asserted `"error" not in reply`, which broke on legitimate assistant explanations like *"this promo will fail at payment with an auth error unless you sign in"* — a correct, helpful warning, not a bug. Assertions now check the actual state that matters (cart contents) rather than pattern-matching prose.
- **The chat reply-detection timing bug:** the assistant appends an empty/loading message bubble immediately and only adds a `.kfc-msg-latency` ("Time taken to respond") badge once a reply has fully rendered. `ChatWidget.send()` waits on the latency badge count, not bubble count — waiting on bubble count alone read empty text and left the input disabled when the next `send()` call fired, causing 30-second timeouts.
- Every selector in the page objects (`.kfc-signin`, `.kfc-pay-error`, `.kfc-chat-fab`, `.kfc-msg-latency`, `.kfc-sidebar`, etc.) was taken from the real running app's DOM via direct inspection, not guessed from documentation.
- **Delivery tests rely on the chatbot inferring the service from natural language** ("I'd like delivery..."), since there's no structured UI toggle like the API's `service="delivery"` parameter. Both delivery tests pass consistently as written.
- **No fixture teardown/cleanup**, same caveat as the API suite — `test_login_pickup.py` and `test_login_delivery.py` place real orders against the shared test account and don't cancel them.
