class HomePage:
    """The KFC ordering landing page: header, sign-in entry point, cart entry point."""

    SIGN_IN_BUTTON = ".kfc-signin"
    CART_BUTTON = ".kfc-bucket"

    def __init__(self, page):
        self.page = page

    def goto(self):
        self.page.goto("/")

    def open_sign_in(self):
        self.page.locator(self.SIGN_IN_BUTTON).click()

    def open_cart(self):
        self.page.locator(self.CART_BUTTON).click()

    def is_signed_in_as(self, email: str) -> bool:
        title = self.page.locator(self.SIGN_IN_BUTTON).get_attribute("title") or ""
        return email in title

    def is_guest(self) -> bool:
        return self.page.locator(self.SIGN_IN_BUTTON).inner_text().strip().lower() == "sign in"
