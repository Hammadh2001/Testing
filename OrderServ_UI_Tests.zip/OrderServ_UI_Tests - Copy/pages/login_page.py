class LoginPage:
    """Two-step email + OTP sign-in form (reached via HomePage.open_sign_in())."""

    EMAIL_INPUT = "input[type='email']"
    SEND_OTP_BUTTON = "button:has-text('Send OTP')"
    OTP_INPUT = "input[type='text']"
    VERIFY_BUTTON = "button:has-text('Verify & Sign in')"
    ERROR_BANNER = ".kfc-pay-error"

    def __init__(self, page):
        self.page = page

    def enter_email(self, email: str):
        self.page.locator(self.EMAIL_INPUT).fill(email)
        self.page.locator(self.SEND_OTP_BUTTON).click()

    def enter_otp(self, otp: str):
        self.page.locator(self.OTP_INPUT).fill(otp)
        self.page.locator(self.VERIFY_BUTTON).click()

    def sign_in(self, email: str, otp: str):
        """Full happy-path login: email -> Send OTP -> otp -> Verify & Sign in."""
        self.enter_email(email)
        self.page.wait_for_selector(self.OTP_INPUT)
        self.enter_otp(otp)

    def error_message(self) -> str:
        return self.page.locator(self.ERROR_BANNER).inner_text()

    def has_error(self) -> bool:
        return self.page.locator(self.ERROR_BANNER).count() > 0
