class CartPanel:
    """The 'Your cart' side panel, updated by both menu clicks and chat actions."""

    ASIDE = "aside.kfc-sidebar"
    OPEN_BUTTON = ".kfc-bucket"
    CLOSE_BUTTON = ".kfc-sidebar-close"
    EMPTY_STATE = ".kfc-sidebar-empty"
    SUBTOTAL = ".kfc-cart-subtotal strong"

    def __init__(self, page):
        self.page = page

    def open(self):
        self.page.locator(self.OPEN_BUTTON).click()
        self.page.wait_for_selector(self.ASIDE)

    def close(self):
        self.page.locator(self.CLOSE_BUTTON).click()

    def is_empty(self) -> bool:
        return self.page.locator(self.EMPTY_STATE).count() > 0

    def subtotal_text(self) -> str:
        return self.page.locator(self.SUBTOTAL).inner_text()
