import re


class ChatWidget:
    """The 'Ask the Colonel' AI ordering chat panel.

    This is the UI equivalent of helpers/agent.py in the API test suite:
    send() replaces chatbot_send_message(), open() replaces create_conversation().
    """

    FAB = ".kfc-chat-fab"
    PANEL = ".kfc-chat-panel"
    INPUT = ".kfc-chat-input"
    SEND_BUTTON = ".kfc-chat-send"
    RESET_BUTTON = ".kfc-chat-reset"
    USER_BUBBLE = ".kfc-msg--user .kfc-msg-bubble"
    ASSISTANT_BUBBLE = ".kfc-msg--assistant .kfc-msg-bubble"
    # The assistant bubble is appended immediately (empty/loading) and the input is
    # disabled while a reply streams in; ".kfc-msg-latency" ("Time taken to respond")
    # only appears once a reply has actually finished rendering, so that's the real
    # "done" signal — waiting on bubble count alone fires too early.
    ASSISTANT_LATENCY_BADGE = ".kfc-msg-latency"
    SUGGESTION_BUTTONS = ".kfc-chat-panel button"

    def __init__(self, page):
        self.page = page

    def open(self):
        fab = self.page.locator(self.FAB)
        aria_label = fab.get_attribute("aria-label") or ""
        if "open chat" in aria_label.lower():
            fab.click()
        self.page.wait_for_selector(self.PANEL)

    def switch_store(self, store_id: str):
        """The chat always starts on store 287 regardless of the header's 'Set Location'
        picker (that picker doesn't actually affect the AI chat's store — confirmed by
        inspecting the create-conversation network call, which sends storeId "287" no
        matter which store is picked there). Asking the assistant directly to switch
        stores is the only way found to change it. See ARCHITECTURE.md for why this is
        needed at all: store 287 currently rejects Wicked Wings / Wicked Boneless adds."""
        
        self.send(f"switch to store {store_id}")

    def close(self):
        fab = self.page.locator(self.FAB)
        aria_label = fab.get_attribute("aria-label") or ""
        if "close chat" in aria_label.lower():
            fab.click()

    def reset(self):
        self.page.locator(self.RESET_BUTTON).click()

    def send(self, text: str, timeout: int = 45000):
        """Send a message and wait for the reply to actually finish rendering
        (see ASSISTANT_LATENCY_BADGE above for why bubble count alone isn't enough)."""
        before = self.page.locator(self.ASSISTANT_LATENCY_BADGE).count()
        self.page.locator(self.INPUT).fill(text)
        self.page.locator(self.SEND_BUTTON).click()
        self.page.wait_for_function(
            "([sel, before]) => document.querySelectorAll(sel).length > before",
            arg=[self.ASSISTANT_LATENCY_BADGE, before],
            timeout=timeout,
        )

    def last_assistant_message(self) -> str:
        return self.page.locator(self.ASSISTANT_BUBBLE).last.inner_text()

    def last_user_message(self) -> str:
        return self.page.locator(self.USER_BUBBLE).last.inner_text()

    def assistant_message_count(self) -> int:
        return self.page.locator(self.ASSISTANT_BUBBLE).count()

    def click_suggestion(self, text_pattern: str):
        """Click a dynamic suggestion/quick-action button by visible text (regex, case-insensitive)."""
        before = self.page.locator(self.ASSISTANT_BUBBLE).count()
        self.page.get_by_role("button", name=re.compile(text_pattern, re.I)).click()
        self.page.wait_for_function(
            "([sel, before]) => document.querySelectorAll(sel).length > before",
            arg=[self.ASSISTANT_BUBBLE, before],
            timeout=30000,
        )
