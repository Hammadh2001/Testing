from config import API_BASE_URL
from pages.home_page import HomePage
from pages.login_page import LoginPage


def test_wrong_otp_shows_error(page, base_url):
    page.request.post(f"{API_BASE_URL}/api/auth/logout")
    HomePage(page).goto()
    HomePage(page).open_sign_in()

    login = LoginPage(page)
    login.enter_email("jeba@gmail.com")
    page.wait_for_selector(LoginPage.OTP_INPUT)
    login.enter_otp("1278")

    page.wait_for_selector(LoginPage.ERROR_BANNER)
    assert "OTP expired or incorrect" in login.error_message()
    # Form reverts to the email step rather than navigating anywhere logged-in.
    assert page.locator(LoginPage.SEND_OTP_BUTTON).is_visible()


def test_login_unregistered_email(page, base_url):
    page.request.post(f"{API_BASE_URL}/api/auth/logout")
    HomePage(page).goto()
    HomePage(page).open_sign_in()

    login = LoginPage(page)
    login.enter_email("notregistered@fake.com")
    page.wait_for_selector(LoginPage.OTP_INPUT)
    login.enter_otp("1277")

    page.wait_for_selector(LoginPage.ERROR_BANNER)
    assert "OTP expired or incorrect" in login.error_message()


def test_guest_sees_sign_in_when_logged_out(page, base_url):
    page.request.post(f"{API_BASE_URL}/api/auth/logout")
    home = HomePage(page)
    home.goto()
    assert home.is_guest()
