from pages.home_page import HomePage


def test_logged_in_sees_account(login_pickup_chat, page):
    home = HomePage(page)
    from config import RETURNING_USER_EMAIL

    assert home.is_signed_in_as(RETURNING_USER_EMAIL)


def test_promo_ask(login_pickup_chat):
    chat = login_pickup_chat
    chat.send("do you have any deals or promotions?")

    reply = chat.last_assistant_message()
    assert reply


def test_add_promoItem_and_checkout(login_pickup_chat, page):
    from pages.cart_panel import CartPanel

    chat = login_pickup_chat
    chat.send("add one pack of 3 Wicked Wings and apply the 50% off deal")

    # The assistant sometimes asks a clarifying question instead of adding directly
    # (inherent LLM non-determinism — see test_promo_negative.py for the same pattern).
    # Disambiguate once if the cart is still empty before moving on.
    cart = CartPanel(page)
    cart.open()
    if cart.is_empty():
        chat.send("just one pack, please, and apply the promo")
        cart.open()
    assert not cart.is_empty()

    chat.send("no thanks just place the order my phone is 0423451871")
    chat.send("Yes, place the order.")

    final_reply = chat.last_assistant_message().lower()
    assert "order" in final_reply
