from pages.cart_panel import CartPanel


def test_add_item_for_delivery(login_delivery_chat, page):
    chat = login_delivery_chat
    chat.send("I'd like delivery. Add any one Zinger burger for delivery")

    reply = chat.last_assistant_message().lower()
    assert "error" not in reply

    cart = CartPanel(page)
    cart.open()
    assert not cart.is_empty()


def test_add_promoItem_and_checkout(login_delivery_chat, page):
    chat = login_delivery_chat
    chat.send("I'd like delivery. Add 3 wicked wings and apply the 50% off deal")

    reply = chat.last_assistant_message().lower()
    assert "error" not in reply

    chat.send("no thanks just place the order my phone is 0423451871")
    final_reply = chat.last_assistant_message().lower()
    assert "error" not in final_reply
