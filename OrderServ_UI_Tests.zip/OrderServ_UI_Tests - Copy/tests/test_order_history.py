def test_logged_in_order_history(login_pickup_chat):
    chat = login_pickup_chat
    chat.send("show me my order history")

    reply = chat.last_assistant_message()
    assert reply
    assert "#" in reply  # order references are shown as #<number>


def test_guest_order_history_blocked(guest_pickup_chat):
    chat = guest_pickup_chat
    chat.send("show me my order history")

    reply = chat.last_assistant_message().lower()
    assert "sign in" in reply or "log in" in reply or "signed in" in reply
