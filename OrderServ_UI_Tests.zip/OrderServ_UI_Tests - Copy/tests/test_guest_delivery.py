def test_promo_ask(guest_delivery_chat):
    chat = guest_delivery_chat
    chat.send("I'd like delivery. Do you have any deals or promotions?")

    reply = chat.last_assistant_message()
    assert reply


def test_add_promoItem(guest_delivery_chat, page):
    from pages.cart_panel import CartPanel

    chat = guest_delivery_chat
    chat.send("I'd like delivery. Add a double chocolate mousse and apply the free delivery promo to it")

    reply = chat.last_assistant_message().lower()
    assert "error" not in reply

    cart = CartPanel(page)
    cart.open()
    assert not cart.is_empty()
