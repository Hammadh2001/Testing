from pages.cart_panel import CartPanel


def test_apply_promo_without_qualifying_item(guest_pickup_chat, page):
    chat = guest_pickup_chat
    chat.send("apply the 50% off wicked wings deal to my order")

    reply = chat.last_assistant_message()
    assert reply

    chat.send("just apply it anyway, I will add the item later")

    cart = CartPanel(page)
    cart.open()
    assert cart.is_empty()


def test_apply_same_promo_twice(guest_pickup_chat, page):
    chat = guest_pickup_chat
    chat.send("add one pack of 3 Wicked Wings and apply the 50% off deal")

    # The assistant sometimes asks a clarifying question here (e.g. "1 pack or 3
    # packs?") instead of adding directly — inherent LLM non-determinism, not a bug.
    # Disambiguate once if the cart is still empty before moving on.
    cart = CartPanel(page)
    cart.open()
    if cart.is_empty():
        chat.send("just one pack, please, and apply the promo")
        cart.open()
    assert not cart.is_empty(), "promo item was never added even after disambiguating"

    chat.send("apply the 50% off wicked wings deal again")
    second_reply = chat.last_assistant_message().lower()

    # The discount should not double up — assistant shouldn't claim a second discount was added.
    assert "already" in second_reply or "applied" in second_reply
