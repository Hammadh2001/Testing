import {expect,type Locator,type Page} from '@playwright/test'

export class OrderChecks2{
page : Page;
productList:Locator;
view:Locator;
id:Locator;
thankuMSG:Locator;

    constructor (page:Page){
        this.page=page;
        this.productList = page.locator('tbody tr');
        this.view = page.getByRole('button',{name:'View'});
        this.id = page.locator(".col-text");
        this.thankuMSG = page.getByText('Thank you for Shopping With Us');

    }

    async ordercheck(orderid:string){

        await this.page.waitForTimeout(3000); // waits for 3 seconds
        await this.page.getByText('Your Orders').waitFor();

        await this.productList.first().waitFor();
        const rowCount = await this.productList.count();
       // console.log(rowCount);

        let matched = false;

        for (let i=0; i<rowCount; i++){

            const rowOrderId0 = await this.productList.nth(i).locator("th").innerText();
           // const rowOrderId = (await this.productList.nth(i).locator("th").textContent())?.trim() ?? '';
           

            if(rowOrderId0.includes(orderid)){
                console.log(rowOrderId0);
                matched = true;
                console.log("--- Order Placed Successfully ---");
                await this.view.nth(i).click();
                break;
            }

        }
        await this.thankuMSG.waitFor();

    }

    async orderIDverify(orderid:string){

        const orderIdDetails = (await this.id.textContent())!;
        expect(orderid.includes(orderIdDetails)).toBeTruthy();

    }

}

