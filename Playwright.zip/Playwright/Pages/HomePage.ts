import {type Locator, type Page, expect} from '@playwright/test';

export class HomePage{
page:Page;
allProducts :Locator;
productsName : Locator;
cartlist : Locator;

    constructor(page:Page){
        this.page=page;
        this.productsName = page.locator(".card-body b");
        this.allProducts = page.locator(".card-body");
        this.cartlist = page.getByRole('listitem');
    }

    async addProducts(){

       
        await this.productsName.first().waitFor();
        const productsNames : string[] = await this.productsName.allTextContents();
        console.log(productsNames); 
        await this.allProducts.filter({hasText:'ZARA COAT 3'})
            .getByRole('button',{name:' Add To Cart'}).click(); 
        await this.cartlist.getByRole('button',{name:'  Cart '}).click();
  

    }

    

}