import { expect, type Locator, type Page } from '@playwright/test';

export class LoginPage{
 page :Page;
 email : Locator;
 password :Locator;
 loginBtn : Locator;

constructor(page :Page){
    this.page=page;
   this.email  = page.getByPlaceholder("email@example.com");
   this.password = page.getByPlaceholder("enter your passsword");
   this.loginBtn = page.locator("[value='Login']");

}

async goToweb(){
   await this.page.goto('https://rahulshettyacademy.com/client');
   
}

async login(username : string,password :string){
    await this.email.fill(username);
    await this.password.fill(password);
    await this.loginBtn.click();
    await this.page.waitForLoadState('networkidle');
    
}
}
