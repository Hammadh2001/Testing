import { expect, type Locator, Page} from "@playwright/test";

export class Cart_n_CheckoutPage{

page:Page;
itemsList : Locator;
checkoutBtn : Locator;
countries : Locator;
indiaBtn : Locator;
placeOrder : Locator;
mail : Locator;

    constructor(page:Page){
        this.page=page;
        this.itemsList = page.locator('.items');
        this.checkoutBtn = page.getByRole('button',{name:'Checkout'});
        this.countries = page.getByPlaceholder('Select Country');
        this.indiaBtn = page.getByRole('button',{name:' India'});
        this.placeOrder = page.getByText('Place Order ');
        this.mail = page.locator(".user__name [type='text']");

    }

    async cart(){
        await this.itemsList.first().waitFor();
        // await expect(this.itemsList.filter({hasText:'ZARA COAT 3'})
        // .getByText('ZARA COAT 3')).toBeVisible();
        await this.checkoutBtn.click();
 
  
    }

    async checkout(email :string){

        await this.countries.pressSequentially("ind", { delay: 150 }) 
        await this.indiaBtn.nth(1).click();
        await expect(this.mail.first()).toHaveText(email);
        await this.placeOrder.click();

    }

}