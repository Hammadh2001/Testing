import {Page} from "@playwright/test";
import { LoginPage } from "./LoginPage";
import { HomePage } from "./HomePage";
import { Cart_n_CheckoutPage } from "./Cart_n_CheckoutPage";  
import { Orders } from "./Orders";
import { OrderChecks2 } from "./OrderCheck2";

export class POManagerTS{
page:Page;
loginPage : LoginPage;
homePage : HomePage;
cartCheck : Cart_n_CheckoutPage;
orders : Orders;
orderChecks : OrderChecks2;


    constructor(page:Page){
        this.page=page
        this.loginPage = new LoginPage(this.page);
        this.homePage = new HomePage(this.page);
        this.cartCheck = new Cart_n_CheckoutPage(this.page);
        this.orders = new Orders(this.page);
        this.orderChecks = new OrderChecks2(this.page);

    }

    getLoginPage(){
        return this.loginPage;
    }

    getHomePage(){
        return this.homePage;
    }

    getCartnCheckout(){
        return this.cartCheck;
    }

    getOrders(){
        return this.orders;
    }

    getOrdersCheck2(){
        return this.orderChecks;
    }

}

