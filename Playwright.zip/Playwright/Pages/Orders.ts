import {expect , type Locator, type Page} from '@playwright/test';

export class Orders{
page:Page;
sucOrder:Locator;
orderID:Locator;
orderPage:Locator;
orderPage1:Locator;

    constructor (page:Page){

        this.page=page;
        this.sucOrder = page.getByText(' Thankyou for the order. ');
        this.orderID = page.locator(".em-spacer-1 .ng-star-inserted");
        this.orderPage = page.getByRole('button', {name:'ORDERS'});
        this.orderPage1 = page.locator("//button[@routerlink='/dashboard/myorders']");
    }

    async order() {

        await expect(this.sucOrder).toHaveText(" Thankyou for the order. ");
        const raw  = await this.orderID.textContent();
        const orderId = raw?.replace(/\|/g, '').trim() ?? '';

        console.log(orderId);
 
       // await this.orderPage.click();
       await this.orderPage1.click();

        return orderId;
       
    }

}