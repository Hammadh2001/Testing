const {test,expect} = require('@playwright/test');


test('UI Basic Test', async ({ page,context }) => {
  // Navigate to the example page
  await page.goto('https://rahulshettyacademy.com/loginpagePractise/');
  console.log(await page.title());

  await expect(page).toHaveTitle("LoginPage Practise | Rahul Shetty Academy");

  const username = page.locator('#username');
  const password = page.locator('input[type="password"]');
  const signin = page.locator('#signInBtn');
  const select = page.locator('select.form-control');

  await username.fill("rahulshettyacademy");
  await password.fill("learning");

  await select.selectOption('consult');
  await page.locator('span.radiotextsty').nth(1).click();
  await page.locator('#okayBtn').click();

  const [newPage] = await Promise.all(
    [context.waitForEvent('page'),
      page.locator("[href*='documents-request']").click(),
    ]
  );

   console.log(await newPage.locator('p.red').textContent());



  //await signin.click();
  
 // console.log(await page.locator('[style*="block"]').textContent());
 // await expect(page.locator("[style*='block']")).toContainText('Incorrect');

//await page.pause();
});