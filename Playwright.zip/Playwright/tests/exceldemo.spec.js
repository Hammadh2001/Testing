const excel = require('exceljs');
const {test,expect} = require('@playwright/test');

async function excelFunc(findText,changeValText,change,path)
{

const workbook = new excel.Workbook();
await workbook.xlsx.readFile(path);
const sheet = workbook.getWorksheet('Sheet1');

const output = await readexcel(sheet,findText);

const changeVal = sheet.getCell(output.roww,output.coll + change.colcount);
changeVal.value=changeValText;
await workbook.xlsx.writeFile(path);

}

async function readexcel(sheet,findText){

    let output = {roww:-1,coll:-1};
    sheet.eachRow((row,rowNumber) => {

    row.eachCell((cell,cellNumber) => {
        if (cell.value == findText) {
                output.roww = rowNumber;
                output.coll = cellNumber;
        };
    })

})
    return output;
}



test('Excel Case', async({page}) => {

    const text = "Mango";
    const price = '1234';
   await page.goto("https://rahulshettyacademy.com/upload-download-test/index.html");
   const downloadPromise = page.waitForEvent('download');
    await page.getByRole('button',{name:'Download'}).click();

   const filePath = "C:/Users/2282491/Downloads/download.xlsx";
    const download = await downloadPromise;
 
   await download.saveAs(filePath);
   await excelFunc(text,price,{rowcount:0,colcount:2},filePath);
   

   //await page.locator("#fileinput").click();
   await page.locator("#fileinput").setInputFiles(filePath);

   const desiredrow = await page.getByRole('row').filter({has:page.getByText(text)});
   await expect(desiredrow.locator("#cell-4-undefined")).toContainText(price);
   page.pause();


})
