import {test,expect,} from '@playwright/test';
const { networkInterfaces } = require('os');

import { POManagerTS } from '../Pages/POManager';

const jsonData = JSON.parse(JSON.stringify(require("C:/Users/2282491/OneDrive - Cognizant/Desktop/JS/Playwright/Pages/data.json")));


test(`eTe script for ${jsonData.product}`, async({page}) => {

   const pomanager = new POManagerTS(page);
    
   const loginpage = pomanager.getLoginPage();
   await loginpage.goToweb();
   await loginpage.login(jsonData.name,jsonData.password);

   const homepage = pomanager.getHomePage();
   await homepage.addProducts();

   const cartCheckout = pomanager.getCartnCheckout();
   await cartCheckout.cart();
   await cartCheckout.checkout(jsonData.name); 
 
   const orders = pomanager.getOrders();
   const orderid = (await orders.order())!
   console.log("-----------"+ orderid +"-------------");
   
   const orderCheck = pomanager.getOrdersCheck2();
   await orderCheck.ordercheck(orderid);
   await orderCheck.orderIDverify(orderid);
 
//await page.pause();
});

