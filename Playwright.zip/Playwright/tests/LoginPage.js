class LoginPage{

constructor(page){
    this.page=page;
   this.email = page.getByPlaceholder("email@example.com");
   this.password = page.getByPlaceholder("enter your passsword");
   this.loginBtn = page.locator("[value='Login']");

}

async goToweb(){
   await this.page.goto('https://rahulshettyacademy.com/client');
   
}

async login(username,password){
    await this.email.fill(username);
    await this.password.fill(password);
    await this.loginBtn.click();
    
}
}

module.exports = {LoginPage};