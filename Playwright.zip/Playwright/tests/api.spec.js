const {test,expect,request} = require('@playwright/test');

const Loginpayload = {userEmail:"hamdh@gmail.com",userPassword:"Helloworld1"};
let token;
const zaraPayload = {orders:[{country:"India",productOrderedId:"6960eac0c941646b7a8b3e68"}]};
let orderid;

test.beforeAll(async ()=>{

    const apiReq = await request.newContext({
        ignoreHTTPSErrors:true
    });
    const loginResponse = await apiReq.post("https://rahulshettyacademy.com/api/ecom/auth/login",
        {
            data:Loginpayload

    });

    expect(loginResponse.ok()).toBeTruthy();
    const loginresponsejson = await loginResponse.json();
    token = loginresponsejson.token;

    console.log(token);

    const orderreqapi = await request.newContext({
        ignoreHTTPSErrors:true
    });
    const orderResponse = await orderreqapi.post("https://rahulshettyacademy.com/api/ecom/order/create-order",{
        data:zaraPayload,
        headers:{
            "Authorization" : token,
            "Content-Type" : 'application/json'
        },
    });

    const orderjson =await orderResponse.json();
    orderid = orderjson.orders[0];



});

test("eTe script", async({page}) => {

    await page.addInitScript(value =>{
        window.localStorage.setItem('token',value)
    },token);


    await page.goto("https://rahulshettyacademy.com/client");
 
   await page.locator("button[routerlink*='myorders']").click();
   await page.locator("tbody").waitFor();
   const rows = await page.locator("tbody tr");
 
 
   for (let i = 0; i < await rows.count(); ++i) {
      const rowOrderId = await rows.nth(i).locator("th").textContent();
      if (orderid.includes(rowOrderId)) {
         await rows.nth(i).locator("button").first().click();
         break;
      }
   }
   const orderIdDetails = await page.locator(".col-text").textContent();
   expect(orderid.includes(orderIdDetails)).toBeTruthy();
 
await page.pause();
});