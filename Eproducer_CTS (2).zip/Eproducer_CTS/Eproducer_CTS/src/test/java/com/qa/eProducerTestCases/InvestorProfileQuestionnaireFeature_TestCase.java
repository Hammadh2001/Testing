package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class InvestorProfileQuestionnaireFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public InvestorProfileQuestionnaireFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateInvestorProfileQuestionnaireFeature
	Purpose    : To validate the Investor Profile Questionnaire feature
	Author     : 25-Jun-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getQuestionnaireData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("QuestionnaireData");
		return data;
	}
	@Test(dataProvider="getQuestionnaireData")
	public void validateInvestorProfileQuestionnaireFeature(String userName, String passWord, String ProducerID, String planNumber,
			String option) throws InterruptedException {
		extentTest = extent.createTest("Investor Profile Questionnaire For "+option+" Scores");
		EProduceractions.loginToAppHONew(userName, passWord);
		
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.verifyInvestorProfileQuestionnaire(ProducerID, planNumber, option);
		
	}
	
	
	
	
	
	
}
