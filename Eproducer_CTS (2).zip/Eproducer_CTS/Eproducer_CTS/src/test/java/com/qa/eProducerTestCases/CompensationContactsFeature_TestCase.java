package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class CompensationContactsFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public CompensationContactsFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateCompensationContactsFeature
	Purpose    : To validate Compensation Contacts feature 
	Author     : 08-Jun-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getCmpnstnContactsData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("CompensationContactsData");
		return data;
	}
	@Test(dataProvider="getCmpnstnContactsData")
	public void validateCompensationContactsFeature(String userName, String passWord, String ProdSearchBy, String criteriaTxt) throws InterruptedException {
		extentTest = extent.createTest("Compensation Contacts and EFT Form Features");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyCompensationContactsFeature(ProdSearchBy, criteriaTxt);
			
	}
	
	
	
	
	
	
}
