package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class Form5500Feature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public Form5500Feature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateForm5500Feature
	Purpose    : To validate Form 5500 feature
	Author     : 5-Jan-2021 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getForm5500Data() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("Form5500Data");
		return data;
	}
	@Test(dataProvider="getForm5500Data")
	public void validateForm5500Feature(String username, String password, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Form 5500 Feature");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyForm5500();
		
	}
	
	
	
	
	
	
}
