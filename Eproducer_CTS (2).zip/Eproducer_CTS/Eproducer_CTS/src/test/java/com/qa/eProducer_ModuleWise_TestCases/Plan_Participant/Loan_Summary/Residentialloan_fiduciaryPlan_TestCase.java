package com.qa.eProducer_ModuleWise_TestCases.Plan_Participant.Loan_Summary;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class Residentialloan_fiduciaryPlan_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public Residentialloan_fiduciaryPlan_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : Residentialloan_fiduciaryPlan
	Purpose    : To validate the Residential Loan feature for fiduciary Plan 
	Author     : 13-Apr-2023 by Arpan Roy
	***********************************************************************/
	@DataProvider
	public Object[][] getFiduciaryPlanData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("Resdentialloan_fidplan");
		return data;
	}
	@Test(dataProvider="getFiduciaryPlanData")
	public void validateDownlaodDivisioanlPlanReportFeature(String userName, String passWord, String planNumber, String SSN) throws InterruptedException, IOException {
		extentTest = extent.createTest("Validate the Residential Loan feature for fiduciary Plan");
		EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.verifyresidentialloanforfiduciaryPlan(planNumber,SSN);
		
	}
	
	
	
	
	
	
}
