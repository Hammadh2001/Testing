package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ParticipantElectronicReport_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ParticipantElectronicReport_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateParticipantElectronicReportFeature
	Purpose    : To validate the Participant Electronic Report feature 
	Author     : 17-Nov-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getPrtcpntElctrncData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ParticipantElectronicReportData");
		return data;
	}
	@Test(dataProvider="getPrtcpntElctrncData")
	public void validateParticipantElectronicReportFeature(String userName, String passWord, String planNumber, String fromDate,
			String toDate) throws InterruptedException {
		extentTest = extent.createTest("Participant Electronic Activity Report Feature");
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyParticipantElectronicReport(fromDate, toDate);
		
	}
	
	
	
	
	
	
}
