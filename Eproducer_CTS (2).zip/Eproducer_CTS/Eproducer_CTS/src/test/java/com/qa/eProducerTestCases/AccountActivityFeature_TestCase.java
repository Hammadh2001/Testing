package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class AccountActivityFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public AccountActivityFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAccountActivityFeature
	Purpose    : To validate Account Activity feature
	Author     : 12-Nov-2020 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getAccountActivityData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("AccountActivityData");
		return data;
	}
	@Test(dataProvider="getAccountActivityData")
	public void validateAccountActivityFeature(String username, String password, String planNumber,
			String reportType, String incorrectFrmtDate, String futureDate, String vldFromDate, String vldToDate) throws InterruptedException {
		extentTest = extent.createTest("Account Activity Feature");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyAccountActivityFeature(reportType, incorrectFrmtDate, futureDate, vldFromDate, vldToDate);
		
	}
	
	
	
	
	
	
}
