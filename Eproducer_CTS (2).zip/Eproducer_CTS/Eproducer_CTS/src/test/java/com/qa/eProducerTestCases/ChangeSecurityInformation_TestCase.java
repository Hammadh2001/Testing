package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.eProducerActions.EProducerRegistrationActions;
import com.qa.utils.TestUtils;

public class ChangeSecurityInformation_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ChangeSecurityInformation_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateChangeSecurityInformationFeature
	Purpose    : To validate the Security information changes feature
	Author     : 11-Jan-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getChangeSecInfoData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ChangeSecurityInfoData");
		return data;
	}
	@Test(dataProvider="getChangeSecInfoData")
	public void validateChangeSecurityInformationFeature(String username, String password, String userIDChange, String newUserID, String confirmNewUsrID, 
			String newPswd, String confirmNewPswd, String selQuestion, String secAnswer) throws InterruptedException {
		extentTest = extent.createTest("Change Security Information Feature");
		EProduceractions.loginToAppNonHONew(username, password);
		EProduceractions.verifyChangeSecurityInformation(userIDChange, newUserID, confirmNewUsrID, newPswd, confirmNewPswd, selQuestion, secAnswer, password);
		
	}
	
	
	
	
	
	
}
