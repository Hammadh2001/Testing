package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class DemosFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public DemosFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateDemosFeature
	Purpose    : To validate Demos feature
	Author     : 04-Nov-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getDemosData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("DemosData");
		return data;
	}
	
	@Test(dataProvider="getDemosData")
	public void validateDemosFeature(String userName, String passWord) throws InterruptedException {
		extentTest = extent.createTest("Demos Feature");
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyDemosFeature();
		
	}
	
	
	
	
	
	
}
