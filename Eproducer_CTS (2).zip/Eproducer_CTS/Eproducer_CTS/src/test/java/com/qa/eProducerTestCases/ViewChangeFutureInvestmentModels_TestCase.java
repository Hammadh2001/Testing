package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ViewChangeFutureInvestmentModels_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ViewChangeFutureInvestmentModels_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateViewChangeFutureInvestmentModelFeature
	Purpose    : To validate the View/Change Future Investment Model feature 
	Author     : 17-Mar-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getViewInvsmtModData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ViewChangeInvsmtModData");
		return data;
	}
	@Test(dataProvider="getViewInvsmtModData")
	public void validateViewChangeFutureInvestmentModelFeature(String userName, String passWord, String prodID, String planNumber,
			String prtcpntID) throws InterruptedException {
		extentTest = extent.createTest("View/Change Future Investment Model feature");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyViewChangeInvestmentModels(prodID, planNumber, prtcpntID);
		
	}
	
	
	
	
	
	
}
