package com.qa.eProducerTestCases;

import java.awt.AWTException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class DownloadingSSRSReportViaeSites_Testcase extends TestBase {
	EProducerActions EProduceractions;

	public DownloadingSSRSReportViaeSites_Testcase() {
		super();
	} 
	@BeforeMethod
	public void setUp() {
		initializationtrials();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateDownloadingSSRSReportViaeSitesFeature
	Purpose    : To validate the Downloading SSRS Report Viae Sites 
	Author     : 13-Aug-2024 Emma Rani
	***********************************************************************/
	@DataProvider

	public Iterator<Object[]> getURLValidationData() throws IOException {
		Object data[][] = TestUtils.geteProducerTestData("UrlValidation");
		List<Object[]> finalData = new ArrayList<>();
		for (int i=0; i<data.length; i++) {
			if (data[i][0].toString().equalsIgnoreCase("yes")) {
				finalData.add(data[i]);
			}
		}
		return finalData.iterator();
	}
	@Test(dataProvider="getURLValidationData")
	public void validateDownlaodURLValidationReportFeature(String Execute,String URLReports,String userName, String passWord,String planNumber,String prodID,String Reportname,String Date,
			String fromDate, String toDate,String fileOptn) throws InterruptedException, AWTException, IOException {
		extentTest = extent.createTest("Download URL Validation SSRS Report Feature "+Reportname);
		EProduceractions.loginToApp_HOUsrV(URLReports,userName, passWord);
		EProduceractions.verifyDownlaodURLValidationReport(URLReports,planNumber,prodID,Reportname,Date);
		//selectProducerID(prodID);
		if( Reportname.equals("FeedbackDeferral")) {
			EProduceractions.verifyDownlaodFeedBackReport(planNumber,prodID,Reportname,Date,fromDate,toDate,fileOptn);
		}
		else if ( Reportname.equals("HistoricalFeedbackFile")) {
			EProduceractions.verifyHistoricalFeedbackFileReport(planNumber,prodID,fromDate,toDate,Reportname,Date);
			}
		else if ( Reportname.equals("Long-TermPartTimereport")) {
			EProduceractions.verifyLongTermPartTimereport(planNumber,prodID,Reportname,Date);
		}
	}

}
