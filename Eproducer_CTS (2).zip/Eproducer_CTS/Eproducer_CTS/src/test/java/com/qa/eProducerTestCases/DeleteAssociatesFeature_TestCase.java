package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class DeleteAssociatesFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public DeleteAssociatesFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateDeleteAssociatesFeature
	Purpose    : To validate Deleting Associates feature 
	Author     : 17-Mar-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getDeleteAssociatesData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("DeleteAssociatesData");
		return data;
	}
	@Test(dataProvider="getDeleteAssociatesData")
	public void validateDeleteAssociatesFeature(String username, String password) throws InterruptedException {
		extentTest = extent.createTest("Delete Associates feature");
	//	EProduceractions.loginToAppNonHO(username, password);
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.verifyDeleteAssociatesFeature();
		
	}
	
	
	
	
	
	
}
