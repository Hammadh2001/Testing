package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class InvestmentSalesSupport_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public InvestmentSalesSupport_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateInvestmentSalesSupportFeature
	Purpose    : To validate Investment Sales Support feature
	Author     : 10-Nov-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getInvstmntSalesData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("InvstmntSalesSupportData");
		return data;
	}
	
	@Test(dataProvider="getInvstmntSalesData")
	public void validateInvestmentSalesSupportFeature(String userName, String passWord) throws InterruptedException {
		extentTest = extent.createTest("Investment Sales Support Feature");
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyInvestmentSalesSupportLinks();
		
	}
	
	
	
	
	
	
}
