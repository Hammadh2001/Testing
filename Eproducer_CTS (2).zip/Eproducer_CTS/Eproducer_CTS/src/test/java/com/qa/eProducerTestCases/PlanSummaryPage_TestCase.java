package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class PlanSummaryPage_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public PlanSummaryPage_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validatePlanSummaryPage
	Purpose    : To validate Plan Summary page
	Author     : 6-Jan-2021 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getPlanSummaryData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("PlanSummaryData");
		return data;
	}
	@Test(dataProvider="getPlanSummaryData")
	public void validatePlanSummaryPage(String username, String password, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Plan Summary Page Feature");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyPlanSummaryPage();
	}
	
	
	
	
	
	
}
