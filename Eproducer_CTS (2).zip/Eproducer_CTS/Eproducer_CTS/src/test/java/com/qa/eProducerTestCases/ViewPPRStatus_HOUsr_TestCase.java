package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ViewPPRStatus_HOUsr_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ViewPPRStatus_HOUsr_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateViewPPRStatus_HOUser
	Purpose    : To validate the functionality of viewing the PPR status by HO user 
	Author     : 29-Jun-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getViewPPRStatusData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ViewPPRStatusData");
		return data;
	}
	@Test(dataProvider="getViewPPRStatusData")
	public void validateViewPPRStatus_HOUser(String userName, String passWord, String budgetCode, String fromDate) throws InterruptedException {
		extentTest = extent.createTest("View PPR Status by HO User");
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyHOViewPPRStatus(budgetCode, fromDate);
		
	}
	
	
	
	
	
	
}
