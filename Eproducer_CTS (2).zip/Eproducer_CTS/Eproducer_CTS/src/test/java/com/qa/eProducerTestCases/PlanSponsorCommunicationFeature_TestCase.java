package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class PlanSponsorCommunicationFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public PlanSponsorCommunicationFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validatePlanSponsorCommunicationFeature
	Purpose    : To validate Plan Sponsor Communication feature
	Author     : 03-Nov-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getPlanSponsorCommunicationData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("PlanSponsorComnctnData");
		return data;
	}
	
	@Test(dataProvider="getPlanSponsorCommunicationData")
	public void validatePlanSponsorCommunicationFeature(String userName, String passWord) throws InterruptedException {
		extentTest = extent.createTest("Plan Sponsor Communication Feature");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyPlanSponsorCommunicationFeature();
		
	}
	
	
	
	
	
	
}
