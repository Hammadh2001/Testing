package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class MonthlyCommissionsFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public MonthlyCommissionsFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateMonthlyCommissionsFeature
	Purpose    : To validate monthly commissions feature 
	Author     : 02-Nov-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getMonthlyCommsnData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("MonthlyCommissionsData");
		return data;
	}
	@Test(dataProvider="getMonthlyCommsnData")
	public void validateMonthlyCommissionsFeature(String userName, String passWord, String ProdSearchBy, String criteriaTxt, String prodNum) throws InterruptedException {
		extentTest = extent.createTest("Monthly Commissions Feature");
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyMonthlyCommissionsFeature(ProdSearchBy, criteriaTxt, prodNum);
		
	}
	
	
	
	
	
	
}
