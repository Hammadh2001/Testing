package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ViewParticipantDataAddColumns_TestCase extends TestBase {
	
	EProducerActions EProduceractions;

	public  ViewParticipantDataAddColumns_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		//initialization();
		initializationtrial();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAdditionalColumn
	Purpose    : To validate participant New column
	Author     : 10-April-2024 by Emma Rani 
	***********************************************************************/
	@DataProvider
	public Object[][] getViewPartcpntListData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ViewParticipantListCol");
		return data;
	}
	@Test(dataProvider="getViewPartcpntListData")
	public void validateViewParticipantListColFeature(String username, String password, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("View Participant List Columns Feature");
		//EProduceractions.loginToApp_HOUsr(username, password);
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionalityforAddNewColumn(planNumber);
	    EProduceractions.verifyParticipantListCol(planNumber);
	
		
			
		}
}
