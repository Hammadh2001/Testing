package com.qa.eProducer_ModuleWise_TestCases.Security;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.eProducerActions.EProducerRegistrationActions;
import com.qa.utils.TestUtils;

public class ForgotMyUserIDandValidations_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ForgotMyUserIDandValidations_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateForgotMyUserIDandValidations
	Purpose    : To validate the Forgot My User ID and Validations
	Author     : 22-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getForgotUsrData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ForgotMyUsrIDData");
		return data;
	}
	@Test(dataProvider="getForgotUsrData")
	public void validateForgotMyUserIDandValidations(String invalidEmailID, String validEmailID) throws Exception {
		extentTest = extent.createTest("Forgot My UserID and Validations feature");
		EProduceractions.verifyForgotMyUsrIDValidations(invalidEmailID, validEmailID);
	}
	
	
	
	
	
	
}
