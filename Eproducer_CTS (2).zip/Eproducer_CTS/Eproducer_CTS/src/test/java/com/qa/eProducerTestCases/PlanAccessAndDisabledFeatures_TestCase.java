package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class PlanAccessAndDisabledFeatures_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public PlanAccessAndDisabledFeatures_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validatePlanAccessAndDisabledFeatures
	Purpose    : To validate Plan Access and Disabled Features
	Author     : 10-Jun-2021 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getPlanAccessData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("PlanAccessData");
		return data;
	}
	@Test(dataProvider="getPlanAccessData")
	public void validatePlanAccessAndDisabledFeatures(String planStatus, String username, String password, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Plan Access and Disabled Feature for "+planStatus + "Plan" );
		//EProduceractions.loginToAppNonHO(username, password);
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.verifyPlanAccessAndDisabledFeatures(planStatus, planNumber);
	}
	
	
	
	
	
	
}
