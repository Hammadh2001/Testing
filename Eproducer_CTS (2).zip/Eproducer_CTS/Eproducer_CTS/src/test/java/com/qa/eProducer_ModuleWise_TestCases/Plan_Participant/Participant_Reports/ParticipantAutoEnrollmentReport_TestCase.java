package com.qa.eProducer_ModuleWise_TestCases.Plan_Participant.Participant_Reports;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ParticipantAutoEnrollmentReport_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ParticipantAutoEnrollmentReport_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validatePrtcpntAutoEnrollmentReportFeature
	Purpose    : To validate the auto enrollment report feature 
	Author     : 15-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getAutoEnrollmentReportData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("AutoEnrollmentReportData");
		return data;
	}
	@Test(dataProvider="getAutoEnrollmentReportData")
	public void validatePrtcpntAutoEnrollmentReportFeature(String userName, String passWord, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Participant Auto Enrollment Report download feature");
		EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.verifyPrtcpntAutoEnrollmentReport(planNumber);
		
	}
	
	
	
	
	
	
}
