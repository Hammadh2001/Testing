package com.qa.eProducer_ModuleWise_TestCases.Investments;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class InvestmentAdvisorSupport_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public InvestmentAdvisorSupport_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateInvstmtAdvsrsuprtPageLinks
	Purpose    : To validate the Loan Summary of a plan 
	Author     : 1-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getInvsmtAdvsrSuprtData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("InvsmtAdvsrSuprtData");
		return data;
	}
	@Test(dataProvider="getInvsmtAdvsrSuprtData")
	public void validateInvstmtAdvsrsuprtPageLinks(String userName, String passWord) throws InterruptedException {
		extentTest = extent.createTest("Investment Advisor Support page links functionality");
		EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.verifyInvsmtAdvSuprtPageLinks();
		
	}
	
	
	
	
	
	
}
