package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ImportantDocumentProNvestAgreement_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ImportantDocumentProNvestAgreement_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateImportantDocumentProNvestAgreementFeature
	Purpose    : To validate Important Document ProNvest Agreement feature
	Author     : 14-Dec-2023 by Priya Natarajan 
	***********************************************************************/
	@DataProvider
	public Object[][] getImportantDocumentProNvestAgreementData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ImpDocProNvestData");
		return data;
	}
	@Test(dataProvider="getImportantDocumentProNvestAgreementData")
	public void validateImportantDocumentProNvestAgreementFeature(String username, String password, String planNumber,
			String PM696) throws InterruptedException {
		extentTest = extent.createTest("Important Document ProNvest Agreement Feature");
		//EProduceractions.loginToApp_HOUsr(username, password);
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyImpDocsProNvestAgreementFeature(PM696);
	}
	
	
	
	
	
	
}
