package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class UnitValuesFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public UnitValuesFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateUnitValueOrSharesFeature
	Purpose    : To validate Unit Values/Shares Feature
	Author     : 6-Jan-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getUnitValuesData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("UnitValuesData");
		return data;
	}
	
	@Test(dataProvider="getUnitValuesData")
	public void validateUnitValueOrSharesFeature(String userName, String passWord, String planNumber,
			String futureDate, String invldDateFormat, String validDate, String month, String year) throws InterruptedException {
		extentTest = extent.createTest("Unit Values/Shares Feature");
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyUnitValuesFeature(futureDate, invldDateFormat, validDate, month, year);
		
	}
	
	
	
	
	
	
}
