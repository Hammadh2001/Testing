package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class InforceOrdering_New_Plan_Installation_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public InforceOrdering_New_Plan_Installation_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateInforceOrderingNewPlanInstallation
	Purpose    : To validate Inforce Ordering for New Plan Installation
	Author     : 17-Nov-2020 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getInforceOrdrNewPlanData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("InforceOrderingNewPlan");
		return data;
	}
	@Test(dataProvider="getInforceOrdrNewPlanData")
	public void validateInforceOrderingNewPlanInstallation(String username, String password, String ordrEmail,
			String plnNumb, String whyOrdering) throws InterruptedException {
		extentTest = extent.createTest("Inforce Ordering - New Plan installation feature");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.verifyInforceOrderingPlans(ordrEmail, plnNumb, whyOrdering);	
	}
	
	
	
	
	
	
}
