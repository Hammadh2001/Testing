package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class PendingTransactionsNoProcess_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public PendingTransactionsNoProcess_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validatePendingTransactionFeature
	Purpose    : To validate Beneficiary Pending transactions page
	Author     : 11-Jan-2021 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getPendingTransactionData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("PendingTransactionData");
		return data;
	}
	@Test(dataProvider="getPendingTransactionData")
	public void validatePendingTransactionFeature(String username, String password, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Beneficiary Pending Transaction Page");
		//EProduceractions.loginToApp_HOUsr(username, password);
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyPendingTransactionProcessPage();
	}

	
	
	
}
