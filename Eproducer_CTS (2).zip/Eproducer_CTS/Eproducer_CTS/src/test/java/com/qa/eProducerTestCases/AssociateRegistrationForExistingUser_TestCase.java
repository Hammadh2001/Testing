package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.eProducerActions.EProducerRegistrationActions;
import com.qa.utils.TestUtils;

public class AssociateRegistrationForExistingUser_TestCase extends TestBase {
	EProducerRegistrationActions EProducerRegistrationactions;

	public AssociateRegistrationForExistingUser_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProducerRegistrationactions = new EProducerRegistrationActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAssociateRegistrationForExistingUser
	Purpose    : To validate the Associate Registration Process for the existing user
	Author     : 21-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getAssociateRegData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("AssociateRgstrnExstngUsrData");
		return data;
	}
	@Test(dataProvider="getAssociateRegData")
	public void validateAssociateRegistrationForExistingUser(String regType, String prodID, String invalidAccessCode, 
			String validAccessCode, String CreateOrExstng, String invalidExstngUsrID, String invalidExstngPwd, 
			String validExstngUsrID, String validExstngPwd) throws InterruptedException {
		extentTest = extent.createTest("Associate Registration for a  Existing User");
		EProducerRegistrationactions.navigateToeProducerRegistrationPage();
		EProducerRegistrationactions.selectTypeofRegistration(regType);
		EProducerRegistrationactions.verifyAssociateRegistrationFlow(prodID, invalidAccessCode, validAccessCode, CreateOrExstng);
		EProducerRegistrationactions.verifyUserisRegistered();
		EProducerRegistrationactions.verifyExistingUserIDPwdFlds(invalidExstngUsrID, invalidExstngPwd, validExstngUsrID, validExstngPwd);
		EProducerRegistrationactions.verifySuccessfullRegistration();
				
	}
	
	
	
	
	
	
}
