package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class LTPTEmployeeDataReview_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public LTPTEmployeeDataReview_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateLTPTEmployeeDataReviewFeature
	Purpose    : To validate LTPT Employee Data Review feature
	Author     : 02-Feb-2024 by Priya Natarajan 
	***********************************************************************/
	@DataProvider
	public Object[][] getLTPTEmployeeDataReviewData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("LTPTEmployeeDataReview");
		return data;
	}
	@Test(dataProvider="getLTPTEmployeeDataReviewData")
	public void validateLTPTEmployeeDataReviewFeature(String username, String password, String planNumber,
			String PM702) throws InterruptedException {
		extentTest = extent.createTest("eProducer LTPT Employee Data Review Feature");
		//EProduceractions.loginToApp_HOUsr(username, password);
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyLTPTEmployeeDataReview(PM702);
		//EProduceractions.verifyImpDocsProNvestAgreementFeature(PM696);
	}
	
	
	
	
	
	
}
