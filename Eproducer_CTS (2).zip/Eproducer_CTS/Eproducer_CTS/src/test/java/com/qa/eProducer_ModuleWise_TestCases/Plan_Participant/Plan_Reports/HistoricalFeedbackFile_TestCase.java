package com.qa.eProducer_ModuleWise_TestCases.Plan_Participant.Plan_Reports;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class HistoricalFeedbackFile_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public HistoricalFeedbackFile_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateHistoricalFeedbackFileFeature
	Purpose    : To validate the historical feedback file report download 
	Author     : 9-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getHistFBFData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("HistoricalFBFileData");
		return data;
	}
	@Test(dataProvider="getHistFBFData")
	public void validateHistoricalFeedbackFileFeature(String userName, String passWord, String planNumber, String fromDate, String toDate) throws InterruptedException {
		extentTest = extent.createTest("Historical Feedback File download feature");
		EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.verifyHistoricalFeedbackFile(planNumber, fromDate, toDate);
		
	}
	
	
	
	
	
	
}
