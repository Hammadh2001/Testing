package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class CommissionsSearchFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public CommissionsSearchFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateCommissionsSearchFeature
	Purpose    : To validate commissions search feature 
	Author     : 22-Jun-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getCommsnSearchData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("CommissionsSearchData");
		return data;
	}
	
	@Test(dataProvider="getCommsnSearchData")
	public void validateCommissionsSearchFeature(String userName, String passWord, String ProdSearchBy, String criteriaTxt) throws InterruptedException {
		extentTest = extent.createTest("Commissions Search Feature -" + ProdSearchBy);
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyCommissionSearchPage(ProdSearchBy, criteriaTxt);
		
	}
	
	
	
	
	
	
}
