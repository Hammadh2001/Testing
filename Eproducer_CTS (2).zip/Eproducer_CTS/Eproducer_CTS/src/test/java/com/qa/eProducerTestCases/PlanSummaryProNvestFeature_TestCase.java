package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class PlanSummaryProNvestFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public PlanSummaryProNvestFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validatePlanSummaryProNvestFeature
	Purpose    : To validate Investment Tab and PlanSummary ProNvest feature
	Author     : 14-Dec-2023 by Priya Natarajan 
	***********************************************************************/
	@DataProvider
	public Object[][] getPlanSummaryProNvestData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("PlanSummaryProNvestData");
		return data;
	}
	@Test(dataProvider="getPlanSummaryProNvestData")
	public void validatePlanSummaryProNvestFeature(String username, String password, String planNumber,
			String PM696) throws InterruptedException {
		extentTest = extent.createTest("Investment Tab and PlanSummary ProNvest Feature");
		//EProduceractions.loginToApp_HOUsr(username, password);
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyPlanSummaryProNvestFeature(PM696);
	}
	
	
	
	
	
	
}
