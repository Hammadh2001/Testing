package com.qa.eProducer_ModuleWise_TestCases.Plan_Participant.Participant;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ParticipantStatements_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ParticipantStatements_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateParticipantStatements
	Purpose    : To validate the Participant Statements feature 
	Author     : 15-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getPrtcpntStmntData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ParticipantStatementsData");
		return data;
	}
	@Test(dataProvider="getPrtcpntStmntData")
	public void validateParticipantStatements(String userName, String passWord, String planNumber, String prtcpntID) throws InterruptedException {
		extentTest = extent.createTest("Participant Statements Feature");
		EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.verifyParticipantStatements(planNumber, prtcpntID);
		
	}
	
	
	
	
	
	
}
