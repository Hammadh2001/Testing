package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class AdvisorPlanFeeReportPage_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public AdvisorPlanFeeReportPage_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		//initialization();
		initializationtrial();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAdvisorPlanFeeReportFeature
	Purpose    : To validate Advisor Fee Report feature
	Author     : 28-Feb-2024 by Priya Natarajan 
	***********************************************************************/
	@DataProvider
	public Object[][] getAdvisorFeeData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("AdvisorPlanFee");
		return data;
	}
	@Test(dataProvider="getAdvisorFeeData")
	public void validateAdvisorPlanFeeReportFeature(String username, String password, String planNumber,
			String PM696) throws InterruptedException {
		extentTest = extent.createTest("eProducer Advisor Plan Fee report Feature");
		
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyAdvisorPlanFee(planNumber, PM696);
		//EProduceractions.verifyImpDocsProNvestAgreementFeature(PM696);
	}
	
	
	
	
	
	
}
