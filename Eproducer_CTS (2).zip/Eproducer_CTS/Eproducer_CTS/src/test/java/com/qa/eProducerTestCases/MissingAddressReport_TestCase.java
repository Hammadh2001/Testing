package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class MissingAddressReport_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public MissingAddressReport_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateMissingAddressReportFeature
	Purpose    : To validate Missing Address Report
	Author     : 7-Jan-2021 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getMissingAddressData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("MissingAddressData");
		return data;
	}
	@Test(dataProvider="getMissingAddressData")
	public void validateMissingAddressReportFeature(String username, String password, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Missing Address Report");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyMissingAddressReportPage();
	}
	
	
	
	
	
	
}
