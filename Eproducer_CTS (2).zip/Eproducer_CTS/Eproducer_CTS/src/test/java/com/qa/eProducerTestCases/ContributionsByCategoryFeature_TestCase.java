package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ContributionsByCategoryFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ContributionsByCategoryFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateContributionsByCategoryFeature
	Purpose    : To validate Contributions By Category feature
	Author     : 13-Nov-2020 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getCntrbtnCtgryData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ContributionCategoryData");
		return data;
	}
	@Test(dataProvider="getCntrbtnCtgryData")
	public void validateContributionsByCategoryFeature(String username, String password, String planNumber,
			String reportType, String incorrectFrmtDate, String futureDate, String vldFromDate, String vldToDate) throws InterruptedException {
		extentTest = extent.createTest("Contributions By Category Feature");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyContributionByCategoryFeature(reportType, incorrectFrmtDate, futureDate, vldFromDate, vldToDate);		
	}
	
	
	
	
	
	
}
