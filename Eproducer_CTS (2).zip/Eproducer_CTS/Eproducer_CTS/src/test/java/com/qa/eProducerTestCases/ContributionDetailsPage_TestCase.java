package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ContributionDetailsPage_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ContributionDetailsPage_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateContributionDetailsPage
	Purpose    : To validate Contribution Details Page
	Author     : 11-Nov-2020 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getContributionDetailData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ContributionDetailsData");
		return data;
	}
	@Test(dataProvider="getContributionDetailData")
	public void validateContributionDetailsPage(String username, String password, String planNumber,
			String reportType, String incorrectFrmtDate, String futureDate, String vldFromDate, String vldToDate) throws InterruptedException {
		extentTest = extent.createTest("Contribution Details Page");
	
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyContributionDetailsFeature(reportType, incorrectFrmtDate, futureDate, vldFromDate, vldToDate);
		
	}
	
	
	
	
	
	
}
