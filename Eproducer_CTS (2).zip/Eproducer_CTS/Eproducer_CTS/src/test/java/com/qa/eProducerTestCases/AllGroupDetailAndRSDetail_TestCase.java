package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class AllGroupDetailAndRSDetail_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public AllGroupDetailAndRSDetail_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAllGroupDetailAndRSDetail
	Purpose    : To validate All Group Detail and RS Detail 
	Author     : 16-Jun-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getAllGroupRSDetailData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("AllGroupAndAllRSDetailData");
		return data;
	}
	@Test(dataProvider="getAllGroupRSDetailData")
	public void validateGroupandRSCompensationSummary(String userName, String passWord, String ProdSearchBy, String criteriaTxt) throws InterruptedException {
		extentTest = extent.createTest("All Group Detail and All Retirement Services Detail ");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyAllGroupAndRetirementServicesDetail(ProdSearchBy, criteriaTxt);
			
	}
	
	
	
	
	
	
}
