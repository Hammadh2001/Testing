package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ServiceRolesPage_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ServiceRolesPage_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateServiceRolesPage
	Purpose    : To validate Service Roles page
	Author     : 7-Jan-2021 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getServiceRolesData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ServiceRolesData");
		return data;
	}
	@Test(dataProvider="getServiceRolesData")
	public void validateServiceRolesPage(String username, String password, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Service Roles Page");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyServiceRolesFeature();
	}
	
	
	
	
	
	
}
