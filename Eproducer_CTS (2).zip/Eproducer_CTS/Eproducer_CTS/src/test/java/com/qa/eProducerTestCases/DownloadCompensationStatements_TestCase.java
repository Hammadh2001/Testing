package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class DownloadCompensationStatements_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public DownloadCompensationStatements_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateDownloadCompensationStatements
	Purpose    : To validate Download Compensation Statements feature 
	Author     : 11-Jun-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getCmpnstnStmntData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("DownloadCompensationStmntData");
		return data;
	}
	@Test(dataProvider="getCmpnstnStmntData")
	public void validateDownloadCompensationStatements(String userName, String passWord, String ProdSearchBy, String criteriaTxt) throws InterruptedException {
		extentTest = extent.createTest("Download Compensation Statement Feature");
	//	EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyDownloadCompensationStatement(ProdSearchBy, criteriaTxt);
			
	}
	
	
	
	
	
	
}
