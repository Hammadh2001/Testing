package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class PayrollFeedback_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public PayrollFeedback_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validatePayrollFeedbackFileFeature
	Purpose    : To validate Payroll Feedback File Feature
	Author     : 17-Nov-2020 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getPayrollFeedbackData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("PayrollFeedbackData");
		return data;
	}
	@Test(dataProvider="getPayrollFeedbackData")
	public void validatePayrollFeedbackFileFeature(String username, String password, String planNumber,
			String beginingnDate, String endingDate, String fileOptn) throws InterruptedException {
		extentTest = extent.createTest("Payroll Feedback On-Demand Report Feature");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyPayrollFeedbackOnDemandReport(beginingnDate, endingDate, fileOptn, planNumber);
	}
	
	
	
	
	
	
}
