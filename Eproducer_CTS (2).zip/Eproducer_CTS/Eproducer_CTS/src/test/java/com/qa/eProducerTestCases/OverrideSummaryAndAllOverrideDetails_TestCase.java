package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class OverrideSummaryAndAllOverrideDetails_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public OverrideSummaryAndAllOverrideDetails_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateOverrideSummaryAndAllOverrideDetails
	Purpose    : To validate Override Summary and All Override Details features 
	Author     : 21-Jun-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getOverrideSummaryData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("OverrideSummaryData");
		return data;
	}
	@Test(dataProvider="getOverrideSummaryData")
	public void validateOverrideSummaryAndAllOverrideDetails(String userName, String passWord, String ProdSearchBy, String criteriaTxt,
			String statementDate) throws InterruptedException {
		extentTest = extent.createTest("Override Summary and All Override Details Features");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyOverrideSummaryAndAllOverrideDetails(ProdSearchBy, criteriaTxt, statementDate);
			
	}
	
	
	
	
	
	
}
