package com.qa.eProducer_ModuleWise_TestCases.Plan_Participant.Loan_Summary;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class DownloadDivisionalPlanReport_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public DownloadDivisionalPlanReport_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateDownlaodDivisioanlPlanReportFeature
	Purpose    : To validate the download functionality of divisional plan report 
	Author     : 3-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getDivisionalPlanData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("DownloadDvsnPlanData");
		return data;
	}
	@Test(dataProvider="getDivisionalPlanData")
	public void validateDownlaodDivisioanlPlanReportFeature(String userName, String passWord, String planNumber, String SSN) throws InterruptedException {
		extentTest = extent.createTest("Download Divisional Plan Report Feature");
		EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.verifyDownloadDivisonalPlanReport(planNumber, SSN);
		
	}
	
	
	
	
	
	
}
