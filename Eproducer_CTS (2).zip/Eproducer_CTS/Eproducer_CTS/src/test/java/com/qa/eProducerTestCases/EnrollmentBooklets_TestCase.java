package com.qa.eProducerTestCases;

import java.awt.AWTException;
import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class EnrollmentBooklets_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public EnrollmentBooklets_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	User Story No : 361342
	Test Name     : validateeSponsor -Location of Link for Enrollment Booklets
	Purpose       : To validate Enrollment Booklets link is present in the location
	Author        : 11/2/2025 by Emma
	***********************************************************************/
	@DataProvider
	public Object[][] getEnrollmentBooklets() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("EnrollmentBookletsData");
		return data;
	}

	@Test(dataProvider = "getEnrollmentBooklets")
	public void validategetEnrollmentBookletsFeature(String username, String password,String prodID, String planNumber) throws InterruptedException, AWTException {
		extentTest = extent.createTest("Important Documents Enrollment Booklets Feature : " +planNumber);	
		if(username.equals("n239lec")) {
			EProduceractions.loginToAppHONew(username, password);			
		}
		else {
		
			EProduceractions.loginToAppNonHONew(username, password);		
	}
		EProduceractions.searchPlans(prodID, planNumber);
		EProduceractions.verifyEnrollmentBookletsFeature(planNumber);
		
	}

}
