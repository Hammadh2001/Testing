package com.qa.eProducer_ModuleWise_TestCases.Investments;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ViewInvestmentModel_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ViewInvestmentModel_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateViewInvestmentModelFeature
	Purpose    : To validate the Investment Model creating and viewing feature 
	Author     : 7-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getViewInvsmtModData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ViewInvsmtModData");
		return data;
	}
	@Test(dataProvider="getViewInvsmtModData")
	public void validateViewInvestmentModelFeature(String userName, String passWord, String ProducerID, String planNumber, String invstModName) throws InterruptedException {
		extentTest = extent.createTest("Create and View Investment Model feature");
		EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.verifyViewInvestmentModelsFeature(ProducerID, planNumber, invstModName);
		
	}
	
	
	
	
	
	
}
