package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.eProducerActions.EProducerRegistrationActions;
import com.qa.utils.TestUtils;

public class BrokerDealerRegistrationForNewUser_TestCase extends TestBase {
	EProducerRegistrationActions EProducerRegistrationactions;

	public BrokerDealerRegistrationForNewUser_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProducerRegistrationactions = new EProducerRegistrationActions();
	}
	
	/* ******************************************************************
	Test Name  : validateBrokerDealerRegistrationForNewUser
	Purpose    : To validate the Broker/Dealer Registration Process for new user
	Author     : 20-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getBrokerRegData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("NewBrokerDealerRegData");
		return data;
	}
	@Test(dataProvider="getBrokerRegData")
	public void validateBrokerDealerRegistrationForNewUser(String regType, String invalidTaxID, String validTaxID, 
			String invalidFirmProdID, String validFirmProdID, String firstName, String lastName, String CreateOrUse,
			String lessThn6Chrs, String UsrIDEndsSpclChr, String UsrIDWithSpclChr, String UsrIDWith9Numbs, String UsrIDWithSpace, String validUsrID,
			String PwdlessThn8Chrs, String PwdNotMeetingCriterias, String PwdWithSpace, String PwdWithUserID, String validPwd,
			String invalidConfrimPwd, String validConfrimPwd, String invalidEmailID, String validEmailID,
			String invalidConfirmEmailID, String validConfirmEmailID, String invalidMobileNumb, String validMobileNumb, 
			String invalidConfirmMoblNumb, String validConfirmMoblNumb, String secQstn, String secAns) throws InterruptedException {
		extentTest = extent.createTest("Broker/Dealer Registration for a  New User");
		EProducerRegistrationactions.navigateToeProducerRegistrationPage();
		EProducerRegistrationactions.selectTypeofRegistration(regType);
		EProducerRegistrationactions.verifyBrokerDealerRegistrationProcess(invalidTaxID, validTaxID, invalidFirmProdID, validFirmProdID, firstName, lastName, CreateOrUse);
		EProducerRegistrationactions.verifyUserIDTxtFld(lessThn6Chrs, UsrIDEndsSpclChr, UsrIDWithSpclChr, UsrIDWith9Numbs, UsrIDWithSpace, validUsrID);
		EProducerRegistrationactions.verifyPasswordTxtFld(PwdlessThn8Chrs, PwdNotMeetingCriterias, PwdWithSpace, PwdWithUserID, validPwd);
		EProducerRegistrationactions.verifyConfirmPwdTxtFld(invalidConfrimPwd, validConfrimPwd);
		EProducerRegistrationactions.verifyEmailTxtFld(invalidEmailID, validEmailID);
		EProducerRegistrationactions.verifyConfirmEmailTxtFld(invalidConfirmEmailID, validConfirmEmailID);
		EProducerRegistrationactions.verifyMobilePhoneTxtFlds(invalidMobileNumb, validMobileNumb, invalidConfirmMoblNumb, validConfirmMoblNumb);
		EProducerRegistrationactions.verifySecurityQstn(secQstn, secAns);
		EProducerRegistrationactions.verifyTermsLinks();
		EProducerRegistrationactions.verifySuccessfullRegistration();
				
	}
	
	
	
	
	
	
}
