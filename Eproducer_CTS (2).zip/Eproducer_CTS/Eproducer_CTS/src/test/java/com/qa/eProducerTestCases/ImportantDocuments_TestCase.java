package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ImportantDocuments_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ImportantDocuments_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateImportantDocumentLinks
	Purpose    : To validate the Loan Summary of a plan 
	Author     : 1-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getImportantDocsData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ImportantDocsData");
		return data;
	}
	@Test(dataProvider="getImportantDocsData")
	public void validateImportantDocsLinks(String userName, String passWord, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Important Document links functionality");
	//	EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyImportantDocumentsLinks(planNumber);
		
	}
	
	
	
	
	
	
}
