package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class PlanSummaryScreenUpdate_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public PlanSummaryScreenUpdate_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validatePlanSummaryScreenUpdate
	Purpose    : To validate Plan Summary page
	Author     : 21-Feb-2024 by Priya Natarajan 
	***********************************************************************/
	@DataProvider
	public Object[][] getPlanSummaryUpdateData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("PlanSummaryUpdateData");
		return data;
	}
	@Test(dataProvider="getPlanSummaryUpdateData")
	public void validatePlanSummaryUpdatePage(String username, String password, String planNumber, String PM696) throws InterruptedException {
		extentTest = extent.createTest("Plan Summary Screen Update Feature " +planNumber);
		//EProduceractions.loginToApp_HOUsr(username, password);
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyPlanSummaryUpdate(PM696);
	}
	
	
	
	
	
	
}
