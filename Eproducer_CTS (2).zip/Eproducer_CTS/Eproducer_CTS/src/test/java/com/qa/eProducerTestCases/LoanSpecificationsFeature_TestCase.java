package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class LoanSpecificationsFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public LoanSpecificationsFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateLoanSpecificationsFeature
	Purpose    : To validate Loan Specifications feature
	Author     : 5-Jan-2021 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getLoanSpecificationsData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("LoanSpecificationsData");
		return data;
	}
	@Test(dataProvider="getLoanSpecificationsData")
	public void validateLoanSpecificationsFeature(String username, String password, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Loan Specifications Feature");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyLoanSpecificationsFeature();
	}
	
	
	
	
	
	
}
