package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class LoanDocuments_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public LoanDocuments_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateLoanDocumentsFeature
	Purpose    : To validate the Loan documents feature 
	Author     : 02-Nov-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getLoanDocData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("LoanDocsData");
		return data;
	}
	@Test(dataProvider="getLoanDocData")
	public void validateLoanDocumentsFeature(String userName, String passWord, String planNumber, String SSN) throws InterruptedException {
		extentTest = extent.createTest("Loan Documents Feature");
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyLoanDocumentsFeature(planNumber, SSN);
		
	}
	
	
	
	
	
	
}
