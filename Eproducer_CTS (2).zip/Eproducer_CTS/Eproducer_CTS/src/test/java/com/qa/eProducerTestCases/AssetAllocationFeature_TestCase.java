package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class AssetAllocationFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public AssetAllocationFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAssetAllocationFeature
	Purpose    : To validate Asset Allocation feature
	Author     : 13-Nov-2020 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getAssetAllocationData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("AssetAllocationData");
		return data;
	}
	@Test(dataProvider="getAssetAllocationData")
	public void validateAssetAllocationFeature(String username, String password, String planNumber,
			String reportType, String incorrectFrmtDate, String futureDate, String vldFromDate, String vldToDate) throws InterruptedException {
		extentTest = extent.createTest("Asset Allocation Feature");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyAssetAllocationFeature(reportType, incorrectFrmtDate, futureDate, vldFromDate, vldToDate);
		
	}
	
	
	
	
	
	
}
