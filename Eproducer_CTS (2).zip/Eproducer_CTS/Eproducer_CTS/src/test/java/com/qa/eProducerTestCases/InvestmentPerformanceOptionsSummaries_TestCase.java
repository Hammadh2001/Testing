package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class InvestmentPerformanceOptionsSummaries_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public InvestmentPerformanceOptionsSummaries_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateInvstmntPrfrmncOptnsSummariesFeature
	Purpose    : To validate Investment Performance Options summaries feature
	Author     : 11-Nov-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getInvstmntPrfrmncData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("InvstmntPrfrmncOptionsData");
		return data;
	}
	
	@Test(dataProvider="getInvstmntPrfrmncData")
	public void validateInvstmntPrfrmncOptnsSummariesFeature(String userName, String passWord) throws InterruptedException {
		extentTest = extent.createTest("Investment Performance Options Summaries Feature");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyInvstmntPrfrmncOptnSummaries();
		
	}
	
	
	
	
	
	
}
