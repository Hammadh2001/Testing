package com.qa.eProducer_ModuleWise_TestCases.Registrations;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.eProducerActions.EProducerRegistrationActions;
import com.qa.utils.TestUtils;

public class AdvisorRegistrationForNewUser_TestCase extends TestBase {
	EProducerRegistrationActions EProducerRegistrationactions;

	public AdvisorRegistrationForNewUser_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProducerRegistrationactions = new EProducerRegistrationActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAdvisorRegistrationForNewUser
	Purpose    : To validate the Advisor Registration Process for a new user
	Author     : 20-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getAdvisorRegData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("NewAdvisorRegistrationData");
		return data;
	}

	@Test(dataProvider = "getAdvisorRegData")
	public void validateAdvisorRegistrationForNewUser(String regType, String invalidSSN, String validSSN, String prodID,
			String stateName, String lessThn6Chrs, String UsrIDEndsSpclChr, String UsrIDWithSpclChr,
			String UsrIDWith9Numbs, String UsrIDWithSpace, String validUsrID, String PwdlessThn8Chrs,
			String PwdNotMeetingCriterias, String PwdWithSpace, String PwdWithUserID, String validPwd,
			String invalidConfrimPwd, String validConfrimPwd, String invalidEmailID, String validEmailID,
			String invalidConfirmEmailID, String validConfirmEmailID, String invalidMobileNumb, String validMobileNumb,
			String invalidConfirmMoblNumb, String validConfirmMoblNumb, String secQstn, String secAns)
			throws InterruptedException {
		extentTest = extent.createTest("Advisor Registration For a  New User");
		EProducerRegistrationactions.navigateToeProducerRegistrationPage();
		EProducerRegistrationactions.selectTypeofRegistration(regType);
		EProducerRegistrationactions.verifyEnterInfoPage(invalidSSN, validSSN, prodID, stateName);
		EProducerRegistrationactions.verifyUserIDTxtFld(lessThn6Chrs, UsrIDEndsSpclChr, UsrIDWithSpclChr,
				UsrIDWith9Numbs, UsrIDWithSpace, validUsrID);
		EProducerRegistrationactions.verifyPasswordTxtFld(PwdlessThn8Chrs, PwdNotMeetingCriterias, PwdWithSpace,
				PwdWithUserID, validPwd);
		EProducerRegistrationactions.verifyConfirmPwdTxtFld(invalidConfrimPwd, validConfrimPwd);
		EProducerRegistrationactions.verifyEmailTxtFld(invalidEmailID, validEmailID);
		EProducerRegistrationactions.verifyConfirmEmailTxtFld(invalidConfirmEmailID, validConfirmEmailID);
		EProducerRegistrationactions.verifyMobilePhoneTxtFlds(invalidMobileNumb, validMobileNumb,
				invalidConfirmMoblNumb, validConfirmMoblNumb);
		EProducerRegistrationactions.verifySecurityQstn(secQstn, secAns);
		EProducerRegistrationactions.verifyTermsLinks();
		EProducerRegistrationactions.verifySuccessfullRegistration();

	}
	
	
	
	
	
}
