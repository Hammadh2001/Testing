package com.qa.eProducerTestCases;

import java.awt.AWTException;
import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;

import com.qa.utils.TestUtils;

public class PlanSummaryScreenPageUpdate_TestCase extends TestBase {
	EProducerActions EProduceractions;
	public PlanSummaryScreenPageUpdate_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validatePlanSummaryScreenUpdate
	Purpose    : To validate Plan Summary page
	Author     : 13-Sep-2024 by Emma Rani
	***********************************************************************/
	@DataProvider
	public Object[][] getPlanSummaryUpdateData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("PlanSummaryScreenUpdateData");
		return data;
	}
	@Test(dataProvider="getPlanSummaryUpdateData")
	public void validatePlanSummaryUpdatePage(String username, String password, String planNumber,String prodID) throws InterruptedException, AWTException {
		extentTest = extent.createTest("Plan Summary Update Feature " +planNumber );

		EProduceractions.verifyPlanSummaryScreenPageUpdates(username,password,planNumber,prodID);
		
	}
}
