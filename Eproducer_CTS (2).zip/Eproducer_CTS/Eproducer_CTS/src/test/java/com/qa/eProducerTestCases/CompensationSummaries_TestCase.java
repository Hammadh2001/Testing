package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class CompensationSummaries_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public CompensationSummaries_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateCompensationSummariesFeatures
	Purpose    : To validate Summaries of Compensation features 
	Author     : 18-Jun-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getCompntstnSummaryData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("CompensationSummariesData");
		return data;
	}
	@Test(dataProvider="getCompntstnSummaryData")
	public void validateGroupandRSCompensationSummary(String userName, String passWord, String ProdSearchBy, String criteriaTxt) throws InterruptedException {
		extentTest = extent.createTest("Compensation Summaries Features");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyCompensationSummariesFeatures(ProdSearchBy, criteriaTxt);
			
	}
	
	
	
	
	
	
}
