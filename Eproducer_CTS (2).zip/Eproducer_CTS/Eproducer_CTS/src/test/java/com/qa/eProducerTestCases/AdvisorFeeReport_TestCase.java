package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class AdvisorFeeReport_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public AdvisorFeeReport_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAdvisorFeeReportFeature
	Purpose    : To validate the advisor fee report feature 
	Author     : 14-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getAdvisroFeeReportData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("AdvisroFeeReportData");
		return data;
	}
	@Test(dataProvider="getAdvisroFeeReportData")
	public void validateAdvisorFeeReportFeature(String userName, String passWord, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Advisor Fee Report download feature");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyAdvisorFeeReport(planNumber);
		
	}
	
	
	
	
	
	
}
