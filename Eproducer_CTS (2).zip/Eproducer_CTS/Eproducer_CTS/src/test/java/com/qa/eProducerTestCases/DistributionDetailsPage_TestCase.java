package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class DistributionDetailsPage_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public DistributionDetailsPage_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateDistributionDetailsPage
	Purpose    : To validate Distribution Details Page
	Author     : 13-Nov-2020 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getDistributionDetailData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("DistributionDetailsData");
		return data;
	}
	@Test(dataProvider="getDistributionDetailData")
	public void validateDistributionDetailsPage(String username, String password, String planNumber,
			String reportType, String incorrectFrmtDate, String futureDate, String vldFromDate, String vldToDate, String SSN) throws InterruptedException {
		extentTest = extent.createTest("Distribution Detail Page");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyDistributionDetailFeature(reportType, incorrectFrmtDate, futureDate, vldFromDate, vldToDate, SSN);	
	}
	
	
	
	
	
	
}
