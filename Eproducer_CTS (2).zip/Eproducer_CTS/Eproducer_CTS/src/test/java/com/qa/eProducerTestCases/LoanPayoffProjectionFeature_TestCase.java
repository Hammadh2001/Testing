package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class LoanPayoffProjectionFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public LoanPayoffProjectionFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateLoanPayoffProjectionFeature
	Purpose    : To validate Loan Payoff Projection feature
	Author     : 5-Jan-2021 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getLoanPayoffProjectionData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("LoanPayoffProjectionData");
		return data;
	}
	@Test(dataProvider="getLoanPayoffProjectionData")
	public void validateLoanPayoffProjectionFeature(String username, String password, String planNumber,
			String ssn, String invalidDate, String futureDate, String validDate) throws InterruptedException {
		extentTest = extent.createTest("Loan Payoff Projection Feature");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyLoanPayOffProjectionFeature(ssn, invalidDate, futureDate, validDate);
	}
	
	
	
	
	
	
}
