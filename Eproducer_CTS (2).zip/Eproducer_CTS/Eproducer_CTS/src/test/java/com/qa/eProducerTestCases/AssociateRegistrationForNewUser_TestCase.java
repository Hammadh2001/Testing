package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.eProducerActions.EProducerRegistrationActions;
import com.qa.utils.TestUtils;

public class AssociateRegistrationForNewUser_TestCase extends TestBase {
	EProducerRegistrationActions EProducerRegistrationactions;

	public AssociateRegistrationForNewUser_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProducerRegistrationactions = new EProducerRegistrationActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAssociateRegistrationForNewUser
	Purpose    : To validate the Broker/Dealer Registration Process for new user
	Author     : 21-Jul-2020 by Yogesh SB
	FYI		   : Get the Access code and ProdID by adding a associate in the eProducer application
	***********************************************************************/
	@DataProvider
	public Object[][] getAssociateRegData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("NewUsrAssociateRegData");
		return data;
	}
	@Test(dataProvider="getAssociateRegData")
	public void validateAssociateRegistrationForNewUser(String regType, String prodID, String invalidAccessCode, String validAccessCode, String CreateOrExstng,
			String lessThn6Chrs, String UsrIDEndsSpclChr, String UsrIDWithSpclChr, String UsrIDWith9Numbs, String UsrIDWithSpace, String validUsrID,
			String PwdlessThn8Chrs, String PwdNotMeetingCriterias, String PwdWithSpace, String PwdWithUserID, String validPwd,
			String invalidConfrimPwd, String validConfrimPwd, String invalidEmailID, String validEmailID,
			String invalidConfirmEmailID, String validConfirmEmailID, String invalidMobileNumb, String validMobileNumb, 
			String invalidConfirmMoblNumb, String validConfirmMoblNumb, String secQstn, String secAns) throws InterruptedException {
		extentTest = extent.createTest("Associate Registration for a  New User");
		EProducerRegistrationactions.navigateToeProducerRegistrationPage();
		EProducerRegistrationactions.selectTypeofRegistration(regType);
		EProducerRegistrationactions.verifyAssociateRegistrationFlow(prodID, invalidAccessCode, validAccessCode, CreateOrExstng);		
		EProducerRegistrationactions.verifyUserIDTxtFld(lessThn6Chrs, UsrIDEndsSpclChr, UsrIDWithSpclChr, UsrIDWith9Numbs, UsrIDWithSpace, validUsrID);
		EProducerRegistrationactions.verifyPasswordTxtFld(PwdlessThn8Chrs, PwdNotMeetingCriterias, PwdWithSpace, PwdWithUserID, validPwd);
		EProducerRegistrationactions.verifyConfirmPwdTxtFld(invalidConfrimPwd, validConfrimPwd);
		EProducerRegistrationactions.verifyEmailTxtFld(invalidEmailID, validEmailID);
		EProducerRegistrationactions.verifyConfirmEmailTxtFld(invalidConfirmEmailID, validConfirmEmailID);
		EProducerRegistrationactions.verifyMobilePhoneTxtFlds(invalidMobileNumb, validMobileNumb, invalidConfirmMoblNumb, validConfirmMoblNumb);
		EProducerRegistrationactions.verifySecurityQstn(secQstn, secAns);
		EProducerRegistrationactions.verifyTermsLinks();
		EProducerRegistrationactions.verifySuccessfullRegistration();
				
	}
	
	
	
	
	
	
}
