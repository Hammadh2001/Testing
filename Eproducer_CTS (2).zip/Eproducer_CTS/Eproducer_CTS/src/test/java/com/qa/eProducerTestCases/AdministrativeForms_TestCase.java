package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class AdministrativeForms_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public AdministrativeForms_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		//initializationtrial();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAdministrativeForms
	Purpose    : To validate Administrative Forms page
	Author     : 7-Jan-2021 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getAdministrativeFormsData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("AdministrativeFormsData");
		return data;
	}
	@Test(dataProvider="getAdministrativeFormsData")
	public void validateAdministrativeForms(String username, String password, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Administrative Forms Feature");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyAdministrativeForms();
	}

	
	
	
}
