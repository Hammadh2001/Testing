package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class CompensationGroupAndRS_Summary_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public CompensationGroupAndRS_Summary_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateGroupandRSCompensationSummary
	Purpose    : To validate Compensation Group and RS summary page 
	Author     : 15-Jun-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getGroupRSSummaryData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("GroupAndRSSummaryData");
		return data;
	}
	@Test(dataProvider="getGroupRSSummaryData")
	public void validateGroupandRSCompensationSummary(String userName, String passWord, String ProdSearchBy, String criteriaTxt) throws InterruptedException {
		extentTest = extent.createTest("Compensation Group and Retirement Services Summary ");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyGroupAndRetirementServicesSummary(ProdSearchBy, criteriaTxt);
			
	}
	
	
	
	
	
	
}
