package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class AddressChangesEactivityReport_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public AddressChangesEactivityReport_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAddressChangeseActivityReport
	Purpose    : To validate the Address changes/eActivity report feature 
	Author     : 15-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getAddresschangesData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("AddressChangesData");
		return data;
	}
	@Test(dataProvider="getAddresschangesData")
	public void validateAddressChangeseActivityReport(String userName, String passWord, String planNumber, String typeAdrs, String fromdate, String todate, String prtcpntID) throws InterruptedException {
		extentTest = extent.createTest("Address Changes/eActivity Report download");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyAddressChangeseActivityFeature(planNumber, typeAdrs, fromdate, todate, prtcpntID);
		
	}
	
	
	
	
	
	
}
