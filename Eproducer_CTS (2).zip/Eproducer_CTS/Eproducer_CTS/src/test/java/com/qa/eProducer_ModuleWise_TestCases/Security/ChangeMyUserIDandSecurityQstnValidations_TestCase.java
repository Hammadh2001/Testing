package com.qa.eProducer_ModuleWise_TestCases.Security;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.eProducerActions.EProducerRegistrationActions;
import com.qa.utils.TestUtils;

public class ChangeMyUserIDandSecurityQstnValidations_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ChangeMyUserIDandSecurityQstnValidations_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateChangeMyUserIDandSecurityQstnValidations
	Purpose    : To validate the Forgot My User ID and Validations
	Author     : 22-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getForgotUsrData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ChangeMyUsrIDSecQstnData");
		return data;
	}
	@Test(dataProvider="getForgotUsrData")
	public void validateChangeMyUserIDandSecurityQstnValidations(String username, String password,String lessThn6chrs, String usrIDEndsWithSpclChr, String usrIDWithSpclChr, String usrIDWith9Numbs,
			String usrIDWithSpace, String usrIDWith64Chrs, String PreviousUsrID, String ValidNewusrID, 
			String invalidCnfrmusrID, String validCnfrmusrID, String secQstn, String Above50ChrsAns, String Below50ChrsAns,
			String invalidCurrtPwd, String validCurrtPwd) throws InterruptedException {
		extentTest = extent.createTest("Change My UserID and Security Question Validations");
		EProduceractions.loginToAppNonHO(username, password);
		EProduceractions.clickMyProfileLink();
		EProduceractions.verifyUserIDValidations(lessThn6chrs, usrIDEndsWithSpclChr, usrIDWithSpclChr, usrIDWith9Numbs, usrIDWithSpace, usrIDWith64Chrs, PreviousUsrID, ValidNewusrID, invalidCnfrmusrID, validCnfrmusrID);
		Thread.sleep(2000);
		EProduceractions.verifyChangeSecurityQstnandValidations(secQstn, Above50ChrsAns, Below50ChrsAns, invalidCurrtPwd, validCurrtPwd);
		
	}
	
	
	
	
	
	
}
