package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class InforceOrdering_Change_Plan_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public InforceOrdering_Change_Plan_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateInforceOrderingChangeToInforcePlan
	Purpose    : To validate Inforce Ordering to change a plan
	Author     : 17-Nov-2020 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getInforceOrdrChangePlanData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("InforceOrderingChangePlan");
		return data;
	}
	@Test(dataProvider="getInforceOrdrChangePlanData")
	public void validateInforceOrderingChangeToInforcePlan(String username, String password, String ordrEmail,
			String plnNumb, String whyOrdering) throws InterruptedException {
		extentTest = extent.createTest("Inforce Ordering - Change to Inforce Plan feature");
		
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.verifyInforceOrderingPlans(ordrEmail, plnNumb, whyOrdering);	
	}
	
	
	
	
	
	
}
