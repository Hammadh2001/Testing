package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class Recurring_RebalanceFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public Recurring_RebalanceFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateRecurring_RebalanceFeature
	Purpose    : To validate the recurring re-balancing of account feature
	Author     : 24-Jun-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getRecurringRebalanceData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("RecurringRebalanceData");
		return data;
	}
	@Test(dataProvider="getRecurringRebalanceData")
	public void validateRecurring_RebalanceFeature(String userName, String passWord, String ProducerID, String planNumber,
			String frequencyType) throws InterruptedException {
		extentTest = extent.createTest("Recurring Rebalance Feature");
	//	EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyRecurringRebalanceFeature(ProducerID, planNumber, frequencyType);
		
	}
	
	
	
	
	
	
}
