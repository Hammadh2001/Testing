package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class LTPTAccessControl_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public LTPTAccessControl_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		//initialization();
		initializationtrial();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateLTPTAccessControlFeature
	Purpose    : To validate LTPT Access Control feature
	Author     : 02-Feb-2024 by Priya Natarajan 
	***********************************************************************/
	@DataProvider
	
	public Iterator<Object[]> getLTPTAccessControlData() throws IOException {
		Object data[][] = TestUtils.geteProducerTestData("LTPTAccessControl");
		List<Object[]> finalData = new ArrayList<>();
		for (int i=0; i<data.length; i++) {
			if (data[i][0].toString().equalsIgnoreCase("yes")) {
				finalData.add(data[i]);
			}
		}
		return finalData.iterator();
	}
	@Test(dataProvider="getLTPTAccessControlData")
	public void validateLTPTAccessControlFeature(String Execute,String username, String password, String prodID, String planNumber,
			String PM702, String PH625) throws InterruptedException {
		extentTest = extent.createTest("eProducer LTPT Access Control Feature");
		if(username.equals("s.malless14")) {
			
			EProduceractions.loginToAppNonHONew(username, password);
		}
		else {
	
			EProduceractions.loginToAppHONew(username, password);
		}
		
		EProduceractions.searchPlans(prodID, planNumber);
		EProduceractions.verifyLTPTAccessControl(planNumber, PM702, PH625);
		
	}
	
	
	
	
	
	
}
