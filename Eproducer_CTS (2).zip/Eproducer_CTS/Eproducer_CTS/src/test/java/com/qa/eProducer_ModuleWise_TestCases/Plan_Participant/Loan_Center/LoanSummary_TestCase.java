package com.qa.eProducer_ModuleWise_TestCases.Plan_Participant.Loan_Center;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class LoanSummary_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public LoanSummary_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateLoanSummaryFeature
	Purpose    : To validate the Loan Summary of a plan 
	Author     : 30-Jun-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getLoanSummaryData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("LoanSummaryData");
		return data;
	}
	@Test(dataProvider="getLoanSummaryData")
	public void validateLoanSummaryFeature(String userName, String passWord, String planNumber, String SSN) throws InterruptedException {
		extentTest = extent.createTest("Loan Summary Feature");
		EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.verifyLoanSummaryFeature(planNumber, SSN);
		
	}
	
	
	
	
	
	
}
