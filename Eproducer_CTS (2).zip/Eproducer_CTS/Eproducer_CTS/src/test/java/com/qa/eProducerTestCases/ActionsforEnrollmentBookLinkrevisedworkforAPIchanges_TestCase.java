package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;

import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ActionsforEnrollmentBookLinkrevisedworkforAPIchanges_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ActionsforEnrollmentBookLinkrevisedworkforAPIchanges_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	User Story No   : 398535
	Test Name       : validate eProducerActionforEnrollmentBookLinkrevisedworkforAPIchanges_TestCase
	Purpose         : To validate Enrollment Booklets Actions
	Author          : 17/3/2025 by Emma
	Add plan number : User: r.jones01/1America-Plan: G51528
	                  INSERT INTO FTDM_USER.VW_PLANAGENT(PRODUCT, PLAN, AGENTNUMBER, AGENTROLE)VALUES ('671D', 'G51528', 'AA57796', 'RT')
    Add plan number : User: n239lec/1-America-Plan: G33331
                      

	***********************************************************************/
	@DataProvider
	
	public Iterator<Object[]> getActionsforEnrollmentBookLink() throws IOException {
		Object data[][] = TestUtils.geteProducerTestData("EnrollmentBookActionData");
		List<Object[]> finalData = new ArrayList<>();
		for (int i=0; i<data.length; i++) {
			if (data[i][0].toString().equalsIgnoreCase("yes")) {
				finalData.add(data[i]);
			}
		}
		return finalData.iterator();
	}
	@Test(dataProvider = "getActionsforEnrollmentBookLink")
	public void validategetActionsforEnrollmentBookLinkFeature(String Execute,String username, String password,String prodID, String planNumber) throws Exception {
		extentTest = extent.createTest("Actions for Enrollment Book Link revised work for API changes : " +planNumber);	
		if(username.equals("n239lec")) {
			EProduceractions.loginToAppHONew(username, password);
			EProduceractions.searchPlanFunctionality(planNumber);
			
		}
		else {	
		
			EProduceractions.loginToAppNonHONew(username, password);
			EProduceractions.selectProducerID(prodID);	
			EProduceractions.searchPlanFunctionality(planNumber);
	}
		
		EProduceractions.verifyActionsforEnrollmentBookLinkrevisedworkforAPIchanges(planNumber);
		
	}
	

}
