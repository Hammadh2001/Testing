package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ViewParticipantDisplayList_TestCase extends TestBase {
	EProducerActions EProduceractions;

      public ViewParticipantDisplayList_TestCase() {
	super();
} 
      
      @BeforeMethod
  	public void setUp() {
  		//initialization();
  		initializationtrial();
  		EProduceractions = new EProducerActions();
  	}
      
      /* ******************************************************************
		Test Name  : validatePlandisplayUpdate
		Purpose    : To validate Plan Display Update
		Author     : 3-April-2024 by Emma Rani 
		***********************************************************************/  
      
      @DataProvider
  	public Object[][] getViewParticipantDisplayUpdate() throws FileNotFoundException {
  		Object data[][] = TestUtils.geteProducerTestData("ParticipantDisplayUpdate");
  		return data;
  	}
      
      @Test(dataProvider="getViewParticipantDisplayUpdate")
  	public void validateViewParticipantDisplayUpdate(String username, String password, String planNumber,
  			String PM696,String PH619,String searchBy, String ssn) throws InterruptedException {
  		extentTest = extent.createTest("eProducer View Participant Display Update : "+planNumber);
  		//EProduceractions.loginToApp_HOUsr(username, password);
  		EProduceractions.loginToAppHONew(username, password);
  		EProduceractions.searchPlanFunctionalityforAddNewColumn(planNumber);
  		EProduceractions.verifyViewParticipantDisplay(planNumber, PM696, PH619,searchBy, ssn);
  		
  	} 
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
}