package com.qa.eProducer_ModuleWise_TestCases.Sales;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ServiceAgreementandFeeDisclosureFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ServiceAgreementandFeeDisclosureFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateServiceAgreementandFeeDisclosureFeature
	Purpose    : To validate the Service Agreement and Fee Disclosure Feature
	Author     : 13-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getSrvcAgrmtData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ServiceAgreemenData");
		return data;
	}
	@Test(dataProvider="getSrvcAgrmtData")
	public void validateServiceAgreementandFeeDisclosureFeature(String userName, String passWord, String emailAdrs, String planname, String plannumb, String plantype, 
			String eligblEmpCount, String annualcontrbtn, String assetValue, String fundLine, String prodType, String firstYrCommsn, 
			String trailCommsn, String advisorCompnstn, String servcLvl, String TPA, String mepOption, String brkrgWin, String loans, 
			String ria, String nonModel, String partAdvc, String plnSpnsrAdvc) throws InterruptedException {
		extentTest = extent.createTest("Service Agreement and Fee Disclosure Feature");
		EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.verifyServiceAgreementandFeeDisclosure(emailAdrs, planname, plannumb, plantype, eligblEmpCount, annualcontrbtn, assetValue,
				fundLine, prodType, firstYrCommsn, trailCommsn, advisorCompnstn, servcLvl, TPA, mepOption, brkrgWin, loans, ria, nonModel, partAdvc, plnSpnsrAdvc);
		
	}
	
	
	
	
	
	
}
