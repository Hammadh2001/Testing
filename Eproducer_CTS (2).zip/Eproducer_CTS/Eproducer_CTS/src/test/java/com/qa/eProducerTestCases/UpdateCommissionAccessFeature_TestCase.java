package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class UpdateCommissionAccessFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public UpdateCommissionAccessFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateUpdateCommissionAccessFeature
	Purpose    : To validate the Update Commission Access feature in  My Profile page 
	Author     : 8-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getUpdateCommsnData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("UpdateCommissionAccessData");
		return data;
	}
	@Test(dataProvider="getUpdateCommsnData")
	public void validateUpdateCommissionAccessFeature(String userName, String passWord) throws InterruptedException {
		extentTest = extent.createTest("Update Producer Commission Access Feature");
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyUpdateCommissionAccessFeature();
		
	}
	
	
	
	
	
	
}
