package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class RebalanceAccountFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public RebalanceAccountFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateRebalanceAccountFeature
	Purpose    : To validate the re-balancing of account feature
	Author     : 10-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getRebalanceAcctData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("RebalanceAccountData");
		return data;
	}
	@Test(dataProvider="getRebalanceAcctData")
	public void validateRebalanceAccountFeature(String userName, String passWord, String prodID, String planNumber, String SSN) throws InterruptedException {
		extentTest = extent.createTest("Rebalance Account feature");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyRebalanceAccountFeature(prodID, planNumber, SSN);
		
	}
	
	
	
	
	
	
}
