package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class DownloadInvestmentPerformance_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public DownloadInvestmentPerformance_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateInvestmentPerformanceDownload
	Purpose    : To validate the Loan Summary of a plan 
	Author     : 30-Jun-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getInvstPrfrmncData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("InvstmtPrfrmncData");
		return data;
	}
	@Test(dataProvider="getInvstPrfrmncData")
	public void validateInvestmentPerformanceDownload(String userName, String passWord, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Download Investment Performance Report");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyDownloadInvstPrfrmncReport(planNumber);
		
	}
	
	
	
	
	
	
}
