package com.qa.eProducer_ModuleWise_TestCases.Plan_Participant.Loan_Summary;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class Residentialloan_NonfiduciaryPlan_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public Residentialloan_NonfiduciaryPlan_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : Residentialloan_NonfiduciaryPlan
	Purpose    : To validate the Residential Loan feature for non fiduciary Plan 
	Author     : 13-Apr-2023 by Arpan Roy
	***********************************************************************/
	@DataProvider
	public Object[][] getNonFiduciaryPlanData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("Resdentialloan_nonfidplan");
		return data;
	}
	@Test(dataProvider="getNonFiduciaryPlanData")
	public void validateDownlaodDivisioanlPlanReportFeature(String userName, String passWord, String planNumber, String SSN) throws InterruptedException, IOException {
		extentTest = extent.createTest("Validate the Residential Loan feature for non fiduciary Plan");
		EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.verifyresidentialloanfornonfiduciaryPlan(planNumber,SSN);
		
	}
	
	
	
	
	
	
}
