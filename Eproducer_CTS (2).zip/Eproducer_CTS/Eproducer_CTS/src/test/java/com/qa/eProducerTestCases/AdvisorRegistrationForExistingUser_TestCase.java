package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.eProducerActions.EProducerRegistrationActions;
import com.qa.utils.TestUtils;

public class AdvisorRegistrationForExistingUser_TestCase extends TestBase {
	EProducerRegistrationActions EProducerRegistrationactions;

	public AdvisorRegistrationForExistingUser_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProducerRegistrationactions = new EProducerRegistrationActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAdvisorRegistrationForExistingUser
	Purpose    : To validate the Advisor Registration Process for the existing user
	Author     : 20-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getAdvisorRegData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("AdvsrRgstrnExstngUsrData");
		return data;
	}
	@Test(dataProvider="getAdvisorRegData")
	public void validateAdvisorRegistrationForExistingUser(String regType, String invalidSSN, String validSSN, String prodID, 
			String stateName, String invalidExstngUsrID, String invalidExstngPwd, String validExstngUsrID, String validExstngPwd) throws InterruptedException {
		extentTest = extent.createTest("Advisor Registration for the User registered to other sites");
		EProducerRegistrationactions.navigateToeProducerRegistrationPage();
		EProducerRegistrationactions.selectTypeofRegistration(regType);
		EProducerRegistrationactions.verifyEnterInfoPage(invalidSSN, validSSN, prodID, stateName);
		EProducerRegistrationactions.verifyUserRegisteredToOtherSites();
		EProducerRegistrationactions.verifyExistingUserIDPwdFlds(invalidExstngUsrID, invalidExstngPwd, validExstngUsrID, validExstngPwd);
		EProducerRegistrationactions.verifySuccessfullRegistration();
				
	}
	
	
	
	
	
	
}
