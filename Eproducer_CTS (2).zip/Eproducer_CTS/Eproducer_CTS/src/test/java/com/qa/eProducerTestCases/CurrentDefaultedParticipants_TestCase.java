package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class CurrentDefaultedParticipants_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public CurrentDefaultedParticipants_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateCurrentDefaultedParticipants
	Purpose    : To validate the Current Defaulted Participants
	Author     : 7-Jun-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getCurrentDefaultPrtcpntData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("CurrentDefaultPrtcpntData");
		return data;
	}
	@Test(dataProvider="getCurrentDefaultPrtcpntData")
	public void validateCurrentDefaultedParticipants(String viewType, String userName, String passWord, String planNumber,
			String searchBy, String criteria) throws InterruptedException {
		extentTest = extent.createTest("Current Defaulted Participants-"+ viewType);
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyCurntDfltdParticipants(searchBy, criteria);
		
	}
	
	
	
	
	
	
}
