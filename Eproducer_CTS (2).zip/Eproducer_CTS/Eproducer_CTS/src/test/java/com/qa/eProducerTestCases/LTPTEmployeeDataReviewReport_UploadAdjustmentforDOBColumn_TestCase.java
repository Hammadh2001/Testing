package com.qa.eProducerTestCases;

import java.awt.AWTException;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;

import com.qa.utils.TestUtils;

public class LTPTEmployeeDataReviewReport_UploadAdjustmentforDOBColumn_TestCase  extends TestBase {
	EProducerActions EProduceractions;

	public LTPTEmployeeDataReviewReport_UploadAdjustmentforDOBColumn_TestCase() {
		super();
	}
	@BeforeMethod
	public void setUp() {
		initializationtrial() ;
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateLTPTEmployeeDataReviewReport_UploadAdjustmentforDOBColumn_TestCase
	Purpose    : To validate LTPTEmployeeDataReviewReport_Upload Adjustment for DOB Column
	Author     : 8-1-2024 by EmmaRani
	***********************************************************************/
	@DataProvider
	public Object[][] getLTPTEmployeeDataReviewUpload() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("LTPTUploadAdjustmntforDOBColumn");
		return data;
	}

	@Test(dataProvider = "getLTPTEmployeeDataReviewUpload")
	public void validateLTPTEmployeeDataReviewUploadFeature(String username, String password, String planNumber) throws InterruptedException, AWTException, IOException {
		extentTest = extent.createTest("LTPT Employee Data Review Report Upload Adjustment for DOB Column");
		//EProduceractions.loginToApp_HOUsr(username, password);
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyLTPTEmployeeDataReviewUploadFeature(planNumber);

}
}
