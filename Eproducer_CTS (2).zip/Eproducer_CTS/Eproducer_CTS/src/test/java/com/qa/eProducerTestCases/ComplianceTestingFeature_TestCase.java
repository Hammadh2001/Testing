package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ComplianceTestingFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ComplianceTestingFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateComplianceTestingFeature
	Purpose    : To validate Compliance Testing feature
	Author     : 5-Jan-2021 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getComplianceTestingData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ComplianceTestingData");
		return data;
	}
	@Test(dataProvider="getComplianceTestingData")
	public void validateComplianceTestingFeature(String username, String password, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Compliance Testing Feature");
		//EProduceractions.loginToApp_HOUsr(username, password);
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyComplianceTestingFeature();
		
	}
	
	
	
	
	
	
}
