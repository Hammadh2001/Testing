package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class BeneficiaryReportCancelBehavior_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public BeneficiaryReportCancelBehavior_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateBeneficiaryReportCancelBtnBehavior
	Purpose    : To validate the Loan Summary of a plan 
	Author     : 30-Jun-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getBeneficiaryDsgnData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("BeneficiaryDsgnReportData");
		return data;
	}
	@Test(dataProvider="getBeneficiaryDsgnData")
	public void validateBeneficiaryReportCancelBtnBehavior(String userName, String passWord, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Beneficiary Designation Report Cancel Button Behavior");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyBeneficiaryReportCancelBtnBehavior(planNumber);
		
	}
	
	
	
	
	
	
}
