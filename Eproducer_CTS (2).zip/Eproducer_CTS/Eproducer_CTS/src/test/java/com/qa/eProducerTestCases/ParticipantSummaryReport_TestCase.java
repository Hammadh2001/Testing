package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ParticipantSummaryReport_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ParticipantSummaryReport_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateParticipantSummaryReport
	Purpose    : To validate the Participant Summary report 
	Author     : 7-Jun-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getPartcpntSmryData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("ParticipantSummaryData");
		return data;
	}
	@Test(dataProvider="getPartcpntSmryData")
	public void validateParticipantSummaryReport(String userName, String passWord, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Participant Summary Report");
		//EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyParticipantSummaryReport(planNumber);
		
	}
	
	
	
	
	
	
}
