package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class CompensationDetail_Individual_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public CompensationDetail_Individual_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateCompensationDetailIndividualPage
	Purpose    : To validate Compensation Detail Individual Page 
	Author     : 11-Jun-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getCmpnstnIndividualData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("CompensationIndividualData");
		return data;
	}
	@Test(dataProvider="getCmpnstnIndividualData")
	public void validateCompensationDetailIndividualPage(String userName, String passWord, String ProdSearchBy, String criteriaTxt) throws InterruptedException {
		extentTest = extent.createTest("Compensation Detail Individual Page");
	//	EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.loginToAppHONew(userName, passWord);
		EProduceractions.verifyCompensationDetailIndividualPage(ProdSearchBy, criteriaTxt);
			
	}
	
	
	
	
	
	
}
