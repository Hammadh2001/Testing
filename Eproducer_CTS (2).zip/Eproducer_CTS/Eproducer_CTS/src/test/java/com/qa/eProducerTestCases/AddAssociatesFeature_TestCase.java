package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class AddAssociatesFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public AddAssociatesFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateAddAssociatesFeature
	Purpose    : To validate Adding Associates feature 
	Author     : 17-Mar-2021 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getAddAssociatesData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("AddAssociatesData");
		return data;
	}
	@Test(dataProvider="getAddAssociatesData")
	public void validateAddAssociatesFeature(String username, String password, String firstName, String lastName, 
			String acsLevel, String regEmailInvld, String regEmailVld) throws InterruptedException {
		extentTest = extent.createTest("Add Associates feature");
		EProduceractions.loginToAppNonHONew(username, password);
		EProduceractions.verifyAddAssociatesFeature(firstName, lastName, acsLevel, regEmailInvld, regEmailVld);
		
	}
	
	
	
	
	
	
}
