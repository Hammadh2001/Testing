package com.qa.eProducer_LoginSmokeTesting_TestCases;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class LoginFunctionality_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public LoginFunctionality_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateLoginFunctionality_TestCase
	Purpose    : To validate Login Functionality
	Author     : 19 Feb 2025 by Emma 
	***********************************************************************/
	@DataProvider
	public Object[][] getLoginDetailsData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("LoginData");
		return data;
	}
	@Test(dataProvider="getLoginDetailsData")
	public void validateLoginDetailsPage(String username, String password, String planNumber) throws InterruptedException {
		extentTest = extent.createTest("Login Details Page Feature Smoke Testing");
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		
	}

}
