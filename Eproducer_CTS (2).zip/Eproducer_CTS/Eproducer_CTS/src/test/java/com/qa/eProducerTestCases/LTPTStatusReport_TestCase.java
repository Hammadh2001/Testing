package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class LTPTStatusReport_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public LTPTStatusReport_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		//initialization();
		initializationtrial();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateLTPTStatusReportFeature
	Purpose    : To validate LTPT Status Report feature
	Author     : 02-Feb-2024 by Priya Natarajan 
	***********************************************************************/
	@DataProvider
	public Object[][] getLTPTStatusReportData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("LTPTStatusReport");
		return data;
	}
	@Test(dataProvider="getLTPTStatusReportData")
	public void validateLTPTStatusReportFeature(String username, String password, String planNumber,
			String PM702, String PH625) throws InterruptedException {
		extentTest = extent.createTest("eProducer LTPT Status Report Feature");
		//EProduceractions.loginToApp_HOUsr(username, password);
		EProduceractions.loginToAppHONew(username, password);
		EProduceractions.searchPlanFunctionality(planNumber);
		EProduceractions.verifyLTPTStatusReport(planNumber, PM702, PH625);
		
	}
	
	
	
	
	
	
}
