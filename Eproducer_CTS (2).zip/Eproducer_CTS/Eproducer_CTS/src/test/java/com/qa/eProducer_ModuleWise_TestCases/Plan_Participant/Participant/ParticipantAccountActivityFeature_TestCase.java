package com.qa.eProducer_ModuleWise_TestCases.Plan_Participant.Participant;

import java.io.FileNotFoundException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class ParticipantAccountActivityFeature_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public ParticipantAccountActivityFeature_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validateParticipantAccountActivityFeature
	Purpose    : To validate the participant data elements and sections displayed 
	Author     : 9-Jul-2020 by Yogesh SB
	***********************************************************************/
	@DataProvider
	public Object[][] getParticipantData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("AccountActvtyData");
		return data;
	}
	@Test(dataProvider="getParticipantData")
	public void validateParticipantAccountActivityFeature(String userName, String passWord, String planNumber, String SSN, String fromDate, String toDate) throws InterruptedException {
		extentTest = extent.createTest("View Participant Account Activity feature");
		EProduceractions.loginToApp_HOUsr(userName, passWord);
		EProduceractions.verifyParticipantAccountActivity(planNumber, SSN, fromDate, toDate);
		
	}
	
	
	
	
	
	
}
