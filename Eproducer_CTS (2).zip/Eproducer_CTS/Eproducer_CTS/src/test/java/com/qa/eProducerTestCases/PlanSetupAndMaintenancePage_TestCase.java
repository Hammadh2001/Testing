package com.qa.eProducerTestCases;

import java.io.FileNotFoundException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.base.TestBase;
import com.qa.eProducerActions.EProducerActions;
import com.qa.utils.TestUtils;

public class PlanSetupAndMaintenancePage_TestCase extends TestBase {
	EProducerActions EProduceractions;

	public PlanSetupAndMaintenancePage_TestCase() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		EProduceractions = new EProducerActions();
	}
	
	/* ******************************************************************
	Test Name  : validatePlanSetupAndMaintenancePage
	Purpose    : To validate Plan Setup and Maintenance page
	Author     : 9-Jun-2021 by Yogesh SB 
	***********************************************************************/
	@DataProvider
	public Object[][] getPlanSetupMaintenanceData() throws FileNotFoundException {
		Object data[][] = TestUtils.geteProducerTestData("PlanSetupMaintenanceData");
		return data;
	}
	@Test(dataProvider="getPlanSetupMaintenanceData")
	public void validatePlanSetupAndMaintenancePage(String username, String password, String agentRole, String adviceOnly) throws InterruptedException {
		extentTest = extent.createTest("Plan Setup and Maintenance page " +agentRole);
		//EProduceractions.loginToAppNonHO(username, password);
		EProduceractions.loginToAppNonHOnew(username, password);
		EProduceractions.verifyPlanSetupAndMaintenancePage(agentRole, adviceOnly);
		
	}
	
	
	
	
	
	
}
