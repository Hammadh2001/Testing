package com.qa.eProducerActions;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.SkipException;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.qa.eProducerPages.EProducerWebPageElements;

public class EProducerActions extends EProducerWebPageElements {

	public EProducerActions() {
		super();
	}

	// eProducer application actions

	// Login to application actions for Non HO users
	public void loginToAppNonHO(String username, String password) throws InterruptedException {
		EnterText(UserNameTxtFld, username, "UserName");
		EnterText(PasswordTxtFld, password, "Password");
		ClickElement(LoginBtn, "Login Button");
		Thread.sleep(1000);
		try {
			if (infoHeaderLogged.isDisplayed()) {
				assertElementDisplayed(eProducerAppLink, "eProducer Application Link");
				ClickElement(eProducerAppLink, "eProducer Application Link");
			}
		} catch (Exception e) {
			extentTest.log(Status.INFO, "Logged in user is mapped only to eProducer.");
			// assertElementDisplayed(eProducerPageHeader, "Welcome to eProducer Header");
		}
	}

	public void loginToAppurl(String URLReports, String userName, String password) throws InterruptedException {
		if (homepagElement.isDisplayed()) {
			driver.get(URLReports);
			assertElementDisplayed(LoginpageHeader, LoginpageHeader.getText());
			takeScreenshotForPassedcase("Url Launched");
			extentTest.log(Status.PASS, "URL launch before Logged in");
		} else {
			extentTest.log(Status.FAIL, "URL launch before Logged in");
		}
		EnterText(UserNameTxtFld, userName, "UserName");
		EnterText(PasswordTxtFld, password, "Password");
		ClickElement(LoginBtn, "Login Button");
		Thread.sleep(5000);
		try {
			if (eProducerAppLink.isDisplayed()) {
				assertElementDisplayed(eProducerAppLink, "eProducer Application Link");
				ClickElement(eProducerAppLink, "eProducer Application Link");
			}
		} catch (Exception e) {
			extentTest.log(Status.INFO, "Multiple Apps are not mapped to the selected user");
		}
	}

	// Login to application actions for HO Users
	public void loginToApp_HOUsr(String username, String password) throws InterruptedException {
		EnterText(UserNameTxtFld, username, "UserName");
		EnterText(PasswordTxtFld, password, "Password");
		ClickElement(LoginBtn, "Login Button");
		Thread.sleep(2000);
		ClickElement(eProducerAppLink, "eProducer Application Link");
	}
	public void loginToAppHONew(String username, String password) throws InterruptedException {
		EnterText(UserNameTxtFldnew, username, "UserName");
		EnterText(PasswordTxtFldnew, password, "Password");
		Thread.sleep(10000);
		ClickElement(LoginBtnnew, "Login button");
		Thread.sleep(10000);
		ClickElementJS(eProducerlinknew, "eProducer link new");
	takeScreenshotForPassedcase("Login Successfully");
		Thread.sleep(5000);
	}
	public void loginToAppNonHOnew(String username, String password) throws InterruptedException {
		EnterText(UserNameTxtFldnew, username, "UserName");
		EnterText(PasswordTxtFldnew, password, "Password");
		ClickElementJS(LoginBtnnew, "Login Button");
		Thread.sleep(2000);
	}
	public void loginToAppNonHONew(String username, String password) throws InterruptedException {
		EnterText(UserNameTxtFldnew, username, "UserName");
		EnterText(PasswordTxtFldnew, password, "Password");
		ClickElementJS(LoginBtnnew, "Login Button");
		Thread.sleep(2000);
		try {
			if (infoHeaderLogged.isDisplayed()) {
				Thread.sleep(2000);
				assertElementDisplayed(eProducerlinknew, "eProducer Application Link");
				ClickElementJS(eProducerlinknew, "eProducer Application Link");
			}
			else {
				
			}
		} catch (Exception e) {
			extentTest.log(Status.INFO, "Logged in user is mapped only to eProducer.");
			// assertElementDisplayed(eProducerPageHeader, "Welcome to eProducer Header");
		}
	}
	public void loginToApp_HOUsrV(String URLReports,String username, String password) throws InterruptedException {
		EnterText(UserNameTxtFldnew, username, "UserName");
		EnterText(PasswordTxtFldnew, password, "Password");
		Thread.sleep(10000);
		ClickElement(LoginBtnnew, "Login button");
		Thread.sleep(10000);
		ClickElementJS(eProducerlinknew, "eProducer link new");
	}
	// Logout from application
	public void logoutFromApplication() throws InterruptedException {
		ClickElement(Logoutlink, "Logout link");
		Thread.sleep(2000);
		assertElementDisplayed(LogoutSuccessMsg, "Logout Success Msg");
	}

	// Select Plan actions
	public void selectPlan(String planNumber) throws InterruptedException {
		Assert.assertTrue(PlanListHeader.isDisplayed());
		String xpath = "//form[@id='dataTableForm']//a/span[contains(text(),'" + planNumber + "')]";
		WebElement plannumber = driver.findElement(By.xpath(xpath));
		ClickElement(plannumber, "Plan Number: " + planNumber);
		Thread.sleep(2000);
	}

	// Search a plan actions
	public void searchPlanFunctionality(String planNumber) throws InterruptedException {
		MoveToElement(PlanParticipantMenu, "Plan/Participant Menu");
		ClickElement(PlanParticipantDataSubmenu, "Plan/Participant Data Sub-menu");
		try {
			if (SearchHeader.isDisplayed()) {
				assertElementDisplayed(SearchHeader, "Search Header");
				assertElementDisplayed(PlanInfoSearchHeader, "Plan/Participant Information Search Header");
				EnterText(CriteriaTxtFld, planNumber, "Criteria");
//				CriteriaTxtFld.sendKeys(Keys.RETURN);
//				Thread.sleep(2000);
//				PlanSearchBtn.click();
//				ComboSelectValue(selectMtchng, "begin", "Matching");
				ClickElementJS(PlanSearchBtn, "Search Button");
				selectPlan(planNumber);
			}
		} catch (Exception e) {
			selectPlan(planNumber);
		}
	}

	// Search a participant actions
	public void searchParticipantFunctionality(String planNumber) throws InterruptedException {
		MoveToElement(PlanParticipantMenu, "Plan/Participant Menu");
		ClickElement(PlanParticipantDataSubmenu, "Plan/Participant Data Sub-menu");
		try {
			if (SearchHeader.isDisplayed()) {
				assertElementDisplayed(SearchHeader, "Search Header");
				assertElementDisplayed(PlanInfoSearchHeader, "Plan/Participant Information Search Header");
				EnterText(CriteriaTxtFld, planNumber, "Criteria");
				ClickElementJS(PlanSearchBtn, "Search Button");
				ClickElementJS(ParticipantSearchBtn, "Search Button");
			}
		} catch (Exception e) {
			selectPlan(planNumber);
		}
	}

	// Search Producer test case actions
	public void verifySearchProducer(String searchBy, String criteriaTxt) throws InterruptedException {
		MoveToElement(PlanParticipantMenu, "Plan/Participant Menu");
		ClickElement(PlanParticipantDataSubmenu, "Plan/Participant Data Sub-menu");
		assertElementDisplayed(SearchHeader, "Search Header");
		assertElementDisplayed(PlanInfoSearchHeader, "Plan/Participant Information Search Header");
		ComboSelectVisibleText(selectSearchBy, searchBy, "Search By: ");
		EnterText(CriteriaTxtFld, criteriaTxt, "Criteria");
		ClickElementJS(PlanSearchBtn, "Search Button");
		Thread.sleep(2000);
		assertElementDisplayed(headerProdList, headerProdList.getText() + " Header");
		takeScreenshot("Producer Search-Producer List");
		ClickElement(linkProdName, "Producer Name Link: " + linkProdName.getText());
		Thread.sleep(2000);
		takeScreenshot("Producer Search-Plan List");
		assertElementDisplayed(headerPlanList, headerPlanList.getText() + " Header");

	}

	// upload file method
	public void verifyChooseFile(String file) throws AWTException, InterruptedException {

		String Dynamicfilepath = System.getProperty("user.dir");

		StringSelection s = new StringSelection(Dynamicfilepath + "\\src\\resource\\java\\com\\qa\\testdata\\" + file);

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s, null);
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		Thread.sleep(1000);
		r.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		r.keyRelease(KeyEvent.VK_V);
		Thread.sleep(1000);
		r.keyRelease(KeyEvent.VK_CONTROL);
		Thread.sleep(1000);
		r.keyPress(KeyEvent.VK_ENTER);
		Thread.sleep(1000);
		r.keyRelease(KeyEvent.VK_ENTER);
		extentTest.log(Status.PASS, "File is Uploaded");
		ClickElement(LTPTSubmitButton, " LTPT Submit Button");

	}

	// View HO User PPR Status test case actions
	public void verifyHOViewPPRStatus(String budgetCode, String fromDate) throws InterruptedException {
		MoveToElement(SalesMenu, "Sales menu");
		ClickElement(PresentationsAndMaterialsSubmenu, "Presentations And Materials Sub-menu");
		assertElementDisplayed(PrsntnsandMtrlsHeader, "Presentations And Materials Header");
		assertElementDisplayed(PeriodicPlanReviewHeader, "Periodic Plan Review Header");
		assertElementDisplayed(PPRStatusLink, "PPR Status Link");
		ClickElement(PPRStatusLink, "PPR Status Link ");
		assertElementDisplayed(PPRStatusHeader, "PPR Status Header");
		takeScreenshot("PPR Status page");
		ComboSelectVisibleText(BudgetCodeList, budgetCode, "Budget Code List");
		EnterText(PPR_FromDateTxtFld, fromDate, "From Date");
		ClickElement(SearchBtn, "Search Button");
		Thread.sleep(2000);
		assertElementDisplayed(PlanCol, "Plan Column");
		assertElementDisplayed(SubmitDate, "Submit Date Column");
		assertElementDisplayed(StatusCol, "Status Column");
		assertElementDisplayed(StatusDateCol, "Status Date Column");
		assertElementDisplayed(OrderNumbCol, "Order Number Column");
		assertElementDisplayed(ActionCol, "Action Column");
		assertElementDisplayed(PPR_SubmitBtn, "Submit Button");
		extentTest.log(Status.PASS, "HO User view PPR Status feature implemented as expected and working successfully");
	}

	// Transaction Summary feature test case actions
	public void verifyTransactionSummaryFeature(String planNumber) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		Thread.sleep(2000);
		ClickElement(TransactionSummaryLink, "Transaction Summary Link");
		assertElementDisplayed(TransactionSummaryHeader, "Transaction Summary Header");
		takeScreenshot("Transaction Summary Page");
		assertElementDisplayed(QurterlyReportsLink, "Qurterly Reports Link");
		assertElementDisplayed(AnnualReportsLink, "Annual Reports Link");
		ClickElement(QurterlyReportsLink, "Qurterly Reports Link");
		assertElementDisplayed(TrscnSumryForPlanHeader, TrscnSumryForPlanHeader.getText());
		try {
			assertElementDisplayed(TitleHeader, "Title Header");
			ClickElement(QuarterReportLink, "Quarter Report Link");
			Thread.sleep(2000);
			extentTest.log(Status.PASS,
					"Transaction Summary report is downloaded and Feature is implemented as expected and working successfully");
		} catch (Exception e) {
			if (NoReportsMsg.isDisplayed()) {
				takeScreenshot("Transaction Summary-No Reports Info message");
				extentTest.log(Status.INFO, NoReportsMsg.getText());
				throw new SkipException(
						"Test case is skipped due to the unavailability of transaction summary reports links for the selected plan.");
			}
		}
	}

	// Select a loan id actions
	public void selectLoanID(String SSN) throws InterruptedException {
		String idPath = "//form[@id='dataTable']//tr//span[contains(text(),'-" + SSN + "')]//following::td[1]/a/span";
		WebElement loanIDLink = driver.findElement(By.xpath(idPath));
		ClickElement(loanIDLink, "Loan ID Link");
		Thread.sleep(2000);
	}

	public void selectDivLoanID(String SSN) throws InterruptedException {
		String idPath = "//form[@id='dataTable']//tr//span[contains(text(),'-" + SSN + "')]//following::td[2]/a/span";
		WebElement loanIDLink = driver.findElement(By.xpath(idPath));
		ClickElement(loanIDLink, "Loan ID Link");
		Thread.sleep(2000);
	}

	// Loan Summary test case actions
	public void verifyLoanSummaryFeature(String planNumber, String SSN) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		MoveToElement(PlanParticipantMenu, "Plan Participant Menu");
		ClickElement(LoanCenterSubmenu, "Loan Center Sub-menu");
		Thread.sleep(10000);
		assertElementDisplayed(LoanSummaryHeader, "Loan Summary Header");
		takeScreenshot("Loan Summary Page");
		assertElementDisplayed(DownloadIcon, "Download Icon");
		try {
			if (DivisonCol.isDisplayed()) {
				selectDivLoanID(SSN);
			}
		} catch (Exception e) {
			selectLoanID(SSN);
		}
		assertElementDisplayed(LoanHistoryHeader, "Loan History Header");
		try {
			if (LoanNumberCol.isDisplayed()) {
				takeScreenshot("Loan History Page");
				assertElementDisplayed(LoanNumberCol, "Loan Number Column");
				assertElementDisplayed(PaymentDateCol, "Payment Date Column");
				assertElementDisplayed(PaymentAmountCol, "Payment Amount Column");
				assertElementDisplayed(PrincipalPaidCol, "Principal Paid Column");
				assertElementDisplayed(InterestPaidCol, "Interest Paid Column");
				assertElementDisplayed(LoanBalanceCol, "Loan Balance Column");
				ClickElement(DownloadIcon, "Download Icon");
				Thread.sleep(2000);
				extentTest.log(Status.PASS, "Loan Summary Feature is implemented as expected and working successfully");
			}
		} catch (Exception e) {
			assertElementDisplayed(NoPaymentHistoryInfo, "No Payment History Info");
			takeScreenshot("Loan Summary-No Payment History Info");
			extentTest.log(Status.INFO, NoPaymentHistoryInfo.getText());
			throw new SkipException(
					"Test case is skipped due to no payment history. Use other plan number or other loan ID to execute the script");
		}
	}

	public void verifyresidentialloanforfiduciaryPlan(String planNumber, String partSSN)
			throws InterruptedException, IOException {
		searchParticipantFunctionality(planNumber);
		String partSSNxpath = "//span[contains(text(),'" + partSSN + "')]/parent::td/preceding-sibling::td/a";
		WebElement participantlink = driver.findElement(By.xpath(partSSNxpath));
		ClickElement(participantlink, "Participant link");
		ClickElement(loancalculatorlink, "loancalculator link");
		ScrollTo(loancalculateheader, "Calculate button");
		takeScreenshot("Loan Calculator Page");
		boolean value = assertElementfornonDisplayed(residentialloan,
				"Is this loan for purchasing a primary residence?");
		if (value == false) {
			extentTest.log(Status.PASS, "Is this loan for purchasing a primary residence? is not displayed");
		}
		extentTest.pass("Residential Loan section is not displayed",
				MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
		Select s = new Select(driver.findElement(By.xpath("//select[@id = 'requestForm:convDurations']")));
		List<WebElement> options = s.getOptions();
		int size = options.size();
		Assert.assertEquals(size, 5, "Maximum Loan duration should be 5 years for Non residential loan");
		extentTest.log(Status.PASS, "Maximum Loan duration should be 5 years for Non residential loan");
		extentTest.log(Status.INFO,
				"residential loan feature for non fiduciary plan is implemented as expected and working successfully");

		Thread.sleep(10000);

	}

	public void verifyresidentialloanfornonfiduciaryPlan(String planNumber, String partSSN)
			throws InterruptedException, IOException {
		searchParticipantFunctionality(planNumber);
		String partSSNxpath = "//span[contains(text(),'" + partSSN + "')]/parent::td/preceding-sibling::td/a";
		WebElement participantlink = driver.findElement(By.xpath(partSSNxpath));
		ClickElement(participantlink, "Participant link");
		ClickElement(loancalculatorlink, "loancalculator link");
		ScrollTo(loancalculateheader, "Calculate button");
		takeScreenshot("Loan Calculator Page");
		assertElementDisplayed(residentialloan, "Is this loan for purchasing a primary residence?");
		extentTest.pass("Residential loan section is displayed",
				MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
		Select s = new Select(driver.findElement(By.xpath("//select[@id = 'requestForm:convDurations']")));
		List<WebElement> options = s.getOptions();
		int size = options.size();
		Assert.assertEquals(size, 5, "Maximum Loan duration should be 5 years for Non residential loan");
		extentTest.log(Status.PASS, "Maximum Loan duration should be 5 years for Non residential loan");
		ClickElement(residentialloan_duration_yes, "residential loan duration yes");

		Select s1 = new Select(driver.findElement(By.xpath("//select[@id = 'requestForm:resDurations']")));
		List<WebElement> options1 = s1.getOptions();
		int resloanduration = options1.size();
		Assert.assertEquals(resloanduration, 30, "Maximum Loan duration should be 30 years for Non residential loan");
		extentTest.log(Status.PASS, "Maximum Loan duration should be 30 years for residential loan");

		extentTest.log(Status.INFO,
				"residential loan feature for non fiduciary plan is implemented as expected and working successfully");

		Thread.sleep(10000);
//		assertElementDisplayed(LoanSummaryHeader, "Loan Summary Header");
//		takeScreenshot("Download divisional plan-Loan Summary Page");
	}

	// Download divisional plan test case action
	public void verifyDownloadDivisonalPlanReport(String planNumber, String SSN) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		MoveToElement(PlanParticipantMenu, "Plan Participant Menu");
		ClickElement(LoanCenterSubmenu, "Loan Center Sub-menu");
		Thread.sleep(10000);
		assertElementDisplayed(LoanSummaryHeader, "Loan Summary Header");
		takeScreenshot("Download divisional plan-Loan Summary Page");
		assertElementDisplayed(DownloadIcon, "Download Icon");
		try {
			if (DivisonCol.isDisplayed()) {
				ComboSelectVisibleText(DisplayList, "all", "Display Rows");
				Thread.sleep(2000);
				assertElementDisplayed(DivisonCol, "Divison Column");
				ClickElement(DownloadIcon, "Download Icon");
				Thread.sleep(2000);
				extentTest.log(Status.INFO, "Loan Summary report downloaded as expected and working successfully");
				selectDivLoanID(SSN);
				assertElementDisplayed(LoanHistoryHeader, "Loan History Header");
				try {
					if (LoanNumberCol.isDisplayed()) {
						takeScreenshot("Download divisional plan-Loan History Page");
						assertElementDisplayed(LoanNumberCol, "Loan Number Column");
						assertElementDisplayed(PaymentDateCol, "Payment Date Column");
						assertElementDisplayed(PaymentAmountCol, "Payment Amount Column");
						assertElementDisplayed(PrincipalPaidCol, "Principal Paid Column");
						assertElementDisplayed(InterestPaidCol, "Interest Paid Column");
						assertElementDisplayed(LoanBalanceCol, "Loan Balance Column");
						ClickElement(DownloadIcon, "Download Icon");
						Thread.sleep(2000);
						extentTest.log(Status.INFO,
								"Loan History report downloaded as expected and working successfully");
						extentTest.log(Status.PASS,
								"Download Divisional Plan feature is implemented as expected and working successfully");
					}
				} catch (Exception e) {
					assertElementDisplayed(NoPaymentHistoryInfo, "No Payment History Info");
					takeScreenshot("Download divisional plan-No Payment History Info");
					extentTest.log(Status.INFO, NoPaymentHistoryInfo.getText());
					throw new SkipException(
							"Test case is skipped due to no payment history. Use other plan number or other loan ID to execute the script");
				}
			}
		} catch (Exception e) {
			extentTest.log(Status.INFO, "Division Column is not displayed for the selected plan");
			throw new SkipException(
					"Test case is skipped. Divison column is not avialble for the selected plan. Use other plan number to execute the script");

		}
	}

	// Download Investment performance report test case actions
	public void verifyDownloadInvstPrfrmncReport(String planNumber) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		Thread.sleep(2000);
		ClickElement(PerformanceLink, "Performance Link");
		Thread.sleep(2000);
		assertElementDisplayed(InvstmntPrfrmncHeader, "Investment Performance Header");
		takeScreenshot("Investment Performance Page");
		ClickElement(DownloadIcon, "Download Icon");
		Thread.sleep(2000);
		extentTest.log(Status.PASS,
				"Download of Investment Performance report feature is implemented as expected and working successfully");
	}

	// Beneficiary Designation report cancel button behavior test case actions
	public void verifyBeneficiaryReportCancelBtnBehavior(String planNumber) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		Thread.sleep(2000);
		ClickElement(PrtcpntBeneficiaryDsgnLink, "Participant Beneficiary Designation Link");
		Thread.sleep(2000);
		assertElementDisplayed(PrtcptBeneficiaryDsgnHeader, "Participant Beneficiary Designation Header");
		takeScreenshot("Participant Beneficiary Designation Page");
		ComboSelectVisibleText(SelectDsgnList, "Primary Designated", "Designation Type");
		Thread.sleep(2000);
		assertElementDisplayed(PrtcptNameCol, "Participant Name Column");
		assertElementDisplayed(SSNCol, "SSN Column");
		assertElementDisplayed(DOBCol, "DOB Column");
		assertElementDisplayed(PrimaryDsgnCol, "Primary Designation Column");
		Thread.sleep(3000);
		ClickElement(DesignatedLink, "Designated Link");
		Thread.sleep(1000);
		assertElementDisplayed(BeneficiaryInformationHeader, "Beneficiary Information Header");
		takeScreenshot("Beneficiary Information Page");
		assertElementDisplayed(CancelBtn, "Cancel Button");
		ClickElement(CancelBtn, "Cancel Button");
		assertElementDisplayed(PrtcptBeneficiaryDsgnHeader, "Participant Beneficiary Designation Header");
		extentTest.log(Status.PASS,
				"Beneficiary Report Cancel button behavior is implemented as expected and working successfully");
	}

	// Investment Advisor support page actions
	public void verifyInvsmtAdvSuprtPageLinks() throws InterruptedException {
		MoveToElement(InvestmentMenu, "Investment Menu");
		ClickElement(InvsmtAdvisorSupportSubmenu, "Investment Advisor Support Sub-menu");
		assertElementDisplayed(InvsmtAdvsrSuprtHeader, "Investment Advisor Support Header");
		takeScreenshotForPassedcase("Investment Advisor Support Page");
		//takeScreenshot("Investment Advisor Support Page");
		int linksCount = InvsmtAdvsrSupLinks.size();
		extentTest.log(Status.INFO, "Number of links displayed :" + linksCount);
		for (int i = 0; i < linksCount; i++) {
			String link = InvsmtAdvsrSupLinks.get(i).getText();
			System.out.println("Link displayed : " + link);
			InvsmtAdvsrSupLinks.get(i).click();
			Thread.sleep(1000);
			switchToWindows(InvsmtAdvsrSupLinks.get(i).getText());
			extentTest.log(Status.INFO,
					InvsmtAdvsrSupLinks.get(i).getText() + " link is clicked and closed successfully");
		}
		extentTest.log(Status.PASS, "Investment Advisor Support page links are working as expected");
	}

	// Important Documents test case actions
	public void verifyImportantDocumentsLinks(String planNumber) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		Thread.sleep(2000);
		ClickElement(ImportantDocsLink, "Important Documents Link");
		assertElementDisplayed(ImportantDocsHeader, "Important Documents Header");
		takeScreenshot("Important Documents Page");
		assertElementDisplayed(PlanDocLink, "Plan Documents Link");
		assertElementDisplayed(SummaryPlanDescrpLink, "Summary Plan Descriptions Link");
		assertElementDisplayed(ContractLink, "Contract, Amendments and Agreements Link");
		try {
			ClickElement(PlanDocLink, "Plan Documents Link");
			assertElementDisplayed(DocLinkHeader, DocLinkHeader.getText() + " Header");
			ClickElement(DocLinkInPlanDocuments, DocLinkInPlanDocuments.getText() + " Link");
			Thread.sleep(1000);
			ClickElement(FeeeDisclosureLink, FeeeDisclosureLink.getText() + " Link");
			switchToWindows(FeeeDisclosureLink.getText());
			extentTest.log(Status.PASS,
					"Important Documents functionality is implemented as expected and links are working successfully");
		} catch (Exception e) {
			assertElementDisplayed(NoDocsInfoMsg, NoDocsInfoMsg.getText());
			takeScreenshot("Important Docs-No Docs info message");
			extentTest.log(Status.INFO, NoDocsInfoMsg.getText());
			throw new SkipException(
					"Test case is skipped due to no documents available. Please use the other plan number");
		}

	}

	// View Current investment models test case actions //AA26760, G62286
	public void verifyViewCurrentInvestmentModelFeature(String ProducerID, String planNumber)
			throws InterruptedException {
		MoveToElement(InvestmentMenu, "Investment Menu");
		ClickElement(InvsmtAdvisorSupportSubmenu, "Investment Advisor Support Sub-menu");
		takeScreenshot("Investment Advisor Support Page");
		Thread.sleep(1000);
		ClickElement(PlanSetUpandMaintenanceLink, "Plan SetUp and Maintenance Link");
		assertElementDisplayed(AdvisorSearchHeader, "Advisor Search Header");
		takeScreenshot("Advisor Search page");
		EnterText(Advsr_Criteria, "AA", "Criteria");
		ClickElement(Advsr_SearchBtn, "Advsr_SearchBtn");
		ComboSelectVisibleText(DisplayList, "all", "Display");
		Thread.sleep(2000);
		String advisoridPath = "//form[@id='dataTable']//td/a[contains(text(),'" + ProducerID + "')]";
		WebElement prodName = driver.findElement(By.xpath(advisoridPath));
		ClickElement(prodName, "Advisor ID: " + ProducerID);
		assertElementDisplayed(PlanSetUpandMaintenanceHeader, "Plan SetUp and Maintenance Header");
		try {
			if (SelectaPlanInfo.isDisplayed()) {
				assertElementDisplayed(SelectaPlanInfo, SelectaPlanInfo.getText());
				String planNum = "//form[@id='dataTable']//td/a/span[contains(text(),'" + planNumber + "')]";
				WebElement plannum = driver.findElement(By.xpath(planNum));
				ClickElement(plannum, "Plan Number Link: " + planNumber);
				try {
					if (InvestmentModelsLink.isDisplayed()) {
						assertElementDisplayed(InvestmentModelsLink, "Investment Models Link");
						ClickElement(InvestmentModelsLink, "Investment Models Link");
						assertElementDisplayed(InvsmtModelHeader, "Investment Models Header");
						takeScreenshot("Investment Models Page");
						ClickElement(ModelNameLink, "Model Name Link");
						assertElementDisplayed(InvsmtModelSetupHeader, "Investment Model Setup Header");
						assertElementDisplayed(ModelInfoHeader, "Model Information Header");
						assertElementDisplayed(ModelNameLabel, "Model Name Label");
						assertElementDisplayed(ModelNarrativeLabel, "Model Narrative Label");
						assertElementDisplayed(Editbtn, "Edit Button");
						ClickElement(Editbtn, "Edit Button");
						Thread.sleep(2000);
						assertElementDisplayed(InvsmtModandNartivHeader, "Investment Model Name and Narrative Header");
						NarrativeTextArea.clear();
						ClickElement(NextBtn, "Next Button");
						Thread.sleep(2000);
						assertElementDisplayed(GlobalErrorInfo, GlobalErrorInfo.getText());
						extentTest.log(Status.PASS,
								"View Current investment model feature is implemented as expected and working successfully");
					}
				} catch (Exception e) {
					assertElementDisplayed(NoPlanSetupRqd, NoPlanSetupRqd.getText());
					takeScreenshot("View Current investment models-SetUp is not required");
					extentTest.log(Status.INFO, NoPlanSetupRqd.getText() + " is displayed");
					throw new SkipException(
							"SetUp is not required for the selected plan. Use the other plan number to execute the script");
				}
			}
		} catch (Exception e) {
			assertElementDisplayed(NoResultsInfo, NoResultsInfo.getText());
			extentTest.log(Status.INFO, NoResultsInfo.getText() + " message is displayed for the selected AdvisorID");
			throw new SkipException(
					"Test case is skipped due to plans are not available for the selected Advisor ID. Use the other Advisor ID and execute the script");
		}

	}

	// View Investment models test case actions
	public void verifyViewInvestmentModelsFeature(String ProducerID, String planNumber, String invstModName)
			throws InterruptedException {
		MoveToElement(InvestmentMenu, "Investment Menu");
		ClickElement(InvsmtAdvisorSupportSubmenu, "Investment Advisor Support Sub-menu");
		Thread.sleep(1000);
		ClickElement(PlanSetUpandMaintenanceLink, "Plan SetUp and Maintenance Link");
		assertElementDisplayed(AdvisorSearchHeader, "Advisor Search Header");
		EnterText(Advsr_Criteria, "AA", "Criteria");
		ClickElement(Advsr_SearchBtn, "Advsr_SearchBtn");
		ComboSelectVisibleText(DisplayList, "all", "Display");
		Thread.sleep(2000);
		String advisoridPath = "//form[@id='dataTable']//td/a[contains(text(),'" + ProducerID + "')]";
		WebElement prodName = driver.findElement(By.xpath(advisoridPath));
		ClickElement(prodName, "Advisor ID: " + ProducerID);
		assertElementDisplayed(PlanSetUpandMaintenanceHeader, "Plan SetUp and Maintenance Header");
		try {
			if (SelectaPlanInfo.isDisplayed()) {
				assertElementDisplayed(SelectaPlanInfo, SelectaPlanInfo.getText());
				String planNum = "//form[@id='dataTable']//td/a/span[contains(text(),'" + planNumber + "')]";
				WebElement plannum = driver.findElement(By.xpath(planNum));
				ClickElement(plannum, "Plan Number Link: " + planNumber);
				try {
					if (InvestmentModelsLink.isDisplayed()) {
						assertElementDisplayed(InvestmentModelsLink, "Investment Models Link");
						takeScreenshot("View Investment models-Investment Models");
						ClickElement(InvestmentModelsLink, "Investment Models Link");
						assertElementDisplayed(InvsmtModelHeader, "Investment Models Header");
						ClickElement(AddAnotherModelBtn, "Add Another Model Button");
						assertElementDisplayed(InvsmtModelSetupHeader, "Investment Model Setup Header");
						assertElementDisplayed(Step1ModelName, "Step1: Model Name");
						assertElementDisplayed(Step2ModelAllocations, "Step2: Model Allocations");
						assertElementDisplayed(Step3Review, "Step3: Review");
						assertElementDisplayed(Step4Complete, " Step4: Complete");
						assertElementDisplayed(InvsmtModandNartivHeader, "Investment Model Name and Narrative Header");
						Thread.sleep(1000);
						EnterText(ModelNameTxtFld, invstModName, "Model Name");
						EnterText(ModelNarrativeTxtFld, "Testing Investment model is for test purpose",
								"Model Narrative");
						ClickElement(NextBtn, "Next Button");
						Thread.sleep(2000);
						assertElementDisplayed(ModelInfoHeader, "Model Information Header");
						takeScreenshot("View Investment models-Model Information page");
						assertElementDisplayed(IOEsHeader, IOEsHeader.getText());
						EnterText(AllocTxtBox, "100", "Allocation Percentage");
						ClickElement(TotalAlloctnPercntg, "Total Allocation Percentage");
						ClickElement(AllocNextBtn, "Next Button");
						ClickElement(AllocSubmitBtn, "Submit Button");
						Thread.sleep(2000);
						assertElementDisplayed(InfoMsg, InfoMsg.getText());
						ClickElement(ContModSetupBtn, "Continue Model Setup Button");
						Thread.sleep(2000);
						assertElementDisplayed(InfoMsg, InfoMsg.getText());
						ClickElement(ModelsCompleteBtn, "Models Complete-Submit for Review Button");
						Thread.sleep(1000);
						assertElementDisplayed(InfoMsg, InfoMsg.getText());
						takeScreenshot("View Investment models-Model successfully created page");
						extentTest.log(Status.PASS,
								"Creation of Investment Models feature is implemented as expected and working successfully");
					}
				} catch (Exception e) {
					assertElementDisplayed(NoPlanSetupRqd, NoPlanSetupRqd.getText());
					takeScreenshot("View Current investment models-SetUp is not required");
					extentTest.log(Status.INFO, NoPlanSetupRqd.getText() + " is displayed");
					throw new SkipException(
							"SetUp is not required for the selected plan. Use the other plan number to execute the script");
				}
			}
		} catch (Exception e) {
			assertElementDisplayed(NoResultsInfo, NoResultsInfo.getText());
			extentTest.log(Status.INFO, NoResultsInfo.getText() + " message is displayed for the selected AdvisorID");
			throw new SkipException(
					"Test case is skipped due to plans are not available for the selected Advisor ID. Use the other Advisor ID and execute the script");
		}
	}

	// Plan Setup and Maintenance page display with plans actions
	public void verifyPlanSetupAndMaintenancePage(String agentRole, String adviceOnly) throws InterruptedException {
		Thread.sleep(1000);
		MoveToElement(InvestmentMenu, "Investment Menu");
		ClickElementJS(InvsmtAdvisorSupportSubmenu, "Investment Advisor Support Sub-menu");
		Thread.sleep(1000);
		ClickElement(PlanSetUpandMaintenanceLink, "Plan SetUp and Maintenance Link");
		Thread.sleep(2000);
		assertElementDisplayed(PlanSetUpandMaintenanceHeader, "Plan SetUp and Maintenance Header");

		if ((agentRole.equalsIgnoreCase("RT") && adviceOnly.equalsIgnoreCase("NA"))
				|| (agentRole.equalsIgnoreCase("RT and RA") && adviceOnly.equalsIgnoreCase("Y"))) {
			assertElementDisplayed(infoMsgNoResultsFound, infoMsgNoResultsFound.getText());
			takeScreenshot("Plan Setup and Maintenance Page_No Results Found");
			extentTest.log(Status.PASS,
					infoMsgNoResultsFound.getText() + " message is displayed as expected for the logged in role");
		} else if ((agentRole.equalsIgnoreCase("RA") && adviceOnly.equalsIgnoreCase("Y"))
				|| (agentRole.equalsIgnoreCase("RA") && adviceOnly.equalsIgnoreCase("N"))
				|| (agentRole.equalsIgnoreCase("RT and RA") && adviceOnly.equalsIgnoreCase("N"))) {
			assertElementDisplayed(SelectaPlanInfo, "Info Text: " + SelectaPlanInfo.getText());
			takeScreenshot("Plan Setup and Maintenance Page_With Plans");
			extentTest.log(Status.PASS,
					"Plan Setup and Maintenance Page is displaying with the plans as expected for the logged in role");
		} else {
			extentTest.log(Status.SKIP,
					"Details of Agent_role and Advice_Only is not correct for the login data. Please add the correct details and try again");
			throw new SkipException(
					"Details of Agent_role and Advice_Only is not correct for the login data. Please add the correct details and try again");
		}
	}

	// My Profile link test case actions
	public void verifyUpdateCommissionAccessFeature() {
		ClickElement(MyProfileLink, "My Profile Link");
		assertElementDisplayed(MyProfileHeader, "My Profile Header");
		takeScreenshot("My Profile Page");
		assertElementDisplayed(SecAccsSettingsLink, "Security Access Settings Link");
		assertElementDisplayed(MaintainAssociateAccsLink, "Maintain Associate Access Link");
		assertElementDisplayed(ProdCommisnAccsLink, "Update Producer Commission Access Link");
		ClickElement(ProdCommisnAccsLink, "Update Producer Commission Access Link");
		assertElementDisplayed(CommAccssHeader, "Update Commission Access Header");
		takeScreenshot("Update Commission Access Page");
		assertElementDisplayed(CommissionLevelsHeader, "Commission Levels Header");
		ClickElement(FulAccessRadioBtn, "Full Access Radio Option");
		ClickElement(UpdateBtn, "Update Button");
		assertElementDisplayed(CommAccssChangeInfoMsg, CommAccssChangeInfoMsg.getText() + " Info Message");
		takeScreenshot("Update Commission Access with Info Message");
		extentTest.log(Status.PASS,
				"Update Commission Access feature is implemented as expected and working successfully");

	}

	// Add Associates test case actions
	public void verifyAddAssociatesFeature(String firstName, String lastName, String acsLevel, String regEmailInvld,
			String regEmailVld) throws InterruptedException {
		ClickElement(MyProfileLink, "My Profile Link");
		assertElementDisplayed(MyProfileHeader, "My Profile Header");
		takeScreenshot("Add Associates - My Profile Page");
		assertElementDisplayed(MaintainAssociateAccsLink, "Maintain Associate Access Link");
		ClickElement(MaintainAssociateAccsLink, "Maintain Associate Access Link");
		assertElementDisplayed(MaintainAssociateAccessHeader, "Maintain Associate Access Header");
		takeScreenshot("Add Associates - Maintain Associate Access Page");
		assertElementDisplayed(AddAssociateBtn, "Add Associate Button");
		ClickElement(AddAssociateBtn, "Add Associate Button");
		takeScreenshot("Add Associates - Add Associate Page");
		assertElementDisplayed(headerEnterInfo, headerEnterInfo.getText() + " Header");
		EnterText(txtldAAFirstName, firstName, "First Name");
		EnterText(txtldAALastName, lastName, "Last Name");
		ComboSelectVisibleText(selectAccessLevel, acsLevel, "Access Level");
		ClickElement(btnAASubmit, "Submit Button");
		Thread.sleep(2000);
		assertElementDisplayed(vldtnMsgpageLevelError, "Page Level Error: " + vldtnMsgpageLevelError.getText());
		assertElementDisplayed(vldtnMsgValRqrd,
				"Validation Message for Empty field Submission: " + vldtnMsgValRqrd.getText());
		takeScreenshot("Add Associates - With Vlidations Page");
		EnterText(txtldAARegEmail, regEmailInvld, "Email Address");
		ClickElement(btnAASubmit, "Submit Button");
		assertElementDisplayed(vldtnMsgValidEmailAdrs,
				"Validation Message For Invalid Email ID: " + vldtnMsgValidEmailAdrs.getText());
		takeScreenshot("Add Associates - With Email Address vlidation Msg");
		EnterText(txtldAARegEmail, regEmailVld, "Email Address");
		ClickElement(btnAASubmit, "Submit Button");
		Thread.sleep(2000);
		assertElementDisplayed(infoMsgAcsCodeSent, "Info Message: " + infoMsgAcsCodeSent.getText());
	takeScreenshotForPassedcase("Add Associate Feature");
		extentTest.log(Status.PASS, "Adding Associate feature is implemented as expected and working successfully");

	}

	// Edit Associates test case actions
	public void verifyEditAssociatesFeature(String acsLevel) {
		ClickElement(MyProfileLink, "My Profile Link");
		assertElementDisplayed(MyProfileHeader, "My Profile Header");
		takeScreenshot("Edit Associates - My Profile Page");
		assertElementDisplayed(MaintainAssociateAccsLink, "Maintain Associate Access Link");
		ClickElement(MaintainAssociateAccsLink, "Maintain Associate Access Link");
		assertElementDisplayed(MaintainAssociateAccessHeader, "Maintain Associate Access Header");
		takeScreenshot("Edit Associates - Maintain Associate Access Page");
		assertElementDisplayed(CurrentAssociateHeader, "Current Associates Header");
		assertElementDisplayed(EditLink, "Edit Link");
		ClickElement(EditLink, "Edit Link");
		assertElementDisplayed(EditAssociateHeader, "Edit Associate Header");
		assertElementDisplayed(EditAssociateInfoHeader, "Edit Associate Information Header");
		takeScreenshot("Edit Associate Page");
		ComboSelectVisibleText(selectAccessLevel, acsLevel, "Access Level");
		ClickElement(btnAASubmit, "Submit Button");
		assertElementDisplayed(MaintainAssociateAccessHeader, "Maintain Associate Access Header");
		extentTest.log(Status.PASS, "Edit Associate feature is implemented as expected and working successfully");

	}

	// Delete Associates Feature test case actions
	public void verifyDeleteAssociatesFeature() throws InterruptedException {
		ClickElement(MyProfileLink, "My Profile Link");
		assertElementDisplayed(MyProfileHeader, "My Profile Header");
		takeScreenshot("Delete Associates - My Profile Page");
		assertElementDisplayed(MaintainAssociateAccsLink, "Maintain Associate Access Link");
		ClickElement(MaintainAssociateAccsLink, "Maintain Associate Access Link");
		assertElementDisplayed(MaintainAssociateAccessHeader, "Maintain Associate Access Header");
		takeScreenshot("Delete Associates - Maintain Associate Access Page");
		assertElementDisplayed(CurrentAssociateHeader, "Current Associates Header");
		assertElementDisplayed(linkAsctDelete, "Delete Link");
		ClickElement(linkAsctDelete, "Delete Link");
		Thread.sleep(2000);
		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());
		Thread.sleep(2000);
		extentTest.log(Status.INFO, alert.getText());
		alert.accept();
		Thread.sleep(2000);
		assertElementDisplayed(infoMsgDeletionSuccess,
				"Deletion Confirmation Msg: " + infoMsgDeletionSuccess.getText());
		takeScreenshot("Delete Associates - Deleted Successfully");
		extentTest.log(Status.PASS, "Delete Associate feature is implemented as expected and working successfully");

	}

	// Select Participant name actions
	public void selectParticipantName(String prtcpntID) throws InterruptedException {
		String xpath = "//form[@id='dataTableForm']//table//tbody//tr//td//span[contains(text(),'" + prtcpntID
				+ "')]//ancestor::tr/td[1]/a/span";
		WebElement prtcpntName = driver.findElement(By.xpath(xpath));
		Thread.sleep(2000);
		ScrollTo(prtcpntName, "Participant Name: " + prtcpntName.getText());
		ClickElement(prtcpntName, "Participant SSN: ***-**-" + prtcpntID);
		Thread.sleep(2000);
	}

	// View Participant Data test case actions
	public void verifyViewParticipantData(String planNumber, String prtcpntID) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		ClickElement(ParticipantListLink, "Participant List Link");
		assertElementDisplayed(ParticipantListHeader, "Participant List Header");
		takeScreenshot("View Participant Data List page");
		selectParticipantName(prtcpntID);
		assertElementDisplayed(ViewPrtcpntDataHeader, ViewPrtcpntDataHeader.getText());
		assertElementDisplayed(PersonalDataHeader, "Personal Data Header");
		takeScreenshot("View Participant Data details page");
		assertElementDisplayed(NameLabel, "Name Label");
		assertElementDisplayed(PlanNumberLabel, "Plan Number Label");
		assertElementDisplayed(StatusLabel, "Status Label");
		assertElementDisplayed(SSNLabel, "SSN Label");
		assertElementDisplayed(EmploymentDateLabel, "Employment Date Label");
		assertElementDisplayed(DivisionLabel, "Division Label");
		assertElementDisplayed(DateofBirthLabel, "Date of Birth Label");
		assertElementDisplayed(EmailLabel, "Email Label");
		assertElementDisplayed(InvstmntAdvsrInfoHeader, "Investment Advisor Information Header");
		assertElementDisplayed(SourceInfoHeader, "Source Information Header");
		assertElementDisplayed(AcctBalncHeader, AcctBalncHeader.getText());
		extentTest.log(Status.PASS,
				"Participant Data elements and sections are displaying as expected and working successfully");
	}

	// Historical Feedback file download
	public void verifyHistoricalFeedbackFile(String planNumber, String fromDate, String toDate)
			throws InterruptedException {
		searchPlanFunctionality(planNumber);
		ClickElement(HistoricalFeedbackFileLink, "Historical Feedback File Link");
		assertElementDisplayed(HistoricalFeedbackFileHeader, "Historical Feedback File Header");
		takeScreenshot("Historical Feedback File Page");
		assertElementDisplayed(PlsSlecActvtyHeader, PlsSlecActvtyHeader.getText() + " Header");
		assertElementDisplayed(SelcDateRangeHeader, SelcDateRangeHeader.getText() + " Header");
		assertElementDisplayed(PrtcpntSearchCriteriaHeader, PrtcpntSearchCriteriaHeader.getText() + " Header");
		assertElementDisplayed(SelcDivisonHeader, SelcDivisonHeader.getText() + " Header");
		assertElementDisplayed(HFF_SubmitBtn, "Submit Button");
		EnterText(FromDate, fromDate, "From Date");
		EnterText(ToDate, toDate, "To Date");
		int CBs = checkBoxes.size();
		for (int i = 0; i < CBs; i++) {
			checkBoxes.get(i).click();
		}
		Thread.sleep(1000);
		ClickElement(HFF_SubmitBtn, "Submit Button");
		Thread.sleep(3000);
		extentTest.log(Status.PASS,
				"Historical Feedback File download feature is implemented as expected and working successfully");
	}

	// Participant Summary report test case actions
	public void verifyParticipantSummaryReport(String planNumber) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		ClickElement(sideMenuPrtcpnSummaryReport, "Participant Summary Report Side-menu");
		Thread.sleep(2000);
		assertElementDisplayed(headerPrtcpntSummary, headerPrtcpntSummary.getText() + " Header");
		takeScreenshot("Participant Summary Page");
		for (int i = 0; i < 3; i++) {
			ClickElement(linkPrtcpntSumryReports.get(i), linkPrtcpntSumryReports.get(i).getText() + " Link");
			Thread.sleep(2000);
		}
		extentTest.log(Status.PASS,
				"Participant Summary Report is downloaded and feature is implemented as expected and working successfully");
	}

	// Participant Account Activity test case actions
	public void verifyParticipantAccountActivity(String planNumber, String prtcpntID, String fromDate, String toDate)
			throws InterruptedException {
		searchPlanFunctionality(planNumber);
		ClickElement(ParticipantListLink, "Participant List Link");
		assertElementDisplayed(ParticipantListHeader, "Participant List Header");
		selectParticipantName(prtcpntID);
		assertElementDisplayed(ViewPrtcpntDataHeader, ViewPrtcpntDataHeader.getText());
		assertElementDisplayed(sideMenuAccountActivity, "Account Activity Side menu");
		ClickElement(sideMenuAccountActivity, "Account Activity Side menu");
		assertElementDisplayed(PrtcpntAcctActvtyHeader, PrtcpntAcctActvtyHeader.getText() + " Header");
		takeScreenshot("Participant Account Activity Page");
		assertElementDisplayed(AcctActivityHeader, AcctActivityHeader.getText() + " Header");
		assertElementDisplayed(Act_SubmitBtn, "Submit Button");
		EnterText(Act_fromDate, fromDate, "From Date");
		EnterText(Act_toDate, toDate, "To Date");
		ClickElement(Act_SubmitBtn, "Submit Button");
		Thread.sleep(1000);
		ScrollTo(ContributionSourceHeader, "Contribution Source Header");
		assertElementDisplayed(ContributionSourceHeader, ContributionSourceHeader.getText() + " Header");
		takeScreenshot("Partcpnt Acnt Actvty Contribution and Investment details");
		assertElementDisplayed(SourceColHeader, "Source Col Header");
		assertElementDisplayed(BgngBalColHeader, BgngBalColHeader.getText() + " Col Header");
		assertElementDisplayed(ContrbtnColHeader, ContrbtnColHeader.getText() + " Col Header");
		assertElementDisplayed(InvstGainColHeader, InvstGainColHeader + " Col Header");
		assertElementDisplayed(EndingBalColHeader, EndingBalColHeader.getText() + " Col Header");
		assertElementDisplayed(InvestmentOptionHeader, InvestmentOptionHeader.getText() + " Header");
		assertElementDisplayed(InvstOptnColHeader, InvstOptnColHeader.getText() + " Col Header");
		assertElementDisplayed(OthrAddColHeader, OthrAddColHeader.getText() + " Col Header");
		assertElementDisplayed(TrnsfrColHeader, TrnsfrColHeader.getText() + " Col Header");
		extentTest.log(Status.PASS,
				"Participant Account Activity feature is implemented as expected and working successfully");
	}

	// Select Producer ID actions
	public void selectProducerID(String prodID) throws InterruptedException {
		String xpath = "//td/a[contains(text(),'" + prodID + "')]";
		WebElement producerID = driver.findElement(By.xpath(xpath));
		ClickElement(producerID, "Producer ID");
		Thread.sleep(1000);
		//assertElementDisplayed(eProducerPageHeader, "Welcome to eProducer Header");

	}

	// Re-balance Account test case actions
	public void verifyRebalanceAccountFeature(String prodID, String planNumber, String prtcpntID)
			throws InterruptedException {
		selectProducerID(prodID);
		MoveToElement(PlanParticipantMenu, "Plan/Participant Menu");
		ClickElement(PlanParticipantDataSubmenu, "Plan/Participant Data Sub-menu");
		ComboSelectVisibleText(displayList, "all", "Display List");
		selectPlan(planNumber);
		ClickElement(ParticipantListLink, "Participant List Link");
		assertElementDisplayed(ParticipantListHeader, "Participant List Header");
		selectParticipantName(prtcpntID);
		assertElementDisplayed(ViewPrtcpntDataHeader, ViewPrtcpntDataHeader.getText());
		try {
			if (RebalanceAccountLink.isDisplayed()) {
				ClickElement(RebalanceAccountLink, "Rebalance Account Link");
				assertElementDisplayed(RebalancingTrnsfrHeader, "Rebalancing Transfer Header");
				takeScreenshot("Rebalancing Transfer Page");
				assertElementDisplayed(step1MakeTrsnfr, step1MakeTrsnfr.getText());
				assertElementDisplayed(step2ReviewSelection, step2ReviewSelection.getText());
				assertElementDisplayed(step3Complete, step3Complete.getText());
				assertElementDisplayed(instruction1, instruction1.getText());
				assertElementDisplayed(instruction2, instruction2.getText());
				assertElementDisplayed(instruction3, instruction3.getText());
				assertElementDisplayed(FrequencyHeader, FrequencyHeader.getText());
				ClickElement(OneTimeOnlyRadioBtn, "One-Time Only Radio Button");
				ClickElement(RBA_NextBtn, "Next Button");
				assertElementDisplayed(InvstOptnElctnsHeader, InvstOptnElctnsHeader.getText());
				ClickElement(SubmitBtn, "Submit Button");
				Thread.sleep(4000);
				assertElementDisplayed(SubmissionConfirmMsg, SubmissionConfirmMsg.getText());
				takeScreenshot("Rebalancing Transfer Confirmation Page");
				extentTest.log(Status.PASS,
						"Rebalance Account feature is implemented as expected and working successfully");
			}

		} catch (Exception e) {
			extentTest.log(Status.INFO,
					"Rebalance Account link is not displaying to the selected participant. Select the other participant and try it");
			throw new SkipException("Rebalance Account link is not displaying to the selected participant ID");
		}

	}

	// Service Agreement and Fee Disclosure test case actions
	public void verifyServiceAgreementandFeeDisclosure(String emailAdrs, String planname, String plannumb,
			String plantype, String eligblEmpCount, String annualcontrbtn, String assetValue, String fundLine,
			String prodType, String firstYrCommsn, String trailCommsn, String advisorCompnstn, String servcLvl,
			String TPA, String mepOption, String brkrgWin, String loans, String ria, String nonModel, String partAdvc,
			String plnSpnsrAdvc) throws InterruptedException {
		MoveToElement(SalesMenu, "Sales Menu");
		ClickElement(ServicesAgrementsSubmenu, ServicesAgrementsSubmenu.getText());
		assertElementDisplayed(SrvcsAgrmtFeeDsclrsHeader, SrvcsAgrmtFeeDsclrsHeader.getText() + " Header");
		assertElementDisplayed(OrderDocLink, OrderDocLink.getText() + " Link");
		assertElementDisplayed(BrowseOrderLink, BrowseOrderLink.getText() + " Link");
		ClickElement(OrderDocLink, OrderDocLink.getText() + " Link");
		assertElementDisplayed(OrderTypeHeader, OrderTypeHeader.getText() + " Header");
		takeScreenshot("Service Agreement and Fees Disclosure-Order Type page");
		assertElementDisplayed(step1OrdrType, step1OrdrType.getText());
		assertElementDisplayed(step2OrdrDetails, step2OrdrDetails.getText());
		assertElementDisplayed(step3ReviewOrdr, step3ReviewOrdr.getText());
		assertElementDisplayed(step4complete, step4complete.getText());
		assertElementDisplayed(GroupsAnnuityLink, GroupsAnnuityLink.getText() + " Link");
		assertElementDisplayed(InforceDisLink, InforceDisLink.getText() + " Link");
		ClickElement(GroupsAnnuityLink, GroupsAnnuityLink.getText() + " Link");
		assertElementDisplayed(OrdrDetailsGrpAnnuityHeader, OrdrDetailsGrpAnnuityHeader.getText() + " Header");
		takeScreenshot("Service Agreement and Fees Disclosure-Groups Annuity page");
		assertElementDisplayed(OrdrConfirmationHeader, OrdrConfirmationHeader.getText() + " Header");
		EnterText(emailAddress, emailAdrs, "E-mail Address");
		assertElementDisplayed(PlanInfoHeader, PlanInfoHeader.getText() + " Header");
		EnterText(planName, planname, "Plan Name");
		EnterText(planNumber, plannumb, "Plan Number");
		ComboSelectVisibleText(planType, plantype, "Plan Type");
		EnterText(numbEligblEmps, eligblEmpCount, "Number of Eligible Employees");
		EnterText(Annualcontributions, annualcontrbtn, "Annual Expected Contributions");
		EnterText(TakeOvrAssets, assetValue, "Estimated Takeover Assets");
		ComboSelectVisibleText(FundLineUp, fundLine, "Fund Line-Up");
		ComboSelectVisibleText(productType, prodType, "Product Type");
		ComboSelectVisibleText(FrstYrCommission, firstYrCommsn, "First year Commission");
		ComboSelectVisibleText(trailCommission, trailCommsn, "Trail Commission");
		ComboSelectVisibleText(advsrCompnstn, advisorCompnstn, "Advisor Compensation");
		ComboSelectVisibleText(serviceLevel, servcLvl, "Service Level");
		ComboSelectVisibleText(TPAaccess, TPA, "TPA Access");
		ComboSelectVisibleText(MEP, mepOption, "MEP option");
		assertElementDisplayed(OptionalSrvcs, OptionalSrvcs.getText() + " Header");
		driver.findElement(By.xpath("//td/input[@name='brokerageWindow' and @value='" + brkrgWin + "']")).click();
		driver.findElement(By.xpath("//td/input[@name='loans' and @value='" + loans + "']")).click();
		driver.findElement(By.xpath("//td/input[@name='ria' and @value='" + ria + "']")).click();
		driver.findElement(By.xpath("//td/input[@name='nonModel' and @value='" + nonModel + "']")).click();
		driver.findElement(By.xpath("//td/input[@name='participantAdvice' and @value='" + partAdvc + "']")).click();
		driver.findElement(By.xpath("//td/input[@name='planSponsorAdvice' and @value='" + plnSpnsrAdvc + "']")).click();
		ClickElement(GA_NextBtn, "Next Button");
		assertElementDisplayed(ReviewGrpAnnuityHeader, ReviewGrpAnnuityHeader.getText() + " Header");
		ClickElement(GA_SubmitBtn, "Submit Button");
		Thread.sleep(2000);
		assertElementDisplayed(ConfirmDetails, ConfirmDetails.getText());
		takeScreenshot("Service Agreement and Fees Disclosure-Confirmation page");
		extentTest.log(Status.PASS,
				"Service Agreement and Fee Disclosure features are implemented as expected and working successfully");

	}

	// Advisor Fee Report test case actions
	public void verifyAdvisorFeeReport(String planNumber) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		ClickElement(AdvisorFeeReportLink, "Advisor Fee Report Link");
		assertElementDisplayed(AdvsrFeeRprtHeader, AdvsrFeeRprtHeader.getText() + " Header");
		try {
			if (yearHeading.isDisplayed()) {
				assertElementDisplayed(FeeReportLink, "Report Link");
				takeScreenshot("Advisor Fee Report Links");
				ClickElement(FeeReportLink, "Fee Report Link");
				extentTest.log(Status.PASS,
						"Advisor Fee Report feature is implemented as expected and Successfully report is downloaded");
			}
		} catch (Exception e) {
			assertElementDisplayed(NoResultsInfoMsg, NoResultsInfoMsg.getText() + " Info message");
			extentTest.log(Status.INFO, "Results are not available");
			throw new SkipException("This test case is skipped due to no results. Select the other plan and try");
		}
	}

	// Participant Auto Enrollment Report test case action
	public void verifyPrtcpntAutoEnrollmentReport(String planNumber) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		ClickElement(AutoEnrollmenReportLink, "Auto Enrollment Report Link");
		assertElementDisplayed(AutoEnrlmntHeader, AutoEnrlmntHeader.getText() + " Header");
		takeScreenshot("Participant Auto Enrollment Report Page");
		try {
			if (PrtcpntAutoEnrlmntSearchLabel.isDisplayed()) {
				assertElementDisplayed(PrtcpntAutoEnrlmntSearchLabel,
						PrtcpntAutoEnrlmntSearchLabel.getText() + " Header");
				ClickElement(DownloadIcon, "Download Icon");
				Thread.sleep(2000);
				extentTest.log(Status.PASS,
						"Auto Enrollment Report feature is implemented as expected and working successfully");
			}

		} catch (Exception e) {
			assertElementDisplayed(NoPrtcpntToReportInfo, NoPrtcpntToReportInfo.getText() + " Info Message");
			extentTest.log(Status.INFO, "Results are not available for the selected plan");
			throw new SkipException(
					"This test case is skipped due to unavailibility of the results. Select the other plan and try");
		}

	}

	// Address changes/eActivity test case actions
	public void verifyAddressChangeseActivityFeature(String planNumber, String typeAdrs, String fromdate, String todate,
			String prtcpntID) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		ClickElement(AddrsChangeseActivityLink, "Address Changes/eActivity Link");
		assertElementDisplayed(AdrsChngsHeader, AdrsChngsHeader.getText() + " Header");
		takeScreenshot("Address changes or eActivity Page");
		assertElementDisplayed(SelectDateRangeInfo, SelectDateRangeInfo.getText() + " Header");
		ComboSelectVisibleText(TypeList, typeAdrs, "Type");
		EnterText(txtFldAdrsChngFromDate, fromdate, "From Date");
		EnterText(txtFldAdrsChngToDate, todate, "To Date");
		ClickElement(AdrsChng_SubmitBtn, "Submit Button");
		Thread.sleep(1000);
		takeScreenshot("Address changes or eActivity details Page");
		assertElementDisplayed(RequestDateCol, "Request Date Column");
		assertElementDisplayed(ParticipantCol, "Participant Column");
		assertElementDisplayed(SSN_Col, "SSN Column");
		assertElementDisplayed(PlanEntryDateCol, "Plan Entry Date Column");
		assertElementDisplayed(SourceCol, "Source Column");
		assertElementDisplayed(Action_Col, "Action Column");
		assertElementDisplayed(UpdateInfoCol, "Updated Information Column");
		ClickElement(DownloadIcon, "Download Icon");
		Thread.sleep(2000);
		ComboSelectVisibleText(displayList, "all", "Display List");
		String prtcpntPath = "//form//table//tbody//tr//td[contains(text(),'" + prtcpntID + "')]//ancestor::tr//td/a";
		WebElement namePrtcpnt = driver.findElement(By.xpath(prtcpntPath));
		ClickElement(namePrtcpnt, "Participant Name: " + namePrtcpnt.getText());
		Thread.sleep(2000);
		assertElementDisplayed(ViewPrtcpntDataHeader, ViewPrtcpntDataHeader.getText());
		assertElementDisplayed(PersonalDataHeader, "Personal Data Header");
		takeScreenshot("View Participant Data details page");
		assertElementDisplayed(NameLabel, "Name Label");
		assertElementDisplayed(PlanNumberLabel, "Plan Number Label");
		assertElementDisplayed(StatusLabel, "Status Label");
		assertElementDisplayed(SSNLabel, "SSN Label");
		assertElementDisplayed(EmploymentDateLabel, "Employment Date Label");
		assertElementDisplayed(DivisionLabel, "Division Label");
		assertElementDisplayed(DateofBirthLabel, "Date of Birth Label");
		assertElementDisplayed(EmailLabel, "Email Label");
		assertElementDisplayed(InvstmntAdvsrInfoHeader, "Investment Advisor Information Header");
		assertElementDisplayed(SourceInfoHeader, "Source Information Header");
		assertElementDisplayed(AcctBalncHeader, AcctBalncHeader.getText());
		extentTest.log(Status.PASS,
				"Address Changes/eActivity report feature is implemented as expected and working successfully");
	}

	// Participant Statements test case actions
	public void verifyParticipantStatements(String planNumber, String prtcpntID) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		ClickElement(ParticipantListLink, "Participant List Link");
		assertElementDisplayed(ParticipantListHeader, "Participant List Header");
		ComboSelectVisibleText(DisplayList, "all", "Display Rows");
		Thread.sleep(2000);
		selectParticipantName(prtcpntID);
		assertElementDisplayed(ViewPrtcpntDataHeader, ViewPrtcpntDataHeader.getText());
		ClickElement(ParticipantStatementsLink, "Participant Statements Link");
		try {
			if (StatementsHeader.isDisplayed()) {
				assertElementDisplayed(StatementsHeader, "Statements Header");
				takeScreenshot("Participant Statements Links page");
				assertElementDisplayed(StatementLink, "Statement Link");
				ClickElement(StatementLink, "Statement Link");
				Thread.sleep(10000);
				switchToWindows("Participant Statements PDF page");
				extentTest.log(Status.PASS,
						"Statement link is clicked and PDF displayed successfully and feature is working as expected");
			}
		} catch (Exception e) {
			assertElementDisplayed(NoStatementsInfoMsg, "No Statement Available info");
			takeScreenshot("Participant Statements NO Statements Info page");
			System.out.println(NoStatementsInfoMsg.getText());
			extentTest.log(Status.INFO, "Statements links are not available for the selected participant name");
			throw new SkipException(
					"Participant Statement Test case is Skipped due to unavailablity of statement links for the selected participant name");
		}

	}

	// Forgot My UserID and Validations test case actions
	public void verifyForgotMyUsrIDValidations(String invalidEmailID, String validEmailID) throws Exception {
		ClickElement(ForgotUsrIDLink, "Forgot User ID Link");
		takeScreenshot("Forgot My UserID and Validations");
		assertElementDisplayed(FrgtUsrHeader, FrgtUsrHeader.getText() + " Header");
		assertElementDisplayed(ContactUsLink, "Contact Us Link");
		//assertElementDisplayed(Frgt_EmailLabel, "Email Label");
		//Did not receive an email? Contact Us for assistance.
		assertElementDisplayed(emailTxtFld, "Email Field");
		//assertElementDisplayed(Frgt_SubmitBtn, "Submit Button");
		//ClickElement(Frgt_SubmitBtn, "Submit Button");
		Thread.sleep(2000);
		//assertElementDisplayed(FldRqd_VldtnMsg, FldRqd_VldtnMsg.getText() + " Validation Message");
		EnterText(emailTxtFld, invalidEmailID, "Email");
		ClickElement(Frgt_SubmitBtn, "Submit Button");
		assertElementDisplayed(InvldEmail_VldtnMsg, "Invalid Email Validation Message");
		EnterText(emailTxtFld, validEmailID, "Email");
		ClickElement(Frgt_SubmitBtn, "Submit Button");
		assertElementDisplayed(CheckEmailHeader, CheckEmailHeader.getText() + " Header");
		assertElementDisplayed(SignInBtn, SignInBtn.getText() + " Button");
		extentTest.log(Status.PASS,
				"Forgot My User ID and Validations are implemented as expected and Working Successfully");

	}

	// Clicking the my profile link for Change user id test case
	public void clickMyProfileLink() {
		ClickElement(MyProfileLink, "My Profile Link");
		assertElementDisplayed(MyProfileHeader, "My Profile Header");
		assertElementDisplayed(SecAccsSettingsLink, "Security Access Settings Link");
		ClickElement(SecAccsSettingsLink, "Security Access Settings Link");
		assertElementDisplayed(SecurityAccessSettingsHeader, "Security Access Settings Header");
	}

	// Change My User ID and its Validations test case actions
	public void verifyUserIDValidations(String lessThn6chrs, String usrIDEndsWithSpclChr, String usrIDWithSpclChr,
			String usrIDWith9Numbs, String usrIDWithSpace, String usrIDWith64Chrs, String PreviousUsrID,
			String ValidNewusrID, String invalidCnfrmusrID, String validCnfrmusrID) {
		ClickElement(UserID_EditCancel, "User ID Edit Button");
		EnterText(NewUserName_TextFld, lessThn6chrs, "UserID with less tahn 6 Chars");
		NewUserName_TextFld.sendKeys(Keys.TAB);
		assertElementDisplayed(UserID_CmnValidationMsg, UserID_CmnValidationMsg.getText() + " Validation Message");
		assertElementDisplayed(Min6Characters_ValidationMsg,
				Min6Characters_ValidationMsg.getText() + " Validation Message");
		EnterText(NewUserName_TextFld, usrIDEndsWithSpclChr, "UserID Ends with Special Chars");
		assertElementDisplayed(EndingwithLetterorNumber_ValidationMsg,
				EndingwithLetterorNumber_ValidationMsg.getText() + " Validation Message");
		EnterText(NewUserName_TextFld, usrIDWithSpclChr, "UserID with Special Char");
		assertElementDisplayed(SpecialCharacter_ValidationMsg,
				SpecialCharacter_ValidationMsg.getText() + " Validation Message");
		EnterText(NewUserName_TextFld, usrIDWith9Numbs, "UserID with 9 numbers");
		assertElementDisplayed(Contains9Characters_ValidationMsg,
				Contains9Characters_ValidationMsg.getText() + " Validation Message");
		EnterText(NewUserName_TextFld, usrIDWithSpace, "UserID with Spaces");
		assertElementDisplayed(ContainsSpace_ValidationMsg,
				ContainsSpace_ValidationMsg.getText() + " Validation Message");
		EnterText(NewUserName_TextFld, usrIDWith64Chrs, "UserID with Spaces");
		assertElementDisplayed(Contains64characters_ValidationMsg,
				Contains64characters_ValidationMsg.getText() + " Validation Message");
		EnterText(NewUserName_TextFld, PreviousUsrID, "UserID with Previously Used");
		NewUserName_TextFld.sendKeys(Keys.TAB);
		assertElementDisplayed(PreviouslyUsedUserID_ErrorMsg,
				PreviouslyUsedUserID_ErrorMsg.getText() + " Validation Message");
		EnterText(NewUserName_TextFld, ValidNewusrID, "UserID");
		EnterText(ConfirmUserID_TxtFld, invalidCnfrmusrID, "Confirm UserID");
		ConfirmUserID_TxtFld.sendKeys(Keys.TAB);
		assertElementDisplayed(ConfirmUserID_ErrorMsg, ConfirmUserID_ErrorMsg.getText() + " Validation Message");
		EnterText(ConfirmUserID_TxtFld, validCnfrmusrID, "Confirm UserID");
		ClickElement(UserID_EditCancel, "User ID Cancel Button");
		extentTest.log(Status.PASS,
				"User ID changes and its validations are implemented as expected and working successfully");
	}

	// Change Security Questions and validations test case actions
	public void verifyChangeSecurityQstnandValidations(String secQstn, String Above50ChrsAns, String Below50ChrsAns,
			String invalidCurrtPwd, String validCurrtPwd) throws InterruptedException {
		ClickElement(SecQuestion_EditCancelBtn, "Security Question Edit Button");
		ComboSelectVisibleText(SecQstnsList, secQstn, "Security Question");
		EnterText(SecQstnAnswerFld, Above50ChrsAns, "Answer with above 50 chrs");
		SecQstnAnswerFld.sendKeys(Keys.TAB);
		assertElementDisplayed(Max50Chrs_VldtnMsg, Max50Chrs_VldtnMsg.getText() + " Validation Message");
		EnterText(SecQstnAnswerFld, Below50ChrsAns, "Answer with below 50 chrs");
		SecQstnAnswerFld.sendKeys(Keys.TAB);
		EnterText(Sec_CurrentPwd, invalidCurrtPwd, "Current Password");
		Sec_CurrentPwd.sendKeys(Keys.RETURN);
		Thread.sleep(2000);
		// assertElementDisplayed(InvldPwd_VldtnMsg, "Invalid Password Validation
		// Message");
		takeScreenshot("Change Security Questions with validations");
		EnterText(Sec_CurrentPwd, validCurrtPwd, "Current Password");
		ClickElement(Sec_SubmitBtn, "Submit Button");
		Thread.sleep(2000);
		assertElementDisplayed(Sec_CongratsMsg, "Congratulations Header");
		assertElementDisplayed(ChangedSuccfllyInfoMsg, ChangedSuccfllyInfoMsg.getText() + " Info Message");
		takeScreenshot("Change Security Questions Successfully info page");
		extentTest.log(Status.PASS,
				"Security Question Changes and its validations are implemented as expected and working successfully");

	}

	// Loan Documents test case actions
	public void verifyLoanDocumentsFeature(String planNumber, String SSN) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		Thread.sleep(2000);
		MoveToElement(PlanParticipantMenu, "Plan Participant Menu");
		ClickElement(LoanCenterSubmenu, "Loan Center Sub-menu");
		Thread.sleep(8000);
		assertElementDisplayed(LoanSummaryHeader, "Loan Summary Header");
		takeScreenshot("Loan Summary Page");
		System.out.println(LoanSummaryHeader.getText() + " page is displayed");
		ComboSelectVisibleText(DisplayList, "all", "Display Rows");
		try {
			if (DivisonCol.isDisplayed()) {
				selectDivLoanID(SSN);
			}
		} catch (Exception e) {
			selectLoanID(SSN);
		}
		assertElementDisplayed(LoanHistoryHeader, "Loan History Header");
		takeScreenshot("Loan Docs Page");
		try {
			if (sideMenuLoanDocs.isDisplayed()) {
				extentTest.log(Status.INFO, "Loan Documents section is displayed");
				assertElementDisplayed(linkLoanRepayment, "Loan Repayment Schedule Link");
				assertElementDisplayed(linkPromisoryNote, "Promisory Note Link");
				ClickElement(linkLoanRepayment, "Loan Repayment Schedule Link");
				Thread.sleep(2000);
				switchToWindows("Loan Repayment Schedule document");
				extentTest.log(Status.INFO,
						"Loan Repayment Schedule document is clicked and opened in PDF format in new window as expected");
				ClickElement(linkPromisoryNote, "Promisory Note Link");
				switchToWindows("Promisory Note document");
				extentTest.log(Status.INFO,
						"Promisory Note document is clicked and opened in PDF format in new window as expected");
				extentTest.log(Status.PASS,
						"Loan Documents functionality is implemented as expected and links are working successfully");
			}
		} catch (Exception e) {
			extentTest.log(Status.INFO, "Loan Documents are not available for the selected SSN.");
			takeScreenshot("No Loan Documents option");
			throw new SkipException(
					"Test case is skipped due to no loan documents available. Please use the other SSS/Plan number");
		}

	}

	// Monthly Commissions test case actions
	public void verifyMonthlyCommissionsFeature(String ProdSearchBy, String criteriaTxt, String prodNum)
			throws InterruptedException {
		MoveToElement(menuCommissions, "Commissions Menu");
		ClickElement(subMenuMonthlyCommissions, "Monthly Commissions Sub-menu");
		Thread.sleep(2000);
		takeScreenshot("Commission Statement Search Page");
		assertElementDisplayed(headerComssnProdSearch, headerComssnProdSearch.getText() + " Header");
		ComboSelectVisibleText(selectProdSearchBy, ProdSearchBy, "Search By");
		EnterText(txtFldCriteria, criteriaTxt, "Criteria");
		ClickElement(btnProdSearch, "Search Button");
		Thread.sleep(2000);
		takeScreenshot("Producer Search Results Page");
		assertElementDisplayed(headerSearchResults, "Search Results");
		assertElementDisplayed(colHeaderProdNumb, colHeaderProdNumb.getText() + " Col Header");
		assertElementDisplayed(colHeaderProdName, colHeaderProdName.getText() + " Col Header");
		assertElementDisplayed(colHeaderNameID, colHeaderNameID.getText() + " Col Header");
		String xpath = "//div[@id='content']//form/table//td/a[contains(text(),'" + prodNum + "')]";
		WebElement prodNumLink = driver.findElement(By.xpath(xpath));
		ClickElement(prodNumLink, "Producer Number Link");
		takeScreenshot("Choose Statement Page");
		assertElementDisplayed(headerChooseStmnt, "Choose Statement Header");
		assertElementDisplayed(headerSelProdNumb, headerSelProdNumb.getText() + " Header");
		assertElementDisplayed(headerSelCommsnMonth, headerSelCommsnMonth.getText() + " Header");
		ClickElement(btnProdSearchSubmit, "Submit Button");
		takeScreenshot("Statement Summary Page");
		assertElementDisplayed(headerStmntSummary, headerStmntSummary.getText() + " Header");
		assertElementDisplayed(headerCompensation, "Compensation Header");
		assertElementDisplayed(headerDeduction_Fees, "Deduction/Fees Header");
		assertElementDisplayed(headerMailingAdrs, "Mailing Address Header");
		extentTest.log(Status.PASS, "Monthly Commissions feature is implemented as expected and working successfully");

	}

	// Weekly Commissions test case actions
	public void verifyWeeklyCommissionsFeature(String SearchBy, String matching, String criteriaTxt)
			throws InterruptedException {
		MoveToElement(menuCommissions, "Commissions Menu");
		ClickElement(subMenuWeeklyCommissions, "Weekly Commissions Sub-menu");
		Thread.sleep(2000);
		assertElementDisplayed(headerWeeklyCommsn, headerWeeklyCommsn.getText() + " Header");
		ComboSelectVisibleText(selectWeeklySearchBy, SearchBy, "Search By");
		ComboSelectVisibleText(selectMatching, matching, "Matching");
		EnterText(txtFldWeeklyCriteria, criteriaTxt, "Criteria");
		ClickElement(btnSubmitWeekly, "Submit Button");
		Thread.sleep(2000);
		takeScreenshot("Weekly Commission Producer Search Results Page");
		if (SearchBy.equalsIgnoreCase("Producer Number")) {
			String xpath = "//div/form//td//label[contains(text(),'" + criteriaTxt + "')]";
			WebElement prodNumOptn = driver.findElement(By.xpath(xpath));
			ClickElement(prodNumOptn, "Producer Number Option");
			ClickElement(btnSubmitWeekly, "Submit Button");
			Thread.sleep(2000);
			try {
				if (headerWklyStmntsDateRange.isDisplayed()) {
					assertElementDisplayed(headerWklyStmntsDateRange, headerWklyStmntsDateRange.getText());
					takeScreenshot("Weekly Commissions Links Page");
					assertElementDisplayed(colHeaderProdName, colHeaderProdName.getText() + " Col Header");
					assertElementDisplayed(colHeaderProdNumb, colHeaderProdNumb.getText() + " Col Header");
					assertElementDisplayed(colHeaderSSNTaxID, "SSN/Tax ID Col Header");
					assertElementDisplayed(colHeaderCommissionTotal,
							colHeaderCommissionTotal.getText() + " Col Header");
					ClickElement(linkWklyCommsns, "Weekly Commision Link: " + linkWklyCommsns.getText());
					assertElementDisplayed(headerIndividual, headerIndividual.getText() + " Header");
					takeScreenshot("Weekly Commissions Details Page");
					assertElementDisplayed(colHeaderCustmrNumb, colHeaderCustmrNumb.getText() + " Col Header");
					assertElementDisplayed(colHeaderCustmrName, colHeaderCustmrName.getText() + " Col Header");
					assertElementDisplayed(colHeaderCaseEfctvDate, colHeaderCaseEfctvDate.getText() + " Col Header");
					assertElementDisplayed(colHeaderProduct, colHeaderProduct.getText() + " Col Header");
					assertElementDisplayed(colHeaderRate, colHeaderRate.getText() + " Col Header");
					assertElementDisplayed(colHeaderPremium, colHeaderPremium.getText() + " Col Header");
					assertElementDisplayed(colHeaderAmount, colHeaderAmount.getText() + " Col Header");
					extentTest.log(Status.PASS,
							"Weekly Commissions Feature is implemented as expected and working successfully");
				}

			} catch (Exception e) {
				assertElementDisplayed(infoMsgNoStmnts, "Info Message: " + infoMsgNoStmnts.getText());
				extentTest.log(Status.SKIP,
						"Test case is skipped due to no weekly statements available for the selected period");
				throw new SkipException("Test case is skipped due to no weekly statements available");
			}
		}

	}

	// Plan Sponsor Communication test case actions
	public void verifyPlanSponsorCommunicationFeature() throws InterruptedException {
		MoveToElement(menuCommunication, "Communication Menu");
		ClickElement(subMenuPlanSponsorCommunication, "Plan Sponsor Communication Sub-menu");
		Thread.sleep(2000);
		assertElementDisplayed(headerPlanSpnsrCommunication, "Plan Sponsor Communication Header");
		takeScreenshot("Plan Sponsor Communication Page");
		int linkCount = linksComctnAULRS.size();
		for (int i = 0; i <linkCount; i++) {
			ClickElement(linksComctnAULRS.get(i), linksComctnAULRS.get(i).getText() + " Link");
			String linkName = linksComctnAULRS.get(i).getText();
			switchToWindows(linkName + " Page");
		}
		extentTest.log(Status.PASS,
				"Plan Sponsor Communication feature is implemented as expected and working successfully");

	}

	// Core Business Communication test case actions
	public void verifyCoreBusinessCommunicationsFeature() throws InterruptedException {
		MoveToElement(menuCommunication, "Communication Menu");
		ClickElement(subMenuCoreBusnsCmnctns, "Core Business Communications Sub-menu");
		Thread.sleep(2000);
		assertElementDisplayed(headerCoreBusnsComnctn, headerCoreBusnsComnctn.getText() + " Header");
		takeScreenshot("Core Business Communication Page");
		assertElementDisplayed(headerAdmnPrcdrs, headerAdmnPrcdrs.getText() + " Header");
		assertElementDisplayed(headerMisclnsComnctns, headerMisclnsComnctns.getText() + " Header");
		assertElementDisplayed(headerFormUpdates, headerFormUpdates.getText() + " Header");
		assertElementDisplayed(headerPrtcpntCmnctns, headerPrtcpntCmnctns.getText() + " Header");
		assertElementDisplayed(headerInvstmntUpdates, headerInvstmntUpdates.getText() + " Header");
		assertElementDisplayed(headerPlanSponsorCmnctns, headerPlanSponsorCmnctns.getText() + " Header");
		assertElementDisplayed(headerLegislativeUpdts, headerLegislativeUpdts.getText() + " Header");
		assertElementDisplayed(headerProductsUpdts, headerProductsUpdts.getText() + " Header");
		assertElementDisplayed(headerMarketingUpdts, headerMarketingUpdts.getText() + " Header");
		assertElementDisplayed(headerTechUpdts, headerTechUpdts.getText() + " Header");

	}

	// Demos test case actions
	public void verifyDemosFeature() throws InterruptedException {
		MoveToElement(menuTechnology, "Technology Menu");
		ClickElement(subMenuDemos, "Demos Sub-menu");
		Thread.sleep(2000);
		assertElementDisplayed(headerDemos, "Demos Header");
		takeScreenshot("Demos Page");
		assertElementDisplayed(linkOAWebsite, "OA Website link");
		ClickElement(linkOAWebsite, "OA Website link");
		Thread.sleep(2000);
		takeScreenshot("OA Applications List Page");
		assertElementDisplayed(headerAccountServices, headerAccountServices.getText() + " Header");
		String ASDetails = "The Account Services website provides plan participants with access and the ability to manage their retirement account information. "
				+ "This site is available 24 hours a day, 7 days a week.";
		assertText(textASDetails, ASDetails, "Account Services description");
		assertElementDisplayed(headereSponsor, headereSponsor.getText() + " Header");
		String eSponsorDetails = "The eSponsor® website provides plan sponsors and administrators with access to plan and"
				+ " participant information. This site is available 24 hours a day, 7 days a week.";
		assertText(texteSponsorDetails, eSponsorDetails, "eSponsor description");
		assertElementDisplayed(headereAccess, headereAccess.getText() + " Header");
		String eAccessDetails = "The eAccess website provides third party administrators with access to plan and "
				+ "participant information. Go to our interactive tour of eAccess to view what it has to offer.";
		assertText(texteAccessDetails, eAccessDetails, "eAccess description");
		takeScreenshotForPassedcase("Demo");
		assertElementDisplayed(headerInvestmentAdvisor, headerInvestmentAdvisor.getText() + " Header");
		assertElementDisplayed(headerMyOneCheckOnline, headerMyOneCheckOnline.getText() + " Header");
		extentTest.log(Status.PASS, "Demos feature is implemented as expected and working successfully");

	}

	// Product Offerings test case actions
	public void verifyProductOfferingsFeature() throws InterruptedException {
		MoveToElement(menuProducts, "Products Menu");
		ClickElement(subMenuPrdctOfferings, "Product Offerings Sub-menu");
		Thread.sleep(2000);
		assertElementDisplayed(headerProducts, "Products Header");
		takeScreenshot("Products Page");
		assertElementDisplayed(headerEmpSponsored, "Employee Sponsored Header");
		assertElementDisplayed(headerVoluntary, "Voluntary Header");
		int prdctOfrngLinks = linksOAProducts.size();
		for (int i = 0; i < prdctOfrngLinks; i++) {
			String poLink = linksOAProducts.get(i).getText();
			ClickElement(linksOAProducts.get(i), linksOAProducts.get(i).getText() + " Link");
			switchToWindows(poLink + "Page");
		}
		extentTest.log(Status.PASS, "Product Offerings feature is implemented as expected and working successfully");

	}

	// Roth 401(k) & 403(b) Feature test case actions
	public void verifyRoth401KAnd403BFeature() throws InterruptedException {
		MoveToElement(menuPlans, "Plans Menu");
		ClickElement(subMenuRothFeature, "Roth 401(k) and 403(b) Feature Sub-menu");
		Thread.sleep(2000);
		assertElementDisplayed(headerRothFeature, headerRothFeature.getText() + " Header");
		takeScreenshot(headerRothFeature.getText() + " Page");
		assertElementDisplayed(headerHowRothWorks, headerHowRothWorks.getText() + " Header");
		assertElementDisplayed(headerAdvantages, headerAdvantages.getText() + " Header");
		assertElementDisplayed(headerPlanSponsorInfo, headerPlanSponsorInfo.getText() + " Header");
		assertElementDisplayed(headerParticipantInfo, headerParticipantInfo.getText() + " Header");
		int rothLinks = linksRoth.size();
		for (int i = 0; i < rothLinks; i++) {
			ClickElement(linksRoth.get(i), linksRoth.get(i).getText() + " Link");
			switchToWindows("Roth PDF Page of link " + (i + 1));
		}
		extentTest.log(Status.PASS, "Roth feature is implemented as expected and working successfully");

	}

	// Investment Sales Support test case actions
	public void verifyInvestmentSalesSupportLinks() throws InterruptedException {
		MoveToElement(InvestmentMenu, "Investment Menu");
		ClickElement(subMenuInvstmntSalesSprt, "Investment Sales Support Sub-menu");
		Thread.sleep(1000);
		assertElementDisplayed(headerInvstmntSalesSupport, headerInvstmntSalesSupport.getText() + " Header");
		takeScreenshot("Investment Sales Support Page");
		String clickedLink = linkFiducarySrvcs38.getText();
		ClickElement(linkFiducarySrvcs38, linkFiducarySrvcs38.getText() + " Link");
		Thread.sleep(1000);
		assertElementDisplayed(headerSelectedLink, headerSelectedLink.getText() + " Header");
		String selectedLink = headerSelectedLink.getText();
		takeScreenshot(headerSelectedLink.getText() + " Page");
		Assert.assertEquals(clickedLink, selectedLink);
		for (int i = 0; i < 3; i++) {
			String clickedFidLink = linksFiducaryServices.get(i).getText();
			ClickElement(linksFiducaryServices.get(i), linksFiducaryServices.get(i).getText() + " Link");
			switchToWindows(clickedFidLink + " Page");
		}
		MoveToElement(InvestmentMenu, "Investment Menu");
		ClickElement(subMenuInvstmntSalesSprt, "Investment Sales Support Sub-menu");
		Thread.sleep(1000);
		String clickedLink1 = linkContractHolderForms.getText();
		ClickElement(linkContractHolderForms, linkContractHolderForms.getText() + " Link");
		Thread.sleep(1000);
		assertElementDisplayed(headerSelectedLink, headerSelectedLink.getText() + " Header");
		String selectedLink1 = headerSelectedLink.getText();
		takeScreenshot(headerSelectedLink.getText() + " Page");
		Assert.assertEquals(clickedLink1, selectedLink1);
		String cntrctLink = linkCntrctHldrRelated.getText();
		ClickElement(linkCntrctHldrRelated, linkCntrctHldrRelated.getText() + " Link");
		switchToWindows(cntrctLink + " Page");
		extentTest.log(Status.PASS, "Investment Sales Support Links are working as expected");

	}

	// Investment Performance and Option Summaries test case actions
	public void verifyInvstmntPrfrmncOptnSummaries() throws InterruptedException {
		MoveToElement(InvestmentMenu, "Investment Menu");
		ClickElement(subMenuInvstmntPrfmncOptn, "Investment Performance and Option Summaries Sub-menu");
		Thread.sleep(1000);
		assertElementDisplayed(headerInvstmntPrfrmncOptn, headerInvstmntPrfrmncOptn.getText() + " Header");
		takeScreenshot("Investment Performance and Option Summaries Page");
		for (int i = 0; i < 4; i++) {
			String invstmntOpntsLink = linksInvstmntPrfrmnsOptns.get(i).getText();
			ClickElement(linksInvstmntPrfrmnsOptns.get(i), linksInvstmntPrfrmnsOptns.get(i).getText() + " Link");
			try {
				if (btnIPOPrevious.isDisplayed()) {
					String clickedPageLink = linkClickedPageLink.getText();
					ClickElement(linkClickedPageLink, linkClickedPageLink.getText() + " Link");
					switchToWindows(clickedPageLink + " Page");
					takeScreenshotForPassedcase("Investment");
					ClickElement(btnIPOPrevious, "Previous Button");
				}

			} catch (Exception e) {
				switchToWindows(invstmntOpntsLink + " Page");
			}
		}
		extentTest.log(Status.PASS, "Investment Performance and Option Summaries links are working as expected");

	}

	// Investment Information test case actions
	public void verifyInvestmentInformationFeature() throws InterruptedException {
		MoveToElement(InvestmentMenu, "Investment Menu");
		ClickElement(subMenuInvstmntInfo, "Investment Information Sub-menu");
		Thread.sleep(1000);
		assertElementDisplayed(headerInvstmntInfo, headerInvstmntInfo.getText() + " Header");
		takeScreenshot("Investment Information Page");
		assertElementDisplayed(headerOneSuite, headerOneSuite.getText() + " Header");
		assertElementDisplayed(headerPreScreened, headerPreScreened.getText() + " Header");
		assertElementDisplayed(headerProdInnovation, headerProdInnovation.getText() + " Header");
		assertElementDisplayed(headerMrktInfo, headerMrktInfo.getText() + " Header");
		takeScreenshotForPassedcase("Screen1");
		for (int i = 0; i < linksInvstmntInfo.size(); i++) {
			String clckngLink = linksInvstmntInfo.get(i).getText();
			ClickElement(linksInvstmntInfo.get(i), linksInvstmntInfo.get(i).getText() + " Link");
			try {
				if (headerResources.size() > 0) {
					takeScreenshot("Resources Page");
					driver.navigate().back();
				} else if (btnIPOPrevious.isDisplayed()) {
					String clickedPageLink = linkClickedPageLink.getText();
					ClickElement(linkClickedPageLink, linkClickedPageLink.getText() + " Link");
					takeScreenshotForPassedcase("Screen2");
					switchToWindows(clickedPageLink + " Page");
					ClickElement(btnIPOPrevious, "Previous Button");
				}

			} catch (Exception e) {
				switchToWindows(clckngLink + " Page");
			}
		}
	}

	// Contribution Details test case actions
	public void verifyContributionDetailsFeature(String reportType, String incorrectFrmtDate, String futureDate,
			String vldFromDate, String vldToDate) throws InterruptedException {
		ClickElement(sideMenuFinancialActvty, "Financial Activity Side menu");
		assertElementDisplayed(headerFinActvty, "Financial Activity Header");
		takeScreenshot("Contribution Details-Financial Activity Page");
		assertElementDisplayed(headerSelFinActvty, headerSelFinActvty.getText() + " Header");
		ComboSelectVisibleText(selectFinActvtyReport, reportType, "Financial Activity Report Type: " + reportType);
		EnterText(txtFldFAFromDate, incorrectFrmtDate, "From Date");
		EnterText(txtFldFAToDate, futureDate, "To Date");
		ClickElement(btnFASubmit, "Submit Button");
		assertElementDisplayed(vldtnMsgInvldDateFrmt,
				"Validation Message for incorrect date format: " + vldtnMsgInvldDateFrmt.getText());
		assertElementDisplayed(vldtnMsgFuPaDate,
				"Validation Message for future/past date: " + vldtnMsgFuPaDate.getText());
		Thread.sleep(2000);
		takeScreenshot("Contribution Details-Fields with validation messages");
		EnterText(txtFldFAFromDate, vldFromDate, "From Date");
		EnterText(txtFldFAToDate, vldToDate, "To Date");
		ClickElement(btnFASubmit, "Submit Button");
		Thread.sleep(2000);
		try {
			if (headerContDtls.isDisplayed()) {
				takeScreenshot("Contribution Details Page");
				assertElementDisplayed(headerContDtls, headerContDtls.getText() + " Header");
				assertElementDisplayed(colHeaderTradeDate, "Col Header: " + colHeaderTradeDate.getText());
				assertElementDisplayed(colHeaderPayrollDate, "Col Header: " + colHeaderPayrollDate.getText());
				assertElementDisplayed(colHeaderContrbtnType, "Col Header: " + colHeaderContrbtnType.getText());
				assertElementDisplayed(colHeaderAmntAlctd, "Col Header: " + colHeaderAmntAlctd.getText());
				assertText(rowTotalContDtls, "Total Contributions from " + vldFromDate + " to " + vldToDate,
						"Last Row Details");
				ClickElement(DownloadIcon, "Download Icon");
				Thread.sleep(2000);
				ClickElement(linkCDInvestment, "Investment Link");
				Thread.sleep(1000);
				takeScreenshot("Contribution By Investment Details Page");
				Thread.sleep(1000);
				ClickElement(btnCDDownload, "Download Button");
				ClickElement(iconCDInvstSourceDwnld, "Download Icon");
				Thread.sleep(1000);
				ClickElement(btnDwnldCancel, "Cancel Button");
				ClickElement(btnCDPrevious, "Previous Button");
				Thread.sleep(2000);
				ClickElement(linkCDSource, "Source Link");
				Thread.sleep(1000);
				takeScreenshot("Contribution By Source Details Page");
				Thread.sleep(2000);
				ClickElement(iconCtrbtnBySrcDwnld, "Download Icon");
				Thread.sleep(1000);
				extentTest.log(Status.PASS,
						"Contribution Details feature is implemented as expected and working successfully");
			}
		} catch (Exception e) {
			assertElementDisplayed(infoMsgPlnDtlsNotAvlbl, "Info Message: " + infoMsgPlnDtlsNotAvlbl.getText());
			takeScreenshot("Contribution details Not available");
			extentTest.log(Status.SKIP, "Test case is Skipped due to " + infoMsgPlnDtlsNotAvlbl.getText());
			throw new SkipException("Test case is Skipped due to " + infoMsgPlnDtlsNotAvlbl.getText());
		}
	}

	// Account Activity test case actions
	public void verifyAccountActivityFeature(String reportType, String incorrectFrmtDate, String futureDate,
			String vldFromDate, String vldToDate) throws InterruptedException {
		ClickElement(sideMenuFinancialActvty, "Financial Activity Side menu");
		assertElementDisplayed(headerFinActvty, "Financial Activity Header");
		takeScreenshot("Account Activity-Financial Activity Page");
		assertElementDisplayed(headerSelFinActvty, headerSelFinActvty.getText() + " Header");
		ComboSelectVisibleText(selectFinActvtyReport, reportType, "Financial Activity Report Type: " + reportType);
		EnterText(txtFldFAFromDate, incorrectFrmtDate, "From Date");
		EnterText(txtFldFAToDate, futureDate, "To Date");
		ClickElement(btnFASubmit, "Submit Button");
		assertElementDisplayed(vldtnMsgInvldDateFrmt,
				"Validation Message for incorrect date format: " + vldtnMsgInvldDateFrmt.getText());
		assertElementDisplayed(vldtnMsgFuPaDate,
				"Validation Message for future/past date: " + vldtnMsgFuPaDate.getText());
		Thread.sleep(2000);
		takeScreenshot("Account Activity-Fields with validation messages");
		EnterText(txtFldFAFromDate, vldFromDate, "From Date");
		EnterText(txtFldFAToDate, vldToDate, "To Date");
		ClickElement(btnFASubmit, "Submit Button");
		Thread.sleep(3000);
		try {
			if (headerPlanAcntActvtySummary.isDisplayed()) {
				takeScreenshot("Account Activity Details Page");
				assertElementDisplayed(headerPlnAcntActvty, headerPlnAcntActvty.getText() + " Header");
				assertElementDisplayed(headerPlanAcntActvtySummary, "Account Activity Summary Header");
				assertText(headerPlanAcntActvtySummary,
						"Plan Account Activity Summary from " + vldFromDate + " to " + vldToDate,
						"Account Summary Details");
				assertElementDisplayed(colHeaderActivity, "Activity Col Header");
				assertElementDisplayed(colHeaderTotal, "Total Col Header");
				assertText(textEndingBalnc, "Ending Balance on " + vldToDate, "Ending Balance details");
				ClickElement(iconAcntActvyDownload, "Download Icon");
				Thread.sleep(2000);
				extentTest.log(Status.PASS, "Account Activity feature is working as expected");
			}
		} catch (Exception e) {
			assertElementDisplayed(infoMsgAcntActvtyDtlsNotAvlbl,
					"Info Message: " + infoMsgAcntActvtyDtlsNotAvlbl.getText());
			takeScreenshot("Account Activity details not available");
			extentTest.log(Status.SKIP, "Test case is Skipped due to " + infoMsgAcntActvtyDtlsNotAvlbl.getText());
			throw new SkipException("Test case is Skipped due to " + infoMsgAcntActvtyDtlsNotAvlbl.getText());
		}
	}

	// Asset Allocation test case actions
	public void verifyAssetAllocationFeature(String reportType, String incorrectFrmtDate, String futureDate,
			String vldFromDate, String vldToDate) throws InterruptedException {
		ClickElement(sideMenuFinancialActvty, "Financial Activity Side menu");
		assertElementDisplayed(headerFinActvty, "Financial Activity Header");
		takeScreenshot("Asset Allocation-Financial Activity Page");
		assertElementDisplayed(headerSelFinActvty, headerSelFinActvty.getText() + " Header");
		ComboSelectVisibleText(selectFinActvtyReport, reportType, "Financial Activity Report Type: " + reportType);
		EnterText(txtFldFAFromDate, incorrectFrmtDate, "From Date");
		EnterText(txtFldFAToDate, futureDate, "To Date");
		ClickElement(btnFASubmit, "Submit Button");
		assertElementDisplayed(vldtnMsgInvldDateFrmt,
				"Validation Message for incorrect date format: " + vldtnMsgInvldDateFrmt.getText());
		assertElementDisplayed(vldtnMsgFuPaDate,
				"Validation Message for future/past date: " + vldtnMsgFuPaDate.getText());
		Thread.sleep(2000);
		takeScreenshot("Asset Allocation-Fields with validation messages");
		EnterText(txtFldFAFromDate, vldFromDate, "From Date");
		EnterText(txtFldFAToDate, vldToDate, "To Date");
		ClickElement(btnFASubmit, "Submit Button");
		Thread.sleep(3000);
		try {
			if (headerAssetAllctnSummary.isDisplayed()) {
				ClickElement(iconAcntActvyDownload, "Download Icon");
				Thread.sleep(2000);
				extentTest.log(Status.PASS, "Asset Allocation feature is working as expected");
			}

		} catch (Exception e) {
			assertElementDisplayed(infoMsgAssetAlctnNotAvlbl, "Info Message: " + infoMsgAssetAlctnNotAvlbl.getText());
			takeScreenshot("Asset Allocation summary not available");
			extentTest.log(Status.SKIP, "Test case is Skipped due to " + infoMsgAssetAlctnNotAvlbl.getText());
			throw new SkipException("Test case is Skipped due to " + infoMsgAssetAlctnNotAvlbl.getText());
		}
	}

	// Contribution by Category test case actions
	public void verifyContributionByCategoryFeature(String reportType, String incorrectFrmtDate, String futureDate,
			String vldFromDate, String vldToDate) throws InterruptedException {
		ClickElement(sideMenuFinancialActvty, "Financial Activity Side menu");
		assertElementDisplayed(headerFinActvty, "Financial Activity Header");
		takeScreenshot("Contribution by Category-Financial Activity Page");
		assertElementDisplayed(headerSelFinActvty, headerSelFinActvty.getText() + " Header");
		ComboSelectVisibleText(selectFinActvtyReport, reportType, "Financial Activity Report Type: " + reportType);
		EnterText(txtFldFAFromDate, incorrectFrmtDate, "From Date");
		EnterText(txtFldFAToDate, futureDate, "To Date");
		ClickElement(btnFASubmit, "Submit Button");
		assertElementDisplayed(vldtnMsgInvldDateFrmt,
				"Validation Message for incorrect date format: " + vldtnMsgInvldDateFrmt.getText());
		assertElementDisplayed(vldtnMsgFuPaDate,
				"Validation Message for future/past date: " + vldtnMsgFuPaDate.getText());
		Thread.sleep(2000);
		takeScreenshot("Cntrbtn by Category-Fields with validation messages");
		EnterText(txtFldFAFromDate, vldFromDate, "From Date");
		EnterText(txtFldFAToDate, vldToDate, "To Date");
		ClickElement(btnFASubmit, "Submit Button");
		Thread.sleep(3000);
		try {
			if (headerContrbtnCtgry.isDisplayed()) {
				assertText(headerContrbtnCtgry, "Contributions by Category from " + vldFromDate + " to " + vldToDate,
						"Contribution Category period range");
				takeScreenshot("Contribution by Category page");
				assertElementDisplayed(colHeaderInvstmntName, colHeaderInvstmntName.getText() + " Col Header");
				assertElementDisplayed(colHeaderInvstmntType, colHeaderInvstmntType.getText() + " Col Header");
				assertElementDisplayed(colHeaderCntrbtnValue, colHeaderCntrbtnValue.getText() + " Col Header");
				ClickElement(linkMrngStarDetails, "Morning Star link");
				switchToWindows(linkMrngStarDetails.getText() + " Link");
				extentTest.log(Status.PASS, "Contribution by Category feature is working as expected");
			}

		} catch (Exception e) {
			assertElementDisplayed(infoMsgCtrbtnDtlsNotAvlbl, "Info Message: " + infoMsgCtrbtnDtlsNotAvlbl.getText());
			takeScreenshot("Contribution Categories Details not available");
			extentTest.log(Status.SKIP, "Test case is Skipped due to " + infoMsgCtrbtnDtlsNotAvlbl.getText());
			throw new SkipException("Test case is Skipped due to " + infoMsgCtrbtnDtlsNotAvlbl.getText());
		}
	}

	// Distribution Detail test case actions
	public void verifyDistributionDetailFeature(String reportType, String incorrectFrmtDate, String futureDate,
			String vldFromDate, String vldToDate, String SSN) throws InterruptedException {
		ClickElement(sideMenuFinancialActvty, "Financial Activity Side menu");
		assertElementDisplayed(headerFinActvty, "Financial Activity Header");
		takeScreenshot("Distribution Detail-Financial Activity Page");
		assertElementDisplayed(headerSelFinActvty, headerSelFinActvty.getText() + " Header");
		ComboSelectVisibleText(selectFinActvtyReport, reportType, "Financial Activity Report Type: " + reportType);
		EnterText(txtFldFAFromDate, incorrectFrmtDate, "From Date");
		EnterText(txtFldFAToDate, futureDate, "To Date");
		ClickElement(btnFASubmit, "Submit Button");
		assertElementDisplayed(vldtnMsgInvldDateFrmt,
				"Validation Message for incorrect date format: " + vldtnMsgInvldDateFrmt.getText());
		assertElementDisplayed(vldtnMsgFuPaDate,
				"Validation Message for future/past date: " + vldtnMsgFuPaDate.getText());
		Thread.sleep(2000);
		takeScreenshot("Distribution Detail-Fields with validation messages");
		EnterText(txtFldFAFromDate, vldFromDate, "From Date");
		EnterText(txtFldFAToDate, vldToDate, "To Date");
		ClickElement(btnFASubmit, "Submit Button");
		Thread.sleep(3000);
		try {
			if (headerDstrbtnDetailsWithDateRange.isDisplayed()) {
				assertText(headerDstrbtnDetailsWithDateRange,
						"Distribution Detail from " + vldFromDate + " to " + vldToDate,
						"Distribution Details with date range");
				assertElementDisplayed(headerDstrbtnDtl, "Distribution Detail Sub header");
				ScrollTo(headerDstrbtnDtl, "Distribution Detail Sub header");
				takeScreenshot("Distribution Details page");
				assertElementDisplayed(colHeaderPrtcpntName, colHeaderPrtcpntName.getText() + " Col Header");
				assertElementDisplayed(colHeaderSSN, colHeaderSSN.getText() + " Col Header");
				try {
					assertElementDisplayed(colHeaderDivison, colHeaderDivison.getText() + " Col Header");
				} catch (Exception e) {
					extentTest.log(Status.INFO,
							"Selected Plan is a non-divisional, hence Dvision column is not displaying");
				}
				assertElementDisplayed(colHeaderDDTradeDate, colHeaderDDTradeDate.getText() + " Col Header");
				assertElementDisplayed(colHeaderGrossAmnt, colHeaderGrossAmnt.getText() + " Col Header");
				assertElementDisplayed(colHeaderCheck, colHeaderCheck.getText() + " Col Header");
				assertElementDisplayed(colHeaderRolloverCash, colHeaderRolloverCash.getText() + " Col Header");
				assertElementDisplayed(colHeaderReason, colHeaderReason.getText() + " Col Header");
				assertElementDisplayed(colHeaderReactivation, colHeaderReactivation.getText() + " Col Header");
				ClickElement(iconDstrbtnDownload, "Download Icon");
				Thread.sleep(2000);
				try {
					if (colHeaderDivison.isDisplayed()) {
						String amntLink = "//form//tbody//span[contains(text(),'" + SSN + "')]//following::td[3]/a";
						WebElement grossAmntLink = driver.findElement(By.xpath(amntLink));
						ClickElement(grossAmntLink, "Amount Link");
					}
				} catch (Exception e) {
					String amntLink = "//form//tbody//span[contains(text(),'" + SSN + "')]//following::td[2]/a";
					WebElement grossAmntLink = driver.findElement(By.xpath(amntLink));
					ClickElement(grossAmntLink, "Amount Link");
				}
				takeScreenshot("Dstrbtn Detail-Transaction and Payment Activites page");
				assertElementDisplayed(btnDDPrevious, "Previous Button");
				assertElementDisplayed(headerPrsnlData, "Personal Data Header");
				assertElementDisplayed(headerTrnsctnActvty, "Transaction Activity Header");
				assertElementDisplayed(headerPaymentActvty, "Payment Activity Header");
				ClickElement(iconDstrbtnDownload, "Download Icon");
				extentTest.log(Status.PASS, "Distribution Detail feature is working as expected");
			}

		} catch (Exception e) {
			assertElementDisplayed(infoMsgDstrbtnDtlsNotAvlbl, "Info Message: " + infoMsgDstrbtnDtlsNotAvlbl.getText());
			takeScreenshot("Distribution Detail not available");
			extentTest.log(Status.SKIP, "Test case is Skipped due to " + infoMsgDstrbtnDtlsNotAvlbl.getText());
			throw new SkipException("Test case is Skipped due to " + infoMsgDstrbtnDtlsNotAvlbl.getText());
		}

	}

	// Inforce Ordering-New Plan Installation/Change plan test case actions
	public void verifyInforceOrderingPlans(String ordrEmail, String plnNumb, String whyOrdering)
			throws InterruptedException {
		MoveToElement(SalesMenu, "Sales Menu");
		ClickElement(ServicesAgrementsSubmenu, ServicesAgrementsSubmenu.getText());
		assertElementDisplayed(SrvcsAgrmtFeeDsclrsHeader, SrvcsAgrmtFeeDsclrsHeader.getText() + " Header");
		assertElementDisplayed(OrderDocLink, OrderDocLink.getText() + " Link");
		assertElementDisplayed(BrowseOrderLink, BrowseOrderLink.getText() + " Link");
		ClickElement(OrderDocLink, OrderDocLink.getText() + " Link");
		assertElementDisplayed(OrderTypeHeader, OrderTypeHeader.getText() + " Header");
		takeScreenshot("Services Agreement and Fee Disclosures Page");
		assertElementDisplayed(step1OrdrType, step1OrdrType.getText());
		assertElementDisplayed(step2OrdrDetails, step2OrdrDetails.getText());
		assertElementDisplayed(step3ReviewOrdr, step3ReviewOrdr.getText());
		assertElementDisplayed(step4complete, step4complete.getText());
		assertElementDisplayed(GroupsAnnuityLink, GroupsAnnuityLink.getText() + " Link");
		assertElementDisplayed(InforceDisLink, InforceDisLink.getText() + " Link");
		ClickElement(InforceDisLink, InforceDisLink.getText() + " Link");
		assertElementDisplayed(headerOrdrInforceDtls, headerOrdrInforceDtls.getText() + " Header");
		takeScreenshot("Order Details - Inforce Page");
		assertElementDisplayed(headerOrdrConfrmtion, headerOrdrConfrmtion.getText() + " Header");
		EnterText(txtFldOrdrCnfrmtnEmail, ordrEmail, "Email");
		assertElementDisplayed(headerPlanInfo, headerPlanInfo.getText() + " Header");
		EnterText(txtFldPlanNumb, plnNumb, "Plan Number");
		String xpath = "//form//table//td//label[contains(text(),' " + whyOrdering + "')]";
		WebElement whyOrderRadioOptn = driver.findElement(By.xpath(xpath));
		ClickElement(whyOrderRadioOptn, "Why Ordering Option");
		ClickElement(btnOrdNext, "Next Button");
		Thread.sleep(1000);
		try {
			if (GA_SubmitBtn.isDisplayed()) {
				ClickElement(GA_SubmitBtn, "Submit Button");
				Thread.sleep(2000);
				assertElementDisplayed(ConfirmDetails, ConfirmDetails.getText());
				extentTest.log(Status.PASS, "Inforce Ordering for " + whyOrdering
						+ " process is implemented as expected and working successfully");
			}
		} catch (Exception e) {
			assertElementDisplayed(infoExistingOrder, "Info Message: " + infoExistingOrder.getText());
			extentTest.log(Status.SKIP, "Test case is Skipped, Info Message: " + infoExistingOrder.getText());
			throw new SkipException("Test case is Skipped, Info Message: " + infoExistingOrder.getText());
			
		}
	}

	// Payroll Feedback - On Demand Report test case actions
	public void verifyPayrollFeedbackOnDemandReport(String beginingnDate, String endingDate, String fileOptn,
			String planNumber) throws InterruptedException {
		ClickElement(sideMenuPayrollFeedbackFile, "Payroll Feedback File Side menu");
		assertElementDisplayed(headerPayrollFdBck, headerPayrollFdBck.getText() + " Header");
		takeScreenshot("Payroll Feedback page");
		assertElementDisplayed(headerSetup, "Setup Header");
		ClickElement(iconExpandSetUp, "Setup Expand Icon");
		MoveToElement(linkOnDemand, "link On Demand");
		Thread.sleep(2000);
		ClickElement(linkOnDemand, linkOnDemand.getText() + " Link");
		Thread.sleep(2000);
		assertElementDisplayed(headerOnDemandRequest, headerOnDemandRequest.getText() + " Header");
		takeScreenshot("Payroll Feedback OnDemand File Request page");
		assertElementDisplayed(labelSetUp, labelSetUp.getText());
		assertElementDisplayed(labelReview, labelReview.getText());
		assertElementDisplayed(labelComplete, labelComplete.getText());
		assertElementDisplayed(headerBeginingDate, headerBeginingDate.getText() + " Header");
		EnterText(txtFldFromDate, beginingnDate, "From Date");
		assertElementDisplayed(headerEndingDate, headerEndingDate.getText() + " Header");
		EnterText(txFldToDate, endingDate, "From Date");
		try {
			if (headerSelectDivision.isDisplayed()) {
				assertElementDisplayed(headerSelectDivision, headerSelectDivision.getText() + " Header");
				ClickElement(linkSelectAll, "Select All Link");
			}

		} catch (Exception e) {
			extentTest.log(Status.INFO,
					"Selected plan is a non-divisional. Select Divison section is not displaying as expected");
		}
		assertElementDisplayed(headerPlsSelectInfo, headerPlsSelectInfo.getText() + " Header");
		ComboSelectVisibleText(selectFileOptn, fileOptn, "Information Type");
		ClickElement(btnFdBckNext, "Next Button");
		ClickElement(btnFdBckSubmit, "Submit Button");
		Thread.sleep(3000);
		assertElementDisplayed(infoMsgSubmissionSuccessfull, "Info Message: " + infoMsgSubmissionSuccessfull.getText());
		takeScreenshot("Payroll Feedback Successfull Submission");
		ClickElement(btnFdBckDshbrd, "Feedback Dashboard Button");
		Thread.sleep(2000);
		ClickElement(iconExpandFBRecords, "Feedback Records Expanding icon");
		assertElementDisplayed(headerPayrollFdbckFileDshbrd, headerPayrollFdbckFileDshbrd.getText() + " Header");
		assertElementDisplayed(colHeaderPlanNumRprtType, "Col Header: " + colHeaderPlanNumRprtType.getText());
		assertElementDisplayed(colHeaderDivisions, "Col Header: " + colHeaderDivisions.getText());
		assertElementDisplayed(colHeaderFileOptn, "Col Header: " + colHeaderFileOptn.getText());
		assertElementDisplayed(colHeaderFrequency, "Col Header: " + colHeaderFrequency.getText());
		assertElementDisplayed(colHeaderLastRun, "Col Header: " + colHeaderLastRun.getText());
		assertElementDisplayed(colHeaderNextRun, "Col Header: " + colHeaderNextRun.getText());
		assertElementDisplayed(colHeaderAction, "Col Header: " + colHeaderAction.getText());
		takeScreenshot("Payroll Feedback Details Page");
		assertText(detailsReportType, planNumber + " - On Demand", "Plan Number/Report Type");
		assertText(detailsFileOptn, fileOptn, "File Option");
		ClickElement(btnView, "View Button");
		Thread.sleep(3000);
		extentTest.log(Status.PASS,
				"Payroll Feedback-OnDemand Report is downloaded and feature is implemented as expected and working successfully");

	}

	// Participant Electronic Report (HO Use Only) test case action
	public void verifyParticipantElectronicReport(String fromDate, String toDate) throws InterruptedException {
		ClickElement(sideMenuPrtcpntElctrncReport, "Participant Electronic Report Side menu");
		assertElementDisplayed(headerPrtcpntElctrncRprt, headerPrtcpntElctrncRprt.getText() + " Header");
		takeScreenshot("Participant Electronic Activity Report page");
		assertElementDisplayed(headerSelectDateRange, headerSelectDateRange.getText() + " Header");
		EnterText(txtFldPERFromDate, fromDate, "From Date");
		EnterText(txtFldPERToDate, toDate, "To Date");
		ClickElement(btnPERSubmit, "Submit Button");
		Thread.sleep(2000);
		try {
			if (headerReportWithDates.isDisplayed()) {
				ScrollTo(headerReportWithDates, "Report Header with Dates");
				takeScreenshot("Participant Electronic Activity Records");
				assertText(headerReportWithDates, "Report from " + fromDate + " through " + toDate,
						"Report Header with date range");
				assertElementDisplayed(colHeaderRequestDate, colHeaderRequestDate.getText() + " Col Header");
				assertElementDisplayed(colHeaderPartcpnt, colHeaderPartcpnt.getText() + " Col Header");
				assertElementDisplayed(colHeaderPERSSN, colHeaderPERSSN.getText() + " Col Header");
				assertElementDisplayed(colHeaderPERDvsn, colHeaderPERDvsn.getText() + " Col Header");
				assertElementDisplayed(colHeaderPlanEntryDate, colHeaderPlanEntryDate.getText() + " Col Header");
				assertElementDisplayed(colHeaderSource, colHeaderSource.getText() + " Col Header");
				assertElementDisplayed(colHeaderPERAction, colHeaderPERAction.getText() + " Col Header");
				assertElementDisplayed(colHeaderUpdatedActn, colHeaderUpdatedActn.getText() + " Col Header");
				ClickElement(DownloadIcon, "Download Icon");
				Thread.sleep(2000);
				extentTest.log(Status.PASS, "Participant Electronic Report feature is working as expected");
			}
		} catch (Exception e) {
			assertElementDisplayed(infoMsgNoElectronicData, "Info Message: " + infoMsgNoElectronicData.getText());
			takeScreenshot("Particpant Electronic Report No Data Info Message");
			extentTest.log(Status.SKIP,
					"Test Case is Skipped due to no electronic data changes for the date range entered. Please try again.");
			throw new SkipException(
					"Test Case is Skipped due to no electronic data changes for the date range entered. Please try again.");
		}

	}

	// Loan Specifications feature test case actions
	public void verifyLoanSpecificationsFeature() {
		ClickElement(sideMenuLoanSpecification, "Loan Specification Side menu");
		assertElementDisplayed(headerLoanSpecifications, "Loan Specifications Header");
		takeScreenshot("Loan Specifications Page");
		assertElementDisplayed(labelLoanAllowedStatus, labelLoanAllowedStatus.getText() + " Label");
		assertElementDisplayed(labelLoanIntrstRate, labelLoanIntrstRate.getText() + " Label");
		assertElementDisplayed(labelInternetLoanAllowed, labelInternetLoanAllowed.getText() + " Label");
		assertElementDisplayed(labelLoanProcessingFee, labelLoanProcessingFee.getText() + " Label");
		assertElementDisplayed(labelLoanAdminFee, labelLoanAdminFee.getText() + " Label");
		assertElementDisplayed(labelMaxLoanAllowed, labelMaxLoanAllowed.getText() + " Label");
		assertElementDisplayed(labelDaysBtwnLoans, labelDaysBtwnLoans.getText() + " Label");
		extentTest.log(Status.INFO, labelLoanAllowedStatus.getText() + " : " + infoLoanStatus.getText());
		extentTest.log(Status.INFO, labelLoanIntrstRate.getText() + " : " + infoLoanIntrstRate.getText());
		extentTest.log(Status.INFO, labelInternetLoanAllowed.getText() + " : " + infoInternetLoanAllowed.getText());
		extentTest.log(Status.INFO, labelLoanProcessingFee.getText() + " : " + infoLoanProcessingFee.getText());
		extentTest.log(Status.INFO, labelLoanAdminFee.getText() + " : " + infoLoanAdminFee.getText());
		extentTest.log(Status.INFO, labelMaxLoanAllowed.getText() + " : " + infoMaxLoanAllowed.getText());
		extentTest.log(Status.INFO, labelDaysBtwnLoans.getText() + " : " + infoDaysBtwnLoans.getText());
		extentTest.log(Status.PASS, "Loan Specifications feature is implemented as expected and working successfully");

	}

	// Compliance Testing test case actions
	public void verifyComplianceTestingFeature() {
		ClickElement(sideMenuComplianceTesting, "Compliance Testing Side menu");
		assertElementDisplayed(headerComplncTesting, "Compliance Testing Header");
		takeScreenshot("Compliance Testing Page");
		try {
			if (headerComplncDetermination.isDisplayed()) {

			}
		} catch (Exception e) {
			assertElementDisplayed(infoMsgNoResultsReturned, "No Results Returned");
			extentTest.log(Status.SKIP, "Results are not returned to the selected Plan");
			throw new SkipException(
					"Test case is skiped due to no results returned for the selected Plan. Try with other plan number");
		}
	}

	// Form 5500 test case action
	public void verifyForm5500() throws InterruptedException {
		ClickElement(sideMenuForm5500, "Form 5500 Side Menu");
		assertElementDisplayed(Form5500Header, "Form 5500 Header");
		takeScreenshot("Form 5500 Page");
		assertElementDisplayed(ImpInfoDocLink, ImpInfoDocLink.getText() + " Link");
		assertElementDisplayed(AuditPckgLink, AuditPckgLink.getText() + " Link");
		ClickElement(ImpInfoDocLink, ImpInfoDocLink.getText() + " Link");
		Thread.sleep(2000);
		switchToWindows("Verify Form Important Info Doc Link page");
		extentTest.log(Status.INFO, ImpInfoDocLink.getText() + " Link is clicked successfully and working as expected");
		ClickElement(AuditPckgLink, AuditPckgLink.getText() + " Link");
		Thread.sleep(2000);
		switchToWindows("Verify Form Audit Package Link page");
		extentTest.log(Status.INFO, AuditPckgLink.getText() + " Link is clicked successfully and working as expected");
		extentTest.log(Status.PASS, "Form 5500 feature is implemented as expected and working successfully");
	}

	// Loan Payoff projection test case actions
	public void verifyLoanPayOffProjectionFeature(String ssn, String invalidDate, String futureDate, String validDate)
			throws InterruptedException {
		ClickElement(sidemenuLoanPayOffProj, "Loan Payoff Projection Side menu");
		takeScreenshot("Loan Payoff Projection Page");
		assertElementDisplayed(headerLoanPayoffProj, headerLoanPayoffProj.getText() + " Header");
		assertElementDisplayed(headerPrtcpntSearch, headerPrtcpntSearch.getText() + " Header");
		assertElementDisplayed(labelPrtcpntSSN, labelPrtcpntSSN.getText() + " Label");
		EnterText(txtFldPrtcpntSSN, ssn, "Participant SSN");
		ClickElement(btnSearch, "Search Button");
		Thread.sleep(4000);
		try {
			if (infoMsgNote.isDisplayed()) {
				takeScreenshot("Loan Payoff- Loan Details");
				assertElementDisplayed(infoMsgNote, infoMsgNote.getText());
				assertElementDisplayed(headerProjectionFor, headerProjectionFor.getText() + " Header");
				assertElementDisplayed(colHeaderLoanNumb, "Column Header: " + colHeaderLoanNumb.getText());
				assertElementDisplayed(colHeaderStatus, "Column Header: " + colHeaderStatus.getText());
				assertElementDisplayed(colHeaderInitDate, "Column Header: " + colHeaderInitDate.getText());
				assertElementDisplayed(colHeaderOrigAmnt, "Column Header: " + colHeaderOrigAmnt.getText());
				ClickElement(linkLoanNumb, "Loan Number Link: " + linkLoanNumb.getText());
				Thread.sleep(2000);
				takeScreenshot("Loan Payoff-Loan Projection Calculation");
				assertElementDisplayed(headerProjctnCalc, headerProjctnCalc.getText() + " Header");
				assertElementDisplayed(labelPayoffDate, labelPayoffDate.getText() + " Label");
				assertElementDisplayed(infoMsgPayoffPrjctn, "Info Message: " + infoMsgPayoffPrjctn.getText());
				assertElementDisplayed(btnCalcualte, "Calculate Button");
				assertElementDisplayed(infoImportantNote1, "Note1: " + infoImportantNote1.getText());
				assertElementDisplayed(infoImportantNote2, "Note2: " + infoImportantNote2.getText());
				EnterText(txtFldPayoffDate, invalidDate, "Payoff Date");
				ClickElement(btnCalcualte, "Calculate Button");
				Thread.sleep(1000);
				assertElementDisplayed(vldtnMsgInvalidDateFormat,
						"Date Format validation Msg: " + vldtnMsgInvalidDateFormat.getText());
				EnterText(txtFldPayoffDate, futureDate, "Payoff Date");
				ClickElement(btnCalcualte, "Calculate Button");
				Thread.sleep(1000);
				assertElementDisplayed(vldtnMsgFuturePayoffDate,
						"Future Date validation Msg: " + vldtnMsgFuturePayoffDate.getText());
				EnterText(txtFldPayoffDate, validDate, "Payoff Date");
				ClickElement(btnCalcualte, "Calculate Button");
				takeScreenshot("Loan Payoff-Loan Calculation Results");
				assertElementDisplayed(btnReCalculate, "Re-Calculate Button");
				assertElementDisplayed(headerCalcResults, headerCalcResults.getText() + " Header");
				assertElementDisplayed(labelProjctnPayoffDate, labelProjctnPayoffDate.getText() + " Label");
				assertElementDisplayed(labelProjctnPayoffAmnt, labelProjctnPayoffAmnt.getText() + " Label");
				assertElementDisplayed(txtPrjctdPayoffAmnt,
						labelProjctnPayoffAmnt.getText() + " " + txtPrjctdPayoffAmnt.getText());
				extentTest.log(Status.PASS,
						"Loan Payoff Projection feature is implemented as expected and working successfuly");
			}
		} catch (Exception e) {
			assertElementDisplayed(infoMsgNoResults, "Info Message: " + infoMsgNoResults.getText());
			takeScreenshot("Loan Payoff- No Results");
			extentTest.log(Status.SKIP, "Test Case is skipped due to No Results returned for the entered SSN");
			throw new SkipException("Test Case is skipped due to No Results returned for the entered SSN");
		}
	}

	// Investment Performance page test case actions
	public void verifyInvestmentPerformanceReport() throws InterruptedException {
		ClickElement(sideMenuPerformance, "Performance Side Menu");
		assertElementDisplayed(headerInvstmntPrfrmnc, headerInvstmntPrfrmnc.getText() + " Header");
		takeScreenshot(headerInvstmntPrfrmnc.getText() + " Page");
		assertElementDisplayed(headerFixedAccnt, headerFixedAccnt.getText() + " Header");
		assertElementDisplayed(headerAnnualized, headerAnnualized.getText() + " Header");
		assertElementDisplayed(colHeaderInvstOptnName, "Col Header: " + colHeaderInvstOptnName.getText());
		assertElementDisplayed(colHeaderInvstType, "Col Header: " + colHeaderInvstType.getText());
		assertElementDisplayed(colHeaderNetExpnsRatio, "Col Header: " + colHeaderNetExpnsRatio.getText());
		assertElementDisplayed(colHeaderYTD, "Col Header: " + colHeaderYTD.getText());
		assertElementDisplayed(colHeaderYear1, "Col Header: " + colHeaderYear1.getText());
		assertElementDisplayed(colHeaderYear3, "Col Header: " + colHeaderYear3.getText());
		assertElementDisplayed(colHeaderYear5, "Col Header: " + colHeaderYear5.getText());
		assertElementDisplayed(colHeaderYears10, "Col Header: " + colHeaderYears10.getText());
		assertElementDisplayed(colHeaderInvOpt, "Col Header: " + colHeaderInvOpt.getText());
		ClickElement(DownloadIcon, "Download Icon");
		Thread.sleep(2000);
		extentTest.log(Status.PASS,
				"Download of Investment Performance report feature is implemented as expected and working successfully");

	}

	// Unit values test case actions
	public void verifyUnitValuesFeature(String futureDate, String invldDateFormat, String validDate, String month,
			String year) throws InterruptedException {
		ClickElement(sideMenuUnitValues, "Unit Values/Shares Submenu");
		assertElementDisplayed(headerUnitVal, headerUnitVal.getText() + " Header");
		takeScreenshot("Unit Values Page");
		assertElementDisplayed(headerByDate, "By Date Header");
		assertElementDisplayed(labelDate, "Date Label");
		assertElementDisplayed(infoMsgToEnterDate, "Info Message: " + infoMsgToEnterDate.getText());
		EnterText(txtFldDate, futureDate, "Date");
		ClickElement(btnDateSubmit, "Submit Button");
		Thread.sleep(1000);
		assertElementDisplayed(vldtnMsgFutureDate, "Validation Message: " + vldtnMsgFutureDate.getText());
		takeScreenshot("Unit Values-Future date validation message");
		EnterText(txtFldDate, invldDateFormat, "Date");
		ClickElement(btnDateSubmit, "Submit Button");
		Thread.sleep(1000);
		assertElementDisplayed(vldtnMsgDateFormat, "Validation Message: " + vldtnMsgDateFormat.getText());
		takeScreenshot("Unit Values-Invalid date format validation message");
		EnterText(txtFldDate, validDate, "Date");
		ClickElement(btnDateSubmit, "Submit Button");
		Thread.sleep(8000);
		ScrollTo(colInvstOptnName, colInvstOptnName.getText());
		assertElementDisplayed(colInvstOptnName, "Column Header: " + colInvstOptnName.getText());
		assertElementDisplayed(colInvstType, "Column Header: " + colInvstType.getText());
		assertElementDisplayed(colValue, "Column Header: " + colValue.getText());
		assertElementDisplayed(colChangeForm, "Column Header: " + colChangeForm.getText());
		takeScreenshot("Unit vaues page by Date option");
		ClickElement(iconDownload, "Download Icon");
		Thread.sleep(2000);
		assertElementDisplayed(headerByMonth, "By Month Header");
		assertElementDisplayed(labelMonth, "Month Label");
		assertElementDisplayed(infoMsgToSelectMonth, "Info Message: " + infoMsgToSelectMonth.getText());
		assertElementDisplayed(labelYear, "Year Label");
		assertElementDisplayed(labelInvstmntOptns, "Investment Options Label");
		assertElementDisplayed(infoMsgToSelectInvstmntOptn, "Info Message: " + infoMsgToSelectInvstmntOptn.getText());
		ComboSelectVisibleText(selectMonth, month, "Month");
		ComboSelectVisibleText(selectYear, year, "Year");
		Select sel = new Select(selectInvstOptn);
		for (int i = 0; i < 7; i++) {
			sel.selectByIndex(i);
		}
		ClickElement(btnMonthSubmit, "Submit Button");
		assertElementDisplayed(vldtnMsgForSelectingMoreInvstOptn,
				"Validation Msg for Selecting more than 6 options: " + vldtnMsgForSelectingMoreInvstOptn.getText());
		takeScreenshot("Unit Values-Validation message for selecting more options");
		sel.deselectAll();
		Thread.sleep(1000);
		Select select = new Select(selectInvstOptn);
		for (int k = 1; k < 7; k++) {
			select.selectByIndex(k);
			String invstOptn = select.getOptions().get(k).getText();
			extentTest.log(Status.INFO, "Investment Option selected: " + invstOptn);
		}
		ClickElement(btnMonthSubmit, "Submit Button");
		Thread.sleep(8000);
		assertElementDisplayed(colDate, "Column Header: Date");
		ScrollTo(colDate, "Column Header: Date");
		takeScreenshot("Unit vaues page by Month option");
		int invstOptnCounts = colHeaderInvstOptns.size();
		for (int j = 0; j < invstOptnCounts; j++) {
			String invstOptnColHeader = colHeaderInvstOptns.get(j).getText();
			extentTest.log(Status.INFO, "Investment Option Col Header: " + invstOptnColHeader);
		}
		ClickElement(iconDownload, "Download Icon");
		Thread.sleep(3000);
		extentTest.log(Status.PASS, "Unit Values/Shares feature is implemented as expected and working successfully");

	}

	// Account Details page actions
	public void verifyAccountDetails() throws InterruptedException {
		assertElementDisplayed(DownloadIcon, "Download Icon");
		assertElementDisplayed(PrintIcon, "Print Icon");
		assertElementDisplayed(AcctDetailsLabel, AcctDetailsLabel.getText());
		takeScreenshot("Account Details page");
		System.out.println(AcctDetailsLabel.getText());
		ScrollTo(InvstmtOptnColumn, "Investment Option Column");
		assertElementDisplayed(InvstmtOptnColumn, "Invstmt Optn Column");
		assertElementDisplayed(InvstmtTypeColumn, "Invstmt Type Column");
		assertElementDisplayed(UnitsColumn, "Units Column");
		assertElementDisplayed(PercentColumn, "Percent Column");
		assertElementDisplayed(ValueColumn, "Value Column");
		ScrollTo(TotalAcctValueRow, "Total Account Value Row");
		assertElementDisplayed(TotalAcctValueRow, "Total Acct Value Row");
		assertElementDisplayed(OutstandingLoanRow, "Outstanding Loan Row");
		assertElementDisplayed(PlanValueRow, "Plan Value Row");
		assertElementDisplayed(AcctDetailsChart, "Acct Details Chart");
		ClickElement(DownloadIcon, "Download Icon");
		Thread.sleep(2000);
		System.out.println("Required key details of account is displaying as expected");
		extentTest.log(Status.PASS, "Required key details of account is displaying as expected");

	}

	// Plan Summary test case actions
	public void verifyPlanSummaryPage() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(sideMenuSummary));
		ClickElement(sideMenuSummary, "Summary Side menu");
		Thread.sleep(5000);
		assertElementDisplayed(headerPlanSummary, headerPlanSummary.getText() + " Header");
		takeScreenshot("Plan Summary page");
		assertElementDisplayed(headerDates, headerDates.getText() + " Header");
		assertElementDisplayed(headerAuthorizedAdmnSrvcs, headerAuthorizedAdmnSrvcs.getText() + " Header");
		assertElementDisplayed(headerPlanSpecifications, headerPlanSpecifications.getText() + " Header");
		assertElementDisplayed(headerRtrmntAge, headerRtrmntAge.getText() + " Header");
		assertElementDisplayed(headerContactInfo, headerContactInfo.getText() + " Header");
		assertElementDisplayed(headerPlanSourceInfo, headerPlanSourceInfo.getText() + " Header");
		assertElementDisplayed(labelTerminationService, labelTerminationService.getText() + " Label");
		assertElementDisplayed(labelFiduciaryService, labelFiduciaryService.getText() + " Header");
		extentTest.log(Status.PASS, "Plan Summary page is implemented as expected and working successfully");

	}

	// Service Roles test case actions
	public void verifyServiceRolesFeature() {
		ClickElement(sideMenuServiceRoles, "Service Roles Side menu");
		assertElementDisplayed(headerServiceRoles, "Service Roles Header");
		takeScreenshot("Service Roles Page");
		assertElementDisplayed(colHeaderName, "Col Header: " + colHeaderName.getText());
		assertElementDisplayed(colHeaderRole, "Col Header: " + colHeaderRole.getText());
		assertElementDisplayed(colHeaderPhnNumb, "Col Header: " + colHeaderPhnNumb.getText());
		takeScreenshotForPassedcase("service");
		assertElementDisplayed(colHeaderEmailAdrs, "Col Header: " + colHeaderEmailAdrs.getText());
		extentTest.log(Status.PASS, "Service Roles feature is implemented as expected and working successfully");
	}

	// Missing Address Report test case actions
	public void verifyMissingAddressReportPage() {
		ClickElement(sideMenuMissingAdrsReport, "Missing Address Report Side menu");
		assertElementDisplayed(headerPrtcpntMissingAdrs, headerPrtcpntMissingAdrs.getText() + " Header");

		try {
			if (colHeaderMA_Participant.isDisplayed()) {
				takeScreenshot("Missing Address Report Page");
				assertElementDisplayed(colHeaderMA_Participant, "Col Header: " + colHeaderMA_Participant.getText());
				assertElementDisplayed(colHeaderMA_SSN, "Col Header: " + colHeaderMA_SSN.getText());
				extentTest.log(Status.PASS,
						"Missing Address Report feature is implemented as expected and working successfully");
			}
		} catch (Exception e) {
			assertElementDisplayed(infoMsgMA_NoResults, "Info Msg: " + infoMsgMA_NoResults.getText());
			takeScreenshot("Missing Address Report No Results Page");
			extentTest.log(Status.INFO, "No Results are returned for the used plan");
			throw new SkipException(
					"Test case is skipped due to no results returend for the slected plan number. Try with the other plan");
		}
	}

	// Administrative Forms test case actions
	public void verifyAdministrativeForms() throws InterruptedException {
		ClickElement(sideMenuAdminForms, "Administrative Forms Submenu");
		assertElementDisplayed(headerAdminForms, headerAdminForms.getText() + " Header");
		takeScreenshot("Administrative Forms Page");
		assertElementDisplayed(labelFaxNumber, "Fax Number Label");
		assertElementDisplayed(labelMailingAddrs, "Mailing Address Label");
		assertText(txtFaxNumber, "317-285-1728", "Fax Number");
		extentTest.log(Status.INFO, labelFaxNumber.getText() + " " + txtFaxNumber.getText());
		extentTest.log(Status.INFO, labelMailingAddrs.getText() + " " + txtMailingAdrs.getText());
		assertElementDisplayed(colHeaderDocumentName, "Col Header: " + colHeaderDocumentName.getText());
		assertElementDisplayed(colHeaderDownload, "Col Header: " + colHeaderDownload.getText());
		assertElementDisplayed(colHeaderEMail, "Col Header: " + colHeaderEMail.getText());

		extentTest.log(Status.INFO, "Number of Administrative Forms Displayed: " + linksForms.size());
		for (int j = 0; j < linksForms.size(); j++) {
			ClickElement(linksForms.get(j), formsName.get(j).getText() + " Link");
			switchToWindows(formsName.get(j).getText() + " Page");
		}
		extentTest.log(Status.PASS,
				"Adminstrative Form link is clicked and PDF is opened successfully and feature is implemented as expected");

	}

	// Change Security Information test case actions
	public void verifyChangeSecurityInformation(String userIDChange, String newUserID, String confirmNewUsrID,
			String newPswd, String confirmNewPswd, String selQuestion, String secAnswer, String existingPwd)
			throws InterruptedException {
		ClickElement(linkMyProfile, "My Profile Link");
		assertElementDisplayed(headerMyProfile, "My Profile Header");
		assertElementDisplayed(linkSecurityAccessSettings, "Security Access Settings Link");
		ClickElement(linkSecurityAccessSettings, "Security Access Settings Link");
		assertElementDisplayed(headerSecurityAccessSettings, "Security Access Settings Header");
		takeScreenshot("Change Security Info-Access Settings Page");
		assertElementDisplayed(labelUserID, "User ID Label");
		assertElementDisplayed(labelPassword, "Password Label");
		assertElementDisplayed(labelEmail, "Email Label");
		assertElementDisplayed(labelMobilePhone, "Mobile Phone Label");
		assertElementDisplayed(labelSecQuestion, "Security Question Label");
		assertElementDisplayed(btnUsrEdit, "UserID Edit Button");
		assertElementDisplayed(btnPwdEdit, "Password Edit Button");
		if (userIDChange.equalsIgnoreCase("yes")) {
			ClickElement(btnUsrEdit, "UserID Edit Button");
			EnterText(txtFldNewUsrID, newUserID, "New UserID");
			EnterText(txtFldCofrmUsrID, confirmNewUsrID, "Confirm New UserID");
		}
		ClickElement(btnPwdEdit, "Password Edit Button");
		EnterText(txtFldNewPwd, newPswd, "New Password");
		EnterText(txtFldConfirmPwd, confirmNewPswd, "Confirm New Password");
		ClickElement(btnSecEdit, "Security Question Edit Button");
		ComboSelectVisibleText(selectSecuQuestion, selQuestion, "Security Question");
		EnterText(txtFldSecAnswer, secAnswer, "Security Answer");
		EnterText(txtFldExistingPwd, existingPwd, "Password");
		ClickElement(btnSecSubmit, "Submit Button");
		Thread.sleep(3000);
		assertElementDisplayed(headerSecCongrats, "Congratulations Header");
		assertElementDisplayed(btnLoginToAcnt, btnLoginToAcnt.getText() + " Button");
		takeScreenshot("Change Security Info-Security Access Settings Updated successfully");
		ClickElement(btnLoginToAcnt, btnLoginToAcnt.getText() + " Button");
		Thread.sleep(3000);

//		if (userIDChange.equalsIgnoreCase("yes")) {
//			 assertElementDisplayed(headerLoginToYrAcnt, "Login To Your Account Page");
//			assertElementDisplayed(headerLoginToYrAcnt1, "Login To Your Account Page");
//		} else {
//			assertElementDisplayed(headerMyProfile, "My Profile Header");
//		}
		extentTest.log(Status.PASS,
				"Change Security Information feature is implemented as expected and working successfully");

	}

	// Pending Transaction no process new test case actions
	public void verifyPendingTransactionProcessPage() {
		ClickElement(sideMenuPendingTransaction, "Pending Transactions Side Menu");
		assertElementDisplayed(headerPendingTransaction, "Pending Transaction Header");
		try {
			if (linkViewDelAction.isDisplayed()) {
				ClickElement(linkViewDelAction, "View Or Delete Action Link");
				Thread.sleep(2000);
				takeScreenshot("Pending Transaction - Beneficiary details Page");
				Thread.sleep(2000);
				ClickElement(btnPT_Cancel, "Cancel Button");
				Thread.sleep(2000);
				ClickElement(sideMenuBeneInfo, "Beneficiary Information Side Menu");
				assertElementDisplayed(headerBeneInfo, "Beneficiary Information Header");
				assertElementDisplayed(infoMsgUnableToProcess, "Info Msg Line1: " + infoMsgUnableToProcess.getText());
				assertElementDisplayed(infoMsgPendingBene, "Info Msg Line2: " + infoMsgPendingBene.getText());
				takeScreenshot("Pending Transaction - Beneficiary Info pending details Page");
				extentTest.log(Status.PASS,
						"Pending Transaction feature is implemented as expected and working successfully");
			}
		} catch (Exception e) {
			extentTest.log(Status.SKIP, "There are no pending transactions for now for the selected plan number");
			throw new SkipException(
					"No Pending Transactions for now for the selected plan number. Try using another plan number");
		}
	}

	// View or Change Future Investment Models test case actions
	public void verifyViewChangeInvestmentModels(String prodID, String planNumber, String prtcpntID)
			throws InterruptedException {
		Thread.sleep(2000);
		selectProducerID(prodID);
		Thread.sleep(2000);
		MoveToElement(PlanParticipantMenu, "Plan/Participant Menu");
		ClickElement(PlanParticipantDataSubmenu, "Plan/Participant Data Sub-menu");
		ComboSelectVisibleText(displayList, "all", "Display List");
		selectPlan(planNumber);
		ClickElement(ParticipantListLink, "Participant List Link");
		assertElementDisplayed(ParticipantListHeader, "Participant List Header");
		selectParticipantName(prtcpntID);
		assertElementDisplayed(ViewPrtcpntDataHeader, ViewPrtcpntDataHeader.getText());
		ClickElement(sideMenuChangeFutureInvstmnt, sideMenuChangeFutureInvstmnt.getText() + " Sidemenu");
		assertElementDisplayed(ViewInvstmntModelsHeader, "View/Change Investment Models Header");
		takeScreenshot("View or Change Future Investment Models Page");

		assertElementDisplayed(labelModelChange, labelModelChange.getText());
		assertElementDisplayed(labelModelReview, labelModelReview.getText());
		assertElementDisplayed(labelChangeComplete, labelChangeComplete.getText());

		assertElementDisplayed(PortfolioDescriptionsHeader, "View Investment Model Portfolio Descriptions Header");
		assertElementDisplayed(InvstModelsLabel, "Investment Models Label");
		assertElementDisplayed(ModelSlctnInfo, "Info on how to select multiple models");
		assertElementDisplayed(DisplayModelsBtn, "Display Models button");

		Select select = new Select(ModelsSelectionListbox);
		int modelCounts = select.getOptions().size();
		if (modelCounts > 7) {
			for (int k = 0; k < 7; k++) {
				select.selectByIndex(k);
			}
			ClickElement(DisplayModelsBtn, "Display Models button");
			Thread.sleep(2000);
			assertElementDisplayed(validationInfoMsg, "Validation Message: " + validationInfoMsg.getText());
			takeScreenshot("View or Change Future Investment Models Validation message display");
			select.deselectAll();
			Thread.sleep(2000);
		}
		for (int i = 0; i < 6; i++) {
			if (!(select.getOptions().get(i).getText().contains("*"))) {
				select.selectByIndex(i);
				String invstModSel = select.getOptions().get(i).getText();
				extentTest.log(Status.INFO, "Selected Investment Model: " + invstModSel);
			}
		}
		ClickElement(DisplayModelsBtn, "Display Models button");
		Thread.sleep(3000);
		assertElementDisplayed(InvstmntTypeColHeader, "Investment Type Column Header");
		ScrollTo(InvstmntTypeColHeader, "Investment Type Column Header");
		takeScreenshot("View or Change Future Investment Models Details Table");
		int colHdrs = invstModlsColHeader.size();
		for (int j = 0; j < colHdrs; j++) {
			String invstMdl = invstModlsColHeader.get(j).getText();
			extentTest.log(Status.INFO, "Investment Model Displayed: " + invstMdl);
		}
		assertElementDisplayed(NoteText, "" + NoteText.getText());
		ClickElement(btnCMNext, "Next Button");
		Thread.sleep(2000);
		assertElementDisplayed(vldtnMsgNotSelectingModel,
				"Validation Message for Not selecting the Model: " + vldtnMsgNotSelectingModel.getText());
		takeScreenshot("View or Change Future Investment Models with Validation Msg");
		ClickElement(radioOptionModels.get(1), "Model Option");
		ClickElement(btnCMNext, "Next Button");
		assertElementDisplayed(infoTxtOnlyOneTime, "Info Text: " + infoTxtOnlyOneTime.getText());
		takeScreenshot("View or Change Future Investment Models Review Page");
		assertElementDisplayed(infoTxtChngCntrbtnElctn, infoTxtChngCntrbtnElctn.getText());
		try {
			if (headerCrntInvstmntModel.isDisplayed()) {
				assertElementDisplayed(headerCrntInvstmntModel, headerCrntInvstmntModel.getText() + " Header");
			}
		} catch (Exception e) {
			extentTest.log(Status.INFO, "There are No Current Investment model for the selected Participant");
		}
		assertElementDisplayed(headerFutureInvstmntModel, headerFutureInvstmntModel.getText() + " Header");
		ClickElement(btnCMSubmit, "Submit Button");
		Thread.sleep(2000);
		assertElementDisplayed(infoChangeModlConfirmation, infoChangeModlConfirmation.getText());
		takeScreenshot("View or Change Future Investment Models Confirmation page");
		extentTest.log(Status.PASS,
				"View or Change Future Investment models feature is implemented as expected and working successfully");

	}

	// Current Defaulted Participants test case actions
	public void verifyCurntDfltdParticipants(String searchBy, String criteria) throws InterruptedException {
		ClickElement(sideMenuCurrntDfltprtctReports, "Current Defaulted Reports");
		assertElementDisplayed(headerCurrDefltPartcpnt, "Current Default Participant Header");
		takeScreenshot("Current Defaulted Participant Page");
		assertElementDisplayed(DownloadIcon, "Download Icon");
		assertElementDisplayed(headerCurrntDefltdParctpntSearch, "Current Default Participant Search Header");
		assertElementDisplayed(labelDPPlanNumber, "Plan Number Label");
		assertElementDisplayed(labelSearchByOptn, "Search By Optn");
		assertElementDisplayed(labelSearchCriteria, "Search Criteria");
		assertElementDisplayed(btnDPSearch, "Search Button");
		ComboSelectVisibleText(selectDPSearchBy, searchBy, "Search By");
		EnterText(txtFldSearchCriteria, criteria, "Criteria");
		ClickElement(btnDPSearch, "Search Button");
		Thread.sleep(2000);
		try {
			if (colHeaderDPParticipantName.isDisplayed()) {
				assertElementDisplayed(linkReturnAllRecords, "Return All Records Link");
				takeScreenshot("Current Defaulted Participant-Search Results page");
			}
		} catch (Exception e) {
			assertElementDisplayed(infoMsgNoResultsRetrnd, "Info Msg: " + infoMsgNoResultsRetrnd.getText());
			takeScreenshot("Current Defaulted Participant-No Results Returned page");
		}
		ClickElement(linkReturnAllRecords, "Return All Records Link");
		Thread.sleep(2000);
		try {
			if (headerDivisions.size() > 0) {
				assertElementDisplayed(headerDivisions.get(0), "Division Header: " + headerDivisions.get(0).getText());
			}
		} catch (Exception e) {
			extentTest.log(Status.INFO,
					"Since selected plan is non-divisional, Division header is not displaying as expected");
		}
		assertElementDisplayed(colHeaderDPParticipantName, "Participant Name Column");
		assertElementDisplayed(colHeaderDPSSN, "SSN Column");
		ClickElement(DownloadIcon, "Download Icon");
		Thread.sleep(2000);
		extentTest.log(Status.PASS,
				"Current Defaulted Report feature is implement as expected and downloaded successfully");

	}

	// Compensation Contacts test case actions
	public void verifyCompensationContactsFeature(String ProdSearchBy, String criteriaTxt) throws InterruptedException {
		MoveToElement(menuCommissions, "Commissions Menu");
		ClickElement(subMenuMonthlyCommissions, "Monthly Commissions Sub-menu");
		Thread.sleep(2000);
		takeScreenshot("Compensation Contacts-Monthly Comissions Page");
		assertElementDisplayed(headerComssnProdSearch, headerComssnProdSearch.getText() + " Header");
		ComboSelectVisibleText(selectProdSearchBy, ProdSearchBy, "Search By");
		EnterText(txtFldCriteria, criteriaTxt, "Criteria");
		ClickElement(btnProdSearch, "Search Button");
		Thread.sleep(2000);
		takeScreenshot("Compensation Contacts-Producer Search Results Page");
		assertElementDisplayed(headerSearchResults, "Search Results");
		assertElementDisplayed(colHeaderProdNumb, colHeaderProdNumb.getText() + " Col Header");
		assertElementDisplayed(colHeaderProdName, colHeaderProdName.getText() + " Col Header");
		assertElementDisplayed(colHeaderNameID, colHeaderNameID.getText() + " Col Header");
		String xpath = "//div[@id='content']//form/table//td/a[contains(text(),'" + criteriaTxt + "')]";
		WebElement prodNumLink = driver.findElement(By.xpath(xpath));
		ClickElement(prodNumLink, "Producer Number Link");
		takeScreenshot("Compensation Contacts-Choose Statement Page");
		assertElementDisplayed(headerChooseStmnt, "Choose Statement Header");
		assertElementDisplayed(headerSelProdNumb, headerSelProdNumb.getText() + " Header");
		assertElementDisplayed(headerSelCommsnMonth, headerSelCommsnMonth.getText() + " Header");
		ClickElement(btnProdSearchSubmit, "Submit Button");
		takeScreenshot("Statement Summary Page");
		assertElementDisplayed(headerStmntSummary, headerStmntSummary.getText() + " Header");
		assertElementDisplayed(headerCompensation, "Compensation Header");
		assertElementDisplayed(headerDeduction_Fees, "Deduction/Fees Header");
		assertElementDisplayed(headerMailingAdrs, "Mailing Address Header");
		assertElementDisplayed(sideMenuCommunications, "Communications Menu");
		assertElementDisplayed(sideMenuCompnstnContacts, "Compensation Contacts SideMenu");
		ClickElement(sideMenuCompnstnContacts, "Compensation Contacts SideMenu");
		Thread.sleep(2000);
		assertElementDisplayed(headerCpmnstnCntcts, headerCpmnstnCntcts.getText() + " Header");
		takeScreenshot("Compensation Contacts Page");
		assertElementDisplayed(headerMailingAdrs, headerMailingAdrs.getText() + " Header");
		assertElementDisplayed(txtRegularMailDetils, txtRegularMailDetils.getText());
		assertElementDisplayed(txtOvernightMailDetails, txtOvernightMailDetails.getText());
		assertElementDisplayed(headerEMailAdrs, headerEMailAdrs.getText() + " Header");
		assertElementDisplayed(txtEmailDetails, txtEmailDetails.getText());
		assertElementDisplayed(headerTelephone, headerTelephone.getText() + " Header");
		assertElementDisplayed(txtTelephoneDetails, txtTelephoneDetails.getText());
		// EFT Form
		ClickElement(sideMenuEFTForm, "EFT Form Side menu");
		assertElementDisplayed(headerEFTForm, headerEFTForm.getText() + " Header");
		takeScreenshot("EFT Form Page");
		assertElementDisplayed(headerMailingAdrs, headerMailingAdrs.getText() + " Header");
		assertElementDisplayed(txtMailingDetails, txtMailingDetails.getText());
		assertElementDisplayed(txtFaxDetails, txtFaxDetails.getText());
		extentTest.log(Status.PASS,
				"Compensation Contacts and EFT Form features are implemented as expected and working successfully");
	}

	// Plan Access and Disabled Feature test case actions
	public void verifyPlanAccessAndDisabledFeatures(String planStatus, String planNumber) throws InterruptedException {
		searchPlanFunctionality(planNumber);
		Thread.sleep(2000);
		if (planStatus.equalsIgnoreCase("Active")) {
			assertElementDisplayed(AcctDetailsLabel, AcctDetailsLabel.getText());
			takeScreenshot("Plan Access - Successfully plan accessed page");
			extentTest.log(Status.PASS, "Accessing of Plan feature is working as expected");
		} else if (planStatus.equalsIgnoreCase("Disabled")) {
			assertElementDisplayed(infoMsgPlanUnavailable, "Info Msg: " + infoMsgPlanUnavailable.getText());
			takeScreenshot("Plan Access - Plan Disabled access Info");
		}
	}

	// Compensation detail-Individual test case actions
	public void verifyCompensationDetailIndividualPage(String ProdSearchBy, String criteriaTxt)
			throws InterruptedException {
		MoveToElement(menuCommissions, "Commissions Menu");
		ClickElement(subMenuMonthlyCommissions, "Monthly Commissions Sub-menu");
		Thread.sleep(2000);
		takeScreenshot("Compensation Detail_Individual-Monthly Comissions Page");
		assertElementDisplayed(headerComssnProdSearch, headerComssnProdSearch.getText() + " Header");
		ComboSelectVisibleText(selectProdSearchBy, ProdSearchBy, "Search By");
		EnterText(txtFldCriteria, criteriaTxt, "Criteria");
		ClickElement(btnProdSearch, "Search Button");
		Thread.sleep(2000);
		takeScreenshot("Compensation Detail_Individual-Producer Search Results Page");
		assertElementDisplayed(headerSearchResults, "Search Results");
		assertElementDisplayed(colHeaderProdNumb, colHeaderProdNumb.getText() + " Col Header");
		assertElementDisplayed(colHeaderProdName, colHeaderProdName.getText() + " Col Header");
		assertElementDisplayed(colHeaderNameID, colHeaderNameID.getText() + " Col Header");
		String xpath = "//div[@id='content']//form/table//td/a[contains(text(),'" + criteriaTxt + "')]";
		WebElement prodNumLink = driver.findElement(By.xpath(xpath));
		ClickElement(prodNumLink, "Producer Number Link");
		takeScreenshot("Compensation Detail_Individual-Choose Statement Page");
		assertElementDisplayed(headerChooseStmnt, "Choose Statement Header");
		assertElementDisplayed(headerSelProdNumb, headerSelProdNumb.getText() + " Header");
		assertElementDisplayed(headerSelCommsnMonth, headerSelCommsnMonth.getText() + " Header");
		ComboSelectVisibleText(selectStmntDate, "Dec, 2020", "Statement Date");
		Thread.sleep(2000);
		ClickElement(btnProdSearchSubmit, "Submit Button");
		takeScreenshot("Compensation Detail_Individual-Statement Summary Page");
		assertElementDisplayed(headerStmntSummary, headerStmntSummary.getText() + " Header");
		assertElementDisplayed(headerCompensation, "Compensation Header");
		assertElementDisplayed(headerDeduction_Fees, "Deduction/Fees Header");
		assertElementDisplayed(headerMailingAdrs, "Mailing Address Header");
		assertElementDisplayed(sideMenuCompnstnDetail, "Compensation Detail Side Menu");
		assertElementDisplayed(subMenuIndividualDetail, "Individual SubMenu");
		ClickElement(subMenuIndividualDetail, "Individual SubMenu");
		Thread.sleep(2000);
		assertElementDisplayed(headerIndvdlCompnstnStmnt, headerIndvdlCompnstnStmnt.getText() + " Header");
		takeScreenshot("Compensation Detail_Individual-Details Page");
		assertElementDisplayed(headerServiceFee, headerServiceFee.getText() + " Header");
		assertElementDisplayed(colHeaderDueDate, "Col Header: " + colHeaderDueDate.getText());
		assertElementDisplayed(colHeaderAccntDay, "Col Header: " + colHeaderAccntDay.getText());
		assertElementDisplayed(colHeaderStmntNum, "Col Header: " + colHeaderStmntNum.getText());
		assertElementDisplayed(colHeaderPolcNmbr, "Col Header: " + colHeaderPolcNmbr.getText());
		assertElementDisplayed(colHeaderPolcHoldr, "Col Header: " + colHeaderPolcHoldr.getText());
		assertElementDisplayed(colHeaderCov, "Col Header: " + colHeaderCov.getText());
		assertElementDisplayed(colHeaderBillType, "Col Header: " + colHeaderBillType.getText());
		assertElementDisplayed(colHeaderSplit, "Col Header: " + colHeaderSplit.getText());
		assertElementDisplayed(colHeaderRatePct, "Col Header: " + colHeaderRatePct.getText());
		assertElementDisplayed(colHeaderCIPremium, "Col Header: " + colHeaderCIPremium.getText());
		assertElementDisplayed(colHeaderCIAmt, "Col Header: " + colHeaderCIAmt.getText());
		assertElementDisplayed(rowTotalIndividual, rowTotalIndividual.getText() + " Row");

	}

	// Download Compensation Statement test case action
	public void verifyDownloadCompensationStatement(String ProdSearchBy, String criteriaTxt)
			throws InterruptedException {
		MoveToElement(menuCommissions, "Commissions Menu");
		ClickElement(subMenuMonthlyCommissions, "Monthly Commissions Sub-menu");
		Thread.sleep(2000);
		takeScreenshot("Compensation Download Statement-Monthly Comissions Page");
		assertElementDisplayed(headerComssnProdSearch, headerComssnProdSearch.getText() + " Header");
		ComboSelectVisibleText(selectProdSearchBy, ProdSearchBy, "Search By");
		EnterText(txtFldCriteria, criteriaTxt, "Criteria");
		ClickElement(btnProdSearch, "Search Button");
		Thread.sleep(2000);
		takeScreenshot("Compensation Download Statement-Producer Search Results Page");
		assertElementDisplayed(headerSearchResults, "Search Results");
		assertElementDisplayed(colHeaderProdNumb, colHeaderProdNumb.getText() + " Col Header");
		assertElementDisplayed(colHeaderProdName, colHeaderProdName.getText() + " Col Header");
		assertElementDisplayed(colHeaderNameID, colHeaderNameID.getText() + " Col Header");
		String xpath = "//div[@id='content']//form/table//td/a[contains(text(),'" + criteriaTxt + "')]";
		WebElement prodNumLink = driver.findElement(By.xpath(xpath));
		ClickElement(prodNumLink, "Producer Number Link");
		takeScreenshot("Compensation Download Statement-Choose Statement Page");
		assertElementDisplayed(headerChooseStmnt, "Choose Statement Header");
		assertElementDisplayed(headerSelProdNumb, headerSelProdNumb.getText() + " Header");
		assertElementDisplayed(headerSelCommsnMonth, headerSelCommsnMonth.getText() + " Header");
		Thread.sleep(2000);
		EnterValue(SelCommsnMonth, SelCommsnMonth.getText(), "statement ");
		ClickElement(btnProdSearchSubmit, "Submit Button");
		takeScreenshot("Compensation Download Statement-Summary Page");
		assertElementDisplayed(headerStmntSummary, headerStmntSummary.getText() + " Header");
		assertElementDisplayed(headerCompensation, "Compensation Header");
		assertElementDisplayed(headerDeduction_Fees, "Deduction/Fees Header");
		assertElementDisplayed(headerMailingAdrs, "Mailing Address Header");
		assertElementDisplayed(sideMenuStmntDisplay, "Statement Display Side menu");
		assertElementDisplayed(sideMenuDwnldStmnt, sideMenuDwnldStmnt.getText() + " Side menu");
		ClickElement(sideMenuDwnldStmnt, sideMenuDwnldStmnt.getText() + " Side menu");
		Thread.sleep(2000);
		assertElementDisplayed(headerDwnldStmnt, headerDwnldStmnt.getText() + " Header");
		assertElementDisplayed(headerCommissionLevel, headerCommissionLevel.getText() + " Header");
		assertElementDisplayed(headerFileType, headerFileType.getText() + " Header");
		assertElementDisplayed(iconFileDwnld, "Download Icon");
		ClickElement(iconFileDwnld, "Download Icon");
		Thread.sleep(2000);
		assertElementDisplayed(linkExcelTemplate, "Link: " + linkExcelTemplate.getText());
		assertElementDisplayed(linkDataDictionary, "Link: " + linkDataDictionary.getText());
		assertElementDisplayed(linkpdfInstrctns, "Link: " + linkpdfInstrctns.getText());
		ClickElement(linkExcelTemplate, "Link: " + linkExcelTemplate.getText());
		Thread.sleep(2000);
		ClickElement(linkDataDictionary, "Link: " + linkDataDictionary.getText());
		Thread.sleep(2000);
		switchToWindows(linkDataDictionary.getText());
		ClickElement(linkpdfInstrctns, "Link: " + linkpdfInstrctns.getText());
		Thread.sleep(2000);
		switchToWindows(linkpdfInstrctns.getText());

	}

	// Compensation Group and Retirement Services Summary test case actions
	public void verifyGroupAndRetirementServicesSummary(String ProdSearchBy, String criteriaTxt)
			throws InterruptedException {
		MoveToElement(menuCommissions, "Commissions Menu");
		ClickElement(subMenuMonthlyCommissions, "Monthly Commissions Sub-menu");
		Thread.sleep(2000);
		takeScreenshot("Group and RS Summary-Monthly Comissions Page");
		assertElementDisplayed(headerComssnProdSearch, headerComssnProdSearch.getText() + " Header");
		ComboSelectVisibleText(selectProdSearchBy, ProdSearchBy, "Search By");
		EnterText(txtFldCriteria, criteriaTxt, "Criteria");
		ClickElement(btnProdSearch, "Search Button");
		Thread.sleep(2000);
		takeScreenshot("Group and RS Summary-Producer Search Results Page");
		assertElementDisplayed(headerSearchResults, "Search Results");
		assertElementDisplayed(colHeaderProdNumb, colHeaderProdNumb.getText() + " Col Header");
		assertElementDisplayed(colHeaderProdName, colHeaderProdName.getText() + " Col Header");
		assertElementDisplayed(colHeaderNameID, colHeaderNameID.getText() + " Col Header");
		String xpath = "//div[@id='content']//form/table//td/a[contains(text(),'" + criteriaTxt + "')]";
		WebElement prodNumLink = driver.findElement(By.xpath(xpath));
		ClickElement(prodNumLink, "Producer Number Link");
		takeScreenshot("Group and RS Summary-Choose Statement Page");
		assertElementDisplayed(headerChooseStmnt, "Choose Statement Header");
		assertElementDisplayed(headerSelProdNumb, headerSelProdNumb.getText() + " Header");
		assertElementDisplayed(headerSelCommsnMonth, headerSelCommsnMonth.getText() + " Header");
		ComboSelectVisibleText(selectStmntDate, "Jan, 2021", "Statement Date");
		Thread.sleep(2000);
		ClickElement(btnProdSearchSubmit, "Submit Button");
		takeScreenshot("Group and RS Summary-Statement Summary Page");
		assertElementDisplayed(headerStmntSummary, headerStmntSummary.getText() + " Header");
		assertElementDisplayed(headerCompensation, "Compensation Header");
		assertElementDisplayed(headerDeduction_Fees, "Deduction/Fees Header");
		assertElementDisplayed(headerMailingAdrs, "Mailing Address Header");

		ClickElement(sideMenuGroup, "Group SubMenu");
		Thread.sleep(2000);
		assertElementDisplayed(headerGrpCompnstn, "Header: " + headerGrpCompnstn.getText());
		takeScreenshot("Group and RS Summary- Group Compensation Summary Page");
		assertElementDisplayed(headerGrpSummary, headerGrpSummary.getText() + " Header");

		ClickElement(sideMenuRetirementServices, "Retirement Services SubMenu");
		Thread.sleep(2000);
		assertElementDisplayed(headerRtrmntSrvcsCmpnstn, "Header: " + headerRtrmntSrvcsCmpnstn.getText());
		takeScreenshot("Group and RS Summary- Retirement Services Summary Page");
		assertElementDisplayed(headerRtrmntSrvcsSummary, headerRtrmntSrvcsSummary.getText() + " Header");

	}

	// All Group and Retirement Services Detail test case actions
	public void verifyAllGroupAndRetirementServicesDetail(String ProdSearchBy, String criteriaTxt)
			throws InterruptedException {
		MoveToElement(menuCommissions, "Commissions Menu");
		ClickElement(subMenuMonthlyCommissions, "Monthly Commissions Sub-menu");
		Thread.sleep(2000);
		takeScreenshot("All Group Detail and All RS Detail-Monthly Comissions Page");
		assertElementDisplayed(headerComssnProdSearch, headerComssnProdSearch.getText() + " Header");
		ComboSelectVisibleText(selectProdSearchBy, ProdSearchBy, "Search By");
		EnterText(txtFldCriteria, criteriaTxt, "Criteria");
		ClickElement(btnProdSearch, "Search Button");
		Thread.sleep(2000);
		takeScreenshot("All Group Detail and All RS Detail-Producer Search Results Page");
		String xpath = "//div[@id='content']//form/table//td/a[contains(text(),'" + criteriaTxt + "')]";
		WebElement prodNumLink = driver.findElement(By.xpath(xpath));
		ClickElement(prodNumLink, "Producer Number Link");
		takeScreenshot("All Group Detail and All RS Detail-Choose Statement Page");
		assertElementDisplayed(headerChooseStmnt, "Choose Statement Header");
		assertElementDisplayed(headerSelProdNumb, headerSelProdNumb.getText() + " Header");
		assertElementDisplayed(headerSelCommsnMonth, headerSelCommsnMonth.getText() + " Header");
		ComboSelectVisibleText(selectStmntDate, "Jan, 2021", "Statement Date");
		Thread.sleep(2000);
		ClickElement(btnProdSearchSubmit, "Submit Button");
		takeScreenshot("All Group Detail and All RS Detail-Statement Summary Page");
		assertElementDisplayed(headerStmntSummary, headerStmntSummary.getText() + " Header");

		ClickElement(sideMenuAllGroupDetail, "All Group Detail Side menu");
		assertElementDisplayed(headerGrpCompnstn, "Header: " + headerGrpCompnstn.getText());
		takeScreenshot("All Group Detail and All RS Detail-Group Compensation Statement Page");
		assertElementDisplayed(headerRenewalWriting, headerRenewalWriting.getText() + " Header");

		ClickElement(sideMenuAllRSDetail, "All RS Detail side menu");
		assertElementDisplayed(headerRtrmntSrvcsCmpnstn, "Header: " + headerRtrmntSrvcsCmpnstn.getText());
		takeScreenshot("All Group Detail and All RS Detail-RS Statement Page");
		assertElementDisplayed(headerRenewalWriting, headerRenewalWriting.getText() + " Header");
	}

	// Compensation Summaries test case actions
	public void verifyCompensationSummariesFeatures(String ProdSearchBy, String criteriaTxt)
			throws InterruptedException {
		MoveToElement(menuCommissions, "Commissions Menu");
		ClickElement(subMenuMonthlyCommissions, "Monthly Commissions Sub-menu");
		Thread.sleep(2000);
		takeScreenshot("Compensation Summaries-Monthly Comissions Page");
		assertElementDisplayed(headerComssnProdSearch, headerComssnProdSearch.getText() + " Header");
		ComboSelectVisibleText(selectProdSearchBy, ProdSearchBy, "Search By");
		EnterText(txtFldCriteria, criteriaTxt, "Criteria");
		ClickElement(btnProdSearch, "Search Button");
		Thread.sleep(2000);
		takeScreenshot("Compensation Summaries-Producer Search Results Page");
		String xpath = "//div[@id='content']//form/table//td/a[contains(text(),'" + criteriaTxt + "')]";
		WebElement prodNumLink = driver.findElement(By.xpath(xpath));
		ClickElement(prodNumLink, "Producer Number Link");
		takeScreenshot("Compensation Summaries-Choose Statement Page");
		assertElementDisplayed(headerChooseStmnt, "Choose Statement Header");
		assertElementDisplayed(headerSelProdNumb, headerSelProdNumb.getText() + " Header");
		assertElementDisplayed(headerSelCommsnMonth, headerSelCommsnMonth.getText() + " Header");
		ComboSelectVisibleText(selectStmntDate, "Jan, 2021", "Statement Date");
		Thread.sleep(2000);
		ClickElement(btnProdSearchSubmit, "Submit Button");
		takeScreenshot("Compensation Summaries-Statement Summary Page");
		assertElementDisplayed(headerStmntSummary, headerStmntSummary.getText() + " Header");

		ClickElement(sideMenuCompensation, sideMenuCompensation.getText() + " Side menu");
		assertElementDisplayed(headerCompnstnSummaries, headerCompnstnSummaries.getText() + " Header");
		takeScreenshot("Compensation Summaries-Compensation Summary Page");
		assertElementDisplayed(tableHeaderCompnstn, tableHeaderCompnstn.getText() + " Table Header");
		assertElementDisplayed(tableHeaderYearToDate, tableHeaderYearToDate.getText() + " Table Header");

		ClickElement(sideMenuDeduction, sideMenuDeduction.getText() + " Side menu");
		assertElementDisplayed(headerCompnstnSummaries, headerCompnstnSummaries.getText() + " Header");
		takeScreenshot("Compensation Summaries-Deduction Details Page");
		for (int i = 0; i < tableHeaders.size(); i++) {
			assertElementDisplayed(tableHeaders.get(i), tableHeaders.get(i).getText());
		}
		assertElementDisplayed(labelTotalDeduction, labelTotalDeduction.getText() + " Label");
		extentTest.log(Status.INFO, labelTotalDeduction.getText() + " : " + valueTotalDeduction.getText());

		ClickElement(sideMenuReconciliation, sideMenuReconciliation.getText() + " Side menu");
		assertElementDisplayed(headerCompnstnSummaries, headerCompnstnSummaries.getText() + " Header");
		takeScreenshot("Compensation Summaries-Reconciliation Details Page");
		for (int i = 0; i < tableHeaders.size(); i++) {
			assertElementDisplayed(tableHeaders.get(i), tableHeaders.get(i).getText() + " Table Header");
		}
		assertElementDisplayed(labelTotalBlances, labelTotalBlances.getText() + " Label");
		extentTest.log(Status.INFO, labelTotalBlances.getText() + " : " + valueTotalBalances.getText());

		ClickElement(sideMenuTaxRecap, sideMenuTaxRecap.getText() + " Side menu");
		assertElementDisplayed(headerCompnstnSummaries, headerCompnstnSummaries.getText() + " Header");
		takeScreenshot("Compensation Summaries-Tax Recap Details Page");
		for (int i = 0; i < tableHeaders.size(); i++) {
			assertElementDisplayed(tableHeaders.get(i), tableHeaders.get(i).getText() + " Table Header");
		}

		ClickElement(sideMenuOthrCompnstn, sideMenuOthrCompnstn.getText() + " Side menu");
		assertElementDisplayed(headerCompnstnSummaries, headerCompnstnSummaries.getText() + " Header");
		takeScreenshot("Compensation Summaries-Other Compensation Details Page");
		try {
			for (int i = 0; i < tableHeaders.size(); i++) {
				assertElementDisplayed(tableHeaders.get(i), tableHeaders.get(i).getText() + " Table Header");
			}
		} catch (Exception e) {
			assertElementDisplayed(infoMsgNoDataToReport, infoMsgNoDataToReport.getText());
		}
	}

	// Override Summary and Details test case actions
	public void verifyOverrideSummaryAndAllOverrideDetails(String ProdSearchBy, String criteriaTxt,
			String statementDate) throws InterruptedException {
		MoveToElement(menuCommissions, "Commissions Menu");
		ClickElement(subMenuMonthlyCommissions, "Monthly Commissions Sub-menu");
		Thread.sleep(2000);
		takeScreenshot("Override Summary-Monthly Comissions Page");
		assertElementDisplayed(headerComssnProdSearch, headerComssnProdSearch.getText() + " Header");
		ComboSelectVisibleText(selectProdSearchBy, ProdSearchBy, "Search By");
		EnterText(txtFldCriteria, criteriaTxt, "Criteria");
		ClickElement(btnProdSearch, "Search Button");
		Thread.sleep(2000);
		takeScreenshot("Override Summary-Producer Search Results Page");
		String xpath = "//div[@id='content']//form/table//td/a[contains(text(),'" + criteriaTxt + "')]";
		WebElement prodNumLink = driver.findElement(By.xpath(xpath));
		ClickElement(prodNumLink, "Producer Number Link");
		takeScreenshot("Override Summary-Choose Statement Page");
		assertElementDisplayed(headerChooseStmnt, "Choose Statement Header");
		assertElementDisplayed(headerSelProdNumb, headerSelProdNumb.getText() + " Header");
		assertElementDisplayed(headerSelCommsnMonth, headerSelCommsnMonth.getText() + " Header");
		ComboSelectVisibleText(selectStmntDate, statementDate, "Statement Date");
		Thread.sleep(2000);
		ClickElement(btnProdSearchSubmit, "Submit Button");
		takeScreenshot("Override Summary-Statement Summary Page");
		assertElementDisplayed(headerStmntSummary, headerStmntSummary.getText() + " Header");

		ClickElement(sideMenuOverride, sideMenuOverride.getText() + " Side menu");
		Thread.sleep(2000);
		assertElementDisplayed(headerCompnstnSummaries, headerCompnstnSummaries.getText() + " Header");
		takeScreenshot("Override Summary Page");
		assertElementDisplayed(linkOvrrideProdNameLink, linkOvrrideProdNameLink.getText() + " Producer Name Link");
		ClickElement(linkOvrrideProdNameLink, "Producer Name Link");
		takeScreenshot("Override Summary-Override details Page");
		assertElementDisplayed(labelTotalOvrride, labelTotalOvrride.getText() + " Row");
		extentTest.log(Status.INFO, labelTotalOvrride.getText() + " : " + valueTtlOvrride.getText());

		ClickElement(sideMenuAllOverrideDetail, sideMenuAllOverrideDetail.getText() + " Side menu");
		Thread.sleep(2000);
		assertElementDisplayed(headerCompnstnSummaries, headerCompnstnSummaries.getText() + " Header");
		takeScreenshot("All Override Summary Page");
		assertElementDisplayed(labelAllOvrdeTotal, labelAllOvrdeTotal.getText() + " Row");
		extentTest.log(Status.INFO, labelAllOvrdeTotal.getText() + " : " + valueAllTtlOvrde.getText());

	}

	// Commission Search test case actions
	public void verifyCommissionSearchPage(String ProdSearchBy, String criteriaTxt) throws InterruptedException {
		MoveToElement(menuCommissions, "Commissions Menu");
		ClickElement(subMenuMonthlyCommissions, "Monthly Commissions Sub-menu");
		Thread.sleep(2000);
		takeScreenshot("Commission Search-Monthly Comissions Page");
		assertElementDisplayed(headerComssnProdSearch, headerComssnProdSearch.getText() + " Header");
		ComboSelectVisibleText(selectProdSearchBy, ProdSearchBy, "Search By");
		EnterText(txtFldCriteria, criteriaTxt, "Criteria");
		ClickElement(btnProdSearch, "Search Button");
		Thread.sleep(2000);
		try {
			if (headerSearchResults.isDisplayed()) {
				assertElementDisplayed(headerSearchResults, headerSearchResults.getText() + " Header");
				assertElementDisplayed(colHeaderProdNumb, colHeaderProdNumb.getText() + " Col Header");
				assertElementDisplayed(colHeaderProdName, colHeaderProdName.getText() + " Col Header");
				assertElementDisplayed(colHeaderNameID, colHeaderNameID.getText() + " Col Header");
				takeScreenshot("Commission Search-Search Results Page");
			}
		} catch (Exception e) {
			assertElementDisplayed(infoMsgNoResultsRtrnd, "Info msg: " + infoMsgNoResultsRtrnd.getText());
			extentTest.log(Status.SKIP, "Info msg: " + infoMsgNoResultsRtrnd.getText());
			throw new SkipException(
					"Test case is SKIPPED due to no results returned. Use other Producer Name or Number");
		}
	}

	// Recurring Re-balance test case actions
	public void verifyRecurringRebalanceFeature(String ProducerID, String planNumb, String frequencyType)
			throws InterruptedException {
		MoveToElement(InvestmentMenu, "Investment Menu");
		ClickElement(InvsmtAdvisorSupportSubmenu, "Investment Advisor Support Sub-menu");
		takeScreenshot("Investment Advisor Support Page");
		Thread.sleep(1000);
		ClickElement(PlanSetUpandMaintenanceLink, "Plan SetUp and Maintenance Link");
		assertElementDisplayed(AdvisorSearchHeader, "Advisor Search Header");
		takeScreenshot("Advisor Search page");
		EnterText(Advsr_Criteria, "AA", "Criteria");
		ClickElement(Advsr_SearchBtn, "Advsr_SearchBtn");
		ComboSelectVisibleText(DisplayList, "all", "Display Rows");
		Thread.sleep(2000);
		String advisoridPath = "//form[@id='dataTable']//td/a[contains(text(),'" + ProducerID + "')]";
		WebElement prodName = driver.findElement(By.xpath(advisoridPath));
		ClickElement(prodName, "Advisor ID: " + ProducerID);
		assertElementDisplayed(PlanSetUpandMaintenanceHeader, "Plan SetUp and Maintenance Header");
		try {
			if (SelectaPlanInfo.isDisplayed()) {
				assertElementDisplayed(SelectaPlanInfo, SelectaPlanInfo.getText());
				ComboSelectVisibleText(DisplayList, "all", "Display Rows");
				String planNum = "//form[@id='dataTable']//td/a/span[contains(text(),'" + planNumb + "')]";
				WebElement plannum = driver.findElement(By.xpath(planNum));
				ClickElement(plannum, "Plan Number Link: " + planNumber);
				try {
					if (InvestmentModelsLink.isDisplayed()) {
						assertElementDisplayed(linkRecurringReblnc, linkRecurringReblnc.getText() + " Link");
						ClickElement(linkRecurringReblnc, linkRecurringReblnc.getText() + " Link");
						assertElementDisplayed(headerRecurringReblnc, headerRecurringReblnc.getText() + " Header");
						takeScreenshot("Recurring Re-balance Setup Page");
						assertElementDisplayed(step1SlctFrqncy, step1SlctFrqncy.getText());
						assertElementDisplayed(step2ReblncReview, step2ReblncReview.getText());
						assertElementDisplayed(step3ReblncComplete, step3ReblncComplete.getText());

						assertElementDisplayed(headerFrequencyOfRebal, headerFrequencyOfRebal.getText() + " Header");
						assertElementDisplayed(labelQuarterly, labelQuarterly.getText() + " Label");
						assertElementDisplayed(labelSemiAnual, labelSemiAnual.getText() + " Label");
						assertElementDisplayed(labelAnnually, labelAnnually.getText() + " Label");
						assertElementDisplayed(labelNoAutomatic, labelNoAutomatic.getText() + " Label");
						String frqncyPath = "//form[@id='planRebalForm']//label[text()=' " + frequencyType + "']";
						WebElement frequencyOption = driver.findElement(By.xpath(frqncyPath));
						ClickElement(frequencyOption, "Frequency Type: " + frequencyType);
						Thread.sleep(2000);
						ClickElement(btnRebalNext, "Next Button");
						Thread.sleep(2000);
						takeScreenshot("Recurring Re-balance- Review Page");

						assertElementDisplayed(txtInfoReview, "Info: " + txtInfoReview.getText());
						assertText(txtFrqncySelected, frequencyType, "Frequency Selected");
						assertElementDisplayed(btnRebalSubmit, "Submit Button");
						ClickElement(btnRebalSubmit, "Submit Button");
						Thread.sleep(2000);
						assertElementDisplayed(txtInfoSuccessfull, "Info: " + txtInfoSuccessfull.getText());
						takeScreenshot("Recurring Re-balance- Completion Page");
						assertElementDisplayed(btnPlanSetup, "Plan Setup Button");
					}
				} catch (Exception e) {
					assertElementDisplayed(NoPlanSetupRqd, NoPlanSetupRqd.getText());
					takeScreenshot("View Current investment models-SetUp is not required");
					extentTest.log(Status.INFO, NoPlanSetupRqd.getText() + " is displayed");
					throw new SkipException(
							"SetUp is not required for the selected plan. Use the other plan number to execute the script");
				}
			}
		} catch (Exception e) {
			assertElementDisplayed(NoResultsInfo, NoResultsInfo.getText());
			extentTest.log(Status.INFO, NoResultsInfo.getText() + " message is displayed for the selected AdvisorID");
			throw new SkipException(
					"Test case is skipped due to plans are not available for the selected Advisor ID. Use the other Advisor ID and execute the script");
		}
	}

	// Investor profile Questionnaire test case actions
	public void verifyInvestorProfileQuestionnaire(String ProducerID, String planNumb, String option)
			throws InterruptedException {
		MoveToElement(InvestmentMenu, "Investment Menu");
		ClickElement(InvsmtAdvisorSupportSubmenu, "Investment Advisor Support Sub-menu");
		takeScreenshot("Investment Advisor Support Page");
		Thread.sleep(1000);
		ClickElement(PlanSetUpandMaintenanceLink, "Plan SetUp and Maintenance Link");
		assertElementDisplayed(AdvisorSearchHeader, "Advisor Search Header");
		takeScreenshot("Advisor Search page");
		EnterText(Advsr_Criteria, "AA", "Criteria");
		ClickElement(Advsr_SearchBtn, "Advsr_SearchBtn");
		ComboSelectVisibleText(DisplayList, "all", "Display Rows");
		Thread.sleep(2000);
		String advisoridPath = "//form[@id='dataTable']//td/a[contains(text(),'" + ProducerID + "')]";
		WebElement prodName = driver.findElement(By.xpath(advisoridPath));
		ClickElement(prodName, "Advisor ID: " + ProducerID);
		assertElementDisplayed(PlanSetUpandMaintenanceHeader, "Plan SetUp and Maintenance Header");
		try {
			if (SelectaPlanInfo.isDisplayed()) {
				assertElementDisplayed(SelectaPlanInfo, SelectaPlanInfo.getText());
				String planNum = "//form[@id='dataTable']//td/a/span[contains(text(),'" + planNumb + "')]";
				WebElement plannum = driver.findElement(By.xpath(planNum));
				ClickElement(plannum, "Plan Number Link: " + planNumb);
				try {
					if (InvestmentModelsLink.isDisplayed()) {
						assertElementDisplayed(linkInvestorPrflQstnre, linkInvestorPrflQstnre.getText() + " Link");
						ClickElement(linkInvestorPrflQstnre, linkInvestorPrflQstnre.getText() + " Link");
						assertElementDisplayed(headerInvstrPrflQstnre, headerInvstrPrflQstnre.getText() + " Header");
						takeScreenshot("Investot Profile Questionnaire Setup Page");
						assertElementDisplayed(step1InvstrQstnre, step1InvstrQstnre.getText());
						assertElementDisplayed(step2QstnreReview, step2QstnreReview.getText());
						assertElementDisplayed(step3QstnreComplete, step3QstnreComplete.getText());
						assertElementDisplayed(headerQstnreSetup, headerQstnreSetup.getText() + " Header");
						assertElementDisplayed(optionEqualQstnWeights, optionEqualQstnWeights.getText() + " Option");
						assertElementDisplayed(optionCustomizeQstnWeights,
								optionCustomizeQstnWeights.getText() + " Option");
						assertElementDisplayed(optionDoNotDisplayQstnWeights,
								optionDoNotDisplayQstnWeights.getText() + " Option");
						assertElementDisplayed(btnInvstrQstnreNext, "Next Button");
						assertElementDisplayed(headerQstnreWeights, headerQstnreWeights.getText() + " Header");

						ClickElement(optionCustomizeQstnWeights, optionEqualQstnWeights.getText() + " Option");
						Thread.sleep(2000);
						for (int i = 0; i < txtFldQstnWeights.size(); i++) {
							txtFldQstnWeights.get(i).clear();
						}
						Thread.sleep(2000);
						EnterText(txtFldQstnWeights.get(0), "12", "Question Score");
						EnterText(txtFldQstnWeights.get(1), "19", "Question Score");
						EnterText(txtFldQstnWeights.get(2), "11", "Question Score");
						// ClickElement(btnInvstrQstnreNext, "Next Button");
						// txtFldQstnWeights.get(3).clear();
						// for (int i = 0; i < txtFldQstnWeights.size()-1; i++) {
						// txtFldQstnWeights.get(i).sendKeys("13");
						// }
						ClickElement(btnInvstrQstnreNext, "Next Button");
						Thread.sleep(2000);
						assertElementDisplayed(errorMsgInvalidEntry, "Error Msg: " + errorMsgInvalidEntry.getText());
						// assertElementDisplayed(infoMsgMultipleScoreOf5,
						// "Info Msg: " + infoMsgMultipleScoreOf5.getText());
						takeScreenshot("Investot Profile Questionnaire-With Validations");
						for (int i = 0; i < txtFldQstnWeights.size(); i++) {
							txtFldQstnWeights.get(i).clear();
						}

						if (option.equalsIgnoreCase("Equal")) {
							ClickElement(optionEqualQstnWeights, optionEqualQstnWeights.getText() + " Option");
							for (int i = 0; i < txtFldQstnWeights.size(); i++) {
								txtFldQstnWeights.get(i).sendKeys("20");
							}
							ClickElement(btnInvstrQstnreNext, "Next Button");
							Thread.sleep(2000);
							assertElementDisplayed(btnInvstrQstnreSubmit, "Submit Button");
							takeScreenshot("Investor Profile Questionnaire-Review Page");
							assertElementDisplayed(headerWithSelectedOption,
									headerWithSelectedOption.getText() + " Header");
							ClickElement(btnInvstrQstnreSubmit, "Submit Button");
							Thread.sleep(2000);
							System.out.println("Successfully Completed");
							assertElementDisplayed(btnRtrnPlanSetup, "Return Setup Button");

						} else if (option.equalsIgnoreCase("Customize")) {
							ClickElement(optionCustomizeQstnWeights, optionCustomizeQstnWeights.getText() + " Option");
							for (int i = 0; i < txtFldQstnWeights.size(); i += 2) {
								EnterText(txtFldQstnWeights.get(i), "15", "Score to Question " + (i + 1));
							}
							for (int j = 1; j < txtFldQstnWeights.size(); j += 2) {
								EnterText(txtFldQstnWeights.get(j), "25", "Score to Question " + (j + 1));
							}
							ClickElement(btnInvstrQstnreNext, "Next Button");
							Thread.sleep(2000);
							assertElementDisplayed(btnInvstrQstnreSubmit, "Submit Button");
							takeScreenshot("Investor Profile Questionnaire-Review Page");
							assertElementDisplayed(headerWithSelectedOption,
									headerWithSelectedOption.getText() + " Header");
							ClickElement(btnInvstrQstnreSubmit, "Submit Button");
							Thread.sleep(2000);
							System.out.println("Successfully Completed");
							assertElementDisplayed(headerASChangingWeights,
									"Info Msg: " + headerASChangingWeights.getText());
							assertElementDisplayed(btnRtrnPlanSetup, "Return Setup Button");
						} else if (option.equalsIgnoreCase("Do Not Display")) {
							optionEqualQstnWeights.click();
							driver.navigate().refresh();
							ClickElement(optionDoNotDisplayQstnWeights,
									optionDoNotDisplayQstnWeights.getText() + " Option");
							ClickElement(btnInvstrQstnreNext, "Next Button");
							Thread.sleep(2000);
							assertElementDisplayed(btnInvstrQstnreSubmit, "Submit Button");
							takeScreenshot("Investor Profile Questionnaire-Review Page");
							assertElementDisplayed(infoMsgQstnsNotDisplay,
									"Info Msg: " + infoMsgQstnsNotDisplay.getText());
							ClickElement(btnInvstrQstnreSubmit, "Submit Button");
							Thread.sleep(2000);
							System.out.println("Successfully Completed");
							assertElementDisplayed(infoMsgQstnsNotDisplay,
									"Successfull Msg: " + infoMsgQstnsNotDisplay.getText());
							assertElementDisplayed(btnRtrnPlanSetup, "Return Setup Button");
							Thread.sleep(2000);
						}
					}
				} catch (Exception e) {
					assertElementDisplayed(NoPlanSetupRqd, NoPlanSetupRqd.getText());
					takeScreenshot("View Current investment models-SetUp is not required");
					extentTest.log(Status.INFO, NoPlanSetupRqd.getText() + " is displayed");
					throw new SkipException(
							"SetUp is not required for the selected plan. Use the other plan number to execute the script");
				}
			}
		} catch (Exception e) {
			assertElementDisplayed(NoResultsInfo, NoResultsInfo.getText());
			extentTest.log(Status.INFO, NoResultsInfo.getText() + " message is displayed for the selected AdvisorID");
			throw new SkipException(
					"Test case is skipped due to plans are not available for the selected Advisor ID. Use the other Advisor ID and execute the script");
		}
	}

//<<<<<<< HEAD
//=======
	// Important Documents ProNvest Agreement
	public void verifyImpDocsProNvestAgreementFeature(String PM696) throws InterruptedException {

		Thread.sleep(2000);
		ClickElement(ImportantDocsLink, "Important Documents Link");
		assertElementDisplayed(ImportantDocsHeader, "Important Documents Header");
		takeScreenshot("Important Documents Page");
		assertElementDisplayed(ContractLink, "Contract, Amendments and Agreements Link");
		try {
			ClickElement(ContractLink, "Contract, Amendments and Agreements Link");
			assertElementDisplayed(DocLinkHeader, DocLinkHeader.getText() + " Header");
			ClickElement(impdocServiceAgreementLink, impdocServiceAgreementLink.getText() + " Link");
			Thread.sleep(1000);
			if (PM696.equals("P")) {
				assertElementDisplayed(futureCapitalAgreement, "Future Capital Agreement Link");
				assertElementDisplayed(futureCapitalDistributorDisclosure,
						"Future Capital Distributor Disclosure Link");
			} else {
				extentTest.log(Status.INFO,
						"Future Capital Agreement and Future Capital Distributor Disclosure are not displayed");

			}
		} catch (Exception e) {
			assertElementDisplayed(NoDocsInfoMsg, NoDocsInfoMsg.getText());
			takeScreenshot("Important Docs-No Docs info message");
			extentTest.log(Status.INFO, NoDocsInfoMsg.getText());
			throw new SkipException(
					"Test case is skipped due to no documents available. Please use the other plan number");
		}

	}

	// Investment Tab and Plan Summary ProNvest Agreement
	public void verifyPlanSummaryProNvestFeature(String PM696) throws InterruptedException {
		// MoveToElement(InvestmentMenu, "Investments Menu");
		ClickElement(InvestmentMenu, "Investments Menu");
		assertElementDisplayed(futureCapitalSubmenu, futureCapitalSubmenu.getText());
		MoveToElement(sideMenuSummary, "Summary SideMenu");
		ClickElement(sideMenuSummary, "Summary Side-menu");
		Thread.sleep(2000);
		assertElementDisplayed(headerPlanSummary, headerPlanSummary.getText());
		assertElementDisplayed(planFeaturesHeader, planFeaturesHeader.getText());
		assertElementDisplayed(managedAccountProviderlabel, managedAccountProviderlabel.getText());
		if (PM696.equals("P")) {
			assertElementDisplayed(managedAccountFutureCapitalvalue, managedAccountFutureCapitalvalue.getText());
		} else {
			extentTest.log(Status.INFO, "Future Capital is not displayed");

		}

	}

	// LTPT Employee Data Review Feature
	public void verifyLTPTEmployeeDataReview(String PM702) throws InterruptedException {

		// MoveToElement(PlanParticipantMenu, "Plan/Participant Menu");
		// MoveToElement(PlanReportsMenu, "Plan Reports menu");
		// List <WebElement>
		// PlanEntryMenu=driver.findElements(By.xpath("//div[@id='primarynav']/form//li//a[text()='Plan
		// Entry']"));
		List<WebElement> PlanEntryMenu = driver
				.findElements(By.xpath("//ul[@id='sideNavMenu']//li//a[text()='Plan Entry']"));
		int PlanEntryMenuCount = PlanEntryMenu.size();
		// boolean flag1 =assertElementfornonDisplayed(submenuPlanEntryoption,
		// submenuPlanEntryoption.getText());
		// if(submenuPlanEntryoption.isDisplayed()) {
		if (PlanEntryMenuCount > 0) {
			MoveToElement(submenuPlanEntryoption, "Plan Entry menu");

			if ((PM702.equals("V")) || (PM702.equals("U")) || (PM702.equals("S")) || (PM702.equals("F"))
					|| (PM702.equals("G")) || (PM702.equals("H")) || (PM702.equals("I")) || (PM702.equals("J"))
					|| (PM702.equals("K")) || (PM702.equals("E"))) {

				assertElementDisplayed(submenuPlanEntryoption, submenuPlanEntryoption.getText());
				boolean value = assertElementfornonDisplayed(submenuLTPTEmployeeDataReview,
						"Long-Term Part-Time Employee Data Review");
				if (value == false) {
					extentTest.log(Status.PASS, "Long-Term Part-Time Employee Data Review is not displayed");
				}
				boolean value1 = assertElementfornonDisplayed(submenuLTPTStatusReport,
						"Long-Term Part-Time Status Report");
				if (value1 == false) {
					extentTest.log(Status.PASS, "Long-Term Part-Time Status Report is not displayed");
				}

			} else {

				assertElementDisplayed(submenuPlanEntryoption, submenuPlanEntryoption.getText());
				assertElementDisplayed(submenuLTPTEmployeeDataReview, submenuLTPTEmployeeDataReview.getText());
				assertElementDisplayed(submenuLTPTStatusReport, submenuLTPTStatusReport.getText());

				MoveToElement(submenuLTPTEmployeeDataReview, "LTPT Employee Data Review menu");
				ClickElement(submenuLTPTEmployeeDataReview, "LTPT Employee Data Review menu Link");
				assertElementDisplayed(LTPTEmployeeDataReviewHeader, LTPTEmployeeDataReviewHeader.getText());
				Assert.assertEquals("Long-Term Part-Time Employee Data Review", LTPTEmployeeDataReviewHeader.getText());

				assertElementDisplayed(SideMenuLTPTEmployeeData, SideMenuLTPTEmployeeData.getText());
				assertElementDisplayed(SideMenuLTPTStatusReport, SideMenuLTPTStatusReport.getText());

				assertElementDisplayed(LTPTDataReviewStep1LTPTLink, LTPTDataReviewStep1LTPTLink.getText());
				ClickElement(LTPTDataReviewStep1LTPTLink, "LTPT Instructions Link");
				Thread.sleep(4000);
				Iterator<String> windows1 = driver.getWindowHandles().iterator();
				String parentID1 = windows1.next();
				String childId1 = windows1.next();
				driver.switchTo().window(childId1);
				Thread.sleep(4000);
				// String ExpectedTitle="Microsoft Word - LTPT Report Review Instructions 9.11";
				// String ChildWindowTitle=driver.getTitle();
				// String ChildWindowTitle=driver.findElement(By.xpath("//span[text()='Microsoft
				// Word - LTPT Report Review Instructions 9.11']")).getText();
				String ExpectedUrl1 = "https://www.ftwcm.oneamerica.com/wps/wcm/connect/40220bba-a57d-4403-a57d-093f32c5685f/LTPT+Report+Review+Instructions+04.17.24.pdf?MOD=AJPERES&CACHEID=ROOTWORKSPACE-40220bba-a57d-4403-a57d-093f32c5685f-o-6.A1d";
				String ChildWindowUrl1 = driver.getCurrentUrl();
				Assert.assertEquals(ExpectedUrl1, ChildWindowUrl1);
				Thread.sleep(2000);
				System.out.println("output:" + ChildWindowUrl1);
				// Assert.assertEquals(ExpectedTitle, ChildWindowTitle);
				driver.close();
				driver.switchTo().window(parentID1);

				ClickElement(LTPTDataReviewStep1Content2Link, "LTPT Employee Data Review Step 1 HyperLink");
				Iterator<String> windows = driver.getWindowHandles().iterator();
				String parentID = windows.next();
				String childId = windows.next();
				driver.switchTo().window(childId);
				String ExpectedUrl = "https://oasf.my.salesforce.com/sfc/p/#50000000bbUu/a/2J000000uYPq/LaVpG1R.K4pP6dvbUM4PHntE25nATv0yCHhOx._khQM";
				String ChildWindowUrl = driver.getCurrentUrl();
				Assert.assertEquals(ExpectedUrl, ChildWindowUrl);
				assertElementDisplayed(LTPTPdfLabel, LTPTPdfLabel.getText());
				driver.close();
				driver.switchTo().window(parentID);

				assertElementDisplayed(LTPTDataReviewStep1DownloadPhButton,
						LTPTDataReviewStep1DownloadPhButton.getAttribute("value"));
				ClickElement(LTPTDataReviewStep1DownloadPhButton, "Download Participant List Button");
				Thread.sleep(2000);
				extentTest.log(Status.INFO, "Participant List is downloaded as expected and working successfully");

			}
		} else {
			System.out.println("Plan Entry option is not displayed");
			boolean value = assertElementfornonDisplayed(submenuPlanEntryoption, "Plan Entry");
			if (value == false) {
				extentTest.log(Status.PASS, "Plan Entry is not displayed");
			}
		}
		Thread.sleep(2000);

	}

	// LTPT Status Report Feature
	public void verifyLTPTStatusReport(String planNumber, String PM702, String PH625) throws InterruptedException {

		List<WebElement> PlanEntryMenu = driver
				.findElements(By.xpath("//ul[@id='sideNavMenu']//li//a[text()='Plan Entry']"));
		int PlanEntryMenuCount = PlanEntryMenu.size();
		if (PlanEntryMenuCount > 0) {
			MoveToElement(submenuPlanEntryoption, "Plan Entry menu");

			if ((PM702.equals("V")) || (PM702.equals("U")) || (PM702.equals("S")) || (PM702.equals("F"))
					|| (PM702.equals("G")) || (PM702.equals("H")) || (PM702.equals("I")) || (PM702.equals("J"))
					|| (PM702.equals("K")) || (PM702.equals("E"))) {

				assertElementDisplayed(submenuPlanEntryoption, submenuPlanEntryoption.getText());
				boolean value = assertElementfornonDisplayed(submenuLTPTEmployeeDataReview,
						"Long-Term Part-Time Employee Data Review");
				if (value == false) {
					extentTest.log(Status.PASS, "Long-Term Part-Time Employee Data Review is not displayed");
				}
				boolean value1 = assertElementfornonDisplayed(submenuLTPTStatusReport,
						"Long-Term Part-Time Status Report");
				if (value1 == false) {
					extentTest.log(Status.PASS, "Long-Term Part-Time Status Report is not displayed");
				}

			} else {

				assertElementDisplayed(submenuLTPTStatusReport, submenuLTPTStatusReport.getText());

				MoveToElement(submenuLTPTStatusReport, "LTPT Status Report menu");
				ClickElement(submenuLTPTStatusReport, "LTPT Status Report menu Link");
				assertElementDisplayed(LTPTStatusReportHeader, LTPTStatusReportHeader.getText());
				Assert.assertEquals("Long-Term Part-Time Status Report", LTPTStatusReportHeader.getText());
				assertElementDisplayed(LTPTStatusReportPlanName, LTPTStatusReportPlanName.getText());
				System.out.println("Plan Name : " + LTPTStatusReportPlanName.getText());
				assertElementDisplayed(LTPTStatusReportPlanNumber, LTPTStatusReportPlanNumber.getText());
				System.out.println("Plan Number : " + LTPTStatusReportPlanNumber.getText());

				assertElementDisplayed(SideMenuLTPTStatusReport, SideMenuLTPTStatusReport.getText());

				assertElementDisplayed(LTPTStatusReportNote, LTPTStatusReportNote.getText());
				Assert.assertEquals("Please Note:", LTPTStatusReportNote.getText());
				assertElementDisplayed(LTPTStatusReportNoteLine1, LTPTStatusReportNoteLine1.getText());
				String NoteContentLine1 = "All participants below are currently indicated as a long-term part-time participant.";
				Assert.assertEquals(NoteContentLine1, LTPTStatusReportNoteLine1.getText());
				assertElementDisplayed(LTPTStatusReportNoteLine2, LTPTStatusReportNoteLine2.getText());
				String NoteContentLine2 = "If you need to edit the status of a particular participant, please click on the participant's name you would like to edit.";
				Assert.assertEquals(NoteContentLine2, LTPTStatusReportNoteLine2.getText());
				assertElementDisplayed(LTPTStatusReportNoteLine3, LTPTStatusReportNoteLine3.getText());
				String NoteContentLine3 = "Any submitted changes will be reflected by the following business day.";
				Assert.assertEquals(NoteContentLine3, LTPTStatusReportNoteLine3.getText());

				if (PH625.equals("Y")) {
					// System.out.println("Table is displayed");
					assertElementDisplayed(LTPTStatusReportPrintIcon, LTPTStatusReportPrintIcon.getAttribute("title"));
					if ((LTPTStatusReportPrintIcon.isEnabled()) == true) {
						System.out.println("Print icon is enabled.Return:" + LTPTStatusReportPrintIcon.isEnabled());
						extentTest.log(Status.PASS, "Print icon is enabled");
					}
					assertElementDisplayed(LTPTStatusReportDownloadIcon,
							LTPTStatusReportDownloadIcon.getAttribute("title"));

					ClickElement(LTPTStatusReportDownloadIcon, "Download Icon");
					// DateTimeFormatter g=DateTimeFormatter.ofPattern("YYYYMMddHHmmss");
					DateTimeFormatter g = DateTimeFormatter.ofPattern("YYYYMMdd");
					LocalDateTime datenew = LocalDateTime.now();
					String date1 = g.format(datenew);
					System.out.println("Date is:" + date1);
					Thread.sleep(2000);
					String downloadPath = System.getProperty("user.dir");
					String FileName = "LTPTStatusReport-" + planNumber + "-" + date1 + ".csv";
					System.out.println("Actual filename: " + FileName);
					File f = new File(downloadPath + "/" + FileName);
					Thread.sleep(5000);
					if (f.exists()) {
						System.out.println("Long-TermPartTimereport Exist in path");
						extentTest.log(Status.PASS, "Long-TermPartTimereport Exist in path");
						Thread.sleep(2000);
						// csv to excel
						boolean converted = true;
						try {
							// CsvToExcel converter=new CSVToExcel();
							final char CSV_FILE_DELIMITER = ',';
							String strSource = downloadPath + "/" + FileName;
							String strdestination = downloadPath;
							String extension = ".xlsx";
							Workbook workBook2 = null;
							FileOutputStream fos = null;
							BufferedReader br = new BufferedReader(new FileReader(f));
							if (extension.equals(".xlsx")) {
								workBook2 = new XSSFWorkbook();
							} else {
								workBook2 = new HSSFWorkbook();
							}
							Sheet sheet = workBook2.createSheet("Sheet");
							String nextLine;
							int rowNum = 0;
							while ((nextLine = br.readLine()) != null) {
								Row currentRow = sheet.createRow(rowNum++);
								String rowData[] = nextLine.split(String.valueOf(CSV_FILE_DELIMITER));
								for (int i = 0; i < rowData.length; i++) {
									currentRow.createCell(i).setCellValue(rowData[i]);
								}
							}
							String FN = f.getName();
							System.out.println("New File Name:" + FN);
							FN = FN.substring(0, FN.lastIndexOf('.'));
							File generatedExcel = new File(strdestination, FN + extension);
							fos = new FileOutputStream(generatedExcel);
							workBook2.write(fos);
							if (generatedExcel.exists()) {
								System.out.println("Newly Generated excel Exist in path");
								Sheet newsh = workBook2.getSheet("Sheet");
								// Sheet sh=workbook.getSheetAt(0);
								Row row = newsh.getRow(0);
								String header1 = row.getCell(0).getStringCellValue();
								System.out.println("header 1 value is" + header1);
								extentTest.log(Status.PASS, "Header 1 : " + header1);
								String header2 = row.getCell(1).getStringCellValue();
								System.out.println("header 2 value is" + header2);
								extentTest.log(Status.PASS, "Header 2 : " + header2);
								String header3 = row.getCell(2).getStringCellValue();
								System.out.println("header 3 value is" + header3);
								extentTest.log(Status.PASS, "Header 3 : " + header3);
								String header4 = row.getCell(3).getStringCellValue();
								System.out.println("header 4 value is" + header4);
								extentTest.log(Status.PASS, "Header 4 : " + header4);
								// String header5=row.getCell(4).getStringCellValue();
								// System.out.println("header 5 value is" +header5);
								// extentTest.log(Status.PASS, "Header 5 : "+header5);

								Thread.sleep(2000);

							}

							try {
								workBook2.close();
								fos.close();
								br.close();
							} catch (IOException e) {
								System.out.println("Exception While Closing I/O Objects");
								e.printStackTrace();
							}
							generatedExcel.delete();

						} catch (Exception e) {
							System.out.println("Unexpected Exception");
							e.printStackTrace();
							converted = false;
						}
						if (converted) {
							System.out.println("Conversion took");
						}
						f.delete();

						/*
						 * FileInputStream fis = null; try { fis = new
						 * FileInputStream(downloadPath+"/"+FileName); } catch (FileNotFoundException e)
						 * { e.printStackTrace(); } //static Workbook book; Workbook workbook=null; try
						 * { workbook = WorkbookFactory.create(fis); } catch (IOException e) {
						 * e.printStackTrace(); } //Sheet
						 * sh=workbook.getSheet("LTPTStatusReport-G35781-2024022"); Sheet
						 * sh=workbook.getSheetAt(0); Row row=sh.getRow(3); String
						 * header1=row.getCell(0).getStringCellValue();
						 * System.out.println("header 1 value is" +header1); extentTest.log(Status.PASS,
						 * "Header 1 : "+header1); String header2=row.getCell(1).getStringCellValue();
						 * System.out.println("header 2 value is" +header2); extentTest.log(Status.PASS,
						 * "Header 2 : "+header2); String header3=row.getCell(2).getStringCellValue();
						 * System.out.println("header 3 value is" +header3); extentTest.log(Status.PASS,
						 * "Header 3 : "+header3); String header4=row.getCell(3).getStringCellValue();
						 * System.out.println("header 4 value is" +header4); extentTest.log(Status.PASS,
						 * "Header 4 : "+header4); String header5=row.getCell(4).getStringCellValue();
						 * System.out.println("header 5 value is" +header5); extentTest.log(Status.PASS,
						 * "Header 5 : "+header5); String header6=row.getCell(5).getStringCellValue();
						 * System.out.println("header 6 value is" +header6); extentTest.log(Status.PASS,
						 * "Header 6 : "+header6); String header7=row.getCell(6).getStringCellValue();
						 * System.out.println("header 7 value is" +header7); extentTest.log(Status.PASS,
						 * "Header 7 : "+header7); String header8=row.getCell(7).getStringCellValue();
						 * System.out.println("header 8 value is" +header8); extentTest.log(Status.PASS,
						 * "Header 8 : "+header8); String header9=row.getCell(8).getStringCellValue();
						 * System.out.println("header 9 value is" +header9); extentTest.log(Status.PASS,
						 * "Header 9 : "+header9); String header10=row.getCell(9).getStringCellValue();
						 * System.out.println("header 10 value is" +header10);
						 * extentTest.log(Status.PASS, "Header 10 : "+header10); Thread.sleep(2000);
						 */
						// f.delete();
					} else {
						System.out.println("Long-TermPartTimereport not Exist in path");
						extentTest.log(Status.PASS, "Long-TermPartTimereport not Exist in path");
					}

					assertElementDisplayed(CurrentLTPTStatus, CurrentLTPTStatus.getText());
					Assert.assertEquals("Current Long-Term Part-Time Status", CurrentLTPTStatus.getText());
					List<WebElement> allHeadersofTable = driver
							.findElements(By.xpath("//table[contains(@id,'formLTPTParticipants')]//th//a"));
					System.out.println("Total Headers found:" + allHeadersofTable.size());
					for (WebElement header : allHeadersofTable) {
						extentTest.log(Status.PASS, "Table Header Name is : " + header.getText());
					}
					List<WebElement> currentLTPTStatusValue = driver
							.findElements(By.xpath("//table[contains(@id,'formLTPTParticipants')]//tr//td[4]"));
					System.out.println("Total current LTPT Status Value row count:" + currentLTPTStatusValue.size());
					for (WebElement CurrentLTPTValue : currentLTPTStatusValue) {
						extentTest.log(Status.PASS,
								"Current LTPT Status Value in table : " + CurrentLTPTValue.getText());
					}
					assertElementDisplayed(CurrentLTPTStatusParticipantName1,
							CurrentLTPTStatusParticipantName1.getText());
					ClickElement(CurrentLTPTStatusParticipantName1, "Current LTPT Status Participant Name Link");
					changeParticipantLTPTStatusreportpage();
					ClickElement(ChangeLTPTStatusCancel, "Cancel Button Link");
					assertElementDisplayed(CurrentLTPTStatus, CurrentLTPTStatus.getText());
				} else {
					System.out.println("Table is not displayed");
					boolean value = assertElementfornonDisplayed(LTPTStatusReportDownloadIcon,
							"LTPT Status Report Download Icon");
					if (value == false) {
						extentTest.log(Status.PASS, "LTPT Status Report Download Icon is not displayed");
					}
					boolean value1 = assertElementfornonDisplayed(LTPTStatusReportPrintIcon,
							"LTPT Status Report Print Icon");
					if (value1 == false) {
						extentTest.log(Status.PASS, "LTPT Status Report Print Icon is not displayed");
					}
					assertElementDisplayed(LTPTStatusReportNoParticipantMsg,
							LTPTStatusReportNoParticipantMsg.getText());
					Assert.assertEquals("No participants at this time to report.",
							LTPTStatusReportNoParticipantMsg.getText());
					// assertElementSelected(LTPTStatusReportLeftNavMenu, "LTPT Satus Report Left
					// Navigation Menu");
					// assertElementDisplayed(LTPTStatusReportLeftNavMenu,
					// LTPTStatusReportLeftNavMenu.getText());
				}

				Thread.sleep(2000);
				extentTest.log(Status.INFO, "Participant List is downloaded as expected and working successfully");

			}
		} else {
			System.out.println("Plan Entry option is not displayed");
			boolean value = assertElementfornonDisplayed(submenuPlanEntryoption, "Plan Entry");
			if (value == false) {
				extentTest.log(Status.PASS, "Plan Entry is not displayed");
			}
		}
		Thread.sleep(2000);

	}

	// Change LTPT Participant Status page test case actions
	public void changeParticipantLTPTStatusreportpage() throws InterruptedException {

		assertElementDisplayed(LTPTStatusReportHeader, LTPTStatusReportHeader.getText());
		Assert.assertEquals("Long-Term Part-Time Status Report", LTPTStatusReportHeader.getText());

		assertElementDisplayed(changePHLTPTtext, changePHLTPTtext.getText());
		Assert.assertEquals("Change Participant LTPT Status", changePHLTPTtext.getText());
		assertElementDisplayed(newLTPTStatustext, newLTPTStatustext.getText());
		String DefaultnewLTPTStatusvalue = newLTPTStatusvalue.getText();
		if (DefaultnewLTPTStatusvalue.equals("- Please Select -")) {
			extentTest.log(Status.PASS, "Default New LTPT Status Value : " + DefaultnewLTPTStatusvalue);
		} else {
			extentTest.log(Status.FAIL, "Default Current LTPT Status Value is not Please Select option");
		}
		Select s = new Select(driver.findElement(
				By.xpath("//form[@id='formStatusUpdate']//table//select[contains(@name,'newLTPTStatus')]")));
		List<WebElement> newLTPTStatusoptions = s.getOptions();
		int size = newLTPTStatusoptions.size();
		System.out.println("Total New LTPT Status Options:" + newLTPTStatusoptions.size());
		for (WebElement NewLTPTStatusoptionsValue : newLTPTStatusoptions) {
			extentTest.log(Status.PASS,
					"New LTPT Status Options available are : " + NewLTPTStatusoptionsValue.getText());
		}
		assertElementDisplayed(ChangeLTPTStatusSubmit, ChangeLTPTStatusSubmit.getAttribute("value"));
		assertElementDisplayed(ChangeLTPTStatusCancel, ChangeLTPTStatusCancel.getAttribute("value"));
		if ((ChangeLTPTStatusSubmit.isEnabled()) == false) {
			System.out.println("Submit Button is disabled.Return:" + ChangeLTPTStatusSubmit.isEnabled());
			extentTest.log(Status.PASS, "Submit Button is disabled");
		}
		// }

	}

	public void searchPlans(String prodID, String planNumber) throws InterruptedException {
		String xpath = "//td/a[contains(text(),'" + prodID + "')]";
		List<WebElement> producerID = driver.findElements(By.xpath(xpath));
		int prodIDsize = producerID.size();
		if (prodIDsize > 0) {
			String xpath1 = "//td/a[contains(text(),'" + prodID + "')]";
			WebElement producerID1 = driver.findElement(By.xpath(xpath1));
			ClickElement(producerID1, "Producer ID");
			MoveToElement(PlanParticipantMenu, "Plan/Participant Menu");
			ClickElement(PlanParticipantDataSubmenu, "Plan/Participant Data Sub-menu");
			Thread.sleep(3000);
			EnterText(Plansearchfield, planNumber, "PlanSearch");
			ClickElementJS(Searchbuttonfield, "Search Button");
			
			selectPlan(planNumber);
		} else {
			MoveToElement(PlanParticipantMenu, "Plan/Participant Menu");
			ClickElement(PlanParticipantDataSubmenu, "Plan/Participant Data Sub-menu");
			try {
				if (SearchHeader.isDisplayed()) {
					assertElementDisplayed(SearchHeader, "Search Header");
					assertElementDisplayed(PlanInfoSearchHeader, "Plan/Participant Information Search Header");
					EnterText(CriteriaTxtFld, planNumber, "Criteria");
					ClickElementJS(PlanSearchBtn, "Search Button");
					selectPlan(planNumber);
				}
			} catch (Exception e) {
				selectPlan(planNumber);
			}
		}
	}

	// LTPT Access Control Feature
	public void verifyLTPTAccessControl(String planNumber, String PM702, String PH625) throws InterruptedException {

		List<WebElement> PlanEntryMenu = driver
				.findElements(By.xpath("//ul[@id='sideNavMenu']//li//a[text()='Plan Entry']"));
		int PlanEntryMenuCount = PlanEntryMenu.size();
		if (PlanEntryMenuCount > 0) {
			MoveToElement(submenuPlanEntryoption, "Plan Entry menu");

			if ((PM702.equals("V")) || (PM702.equals("U")) || (PM702.equals("S")) || (PM702.equals("F"))
					|| (PM702.equals("G")) || (PM702.equals("H")) || (PM702.equals("I")) || (PM702.equals("J"))
					|| (PM702.equals("K")) || (PM702.equals("E"))) {

				assertElementDisplayed(submenuPlanEntryoption, submenuPlanEntryoption.getText());
				boolean value = assertElementfornonDisplayed(submenuLTPTEmployeeDataReview,
						"Long-Term Part-Time Employee Data Review");
				if (value == false) {
					extentTest.log(Status.PASS, "Long-Term Part-Time Employee Data Review is not displayed");
				}
				boolean value1 = assertElementfornonDisplayed(submenuLTPTStatusReport,
						"Long-Term Part-Time Status Report");
				if (value1 == false) {
					extentTest.log(Status.PASS, "Long-Term Part-Time Status Report is not displayed");
				}

			} else {

				assertElementDisplayed(submenuLTPTEmployeeDataReview, submenuLTPTEmployeeDataReview.getText());
				assertElementDisplayed(submenuLTPTStatusReport, submenuLTPTStatusReport.getText());
				MoveToElement(submenuLTPTEmployeeDataReview, "LTPT Employee Data Review menu");
				ClickElement(submenuLTPTEmployeeDataReview, "LTPT Employee Data Review menu Link");
				assertElementDisplayed(LTPTEmployeeDataReviewHeader, LTPTEmployeeDataReviewHeader.getText());
				Assert.assertEquals("Long-Term Part-Time Employee Data Review", LTPTEmployeeDataReviewHeader.getText());
				assertElementDisplayed(LTPTDataReviewStep1DownloadPhButton,
						LTPTDataReviewStep1DownloadPhButton.getAttribute("value"));
				ClickElement(LTPTDataReviewStep1DownloadPhButton, "Download Participant List Button");
				DateTimeFormatter g = DateTimeFormatter.ofPattern("YYYYMMddHHmmss");
				// DateTimeFormatter g=DateTimeFormatter.ofPattern("YYYYMMdd");
				LocalDateTime datenew = LocalDateTime.now();
				String date1 = g.format(datenew);
				System.out.println("Date is:" + date1);
				Thread.sleep(3000);
				String downloadPath = System.getProperty("user.dir");
				String FileName = "Long-TermPartTimereport-" + planNumber + "-" + date1 + ".csv";
				System.out.println("Actual filename: " + FileName);
				File f = new File(downloadPath + "/" + FileName);
				Thread.sleep(6000);
				if (f.exists()) {
					System.out.println("Long-TermPartTimereport Exist in path");
					extentTest.log(Status.PASS, "Long-TermPartTimereport Exist in path");
					f.delete();
				} else {
					System.out.println("Long-TermPartTimereport not Exist in path");
					extentTest.log(Status.PASS, "Long-TermPartTimereport not Exist in path");
				}

				assertElementDisplayed(ChooseFile, ChooseFile.getAttribute("title"));
				if ((ChooseFile.isEnabled()) == false) {
					System.out.println("Choose File is disabled.Return:" + ChooseFile.isEnabled());
					extentTest.log(Status.PASS, "Choose File is disabled");
				}

				assertElementDisplayed(LTPTSubmitButton, LTPTSubmitButton.getAttribute("value"));
				if ((LTPTSubmitButton.isEnabled()) == false) {
					System.out.println("Submit Button is disabled.Return:" + LTPTSubmitButton.isEnabled());
					extentTest.log(Status.PASS, "Submit Button is disabled");
				}
				MoveToElement(submenuLTPTStatusReport, "LTPT Status Report menu");
				ClickElement(submenuLTPTStatusReport, "LTPT Status Report menu Link");
				if (PH625.equals("Y")) {
					assertElementDisplayed(CurrentLTPTStatusParticipantName1,
							CurrentLTPTStatusParticipantName1.getText());
					ClickElement(CurrentLTPTStatusParticipantName1, "Current LTPT Status Participant Name Link");
					assertElementDisplayed(ChangeLTPTStatusSubmit, ChangeLTPTStatusSubmit.getAttribute("value"));
					if ((ChangeLTPTStatusSubmit.isEnabled()) == false) {
						System.out.println("Submit Button is disabled.Return:" + ChangeLTPTStatusSubmit.isEnabled());
						extentTest.log(Status.PASS, "Submit Button is disabled");
					}
				} else {
					System.out.println("Table is not displayed");
					assertElementDisplayed(LTPTStatusReportNoParticipantMsg,
							LTPTStatusReportNoParticipantMsg.getText());
					Assert.assertEquals("No participants at this time to report.",
							LTPTStatusReportNoParticipantMsg.getText());

				}

			}
		} else {
			System.out.println("Plan Entry option is not displayed");
			boolean value = assertElementfornonDisplayed(submenuPlanEntryoption, "Plan Entry");
			if (value == false) {
				extentTest.log(Status.PASS, "Plan Entry is not displayed");
			}
		}
		Thread.sleep(2000);

	}

	// Plan Summary Screen Update test case actions
	public void verifyPlanSummaryUpdate(String PM696) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(sideMenuSummary));
		ClickElement(sideMenuSummary, "Summary Side menu");
		Thread.sleep(5000);
		assertElementDisplayed(headerPlanSummary, headerPlanSummary.getText() + " Header");
		assertElementDisplayed(managedAccountProviderlabel, managedAccountProviderlabel.getText());
		if (PM696.equals("M")) {
			assertElementDisplayed(managedAccountvalue, managedAccountvalue.getText());
			takeScreenshotForPassedcase("Managed Account Provider is displayed as expected");
			Assert.assertEquals("Advisor Managed", managedAccountvalue.getText());
			extentTest.log(Status.PASS, "Managed Account Provider is displayed as expected");

		} else if (PM696.equals("R")) {
			assertElementDisplayed(managedAccountvalue, managedAccountvalue.getText());
			takeScreenshotForPassedcase("Managed Account Provider is displayed as expected");
			Assert.assertEquals("MS Retirement Manager", managedAccountvalue.getText());
			extentTest.log(Status.PASS, "Managed Account Provider is displayed as expected");
		} else if (PM696.equals("P")) {
			assertElementDisplayed(managedAccountvalue, managedAccountvalue.getText());
			takeScreenshotForPassedcase("Managed Account Provider is displayed as expected");
			Assert.assertEquals("Future Capital", managedAccountvalue.getText());
			extentTest.log(Status.PASS, "Managed Account Provider is displayed as expected");
		} else if (PM696.equals("A")) {
			assertElementDisplayed(managedAccountvalue, managedAccountvalue.getText());
			takeScreenshotForPassedcase("Managed Account Provider is displayed as expected");
			Assert.assertEquals("Advisor", managedAccountvalue.getText());
			extentTest.log(Status.PASS, "Managed Account Provider is displayed as expected");

		}
	}

	// Advisor Plan Fee Report Feature
	public void verifyAdvisorPlanFee(String planNumber, String PM696) throws InterruptedException {

		if ((PM696.equals("M")) || (PM696.equals("R")) || (PM696.equals("A")) || (PM696.equals("P"))) {

			assertElementDisplayed(AdvisorFeeReportLink, AdvisorFeeReportLink.getText());
			ClickElement(AdvisorFeeReportLink, "Advisor Fee Report Link");
			assertElementDisplayed(AdvsrFeeRprtHeader, AdvsrFeeRprtHeader.getText() + " Header");
			assertElementDisplayed(AdvisorFeeReportLink, AdvisorFeeReportLink.getText() + " Side Menu");
			assertElementDisplayed(advisorPlanName, advisorPlanName.getText());
			assertElementDisplayed(advisorPlanNum, advisorPlanNum.getText());
			assertElementDisplayed(advisorPrint, advisorPrint.getAttribute("title"));
			if ((advisorPrint.isEnabled()) == true) {
				System.out.println("Print icon is enabled.Return:" + advisorPrint.isEnabled());
				extentTest.log(Status.PASS, "Print icon is enabled");
			}
			assertElementDisplayed(yearHeading, yearHeading.getText());
			List<WebElement> feeRptYearList = driver
					.findElements(By.xpath("//tbody[contains(@id,'advisorPlanFeeRpt:yearList')]//td//a"));
			int feeRptYearListCount = feeRptYearList.size();
			System.out.println("Total Quarters list found:" + feeRptYearListCount);
			for (int i = 0; i < feeRptYearListCount; i++) {

				extentTest.log(Status.PASS,
						"Advisor Plan Fee Report Document Name is : " + feeRptYearList.get(i).getText());
			}
			assertElementDisplayed(advisordoc1, advisordoc1.getText());
			String DocumentName = planNumber + " RIA Summary " + planNumber + " 1st Qtr";
			Assert.assertEquals(DocumentName, advisordoc1.getText());
			ClickElement(advisordoc1, "Download Document");
			String downloadPath = System.getProperty("user.dir");
			String Doc1 = planNumber + "_RIA_FEES.csv";
			System.out.println("Actual filename: " + Doc1);
			File f = new File(downloadPath + "/" + Doc1);
			Thread.sleep(5000);
			if (f.exists()) {
				System.out.println("Advisor Fee Report Exist in path");
				extentTest.log(Status.PASS, "Advisor Fee Report Exist in path");
				// f.delete();

				// csv to excel
				boolean converted = true;
				try {
					// CsvToExcel converter=new CSVToExcel();
					final char CSV_FILE_DELIMITER = ',';
					String strSource = downloadPath + "/" + Doc1;
					String strdestination = downloadPath;
					String extension = ".xlsx";
					Workbook workBook2 = null;
					FileOutputStream fos = null;
					BufferedReader br = new BufferedReader(new FileReader(f));
					if (extension.equals(".xlsx")) {
						workBook2 = new XSSFWorkbook();
					} else {
						workBook2 = new HSSFWorkbook();
					}
					Sheet sheet = workBook2.createSheet("Sheet");
					String nextLine;
					int rowNum = 0;
					while ((nextLine = br.readLine()) != null) {
						Row currentRow = sheet.createRow(rowNum++);
						String rowData[] = nextLine.split(String.valueOf(CSV_FILE_DELIMITER));
						for (int i = 0; i < rowData.length; i++) {
							currentRow.createCell(i).setCellValue(rowData[i]);
						}
					}
					String FN = f.getName();
					System.out.println("New File Name:" + FN);
					FN = FN.substring(0, FN.lastIndexOf('.'));
					File generatedExcel = new File(strdestination, FN + extension);
					fos = new FileOutputStream(generatedExcel);
					workBook2.write(fos);
					if (generatedExcel.exists()) {
						System.out.println("Newly Generated excel Exist in path");
						Sheet newsh = workBook2.getSheet("Sheet");
						int rowCounts1 = newsh.getPhysicalNumberOfRows();
						int rowCounts = rowCounts1;
						System.out.println("rowCounts:" + rowCounts);
						for (int a = 0; a < 6; a++) {
							Cell c1 = newsh.getRow(a).getCell(0);
							String value1 = c1.getStringCellValue();
							extentTest.log(Status.PASS, value1 + " is displayed in excel");
						}
						for (int b = 0; b < 7; b++) {
							Cell c1 = newsh.getRow(7).getCell(b);
							String value2 = c1.getStringCellValue();
							extentTest.log(Status.PASS, "Header: " + value2 + " is displayed in excel");
						}
						int last = newsh.getLastRowNum();
						Cell lv1 = newsh.getRow(last).getCell(5);
						String lastvalue = lv1.getStringCellValue();
						extentTest.log(Status.PASS, lastvalue + " is displayed in excel");
						int lastPrevious = newsh.getLastRowNum() - 2;
						Cell lv2 = newsh.getRow(lastPrevious).getCell(5);
						String lastpreviousvalue = lv2.getStringCellValue();
						extentTest.log(Status.PASS, lastpreviousvalue + " is displayed in excel");
						Thread.sleep(2000);
					}

					try {
						workBook2.close();
						fos.close();
						br.close();
					} catch (IOException e) {
						System.out.println("Exception While Closing I/O Objects");
						e.printStackTrace();
					}
					generatedExcel.delete();
				} catch (Exception e) {
					System.out.println("Unexpected Exception");
					e.printStackTrace();
					converted = false;
				}
				if (converted) {
					System.out.println("Conversion took");
				}
				f.delete();

			}

		} else {
			boolean value = assertElementfornonDisplayed(AdvisorFeeReportLink, "Advisor Fee Report");
			if (value == false) {
				extentTest.log(Status.PASS, "Advisor Fee Report is not displayed");
			}
		}
		Thread.sleep(2000);

	}
//>>>>>>> f1d430a2753dd04d27892e19cf6a9370bd072f96

	// Search a plan for new additional column in participant list actions
	public void searchPlanFunctionalityforAddNewColumn(String planNumber) throws InterruptedException {
		MoveToElement(PlanParticipantMenu, "Plan/Participant Menu");
		ClickElement(PlanParticipantDataSubmenu, "Plan/Participant Data Sub-menu");
		try {
			if (SearchHeader.isDisplayed()) {
				assertElementDisplayed(SearchHeader, "Search Header");
				assertElementDisplayed(PlanInfoSearchHeader, "Plan/Participant Information Search Header");
				EnterText(CriteriaTxtFld, planNumber, "Criteria");
				ClickElementJS(PlanSearchBtn, "Search Button");
				// selectPlan(planNumber);
				// ClickElementJS(participantlist, "Participant List Link");
			}
		} catch (Exception e) {
			selectPlan(planNumber);
		}
	}

	// Participant List New Columns test case actions
	public void verifyParticipantListCol(String planNumber) throws InterruptedException {
		assertElementDisplayed(Participantlistlink, Participantlistlink.getText());
		ClickElement(Participantlistlink, "Participant List Link");
		// assertElementDisplayed(TableheaderinUI, TableheaderinUI.getText()+" Header");
		takeScreenshot("View Participant Data List page");
		assertElementDisplayed(DisplayedplanNumber, DisplayedplanNumber.getText());
		extentTest.log(Status.PASS, "planNumber is displayed as expected");

		Thread.sleep(2000);
		assertElementDisplayed(Printicon, Printicon.getText());
		ClickElement(IconDownloadPhList, "Download Icon");
		String downloadPath = System.getProperty("user.dir");
		// String downloadPath="C:\\Users\\T007786\\Downloads";
		String FileName = "PartList-" + planNumber + ".csv";
		System.out.println("Actual filename: " + FileName);
		File f = new File(downloadPath + "/" + FileName);
		Thread.sleep(5000);

		if (f.exists()) {
			System.out.println("Participant List Exist in path");
			extentTest.log(Status.PASS, "Participant List Exist in path");
			Thread.sleep(2000);

			// csv to excel
			boolean converted = true;
			try {
				// CsvToExcel converter=new CSVToExcel();
				final char CSV_FILE_DELIMITER = ',';
				String strSource = downloadPath + "/" + FileName;
				String strdestination = downloadPath;
				String extension = ".xlsx";
				Workbook workBook2 = null;
				FileOutputStream fos = null;
				BufferedReader br = new BufferedReader(new FileReader(f));
				if (extension.equals(".xlsx")) {
					workBook2 = new XSSFWorkbook();
				} else {
					workBook2 = new HSSFWorkbook();
				}
				Sheet sheet = workBook2.createSheet("Sheet");
				String nextLine;

				int rowNum = 0;
				while ((nextLine = br.readLine()) != null) {
					Row currentRow = sheet.createRow(rowNum++);
					String rowData[] = nextLine.split(String.valueOf(CSV_FILE_DELIMITER));
					for (int i = 0; i < rowData.length; i++) {
						currentRow.createCell(i).setCellValue(rowData[i]);
					}
				}
				String FN = f.getName();
				System.out.println("New File Name:" + FN);
				FN = FN.substring(0, FN.lastIndexOf('.'));
				File generatedExcel = new File(strdestination, FN + extension);
				fos = new FileOutputStream(generatedExcel);
				workBook2.write(fos);
				if (generatedExcel.exists()) {
					System.out.println("Newly Generated excel Exist in path");
					Sheet newsh = workBook2.getSheet("Sheet");

					for (int b = 4; b < 8; b++) {
						Row row = newsh.getRow(0);
						Cell lv1 = newsh.getRow(0).getCell(b);
						String header = lv1.getStringCellValue();
						System.out.println("header value is" + header);
						extentTest.log(Status.PASS, "New Header in excel: " + header + " is displayed");
						extentTest.log(Status.PASS,
								"Header Col present in between the Status column and AddressLine 1 column: " + header
										+ " is displayed as Expected");
					}
					Thread.sleep(2000);

					// find the index of each requried column
					for (int i = 3; i <= 8; i++) {
						Row row1 = sheet.getRow(0);
						Cell lv2 = newsh.getRow(0).getCell(i);
						String headerName = lv2.getStringCellValue();
						// if(headerName.equals(status && "AddressLine1"))
						System.out.println("headerName value is" + headerName);
						// extentTest.log(Status.PASS, "Header Col present in between the Status column
						// and AddressLine 1 column: "+headerName+" is displayed as Expected");
					}
				}

				try {
					workBook2.close();
					fos.close();
					br.close();
				} catch (IOException e) {
					System.out.println("Exception While Closing I/O Objects");
					e.printStackTrace();
				}
				generatedExcel.delete();

			} catch (Exception e) {
				System.out.println("Unexpected Exception");
				e.printStackTrace();
				converted = false;
			}
			if (converted) {
				System.out.println("Conversion took");
			}
			f.delete();
		} else {
			System.out.println("Participant List not Exist in path");
			extentTest.log(Status.FAIL, "Participant List not Exist in path");
		}
		extentTest.log(Status.PASS,
				"View Participant Data added columns are displaying as expected and working successfully in while downloaded");
		List<WebElement> participantlistheadervisible = driver
				.findElements(By.xpath("//form[@id='dataTableForm']//table//thead//th"));
		int participantlistheadervisiblecount = participantlistheadervisible.size();
		System.out.println("Header " + participantlistheadervisiblecount + " displayed");
		for (int i = 0; i < participantlistheadervisiblecount; i++) {
			assertElementDisplayed(participantlistheadervisible.get(i), participantlistheadervisible.get(i).getText());
		}

		extentTest.log(Status.PASS,
				"View participant data list newly add column is not visible in UI as excepted and working Successfully");
//					extentTest.log(Status.PASS,
//							"View participant data list newly add column is not visible as excepted and working Successfully");
	}

	// ViewParticipantListDisplayUpdate_TestCase

	public void verifyViewParticipantDisplay(String planNumber, String PM696, String PH619, String searchBy, String ssn)
			throws InterruptedException {
		ClickElement(Participantlistlink, "Participant List Link");
		takeScreenshot("View Participant Data List page");
		// Thread.sleep(2000);

		if (PM696.equals("P")) {
			ComboSelectVisibleText(selectDPSearchBy, searchBy, "Search By");
			EnterText(txtFldPrtcpntSSN, ssn, "Participant SSN");
			// EnterText(txtFldSearchCriteria, criteria, "Criteria");
			ClickElement(btnDPSearch, "Search Button");
			Thread.sleep(2000);
			assertElementDisplayed(managedaccountservice, managedaccountservice.getText() + " Header");
			Assert.assertEquals("Managed Account Service", managedaccountservice.getText());
			extentTest.log(Status.PASS, "Managed Account Service column is displayed as expected");
			assertElementDisplayed(DisplayedplanNumber, DisplayedplanNumber.getText());
			extentTest.log(Status.PASS, "planNumber is displayed as expected");
			assertElementDisplayed(SSNDisplayed, SSNDisplayed.getText());
			Assert.assertEquals("Enrolled", managedaccountservicenameEnrolled.getText());
			extentTest.log(Status.PASS,
					"In Managed Account Service column for given SSN along with plan -Enrolled- is displayed as expected");

		} else if (PM696.equals("R")) {
			ComboSelectVisibleText(selectDPSearchBy, searchBy, "Search By");
			// EnterText(txtFldSearchCriteria, ssn, "Criteria");
			EnterText(txtFldPrtcpntSSN, ssn, "Participant SSN");
			ClickElement(btnDPSearch, "Search Button");
			Thread.sleep(2000);
			assertElementDisplayed(managedaccountservice, managedaccountservice.getText());
			Assert.assertEquals("Managed Account Service", managedaccountservice.getText());
			extentTest.log(Status.PASS, "Managed Account Service column is displayed as expected");
			if (PH619.equals("Q")) {
				assertElementDisplayed(DisplayedplanNumber, DisplayedplanNumber.getText());
				extentTest.log(Status.PASS, "planNumber is displayed as expected");
				assertElementDisplayed(SSNDisplayedforplan2, SSNDisplayedforplan2.getText());
				Assert.assertEquals("Defaulted", managedaccountservicenameDefaulted.getText());
				assertElementDisplayed(managedaccountservicenameDefaultedwithdate,
						managedaccountservicenameDefaultedwithdate.getText());
				extentTest.log(Status.PASS,
						"In Managed Account Service column for given SSN along with plan -Defaulted- is displayed as expected");

			} else {
				System.out.println("Defaulted is not displayed");

			}
		} else if (PM696.equals("R1")) {
			ComboSelectVisibleText(selectDPSearchBy, searchBy, "Search By");
			// EnterText(txtFldSearchCriteria, criteria, "Criteria");
			EnterText(txtFldPrtcpntSSN, ssn, "Participant SSN");
			ClickElement(btnDPSearch, "Search Button");
			Thread.sleep(2000);
			assertElementDisplayed(managedaccountservice, managedaccountservice.getText());
			Assert.assertEquals("Managed Account Service", managedaccountservice.getText());
			extentTest.log(Status.PASS, "Managed Account Service column is displayed as expected");
			if (PH619.equals("Y")) {
				assertElementDisplayed(DisplayedplanNumber, DisplayedplanNumber.getText());
				extentTest.log(Status.PASS, "planNumber is displayed as expected");
				assertElementDisplayed(SSNDisplayedforplan1, SSNDisplayedforplan1.getText());
				Assert.assertEquals("Yes", managedaccountservicenameyes.getText());
				assertElementDisplayed(managedaccountservicenameYeswithdate,
						managedaccountservicenameYeswithdate.getText());
				extentTest.log(Status.PASS,
						"In Managed Account Service column for given SSN along with plan -Yes- is displayed as expected");

			} else {
				System.out.println("yes is not displayed");

			}
		}

		else if (PM696.equals("M")) {
			ComboSelectVisibleText(selectDPSearchBy, searchBy, "Search By");
			// EnterText(txtFldSearchCriteria, criteria, "Criteria");
			EnterText(txtFldPrtcpntSSN, ssn, "Participant SSN");
			ClickElement(btnDPSearch, "Search Button");
			Thread.sleep(2000);
			assertElementDisplayed(managedaccountservice, managedaccountservice.getText());
			Assert.assertEquals("Managed Account Service", managedaccountservice.getText());
			extentTest.log(Status.PASS, "Managed Account Service column is displayed as expected");
			assertElementDisplayed(SSNDisplayedforplan3, SSNDisplayedforplan3.getText());
			Assert.assertEquals("No", managedaccountservicename.getText());
			assertElementDisplayed(managedaccountservicenameNameEvenwithdate,
					managedaccountservicenameNameEvenwithdate.getText());
			extentTest.log(Status.PASS,
					"In Managed Account Service column for given SSN along with plan No is displayed as expected");
			Thread.sleep(2000);
			ClickElement(IconDownloadPhList, "Download Icon");
			String downloadPath = System.getProperty("user.dir");
			String FileName = "PartList-" + planNumber + ".csv";
			System.out.println("Actual filename: " + FileName);
			File f = new File(downloadPath + "/" + FileName);
			System.out.println(f);
			Thread.sleep(5000);
			if (f.exists()) {
				System.out.println("Participant List Exist in path");
				extentTest.log(Status.PASS, "Participant List Exist in path");
				Thread.sleep(2000);

				// csv to excel
				boolean converted = true;
				try {
					// CsvToExcel converter=new CSVToExcel();
					final char CSV_FILE_DELIMITER = ',';
					String strSource = downloadPath + "/" + FileName;
					String strdestination = downloadPath;
					String extension = ".xlsx";
					Workbook workBook2 = null;
					FileOutputStream fos = null;
					BufferedReader br = new BufferedReader(new FileReader(f));
					if (extension.equals(".xlsx")) {
						workBook2 = new XSSFWorkbook();
					} else {
						workBook2 = new HSSFWorkbook();
					}
					Sheet sheet = workBook2.createSheet("Sheet");
					String nextLine;

					int rowNum = 0;
					while ((nextLine = br.readLine()) != null) {
						Row currentRow = sheet.createRow(rowNum++);
						String rowData[] = nextLine.split(String.valueOf(CSV_FILE_DELIMITER));
						for (int i = 0; i < rowData.length; i++) {
							currentRow.createCell(i).setCellValue(rowData[i]);
						}
					}
					String FN = f.getName();
					System.out.println("New File Name:" + FN);
					FN = FN.substring(0, FN.lastIndexOf('.'));
					File generatedExcel = new File(strdestination, FN + extension);
					fos = new FileOutputStream(generatedExcel);
					workBook2.write(fos);
					if (generatedExcel.exists()) {
						System.out.println("Newly Generated excel Exist in path");
						Sheet newsh = workBook2.getSheet("Sheet");
						// Sheet sh=workbook.getSheetAt(0);
						// int cellcount=newsh.getRow(0).getLastCellNum();
						// System.out.println("cellcount"+cellcount);

						for (int b = 0; b < 8; b++) {
							Row row = newsh.getRow(0);
							Cell lv1 = newsh.getRow(0).getCell(b);
							String header = lv1.getStringCellValue();
							System.out.println("header value is" + header);
							extentTest.log(Status.PASS, "New Header in excel: " + header + " is displayed");
							extentTest.log(Status.PASS,
									"Header Columns are present " + header + " is displayed as Expected");
						}
						Thread.sleep(2000);
					}

					try {
						workBook2.close();
						fos.close();
						br.close();
					} catch (IOException e) {
						System.out.println("Exception While Closing I/O Objects");
						e.printStackTrace();
					}
					generatedExcel.delete();

				} catch (Exception e) {
					System.out.println("Unexpected Exception");
					e.printStackTrace();
					converted = false;
				}
				if (converted) {
					System.out.println("Conversion took");
				}
				f.delete();
			} else {
				System.out.println("Participant List not Exist in path");
				extentTest.log(Status.FAIL, "Participant List not Exist in path");
			}
			extentTest.log(Status.PASS,
					"View Participant Data Feature elements and sections are displaying as expected and working successfully");

		} else if (PM696.equals("A")) {
			assertElementDisplayed(managedaccountservice, managedaccountservice.getText());
			Assert.assertEquals("Investment Model Status", managedaccountservice.getText());
			extentTest.log(Status.PASS, "Investment Model Status column is displayed as expected");
			assertElementDisplayed(DisplayedplanNumber, DisplayedplanNumber.getText());
			extentTest.log(Status.PASS, "planNumber is displayed as expected");
			assertElementDisplayed(Printicon, Printicon.getText());
			if ((Printicon.isEnabled()) == true) {
				System.out.println("Print icon is enabled.Return:" + Printicon.isEnabled());
				extentTest.log(Status.PASS, "Print icon is enabled");
			}

		}
	}

//LTPTEmployeeDataReviewUploadFeature
	public void verifyLTPTEmployeeDataReviewUploadFeature(String planNumber)
			throws InterruptedException, AWTException, IOException {
		MoveToElement(submenuPlanEntryoption, "Plan Entry menu");
		assertElementDisplayed(submenuPlanEntryoption, submenuPlanEntryoption.getText());
		assertElementDisplayed(submenuLTPTEmployeeDataReview, submenuLTPTEmployeeDataReview.getText());
		assertElementDisplayed(submenuLTPTStatusReport, submenuLTPTStatusReport.getText());

		MoveToElement(submenuLTPTEmployeeDataReview, "LTPT Employee Data Review menu");
		ClickElement(submenuLTPTEmployeeDataReview, "LTPT Employee Data Review menu Link");
		assertElementDisplayed(LTPTEmployeeDataReviewHeader, LTPTEmployeeDataReviewHeader.getText());
		Assert.assertEquals("Long-Term Part-Time Employee Data Review", LTPTEmployeeDataReviewHeader.getText());

		assertElementDisplayed(SideMenuLTPTEmployeeData, SideMenuLTPTEmployeeData.getText());
		assertElementDisplayed(SideMenuLTPTStatusReport, SideMenuLTPTStatusReport.getText());

		assertElementDisplayed(LTPTDataReviewStep1LTPTLink, LTPTDataReviewStep1LTPTLink.getText());
		assertElementDisplayed(LTPTDataReviewStep1DownloadPhButton,
				LTPTDataReviewStep1DownloadPhButton.getAttribute("value"));
		ClickElement(LTPTDataReviewStep1DownloadPhButton, "Download Participant List Button");
		DateTimeFormatter g = DateTimeFormatter.ofPattern("YYYYMMddHHmmss");
		LocalDateTime datenew = LocalDateTime.now();
		LocalDateTime later = datenew.plusSeconds(00);
		String date1 = g.format(later);
		System.out.println("Date is:" + date1);
		Thread.sleep(5000);
		String downloadPath = System.getProperty("user.dir");
		// Long-TermPartTimereport-B01230-20240802055206
		String FileName = "Long-TermPartTimereport-" + planNumber + "-" + date1 + ".csv";
		System.out.println("Actual filename: " + FileName);
		File f = new File(downloadPath + "/" + FileName);
		Thread.sleep(5000);
		if (f.exists()) {
			System.out.println("File Exist in path");
			extentTest.log(Status.PASS, "Long-TermPart Timereport report Exist in path");
			Thread.sleep(2000);
			boolean converted = true;
			try {
				// CsvToExcel converter=new CSVToExcel();
				final char CSV_FILE_DELIMITER = ',';
				String strSource = downloadPath + "/" + FileName;
				String strdestination = downloadPath;
				String extension = ".xlsx";
				Workbook workBook2 = null;
				FileOutputStream fos = null;
				BufferedReader br = new BufferedReader(new FileReader(f));
				if (extension.equals(".xlsx")) {
					workBook2 = new XSSFWorkbook();
				} else {
					workBook2 = new HSSFWorkbook();
				}
				Sheet sheet = workBook2.createSheet("Sheet");
				String nextLine;

				int rowNum = 0;
				while ((nextLine = br.readLine()) != null) {
					Row currentRow = sheet.createRow(rowNum++);
					String rowData[] = nextLine.split(String.valueOf(CSV_FILE_DELIMITER));
					for (int i = 0; i < rowData.length; i++) {
						currentRow.createCell(i).setCellValue(rowData[i]);
					}
				}
				String FN = f.getName();
				System.out.println("New File Name:" + FN);
				FN = FN.substring(0, FN.lastIndexOf('.'));
				File generatedExcel = new File(strdestination, FN + extension);
				fos = new FileOutputStream(generatedExcel);
				workBook2.write(fos);
				if (generatedExcel.exists()) {
					System.out.println("Newly Generated excel Exist in path");

					Thread.sleep(2000);
					Sheet sh = workBook2.getSheet("Sheet");
					Row row = sh.getRow(3);
					String header1 = row.getCell(6).getStringCellValue();
					System.out.println("header  value is" + header1);
					extentTest.log(Status.PASS, "Header : " + header1);
					Assert.assertEquals("Division", header1);
					Thread.sleep(2000);
					List<String> columnData = new ArrayList<>();
					int startRow = 3;
					int endRow = 15;
					for (int i = startRow; i <= endRow; i++) {
						Row row2 = sheet.getRow(i);

						Cell cell = row2.getCell(6);
						if (cell == null || cell.getCellType() == CellType.BLANK) {
							// System.out.println("Cell is empty");
						} else {
							String cellValue = cell.getStringCellValue();
							columnData.add(cellValue);
							System.out.println(cellValue);
							extentTest.log(Status.PASS, "value is " + cellValue);
						}

					}
				}

				try {
					workBook2.close();
					fos.close();
					br.close();
				} catch (IOException e) {
					System.out.println("Exception While Closing I/O Objects");
					e.printStackTrace();
				}
				generatedExcel.delete();

			} catch (Exception e) {
				System.out.println("Unexpected Exception");
				e.printStackTrace();
				converted = false;
			}
			if (converted) {
				System.out.println("Conversion took");
			}
			f.delete();
		} else {
			System.out.println("Long-TermPartTimereport not Exist in path");
			extentTest.log(Status.PASS, "Long-TermPartTimereport not Exist in path");
		}
	}

//DownlaodURLValidationReport
	public void verifyDownlaodURLValidationReport(String URLReports, String planNumber, String prodID,
			String Reportname, String Date) throws InterruptedException, AWTException, IOException {
		// selectProducerID(prodID);
		if (Reportname.equals("Long-TermPartTimereport")) {
			driver.get(URLReports);
			extentTest.log(Status.PASS, "URL launch After Logged in");
			extentTest.log(Status.PASS,
					"Long-TermPartTimereport File download feature is implemented as expected and working successfully");

			/*
			 * String downloadPath2 = System.getProperty("user.dir"); DateTimeFormatter g2 =
			 * DateTimeFormatter.ofPattern("YYYYMMddHHmmss"); LocalDateTime datenew2 =
			 * LocalDateTime.now(); String date3 = g2.format(datenew2);
			 * System.out.println("Date is:" + date3); LocalDateTime later =
			 * datenew2.plusSeconds(00); Thread.sleep(1000); String FileName =
			 * "Long-TermPartTimereport-" + planNumber + "-" + date3 + ".csv";
			 * System.out.println("Actual filename: " + FileName); File f = new
			 * File(downloadPath2 + "/" + FileName); Thread.sleep(5000); if (f.exists()) {
			 * System.out.println("File Exist in path"); extentTest.log(Status.PASS,
			 * "Long-TermPart Timereport report Exist in path"); Thread.sleep(2000);
			 * f.delete(); }
			 * 
			 * else { System.out.println("not exsit in path"); extentTest.log(Status.FAIL,
			 * "Long-TermPart Timereport report not Exist in path"); }
			 */

		} else {
			driver.get(URLReports);
			extentTest.log(Status.PASS, "URL launch After Logged in");
			Thread.sleep(2000);
			takeScreenshotForPassedcase("Url Launched");

			String downloadPath3 = System.getProperty("user.dir");
			String FileName = Reportname + "-" + planNumber + "-" + Date + ".xls";
			System.out.println("Actual filename: " + FileName);
			File f = new File(downloadPath3 + "/" + FileName);

			Thread.sleep(4000);
			if (f.exists()) {
				System.out.println("File Exist in path");
				extentTest.log(Status.PASS, Reportname + "report Exist in path");
				f.delete();
			} else {
				System.out.println("File not Exist in path");
				extentTest.log(Status.FAIL, Reportname + "report not Exist in path");
			}
		}
	}

	// feedback report
	public void verifyDownlaodFeedBackReport(String planNumber, String prodID, String Reportname, String Date,
			String fromDate, String toDate, String fileOptn) throws InterruptedException, AWTException, IOException {

		Thread.sleep(3000);
		selectProducerID(prodID);
		searchPlanFunctionality(planNumber);
		ClickElement(sideMenuPayrollFeedbackFile, "Payroll Feedback File Side menu");
		assertElementDisplayed(headerPayrollFdBck, headerPayrollFdBck.getText() + " Header");
		takeScreenshot("Payroll Feedback page");
		assertElementDisplayed(headerSetup, "Setup Header");
		ClickElement(iconExpandSetUp, "Setup Expand Icon");
		MoveToElement(linkOnDemand, "link On Demand");
		ClickElement(linkOnDemand, linkOnDemand.getText() + " Link");
		Thread.sleep(2000);
		assertElementDisplayed(headerOnDemandRequest, headerOnDemandRequest.getText() + " Header");
		takeScreenshot("Payroll Feedback OnDemand File Request page");
		assertElementDisplayed(labelSetUp, labelSetUp.getText());
		assertElementDisplayed(labelReview, labelReview.getText());
		assertElementDisplayed(labelComplete, labelComplete.getText());
		assertElementDisplayed(headerBeginingDate, headerBeginingDate.getText() + " Header");
		EnterText(txtFldFromDate, fromDate, "From Date");
		assertElementDisplayed(headerEndingDate, headerEndingDate.getText() + " Header");
		EnterText(txFldToDate, toDate, "To Date");
		try {
			if (headerSelectDivision.isDisplayed()) {
				assertElementDisplayed(headerSelectDivision, headerSelectDivision.getText() + " Header");
				ClickElement(linkSelectAll, "Select All Link");
			}

		} catch (Exception e) {
			extentTest.log(Status.INFO,
					"Selected plan is a non-divisional. Select Divison section is not displaying as expected");
		}
		assertElementDisplayed(headerPlsSelectInfo, headerPlsSelectInfo.getText() + " Header");
		ComboSelectVisibleText(selectFileOptn, fileOptn, "Information Type");
		ClickElement(btnFdBckNext, "Next Button");
		ClickElement(btnFdBckSubmit, "Submit Button");
		Thread.sleep(3000);
		assertElementDisplayed(infoMsgSubmissionSuccessfull, "Info Message: " + infoMsgSubmissionSuccessfull.getText());
		takeScreenshot("Payroll Feedback Successfull Submission");
		ClickElement(btnFdBckDshbrd, "Feedback Dashboard Button");
		//Thread.sleep(3000);
       //ClickElementJS(btnFdBckHome, "btnFdBckHome");
       Thread.sleep(2000);
       MoveToElement(ViewButton1, "View Button");
		ClickElement(ViewButton1, "View Button");
		Thread.sleep(3000);
		extentTest.log(Status.PASS,
				"Payroll Feedback-OnDemand Report is downloaded and feature is implemented as expected and working successfully");

		String downloadPath = System.getProperty("user.dir");

		String FileName = Reportname + "-" + planNumber + "-" + Date + ".xls";
		System.out.println("Actual filename: " + FileName);
		File f = new File(downloadPath + "/" + FileName);
		Thread.sleep(2000);
		if (f.exists()) {
			System.out.println("File Exist in path");
			extentTest.log(Status.PASS, Reportname + "report Exist in path");

			//f.delete();
		} else {
			System.out.println("File not Exist in path");
			extentTest.log(Status.FAIL, Reportname + "report not Exist in path");

		}
	}

	// HistoricalFeedbackFileReport
	public void verifyHistoricalFeedbackFileReport(String planNumber, String prodID, String fromDate, String toDate,
			String Reportname, String Date) throws InterruptedException, AWTException, IOException {
		selectProducerID(prodID);
		Thread.sleep(3000);
		ClickElement(PlanParticipantMenu,"PlanParticipantMenu");
		ClickElement(PlanParticipantDataSubmenu, "Plan/Participant Data Submenu");
		searchPlanFunctionality(planNumber);
		ClickElement(HistoricalFeedbackFileLink, "Historical Feedback File Link");
		assertElementDisplayed(HistoricalFeedbackFileHeader, "Historical Feedback File Header");
		takeScreenshot("Historical Feedback File Page");
		assertElementDisplayed(PlsSlecActvtyHeader, PlsSlecActvtyHeader.getText() + " Header");
		assertElementDisplayed(SelcDateRangeHeader, SelcDateRangeHeader.getText() + " Header");
		assertElementDisplayed(PrtcpntSearchCriteriaHeader, PrtcpntSearchCriteriaHeader.getText() + " Header");
		// assertElementDisplayed(SelcDivisonHeader, SelcDivisonHeader.getText() + "
		// Header");
		assertElementDisplayed(HFF_SubmitBtn, "Submit Button");
		EnterText(FromDate, fromDate, "From Date");
		EnterText(ToDate, toDate, "To Date");
		ClickElement(HFF_SubmitBtn, "Submit Button");
		Thread.sleep(3000);
		extentTest.log(Status.PASS,
				"Historical Feedback File download feature is implemented as expected and working successfully");

		String downloadPath = System.getProperty("user.dir");
		String FileName = Reportname + "-" + planNumber + "-" + Date + ".xls";
		System.out.println("Actual filename: " + FileName);
		File f = new File(downloadPath + "/" + FileName);
		Thread.sleep(4000);
		if (f.exists()) {
			System.out.println("File Exist in path");
			extentTest.log(Status.PASS, Reportname + "report Exist in path");

			f.delete();
		} else {
			System.out.println("not exsit in path");
			extentTest.log(Status.INFO, Reportname + "report not Exist in path");
		}
	}

	// LongTermPartTimereportURL
	public void verifyLongTermPartTimereport(String planNumber, String prodID, String Reportname, String Date)
			throws InterruptedException, AWTException, IOException {
		selectProducerID(prodID);
		MoveToElement(PlanParticipantMenu, "Plan/Participant Menu");
		ClickElement(PlanParticipantDataSubmenu, "Plan/Participant Data Submenu");
		searchPlanFunctionality(planNumber);
		MoveToElement(submenuLTPTEmployeeDataReview, "LTPT Employee Data Review menu");
		ClickElement(submenuLTPTEmployeeDataReview, "LTPT Employee Data Review menu Link");
		assertElementDisplayed(LTPTEmployeeDataReviewHeader, LTPTEmployeeDataReviewHeader.getText());
		Assert.assertEquals("Long-Term Part-Time Employee Data Review", LTPTEmployeeDataReviewHeader.getText());

		assertElementDisplayed(SideMenuLTPTEmployeeData, SideMenuLTPTEmployeeData.getText());
		assertElementDisplayed(SideMenuLTPTStatusReport, SideMenuLTPTStatusReport.getText());

		assertElementDisplayed(LTPTDataReviewStep1LTPTLink, LTPTDataReviewStep1LTPTLink.getText());
		assertElementDisplayed(LTPTDataReviewStep1DownloadPhButton,
				LTPTDataReviewStep1DownloadPhButton.getAttribute("value"));
		ClickElement(LTPTDataReviewStep1DownloadPhButton, "Download Participant List Button");
		Thread.sleep(1000);
		DateTimeFormatter g = DateTimeFormatter.ofPattern("YYYYMMddHHmmss");
		LocalDateTime datenew = LocalDateTime.now();
		LocalDateTime later = datenew.plusSeconds(00);
		String date1 = g.format(later);
		System.out.println("Date is:" + date1);
		Thread.sleep(3000);
		String downloadPath = System.getProperty("user.dir");

		String FileName = "Long-TermPartTimereport-" + planNumber + "-" + date1 + ".csv";
		System.out.println("Actual filename: " + FileName);
		File f = new File(downloadPath + "/" + FileName);
		if (f.exists()) {
			System.out.println("File Exist in path");
			extentTest.log(Status.PASS, "Long-TermPart Timereport report Exist in path");
			Thread.sleep(2000);
			f.delete();
		} else {
			System.out.println(" File not exsit in path");
			extentTest.log(Status.INFO, Reportname + "report not Exist in path");
		}
	}

	// Plan Summary Screen Update Page
	public void verifyPlanSummaryScreenPageUpdates(String username, String password, String planNumber, String prodID)
			throws InterruptedException, AWTException {
		Thread.sleep(2000);
		if (planNumber.equals("G37170")) {
			loginToAppHONew(username, password);
			searchPlanFunctionality(planNumber);
			Thread.sleep(2000);
			ClickElement(sideMenuSummary, "Summary Side menu");
			Thread.sleep(2000);
			assertElementDisplayed(headerPlanSummary, headerPlanSummary.getText() + " Header");
			assertElementDisplayed(managedAccountProviderlabel, managedAccountProviderlabel.getText());
			assertElementDisplayed(SpecificationHeader, SpecificationHeader.getText());
			ScrollTo(SpecificationHeader, "Plan Specification Header");
			Assert.assertEquals("Mesirow 3(21) / 3(38) Fiduciary Service:", Mesirowtext.getText());
			takeScreenshotForPassedcase("Mesirow Header is displayed ");
			extentTest.log(Status.PASS, "Mesirow Header is displayed as expected");
		} else if (planNumber.equals("G36155")) {
			loginToAppNonHONew(username, password);
			selectProducerID(prodID);
			MoveToElement(PlanParticipantMenu, "Plan/Participant Menu");
			ClickElement(PlanParticipantDataSubmenu, "Plan/Participant Data Submenu");
			selectPlan(planNumber);
			Thread.sleep(2000);
			ClickElement(sideMenuSummary, "Summary Side menu");
			Thread.sleep(2000);
			assertElementDisplayed(headerPlanSummary, headerPlanSummary.getText() + " Header");
			assertElementDisplayed(managedAccountProviderlabel, managedAccountProviderlabel.getText());
			assertElementDisplayed(SpecificationHeader, SpecificationHeader.getText());
			ScrollTo(SpecificationHeader, "Plan Specification Header");
			Assert.assertEquals("Mesirow 3(21) / 3(38) Fiduciary Service:", Mesirowtext.getText());
			takeScreenshotForPassedcase("Mesirow Header is displayed ");
			extentTest.log(Status.PASS, "Mesirow Header is displayed as expected");
		} else if (planNumber.equals("G32367")) {
			loginToAppNonHONew(username, password);
			
			MoveToElement(PlanParticipantMenu, "Plan/Participant Menu");
			ClickElement(PlanParticipantDataSubmenu, "Plan/Participant Data Submenu");
			searchPlanFunctionality(planNumber);
			Thread.sleep(2000);
			ClickElement(sideMenuSummary, "Summary Side menu");
			Thread.sleep(2000);
			assertElementDisplayed(headerPlanSummary, headerPlanSummary.getText() + " Header");
			assertElementDisplayed(managedAccountProviderlabel, managedAccountProviderlabel.getText());
			assertElementDisplayed(SpecificationHeader, SpecificationHeader.getText());
			ScrollTo(SpecificationHeader, "Plan Specification Header");
			Assert.assertEquals("Mesirow 3(21) / 3(38) Fiduciary Service:", Mesirowtext.getText());
			takeScreenshotForPassedcase("Mesirow Header is displayed");
			extentTest.log(Status.PASS, "Mesirow Header is displayed as expected");
		}

	}

	// validate Important Documents ProNvest Agreement
	 	public void verifyEnrollmentBookletsFeature(String planNumber ) {
	 		ClickElement(ImportantDocsLink, "Important Documents Link");
			assertElementDisplayed(ImportantDocsHeader, "Important Documents Header");
			takeScreenshot("Important Documents Page");
	 		assertElementDisplayed(ImpDocPageHeader, "Important document page header");
	 		WebElement PlanNum = driver.findElement(By.xpath("//span[text()='"+ planNumber +"']"));
	 		assertElementDisplayed(PlanNum, "Plan Number " +planNumber);
	 		assertElementDisplayed(EnrollmentMaterialheader, "Enrollment Material header");
	 		//ClickElement(enrollmentbookletlink, "Enrollment Booklets Link");
	 		assertElementDisplayed(enrollmentbookletlink, "Enrollment Booklets Link");
	
		try {
			assertElementDisplayed(enrollmentbookletlink, "Enrollment Booklets Link");
			extentTest.log(Status.PASS,
					"Important Documents functionality is implemented as expected and links are working successfully");
		} catch (Exception e) {
			assertElementDisplayed(NoDocsInfoMsg, NoDocsInfoMsg.getText());
			takeScreenshot("Important Docs-No Docs info message");
			extentTest.log(Status.FAIL, NoDocsInfoMsg.getText());
			throw new SkipException(
					"Test case is skipped due to no documents available. Please use the other plan number");
		}	
	 	
	 	}	
	 	
	 	public void DocumentTab() throws InterruptedException, AWTException {

	 		//using the robot class to navigate to the download button 
	 				Robot robot = new Robot();

	 				robot.delay(2000);

	 				for (int i = 0; i <= 13; i++) {
	 					robot.keyPress(KeyEvent.VK_TAB);
	 					robot.keyRelease(KeyEvent.VK_TAB);
	 					robot.delay(2000);
	 				}

	 				robot.keyPress(KeyEvent.VK_ENTER);
	 				robot.keyRelease(KeyEvent.VK_ENTER);

	 				// Wait for the file dialog to appear
	 				robot.delay(3000);

	 				// Press Tab to navigate to the "Save as type" dropdown
	 				robot.keyPress(KeyEvent.VK_TAB);
	 				robot.keyRelease(KeyEvent.VK_TAB);
	 				robot.delay(3000);

	 				// Press Down Arrow to select "All Files"
	 				robot.keyPress(KeyEvent.VK_DOWN);
	 				robot.keyRelease(KeyEvent.VK_DOWN);
	 				robot.delay(3000);

	 				// Press Enter to confirm the selection
	 				robot.keyPress(KeyEvent.VK_ENTER);
	 				robot.keyRelease(KeyEvent.VK_ENTER);
	 				robot.delay(3000);

	 				// Press Enter to confirm the selection
	 				robot.keyPress(KeyEvent.VK_ENTER);
	 				robot.keyRelease(KeyEvent.VK_ENTER);

	 				robot.delay(5000);
	 				// Fot print icon
	 				robot.keyPress(KeyEvent.VK_TAB);
	 				robot.keyRelease(KeyEvent.VK_TAB);
	 				robot.delay(2000);

	 				robot.keyPress(KeyEvent.VK_ENTER);
	 				robot.keyRelease(KeyEvent.VK_ENTER);
	 				robot.delay(3000);
	 			}
	 	
	 	public void EnrollmentbookDoc() throws InterruptedException, AWTException {

			Robot robot = new Robot();
			// if not in Save as Pdf then need perform this
			for (int i = 0; i <= 4; i++) {
				robot.keyPress(KeyEvent.VK_TAB);
				robot.keyRelease(KeyEvent.VK_TAB);
				robot.delay(2000);
			}
			// Press Down Arrow to select "All Files"
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			robot.delay(3000);

			// Print button
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			robot.delay(5000);

			for (int i = 0; i < 4; i++) {
				robot.keyPress(KeyEvent.VK_TAB);
				robot.keyRelease(KeyEvent.VK_TAB);
				robot.delay(2000);
			}

			// Print button
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

			robot.delay(3000);

			// Save button
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

			Thread.sleep(4000);

		}
	 	
	 	public void EnrollmentBook457Tab() throws Exception {
			String userHome = System.getProperty("user.home");
		EnrollmentBook457Link.click();
		// Wait for the new tab to open
		// Store the main window handle
				String parentWindow = driver.getWindowHandle();
				Iterator<String> windows = driver.getWindowHandles().iterator();
				String parentID = windows.next();
				String childID = windows.next();

				driver.switchTo().window(childID);
		DocumentTab();
		EnrollmentbookDoc457();

		String filedownload457 = "Enrollment Book 457";

		String downloadPath457 = userHome + "\\Downloads\\" + filedownload457;

		File file457 = new File(downloadPath457);
		if (file457.exists()) {
			System.out.println("File downloaded successfully as: " + filedownload457);
			extentTest.log(Status.PASS, "File_457 downloaded successfully");

		} else {
			System.out.println("File download failed for 457.");
			extentTest.log(Status.FAIL, "File 457 is not Downloaded or not located in the path");
		}
	driver.close();
		driver.switchTo().window(parentID);
	Thread.sleep(2000);
	}
		
	 	public void EnrollmentbookDoc457() throws InterruptedException, Exception  {
			Robot robot = new Robot();
			// if not in Save as Pdf then need perform this

			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			robot.delay(2000);

			// Print button
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			robot.delay(5000);

			Thread.sleep(4000);

		}
		
	 	//Actions for Enrollment Book Link revised work for API change 
		public void verifyActionsforEnrollmentBookLinkrevisedworkforAPIchanges(String planNumber)
				throws Exception {
				
			if(planNumber.equals("G33331")) {
				verifyEnrollmentBookletsFeature(planNumber);
			ClickElement(enrollmentbookletlink, "Enrollment Booklets Link");
			assertElementDisplayed(ImpDocPageHeader, ImpDocPageHeader.getText() + " Header");
			assertElementDisplayed(EnrollmentBookletheader, EnrollmentBookletheader.getText() + " Header");
			String expectedValue = "Enrollment Book";
			String Actualvalue = EnrollmentBookLink.getText();

			Assert.assertEquals(expectedValue, Actualvalue, "Document link name as Excepted");

			// Click on the link that opens the document in a new tab
			EnrollmentBookLink.click();

			// Wait for the new tab to open
			Thread.sleep(5000);
			// Store the main window handle
			String parentWindow = driver.getWindowHandle();
			Iterator<String> windows = driver.getWindowHandles().iterator();
			String parentID = windows.next();
			String childID = windows.next();

			driver.switchTo().window(childID);

			Thread.sleep(2000);
			takeScreenshot(" PDF in new tab");
			// verify switching
			Assert.assertNotEquals(driver.getWindowHandles(), parentWindow, "failed to switch to the child window");

			takeScreenshotForPassedcase(childID);
			DocumentTab();
			EnrollmentbookDoc();
			String filedownload = "Enrollment Book";
			String userHome = System.getProperty("user.home");
			String downloadPath = userHome + "\\Downloads\\" + filedownload;

			File file = new File(downloadPath);
			if (file.exists()) {
				System.out.println("File downloaded successfully as: " + filedownload);
				extentTest.log(Status.PASS, "File downloaded successfully");

			} else {
				System.out.println("File download failed.");
				extentTest.log(Status.FAIL, "File is not Downloaded or not located in the path");
			}

			// Step 6: Verify if the file is saved correctly
			Thread.sleep(5000);

			String PdfName = "importantPlanDocsCmodList.faces.pdf"; // Set the desired file name
			String userHome1 = System.getProperty("user.home");
			String downloadPath1 = userHome1 + "\\Downloads\\" + PdfName;

			File file1 = new File(downloadPath1);
			if (file1.exists()) {
				System.out.println("PDF downloaded successfully as: " + PdfName);
				extentTest.log(Status.PASS, "PDF downloaded successfully");

			}
	 	 		 	
			}
			else {
								
				verifyEnrollmentBookletsFeature(planNumber);
				ClickElement(enrollmentbookletlink, "Enrollment Booklets Link");
				assertElementDisplayed(ImpDocPageHeader, ImpDocPageHeader.getText() + " Header");
				assertElementDisplayed(EnrollmentBookletheader, EnrollmentBookletheader.getText() + " Header");
				String expectedValue = "Enrollment Book";
				String Actualvalue = EnrollmentBookLink.getText();

				Assert.assertEquals(expectedValue, Actualvalue, "Document link name as Excepted");

				// Click on the link that opens the document in a new tab
				EnrollmentBookLink.click();

				// Wait for the new tab to open
				Thread.sleep(5000);
				// Store the main window handle
				String parentWindow = driver.getWindowHandle();
				Iterator<String> windows = driver.getWindowHandles().iterator();
				String parentID = windows.next();
				String childID = windows.next();

				driver.switchTo().window(childID);

				Thread.sleep(2000);
				takeScreenshot(" PDF in new tab");
				// verify switching
				Assert.assertNotEquals(driver.getWindowHandles(), parentWindow, "failed to switch to the child window");

				takeScreenshotForPassedcase(childID);
				DocumentTab();
				EnrollmentbookDoc();
				String filedownload = "Enrollment Book";
				String userHome = System.getProperty("user.home");
				String downloadPath = userHome + "\\Downloads\\" + filedownload;

				File file = new File(downloadPath);
				if (file.exists()) {
					System.out.println("File downloaded successfully as: " + filedownload);
					extentTest.log(Status.PASS, "File downloaded successfully");

				} else {
					System.out.println("File download failed.");
					extentTest.log(Status.FAIL, "File is not Downloaded or not located in the path");
				}

				// Step 6: Verify if the file is saved correctly
				Thread.sleep(5000);

				String PdfName = "importantPlanDocsCmodList.faces.pdf"; // Set the desired file name
				String userHome1 = System.getProperty("user.home");
				String downloadPath1 = userHome1 + "\\Downloads\\" + PdfName;

				File file1 = new File(downloadPath1);
				if (file1.exists()) {
					System.out.println("PDF downloaded successfully as: " + PdfName);
					extentTest.log(Status.PASS, "PDF downloaded successfully");

				} else {
					System.out.println("PDF download failed.");
					extentTest.log(Status.FAIL, "PDF is not Downloaded or not located in the path");
				}

				driver.close();
				driver.switchTo().window(parentID);
			Thread.sleep(2000);
				// For Enrollment Book 457 Link

			EnrollmentBook457Tab();
				
				// For Enrollment Book Sp Link
			String parentWindowHandle = driver.getWindowHandle();
				// Click on the link that opens the document in a new tab
				EnrollmentBookSPLink.click();
				// Wait for the new tab to open
				Set<String> allWindowHandles = driver.getWindowHandles();
				for (String windowHandle : allWindowHandles) {
				    if (!windowHandle.equals(parentWindowHandle)) {
				        driver.switchTo().window(windowHandle);
				        break;
				    }
				}
				
		Thread.sleep(3000);
		Robot robot = new Robot();

				for (int i = 0; i <= 13; i++) {
					robot.keyPress(KeyEvent.VK_TAB);
					robot.keyRelease(KeyEvent.VK_TAB);
					robot.delay(2000);
				}

				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);

				// Wait for the file dialog to appear
				robot.delay(3000);

				// Press Tab to navigate to the "Save as type" dropdown
				robot.keyPress(KeyEvent.VK_TAB);
				robot.keyRelease(KeyEvent.VK_TAB);
				robot.delay(3000);

				// Press Down Arrow to select "All Files"
				robot.keyPress(KeyEvent.VK_DOWN);
				robot.keyRelease(KeyEvent.VK_DOWN);
				robot.delay(3000);

				// Press Enter to confirm the selection
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);
				robot.delay(3000);

				// Press Enter to confirm the selection
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);

				robot.delay(5000);
				// Fot print icon
				robot.keyPress(KeyEvent.VK_TAB);
				robot.keyRelease(KeyEvent.VK_TAB);
				robot.delay(2000);

				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);
				robot.delay(3000);
				Thread.sleep(5000);
				// if not in Save as Pdf then need perform this

				EnrollmentbookDoc457();
				

				String filedownloadSP = "Enrollment Book SP";

				String downloadPathSP = userHome + "\\Downloads\\" + filedownloadSP;

				File fileSP = new File(downloadPathSP);
				if (fileSP.exists()) {
					System.out.println("File downloaded successfully as: " + filedownloadSP);
					extentTest.log(Status.PASS, "File_SP downloaded successfully");

				} else {
					System.out.println("File download failed for SP.");
					extentTest.log(Status.FAIL, "File SP is not Downloaded or not located in the path");
				}

				// Step 6: Verify if the file is saved correctly
				Thread.sleep(5000); // Wait for file to be saved

				driver.close();
				driver.switchTo().window(parentID);
				//driver.close();
				robot.delay(3000);
				}
}	
		
		public void previousBtnAction(String planNumber) throws InterruptedException{
	 	 		takeScreenshot("Enrollment Booklet Page");
	 			assertElementDisplayed(enrollmentbookletSubheading, "Enrollment Booklets Subheading");
	 	 		for (WebElement button : previousBtn) {
 	            	
 	            	try {
 	            		button.click();
 	            		Thread.sleep(1500); 
 					} catch (StaleElementReferenceException e) {
 						button = driver.findElement(By.xpath("//input[@value='Previous']"));
 						button.click();
 						Thread.sleep(1500); 
 					}
 	                

 	                assertElementDisplayed(ImpDocPageHeader, "Important document page header");
 	         		WebElement PlanNum = driver.findElement(By.xpath("//span[text()='"+ planNumber +"']"));
 	         		assertElementDisplayed(PlanNum, "Plan Number " +planNumber);
 	         		 Thread.sleep(1500);
 	              
 	                  // Navigate back to the initial page to click the next button
	 	                ClickElement(enrollmentbookletlink, "Enrollment Booklet Link");
	 	                Thread.sleep(1500); // Adjust the sleep time as needed 
 	            }
	 	 		
	 	 	}

		
		
		//VerifyEnrollmentBookDisplayFeature
		public void verifyEnrollmentBookDisplayFeature(String planNumber) throws InterruptedException, AWTException {
	 		
	 		verifyEnrollmentBookletsFeature(planNumber);
	 		ClickElement(enrollmentbookletlink, "Enrollment Booklets Link");
	 		
			Thread.sleep(2000);
				
	 			if ("G51528".equals(planNumber)) {
					 			
	 	 			if (enrollmentbook.isDisplayed() && enrollmentbook457.isDisplayed() && enrollmentbookSP.isDisplayed()) {
	 	 				takeScreenshotForPassedcase(planNumber);
	 	 				assertElementDisplayed(enrollmentbook, "Enrollment Book");
	 	 				assertElementDisplayed(enrollmentbook457, "Enrollment Book 457");
	 	 				assertElementDisplayed(enrollmentbookSP, "Enrollment Book SP");
	 	 				
	 	 				System.out.println(planNumber + " has " + enrollmentbook.getText() + " , " +
	 	 						enrollmentbook457.getText() + " and " + enrollmentbookSP.getText());
	 	 				
	 	 				 extentTest.log(Status.PASS, planNumber + " has " + enrollmentbook.getText() + " , " 
	 	 				 		+ enrollmentbook457.getText() + " and " + enrollmentbookSP.getText());
	 	 				 
	 	 				Thread.sleep(3000);
	 	 				assertElementDisplayed(PrintbuttonImpDocPage, "PrintbuttonImpDocPage");
	 	 				System.out.println("PrintbuttonImpDocPage");
	 	 				Thread.sleep(3000);
	 	 				 previousBtnAction(planNumber);
	 	 				
	 	 				
					}
	 	 			else {
	 	 				 extentTest.log(Status.FAIL,"Some of the books are missing");
	 	 			}
	 	 	 		
	 			}else if ("G33331".equals(planNumber)) {
					
	 	 			if (enrollmentbook.isDisplayed() ) {
	 	 				takeScreenshotForPassedcase(planNumber);
	 	 				System.out.println(planNumber + " has " + enrollmentbook.getText());
	 	 				 extentTest.log(Status.PASS,"Enrollment book Dislayed as Expected");
	 	 				 Thread.sleep(2000);
	 	 				assertElementDisplayed(PrintbuttonImpDocPage, "PrintbuttonImpDocPage");
	 	 				System.out.println("PrintbuttonImpDocPage");
	 	 				Thread.sleep(2000);
	 	 				previousBtnAction(planNumber);
	 	 				
					}		 	 			
	 	 			else {
	 	 				 extentTest.log(Status.FAIL,"Enrollment book is missing");
	 	 			}
				}else if ("G30548".equals(planNumber)) {	
					
	 	 			if (enrollmentbook.isDisplayed() && enrollmentbook457.isDisplayed()) {
	 	 				takeScreenshotForPassedcase(planNumber);
	 	 				assertElementDisplayed(enrollmentbook, "Enrollment Book");
	 	 				assertElementDisplayed(enrollmentbook457, "Enrollment Book 457");
	 	 				
	 	 				System.out.println(planNumber + " has " + enrollmentbook.getText() + " and " +
	 	 						enrollmentbook457.getText());
	 	 				
	 	 				previousBtnAction(planNumber);
	 	 				
					}
	 	 			else {
	 	 				 extentTest.log(Status.FAIL,"Some of the books are missing");
	 	 			}
	 	 	 		
					
				}else if ("G35910".equals(planNumber)) {	
					
	 	 			if (enrollmentbook.isDisplayed() && enrollmentbookSP.isDisplayed()) {
	 	 				takeScreenshotForPassedcase(planNumber);
	 	 				assertElementDisplayed(enrollmentbook, "Enrollment Book");
	 	 				assertElementDisplayed(enrollmentbookSP, "Enrollment Book SP");
	 	 				
	 	 				System.out.println(planNumber + " has " + enrollmentbook.getText() +
	 	 						" and " + enrollmentbookSP.getText());
	 	 				
	 	 				 previousBtnAction(planNumber);
	 	 				
					}
	 	 			else {
	 	 				 extentTest.log(Status.FAIL,"Some of the books are missing");
	 	 			}
	 	 	 		
				}else if ("B01230".equals(planNumber)) {	
					
					assertElementDisplayed(errorMsg, "Error Message");
					String actualerromessageString = errorMsg.getText();
		 	 		String expectederrorMessageString = "No documents were found for the category you selected";
		 	 		takeScreenshotForPassedcase(planNumber);
		 			takeScreenshot("Error Message");
		 			System.out.println("No Enrollment Book present");
		 			
		 			if(actualerromessageString.equals(expectederrorMessageString)) {
		 				System.out.println("The Error Meassge is displayed as - " + actualerromessageString);
		 				extentTest.log(Status.PASS,"No Enrollment Book present");
				}
		 	}else {
		 				extentTest.log(Status.FAIL,"Test Fail");
		 				System.out.println("---FAIL---");
		 				takeFailedScreenshot(planNumber);
					}
	 	}
		
}