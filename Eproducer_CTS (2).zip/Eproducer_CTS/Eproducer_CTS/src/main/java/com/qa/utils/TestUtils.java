package com.qa.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

import com.qa.base.TestBase;

public class TestUtils extends TestBase {
	
	public static long PAGE_LOAD_TIMEOUT = 60;
	public static long IMPLICIT_WAIT = 20;
	
	static Workbook book;
	static Sheet sheet;
	public static String TestDataSheetPath = ".//src//resource//java//com//qa//testdata//eProducerRegTestData.xlsx";
	
	public TestUtils() {
		super();
	}
	

	//To get the test data from excel sheet
	public static Object[][] geteProducerTestData(String SheetName) throws FileNotFoundException {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(TestDataSheetPath);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
		book = WorkbookFactory.create(fis);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		sheet = book.getSheet(SheetName);
		Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
		for (int i = 0; i < sheet.getLastRowNum(); i++) {
			for (int k = 0; k < sheet.getRow(0).getLastCellNum(); k++) {
				data[i][k] = sheet.getRow(i + 1).getCell(k).toString();
			}
		}
		return data;
	}

	public static String getFailedScreenshot(WebDriver driver, String screenshotname) throws IOException {
		String datename = new SimpleDateFormat("MM-dd-yyyy_HH-mm-ss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destination = ".//Screenshots//Failed Screenshots//"+screenshotname +"_"+ datename + ".png";
		File finaldestination = new File(destination);
		FileUtils.copyFile(source, finaldestination);
		return destination;
	}

	public static String getPassedScreenshot(WebDriver driver, String screenshotname) throws IOException {
		String datename = new SimpleDateFormat("MM-dd-yyyy_HH-mm-ss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destination = ".//Screenshots//Passed Screenshots//"+screenshotname +"_"+ datename + ".png";
		File finaldestination = new File(destination);
		FileUtils.copyFile(source, finaldestination);
		return destination;
	}




















}
