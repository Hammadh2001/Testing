package com.qa.eProducerActions;

import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;
import com.qa.eProducerPages.EProducerWebPageElements;
import com.qa.utils.TestUtils;
import com.qa.utils.Wait;

public class EProducerRegistrationActions extends EProducerWebPageElements {
	
	public EProducerRegistrationActions() {
		super();
	}
	
	//eProducer registration scenarios actions
	
	//Navigating to eProducer registration page
	public void navigateToeProducerRegistrationPage() throws InterruptedException {
		assertElementDisplayed(loginHdr, "Log in to your account header");
		takeScreenshot("LoginPage");
		ClickElement(createYourAccBtn, "Create An Account link");
		Thread.sleep(2000);
	//	ClickElement(CreateAcc, "New Account Button");
		ClickElement(eProducerCardHdr, "Register for New Account Button");
		ClickElement(eProducerRegisterLink, "eProducer Application Link");
	}
	
	//Select the type of Registration 
	public void selectTypeofRegistration(String regType) throws InterruptedException {
		assertElementDisplayed(RegisterForeProdHeader, "Register For eProducer Header");
		String xpath = "//td/label[contains(text(),' "+regType+"')]";
		WebElement registrationType = driver.findElement(By.xpath(xpath));
		ClickElement(registrationType, "Registration Type: "+ regType);
		Thread.sleep(3000);
		System.out.println("before next");
		ClickElement(eProdReg_NextBtn, "Next Button");
		System.out.println("next worked");
		Thread.sleep(3000);
	}
	
	//Verifying Information entry page
	public void verifyEnterInfoPage(String invalidSSN, String validSSN,String prodID, String stateName) throws InterruptedException {
		assertElementDisplayed(EnterYourInfoHeader, "Enter Your Information Header");
		EnterText(SSNTxtFld, invalidSSN, "SSN");
		SSNTxtFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(CommonValidationMsg, CommonValidationMsg.getText());
		assertElementDisplayed(SSNValidationMsg, SSNValidationMsg.getText());
		takeScreenshot("Information page with validation");
		EnterText(SSNTxtFld, validSSN, "SSN");
		EnterText(ProducerIDTxtFld, prodID, "Producer ID");
		ComboSelectVisibleText(ApplicationStateFld, stateName, "Application State");
		ClickElement(eProdReg_NextBtn, "Next Button");
		Thread.sleep(1000);
		
	}
	
	//Verifying the User ID text field
	public void verifyUserIDTxtFld(String lessThn6Chrs, String UsrIDEndsSpclChr, String UsrIDWithSpclChr, String UsrIDWith9Numbs,
			String UsrIDWithSpace, String validUsrID) throws InterruptedException {
		assertElementDisplayed(CreateUsrIDPwdHeader, CreateUsrIDPwdHeader.getText()+ " Header");
		ClickElement(UserIDRqmntsLink, "User ID Requirements Link");
		Thread.sleep(1000);
		Iterator<String>windows =  driver.getWindowHandles().iterator();
		String parent = windows.next();
		String child = windows.next();
		driver.switchTo().window(child);
		Thread.sleep(2000);
		assertElementDisplayed(UsrIDRqmntsHeader, "User ID Requirements Header");
		takeScreenshot("User ID Requirements Page");
		driver.close();
		driver.switchTo().window(parent);
		Thread.sleep(1000);
		EnterText(UserIDFld, lessThn6Chrs, "User ID");
		UserIDFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(Minimum6Chrs_VldtnMsg, Minimum6Chrs_VldtnMsg.getText());
		EnterText(UserIDFld, UsrIDEndsSpclChr, "User ID");
		UserIDFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(EndingWithLtrNumb_VldtnMsg, EndingWithLtrNumb_VldtnMsg.getText());
		EnterText(UserIDFld, UsrIDWithSpclChr, "User ID");
		UserIDFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(SpecialChrs_VldtnMsg, SpecialChrs_VldtnMsg.getText());
		EnterText(UserIDFld, UsrIDWith9Numbs, "User ID");
		UserIDFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(Contains9Numbs_VldtnMsg, Contains9Numbs_VldtnMsg.getText());
		EnterText(UserIDFld, UsrIDWithSpace, "User ID");
		UserIDFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(ContainsSpaces_VldtnMsg, ContainsSpaces_VldtnMsg.getText());
		EnterText(UserIDFld, validUsrID, "User ID");
		UserIDFld.sendKeys(Keys.RETURN);		
	}
	
	//Verifying password text field
	public void verifyPasswordTxtFld(String PwdlessThn8Chrs, String PwdNotMeetingCriterias, String PwdWithSpace, String PwdWithUserID, String validPwd) throws InterruptedException {
//		ClickElement(PwdRqmntsLink, "Password Requirements Link");
//		Thread.sleep(1000);
//		Iterator<String>windows =  driver.getWindowHandles().iterator();
//		String parent = windows.next();
//		String child = windows.next();
//		driver.switchTo().window(child);
//		Thread.sleep(2000);
//		assertElementDisplayed(PwdRqmntsHeader, "Password Requirements Header");
//		takeScreenshot("Password Requirements Page");
//		driver.close();
//		driver.switchTo().window(parent);
//		Thread.sleep(1000);
//		EnterText(PasswordFld, PwdlessThn8Chrs, "Password");
//		PasswordFld.sendKeys(Keys.RETURN);
//		assertElementDisplayed(Minimum8Chrs_VldtnMsg, Minimum8Chrs_VldtnMsg.getText());
//		EnterText(PasswordFld, PwdNotMeetingCriterias, "Password");
//		PasswordFld.sendKeys(Keys.RETURN);
//		assertElementDisplayed(PwdWithNotMeetingCriterias_VldtnMsg, PwdWithNotMeetingCriterias_VldtnMsg.getText());
		EnterText(PasswordFld, PwdWithSpace, "Password");
		PasswordFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(PwdWithSpace_VldtnMsg, PwdWithSpace_VldtnMsg.getText());
		EnterText(PasswordFld, PwdWithUserID, "Password");
		PasswordFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(PwdWithUserID_VldtnMsg, PwdWithUserID_VldtnMsg.getText());
		EnterText(PasswordFld, validPwd, "Password");
		PasswordFld.sendKeys(Keys.RETURN);
		
	}
	
	//Verifying confirm password field
	public void verifyConfirmPwdTxtFld(String invalidConfrimPwd, String validConfrimPwd) throws InterruptedException {
		Thread.sleep(2000);
		EnterText(ConfirmPwdFld, invalidConfrimPwd, "Password");
		ConfirmPwdFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(PwdNotMatch_VldtnMsg, PwdNotMatch_VldtnMsg.getText());
		EnterText(ConfirmPwdFld, validConfrimPwd, "Password");
		ConfirmPwdFld.sendKeys(Keys.RETURN);
	}
	
	//Verifying email field
	public void verifyEmailTxtFld(String invalidEmailID, String validEmailID) {
		assertElementDisplayed(SecAccessHeader, SecAccessHeader.getText() + " Header");
		EnterText(EmailFld, invalidEmailID, "Email");
		EmailFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(invalidEmail_VldtnMsg, invalidEmail_VldtnMsg.getText());
		EnterText(EmailFld, validEmailID, "Email");
		EmailFld.sendKeys(Keys.RETURN);

	}
	
	//Verifying confirm email field
	public void verifyConfirmEmailTxtFld(String invalidConfirmEmailID, String validConfirmEmailID) {
		EnterText(ConfirmEmailFld, invalidConfirmEmailID, "Confirm Email");
		ConfirmEmailFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(emailsNotMatch_VldtnMsg, emailsNotMatch_VldtnMsg.getText());
		EnterText(ConfirmEmailFld, validConfirmEmailID, "Confirm Email");
		ConfirmEmailFld.sendKeys(Keys.RETURN);
	}
	
	//Verifying mobile phone field
	public void verifyMobilePhoneTxtFlds(String invalidMobileNumb, String validMobileNumb, String invalidConfirmMoblNumb, String validConfirmMoblNumb) {
		EnterText(mobilePhoneFld, invalidMobileNumb, "Mobile Phone");
		mobilePhoneFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(phoneNumb_VldtnMsg, phoneNumb_VldtnMsg.getText());
		EnterText(mobilePhoneFld, validMobileNumb, "Mobile Phone");
		mobilePhoneFld.sendKeys(Keys.RETURN);
		EnterText(confirmMobileNumbFld, invalidConfirmMoblNumb, "Confirm Mobile Phone");
		confirmMobileNumbFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(numbersNonMatch_VldtnMsg, numbersNonMatch_VldtnMsg.getText());
		EnterText(confirmMobileNumbFld, validConfirmMoblNumb, "Confirm Mobile Phone");
		confirmMobileNumbFld.sendKeys(Keys.RETURN);
	}
	
	//Verifying security question section
	public void verifySecurityQstn(String secQstn, String secAns) throws InterruptedException {
	//	assertElementDisplayed(SecurityQuestionHeader, SecurityQuestionHeader.getText()+ " Header");
		ComboSelectVisibleText(selectQstn, secQstn, "Security Question");
		EnterText(SecAnswer, secAns, "Security Answer");
		SecAnswer.sendKeys(Keys.RETURN);
		assertElementDisplayed(CommonValidationMsg, CommonValidationMsg.getText());
		ClickElement(checkBox, "Check Box");
		
	}
	
	//Verifying terms links 
	public void verifyTermsLinks() throws InterruptedException {
		int termsCount = termsLinks.size();
		for (int i = 0; i < termsCount; i++) {
			termsLinks.get(i).click();
			System.out.println(termsLinks.get(i).getText());
			Thread.sleep(1000);
			Iterator<String> windows = driver.getWindowHandles().iterator();
			String parent = windows.next();
			String child = windows.next();
			driver.switchTo().window(child);
			Thread.sleep(2000);
			assertElementDisplayed(termsLinkHeader, termsLinkHeader.getText() + " Header");
			takeScreenshot(termsLinkHeader.getText() + " Page");
			driver.close();
			driver.switchTo().window(parent);
		}
	}
	
	//Verifying successfully registered message
	public void verifySuccessfullRegistration() throws InterruptedException {
		ClickElement(Reg_SubmitBtn, "Submit Button");
		Thread.sleep(2000);
		assertElementDisplayed(congratsHeader, "congratulations Header");
		takeScreenshot("Successfully Registered page");
		assertElementDisplayed(RegstdInfo, RegstdInfo.getText()+ " Info Message");
		extentTest.log(Status.PASS, "Registration process is implemented as expected and Working successfully");
	}
	
	//Advisor Registration for Existing user
	//Verifying user is already registered to other sites actions
	public void verifyUserRegisteredToOtherSites() {
		assertElementDisplayed(AlreadyRegistredInfoMsg, AlreadyRegistredInfoMsg.getText() + " Info Message");
		assertElementDisplayed(webSitesListRegistered, "Registered to " + webSitesListRegistered.getText());
		assertElementDisplayed(existingUsrPwdHeader, existingUsrPwdHeader.getText() + " Header");
		ClickElement(Reg_SubmitBtn, "Submit Button");
		assertElementDisplayed(CommonValidationMsg, CommonValidationMsg.getText() + " Validation Message");
		takeScreenshot("User is already registered to other sites");
	}
	
	//Verify existing user id and password fields actions
	public void verifyExistingUserIDPwdFlds(String invalidExstngUsrID, String invalidExstngPwd, String validExstngUsrID, String validExstngPwd) throws InterruptedException {
		EnterText(existingUserIDFld, invalidExstngUsrID, "User ID");
		EnterText(existingPwdFld, invalidExstngPwd, "Password");
		ClickElement(Reg_SubmitBtn, "Submit Button");
		assertElementDisplayed(weAreSorryInfoMsg, weAreSorryInfoMsg.getText()+ "Validation Message");
		takeScreenshot("Verify existing user id and password with validations");
		EnterText(existingUserIDFld, validExstngUsrID, "User ID");
		EnterText(existingPwdFld, validExstngPwd, "Password");
	}
	
	
	//Broker/Dealer Registration for new user actions
	public void verifyBrokerDealerRegistrationProcess(String invalidTaxID, String validTaxID, String invalidFirmProdID,
			String validFirmProdID, String firstName, String lastName, String CreateOrUse ) throws InterruptedException {
		assertElementDisplayed(BrkrDlrRegInstructionsHeader, BrkrDlrRegInstructionsHeader.getText()+ " Header");
		assertElementDisplayed(reg_NxtBtn,reg_NxtBtn.getText()+ "button");
		ClickElement(reg_NxtBtn, "Next Button");    
		assertElementDisplayed(FirmInfoHeader, FirmInfoHeader.getText()+ " Header");
		EnterText(BrkrDlr_TaxIDFld, invalidTaxID, "Broker/Dealer Firm Tax ID");
		BrkrDlr_TaxIDFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(taxID_VldtnMsg, taxID_VldtnMsg.getText()+" Validation Message");
		EnterText(BrkrDlr_TaxIDFld, validTaxID, "Broker/Dealer Firm Tax ID");
		EnterText(FirmProdIDFld, invalidFirmProdID, "Broker/Dealer Firm Producer ID");
		FirmProdIDFld.sendKeys(Keys.RETURN);
		assertElementDisplayed(incorrectInfo_VldtnMsg, incorrectInfo_VldtnMsg.getText()+" Validation Message");
		takeScreenshot("Broker or Dealer Registration for new user - With validations");
		EnterText(FirmProdIDFld, validFirmProdID, "Broker/Dealer Firm Producer ID");
		ClickElement(reg_NxtBtn, "Next Button");
		assertElementDisplayed(EntrInfoHeader, EntrInfoHeader.getText()+" Header");
		EnterText(FirstNameFld, firstName, "First Name");
		EnterText(LastNameFld, lastName, "Last Name");
		ClickElement(reg_NxtBtn, "Next Button");
		assertElementDisplayed(AuthenticatedInfo, AuthenticatedInfo.getText()+ " Authenticated Info Message");
		String xpath = "//td//label[contains(text(),' "+CreateOrUse+"')]";
		WebElement NeworExstng = driver.findElement(By.xpath(xpath));
		ClickElement(NeworExstng, "Create/Use the Credentials Option");
		ClickElement(reg_NxtBtn, "Next Button");		
	}
	
	//Broker/Dealer Registration for existing user actions
	public void verifyUserisRegistered() {
		assertElementDisplayed(RegstrdUsrInfoMsg, RegstrdUsrInfoMsg.getText()+ " Info Message");
	}
	
	//Associate Registration for new user actions
	public void verifyAssociateRegistrationFlow(String prodID, String invalidAccessCode, 
			String validAccessCode, String CreateOrExstng) throws InterruptedException {
		assertElementDisplayed(EntrProdIDAccssCodeHeader, EntrProdIDAccssCodeHeader.getText()+ " Header");
		EnterText(AS_ProdIDFld, prodID, "Producer ID");
		EnterText(AS_AcsCodeFld, invalidAccessCode, "Access Code");
		ClickElement(reg_NxtBtn, "Next Button");
		Thread.sleep(2000);
		assertElementDisplayed(incorrectInfoMsg, incorrectInfoMsg.getText()+" Validation Message");
		takeScreenshot("Associate Registration for new user-Invalid access code validation");
		EnterText(AS_AcsCodeFld, validAccessCode, "Access Code");
		ClickElement(reg_NxtBtn, "Next Button");
		Thread.sleep(2000);
		assertElementDisplayed(AuthenticatedInfo, AuthenticatedInfo.getText()+ " Authenticated Info Message");
		String xpath = "//td//label[contains(text(),' "+CreateOrExstng+"')]";
		WebElement NeworExstng = driver.findElement(By.xpath(xpath));
		ClickElement(NeworExstng, "Create/Use the Credentials Option");
		ClickElement(reg_NxtBtn, "Next Button");
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
