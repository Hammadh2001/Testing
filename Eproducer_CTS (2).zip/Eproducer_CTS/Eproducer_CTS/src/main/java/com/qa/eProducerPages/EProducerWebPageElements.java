package com.qa.eProducerPages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.utils.GenericFunction;

public class EProducerWebPageElements extends GenericFunction{
	
	public EProducerWebPageElements() {
		super();
		PageFactory.initElements(driver, this);
	}

//WebElements of eProducer application
	//Login Page elements new
	@FindBy(xpath= "//input[@aria-label='User ID']") public WebElement UserNameTxtFldnew;
	@FindBy(xpath = "//input[@aria-label='Password']") public WebElement PasswordTxtFldnew;
	@FindBy(xpath = "(//button[@role='button'])[3]") public WebElement LoginBtnnew;
//	@FindBy(xpath = "(//div[@role='button'])[3]") public WebElement LoginBtnnew;
	@FindBy(xpath = "(//h2[text()='eProducer']//following::button[@role='button'])[1]") public WebElement eProducerlinknew;
	@FindBy(xpath = "//div[text()='CREATE AN ACCOUNT']") public WebElement CreateAcc;
	@FindBy(xpath = "//h1[contains(text(),'Log in to your account')]") public WebElement loginHdr;
	@FindBy(xpath = "//button[contains(@aria-label,'Create An Account Button')]") public WebElement createYourAccBtn;
	//@FindBy(xpath = "//div[contains(@aria-label,'Create An Account Button') and @role='button']") public WebElement createYourAccBtn;
//Login Page elements
//@FindBy(id= "username2") public WebElement UserNameTxtFld;
	@FindBy(xpath = "//input[@id='username2']") public WebElement UserNameTxtFld;
@FindBy(id = "password2") public WebElement PasswordTxtFld;
@FindBy(id = "oktaSignIn2") public WebElement LoginBtn;
//Common home page web elements
//@FindBy(xpath = "//div//h2[contains(text(),'logged')]") public WebElement infoHeaderLogged;
@FindBy(xpath = "//h3[contains(text(),'Navigate to Other Portals')]") public WebElement infoHeaderLogged;
@FindBy(xpath = "//div[@id='globalnav']//form//a[contains(text(),'Logout')]") public WebElement Logoutlink;
@FindBy(xpath = "//div[@id='messageContainer2']/strong[contains(text(),'Thank you')]") public WebElement LogoutSuccessMsg;
@FindBy(xpath = "//div[@id='content']//h1[contains(text(),'Welcome')]") public WebElement eProducerPageHeader;
@FindBy(xpath = "//div[@id='content']/h1[contains(text(),'Plan List')]") public WebElement PlanListHeader;
@FindBy(xpath = "//div[@id='content']//p/a/img[contains(@title,'Download')]") public WebElement DownloadIcon;
@FindBy(xpath = "//div[@id='content']//p//img[contains(@title,'Print')]") public WebElement PrintIcon;
@FindBy(xpath = "//div/span/select") public WebElement DisplayList;
@FindBy(xpath = "//div[@class='js-fp-main']//li/a[contains(text(),'eProducer')]") public WebElement eProducerAppLink;
//Search a plan web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[text()='Plan/Participant']") public WebElement PlanParticipantMenu;
@FindBy(xpath = "//a[text()='Loan Calculator']") public WebElement loancalculatorlink;
@FindBy(xpath="//label[contains(text(),'Is this loan for purchasing a primary residence?')]") public WebElement residentialloan;
@FindBy(xpath="//input[@id='requestForm:j_id_jsp_352010711_45pc6']") public WebElement residentialloan_duration_yes;
@FindBy(xpath = "//h2[text() = 'Loan Calculator']") public WebElement loancalculateheader;
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[text()='Plan/Participant Data']") public WebElement PlanParticipantDataSubmenu;
@FindBy(xpath = "//div[@id='content']//h1[contains(text(),'Search')]") public WebElement SearchHeader;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'Info')]") public WebElement PlanInfoSearchHeader;
@FindBy(xpath = "//td/select[@id='searchOmni:matchField']") public WebElement selectSearchBy;
@FindBy(xpath = "//div[@id='content']//td/input[@id='searchOmni:matchValue']") public WebElement CriteriaTxtFld;
@FindBy(xpath = "//form[@id='searchOmni']//td/input[@id='searchOmni:searchButton']") public WebElement PlanSearchBtn;
@FindBy(xpath = "//span[text()='Participant List']") public WebElement ParticipantSearchBtn;
@FindBy(xpath = "//form[@id='searchOmni']//td//select[@id='searchOmni:matchLike']") public WebElement selectMtchng; 
@FindBy(xpath = "//div//li[contains(text(),'unavailable')]") public WebElement infoMsgPlanUnavailable;
@FindBy(xpath = "//form[@id='dataTableForm']//tr[1]//td[1]/a") public WebElement linkProdName;
@FindBy(xpath = "//div/h1[contains(text(),'Prod')]") public WebElement headerProdList;
@FindBy(xpath = "//div/h1[contains(text(),'Plan')]") public WebElement headerPlanList;

//View HO User PPR Status test case web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[text()='Sales']") public WebElement SalesMenu;
@FindBy(xpath = "//div[@id='primarynav']/form//li//a[contains(text(),'Presentations')]") public WebElement PresentationsAndMaterialsSubmenu;
@FindBy(xpath = "//div[@id='content']//h1[contains(text(),'Materials')]") public WebElement PrsntnsandMtrlsHeader;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'Periodic')]") public WebElement PeriodicPlanReviewHeader;
@FindBy(xpath = "//div[@id='content']//ul//li/a[contains(text(),'PPR Status')]") public WebElement PPRStatusLink;
@FindBy(xpath = "//div[@id='content']/h1[contains(text(),'Status')]") public WebElement PPRStatusHeader;
@FindBy(xpath = "//div[@id='content']//td/select[@id='aprInquiry:budgetCode']") public WebElement BudgetCodeList;
@FindBy(xpath = "//form[@id='aprInquiry']//td/input[@id='aprInquiry:fromDate']") public WebElement PPR_FromDateTxtFld;
@FindBy(xpath = "//form[@id='aprInquiry']//td/input[@id='aprInquiry:aprInquirySearch']") public WebElement SearchBtn;
@FindBy(xpath = "//form[@id='aprInquiryTable']//th/a[contains(text(),'Plan')]") public WebElement PlanCol;
@FindBy(xpath = "//form[@id='aprInquiryTable']//th/a[contains(text(),'Submit')]") public WebElement SubmitDate;
@FindBy(xpath = "//form[@id='aprInquiryTable']//th/a[text()='Status']") public WebElement StatusCol;
@FindBy(xpath = "//form[@id='aprInquiryTable']//th/a[text()='Status Date']") public WebElement StatusDateCol;
@FindBy(xpath = "//form[@id='aprInquiryTable']//th/a[text()='Order Number']") public WebElement OrderNumbCol;
@FindBy(xpath = "//form[@id='aprInquiryTable']//th[text()='Action']") public WebElement ActionCol;
@FindBy(xpath = "//form[@id='aprInquiryTable']//div/input[@value='Submit']") public WebElement PPR_SubmitBtn;
//Transaction Summary test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[contains(text(),'Transaction Summary')]") public WebElement TransactionSummaryLink;
@FindBy(xpath = "//div[@id='content']/h1[contains(text(),'Transaction')]") public WebElement TransactionSummaryHeader;
@FindBy(xpath = "//form[@id='transSummaryReports']//li/a[contains(text(),'Quarterly')]") public WebElement QurterlyReportsLink;
@FindBy(xpath = "//form[@id='transSummaryReports']//li/a[contains(text(),'Annual')]") public WebElement AnnualReportsLink;
@FindBy(xpath = "//div[@id='content']//h1") public WebElement TrscnSumryForPlanHeader;
@FindBy(xpath = "//form[@id='formTable']//a[contains(text(),'Title')]") public WebElement TitleHeader;
@FindBy(xpath = "//form[@id='formTable']//a[contains(text(),'Quarter')]") public WebElement QuarterReportLink;
@FindBy(xpath = "//div[@id='content']//p[contains(text(),'There')]") public WebElement NoReportsMsg;
//Loan Summary test case web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[text()='Loan Center']") public WebElement LoanCenterSubmenu;
@FindBy(xpath = "//ul[@id='sideNavMenu']//li//a[contains(text(),'Loan Center')]//following::a[text()='Loan Summary']") public WebElement LoanSummaryLink;
@FindBy(xpath = "//div[@id='content']//h1[contains(text(),'Loan')]") public WebElement LoanSummaryHeader;
@FindBy(xpath = "//form[@id='dataTable']//a/span[text()='Division']") public WebElement DivisonCol;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement LoanHistoryHeader;
@FindBy(xpath = "//div[@id='content']//th[contains(text(),'Loan Number')]") public WebElement LoanNumberCol;
@FindBy(xpath = "//div[@id='content']//th[contains(text(),'Payment Date')]") public WebElement PaymentDateCol;
@FindBy(xpath = "//div[@id='content']//th[contains(text(),'Payment Amount')]") public WebElement PaymentAmountCol;
@FindBy(xpath = "//div[@id='content']//th[contains(text(),'Principal Paid')]") public WebElement PrincipalPaidCol;
@FindBy(xpath = "//div[@id='content']//th[contains(text(),'Interest Paid')]") public WebElement InterestPaidCol;
@FindBy(xpath = "//div[@id='content']//th[contains(text(),'Loan Balance')]") public WebElement LoanBalanceCol;
@FindBy(xpath = "//div[@id='content']//h2") public WebElement NoPaymentHistoryInfo;
//Loan Documents test case web elements
@FindBy(xpath = "//div[@id='sidenav']//ul/li/a[contains(text(),'Loan Doc')]") public WebElement sideMenuLoanDocs;
@FindBy(xpath = "//div[@id='sidenav']//ul//li/form/a[contains(text(),'Loan Repay')]") public WebElement linkLoanRepayment;
@FindBy(xpath = "//div[@id='sidenav']//ul//li/form/a[contains(text(),'Note')]") public WebElement linkPromisoryNote;
//Download investment performance test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[contains(text(),'Performance')]") public WebElement PerformanceLink;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement InvstmntPrfrmncHeader;
//Beneficiary designation Report test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[contains(text(),'Beneficiary')]") public WebElement PrtcpntBeneficiaryDsgnLink;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement PrtcptBeneficiaryDsgnHeader;
@FindBy(xpath = "//form[@id='formFilter']//select[@id='formFilter:designationFilter']") public WebElement SelectDsgnList;
@FindBy(xpath = "//form[@id='formTable']//th/a[contains(text(),'Name')]") public WebElement PrtcptNameCol;
@FindBy(xpath = "//form[@id='formTable']//th/a[contains(text(),'SSN')]") public WebElement SSNCol;
@FindBy(xpath = "//form[@id='formTable']//th/a[contains(text(),'Date')]") public WebElement DOBCol;
@FindBy(xpath = "//form[@id='formTable']//th/a[contains(text(),'Primary')]") public WebElement PrimaryDsgnCol;
@FindBy(xpath = "//form[@id='formTable']//td//span[contains(@id,'0:designation')]") public WebElement DesignatedLink;
@FindBy(xpath = "//div[@id='content']//h1") public WebElement BeneficiaryInformationHeader;
@FindBy(xpath = "//form[@id='frmMain']//input[@value='Cancel']") public WebElement CancelBtn;
//Investment Advisor Support test case web elements
@FindBy(xpath = "//ul[@id='primaryNavMenu']//li[contains(@class,'sub')]/a[text()='Investments']") public WebElement InvestmentMenu;
@FindBy(xpath = "//ul[@id='primaryNavMenu']//li/a[contains(text(),'Investment Ad')]") public WebElement InvsmtAdvisorSupportSubmenu;
@FindBy(xpath = "//div[@id='content']//h1") public WebElement InvsmtAdvsrSuprtHeader;
@FindBy(xpath = "//div[@id='content']//p/a") public List<WebElement> InvsmtAdvsrSupLinks;
//Important Documents test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//ul/li/a[text()='Important Documents']") public WebElement ImportantDocsLink; 
@FindBy(xpath = "//div[@id='content']//h1") public WebElement ImportantDocsHeader;
@FindBy(xpath = "//form[@id='importantPlanDocs']/ul/li/a[contains(text(),'Documents')]") public WebElement PlanDocLink;
@FindBy(xpath = "//form[@id='importantPlanDocs']/ul/li/a[contains(text(),'Descriptions')]") public WebElement SummaryPlanDescrpLink;
@FindBy(xpath = "//form[@id='importantPlanDocs']/ul/li/a[contains(text(),'Contract')]") public WebElement ContractLink;
@FindBy(xpath = "//div[@id='content']/h1/span") public WebElement DocLinkHeader;
@FindBy(xpath = "//form[@id='importantPlanDocs']/ul/li/a") public WebElement DocLinkInPlanDocuments;
@FindBy(xpath = "//form[@id='formTable']//td[contains(text(),'Adobe Acrobat')]//preceding::td[1]/a") public WebElement FeeeDisclosureLink;
@FindBy(xpath = "//div[@id='content']/ul/li[contains(text(),'No')]") public WebElement NoDocsInfoMsg;
@FindBy(xpath = "//form[@id='importantPlanDocs']/p/input[@value='Previous']") public WebElement PreviousBtn;
//View current investment model test case web elements
@FindBy(xpath = "//ul[@id='sideNavMenu']//li/a[contains(text(),'Plan')]") public WebElement PlanSetUpandMaintenanceLink;
@FindBy(xpath = "//div[@id='content']//h1") public WebElement AdvisorSearchHeader;
@FindBy(xpath = "//form[@id='searchForm']//td/input[@id='searchForm:matchValue']") public WebElement Advsr_Criteria;
@FindBy(xpath = "//form[@id='searchForm']//td/input[@id='searchForm:buttonSearch']") public WebElement Advsr_SearchBtn;
@FindBy(xpath = "//div[@id='content']//h1[contains(text(),'Plan')]") public WebElement PlanSetUpandMaintenanceHeader;
@FindBy(xpath = "//div[@id='content']//p[contains(text(),'Select')]") public WebElement SelectaPlanInfo;
@FindBy(xpath = "//form[@id='planSetupForm']//td/a[contains(text(),'Models')]") public WebElement InvestmentModelsLink;
@FindBy(xpath = "//div[@id='content']//h1") public WebElement InvsmtModelHeader;
@FindBy(xpath = "//form[@id='maintPlanForm']//td//a") public WebElement ModelNameLink;
@FindBy(xpath = "//div[@id='content']//h1") public WebElement InvsmtModelSetupHeader;
@FindBy(xpath = "//form[@id='modelNameForm']//h2") public WebElement ModelInfoHeader;
@FindBy(xpath = "//form[@id='modelNameForm']//td/label[contains(text(),'Model Name')]") public WebElement ModelNameLabel;
@FindBy(xpath = "//form[@id='modelNameForm']//td/label[contains(text(),'Model Narrative')]") public WebElement ModelNarrativeLabel;
@FindBy(xpath = "//form[@id='modelNameForm']//td/input") public WebElement Editbtn;
@FindBy(xpath = "//form[@id='modelSetup1Form']//h2") public WebElement InvsmtModandNartivHeader;
@FindBy(xpath = "//form[@id='modelSetup1Form']//td/textarea[@id='modelSetup1Form:desc']") public WebElement NarrativeTextArea;
@FindBy(xpath = "//form[contains(@id,'model')]//p/input[@value='Next']") public WebElement NextBtn;
@FindBy(xpath = "//div[@id='content']/ul/li/span") public WebElement GlobalErrorInfo;
@FindBy(xpath = "//div[@id='content']/ul/li/span[contains(text(),'This')]") public WebElement NoPlanSetupRqd;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'No')]") public WebElement NoResultsInfo;
@FindBy(xpath = "//div[@id='content']//h1[contains(text(),'No')]") public WebElement infoMsgNoResultsFound;

//Recurring Re-balance test case web elements
@FindBy(xpath = "//form[@id='planSetupForm']//td/a[contains(text(),'Rebal')]") public WebElement linkRecurringReblnc;
@FindBy(xpath = "//div[@id='content']//h1[contains(text(),'Rec')]") public WebElement headerRecurringReblnc;
@FindBy(xpath = "//div[@id='content']//li[1]") public WebElement step1SlctFrqncy;
@FindBy(xpath = "//div[@id='content']//li[2]") public WebElement step2ReblncReview;
@FindBy(xpath = "//div[@id='content']//li[3]") public WebElement step3ReblncComplete;
@FindBy(xpath = "//form[@id='planRebalForm']//h2") public WebElement headerFrequencyOfRebal;
@FindBy(xpath = "//form[@id='planRebalForm']//label[contains(text(),'Quarterly')]") public WebElement labelQuarterly;
@FindBy(xpath = "//form[@id='planRebalForm']//label[contains(text(),'Semi')]") public WebElement labelSemiAnual;
@FindBy(xpath = "//form[@id='planRebalForm']//label[text()=' Annually']") public WebElement labelAnnually;
@FindBy(xpath = "//form[@id='planRebalForm']//label[contains(text(),'auto')]") public WebElement labelNoAutomatic;
@FindBy(xpath = "//form[@id='planRebalForm']//p//input[@value='Next']") public WebElement btnRebalNext;
@FindBy(xpath = "//div//p[contains(text(),'Please review')]") public WebElement txtInfoReview;
@FindBy(xpath = "//form[@id='planRebalForm']//div") public WebElement txtFrqncySelected;
@FindBy(xpath = "//form[@id='planRebalForm']//p//input[@value='Submit']") public WebElement btnRebalSubmit;
@FindBy(xpath = "//div//p[contains(text(),'successfully received')]") public WebElement txtInfoSuccessfull;
@FindBy(xpath = "//div//p//input[@id='planRebalForm:planSetup']") public WebElement btnPlanSetup;

//Investor Profile Questionnaire test case web elements
@FindBy(xpath = "//form[@id='planSetupForm']//td/a[contains(text(),'Investor')]") public WebElement linkInvestorPrflQstnre;
@FindBy(xpath = "//div[@id='content']//h1[contains(text(),'Inv')]") public WebElement headerInvstrPrflQstnre;
@FindBy(xpath = "//div[@id='content']//li[1]") public WebElement step1InvstrQstnre;
@FindBy(xpath = "//div[@id='content']//li[2]") public WebElement step2QstnreReview;
@FindBy(xpath = "//div[@id='content']//li[3]") public WebElement step3QstnreComplete;
@FindBy(xpath = "//form[@id='rtqForm']//h2[contains(text(),'Set')]") public WebElement headerQstnreSetup;
@FindBy(xpath = "//form[@id='rtqForm']//h2[contains(text(),'weights')]") public WebElement headerQstnreWeights;
@FindBy(xpath = "//form[@id='rtqForm']//label[contains(text(),'equal')]") public WebElement optionEqualQstnWeights;
@FindBy(xpath = "//form[@id='rtqForm']//label[contains(text(),'Customize')]") public WebElement optionCustomizeQstnWeights;
@FindBy(xpath = "//form[@id='rtqForm']//label[contains(text(),'Do not')]") public WebElement optionDoNotDisplayQstnWeights;
@FindBy(xpath = "//form//p//input[@value='Next']") public WebElement btnInvstrQstnreNext;
@FindBy(xpath = "//form[@id='rtqForm']//table//span/input[contains(@id,'rtqForm')]") public List<WebElement> txtFldQstnWeights;
@FindBy(xpath = "//div[@id='content']//li/span[contains(text(),'invalid')]") public WebElement errorMsgInvalidEntry;
@FindBy(xpath = "//div[@id='content']//li/span[contains(text(),'multiple')]") public WebElement infoMsgMultipleScoreOf5;
@FindBy(xpath = "//form//p//input[@value='Submit']") public WebElement btnInvstrQstnreSubmit;
@FindBy(xpath = "//form[@id='rtqForm']//h2") public WebElement headerWithSelectedOption;
@FindBy(xpath = "//form//input[@id='buttonForm1:buttonPlanSetup1']") public WebElement btnRtrnPlanSetup;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'changing')]") public WebElement headerASChangingWeights;
@FindBy(xpath = "//div//p/span[contains(text(),'not display')]") public WebElement infoMsgQstnsNotDisplay;



//View Investments test case web elements
@FindBy(xpath = "//div[@id='content']//li[1]") public WebElement Step1ModelName;
@FindBy(xpath = "//div[@id='content']//li[2]") public WebElement Step2ModelAllocations;
@FindBy(xpath = "//div[@id='content']//li[3]") public WebElement Step3Review;
@FindBy(xpath = "//div[@id='content']//li[3]") public WebElement Step4Complete;
@FindBy(xpath = " //form[@id='maintPlanForm']//p/input[contains(@value,'Add')]") public WebElement AddAnotherModelBtn;
@FindBy(xpath = "//input[@id='modelSetup1Form:name']") public WebElement ModelNameTxtFld;
@FindBy(xpath = "//textarea[@id='modelSetup1Form:desc']") public WebElement ModelNarrativeTxtFld;
@FindBy(xpath = "//form[@id='modelAlloc']/h2") public WebElement IOEsHeader;
@FindBy(xpath = "//form[@id='modelAlloc']//tr[1]//td[2]/input[contains(@name,'invAlloc')]") public WebElement AllocTxtBox;
@FindBy(xpath = "//form[@id='modelAlloc']//tr[1]//td[2]/input[contains(@name,'reallocPercent')]") public WebElement TotalAlloctnPercntg;
@FindBy(xpath = "//form[@id='modelAlloc']//p/input[@value='Next']") public WebElement AllocNextBtn;
@FindBy(xpath = "//div[@id='content']//p/input[@value='Submit']") public WebElement AllocSubmitBtn;
@FindBy(xpath = "//div[@id='content']//li/span") public WebElement InfoMsg;
@FindBy(xpath = "//div[@id='content']//p//input[@value='Continue Model Setup']") public WebElement ContModSetupBtn;
@FindBy(xpath = "//div[@id='content']//p//input[@value='Models Complete - Submit for Review']") public WebElement ModelsCompleteBtn;

//My Profile test case web elements
@FindBy(xpath = "//ul[@id='globalNavMenu']//li/a[contains(text(),'My')]") public WebElement MyProfileLink;
@FindBy(xpath = "//div[@id='content']//form[@id='passwordInfoForm']/a") public WebElement SecAccsSettingsLink;
@FindBy(xpath = "//div[@id='content']//form[@id='producerForm']/a") public WebElement ProdCommisnAccsLink;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement MyProfileHeader;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement CommAccssHeader;
@FindBy(xpath = "//div[@id='content']/h2") public WebElement CommissionLevelsHeader;
@FindBy(xpath = "//form[@id='accessForm']//td/input[@id='accessLevel1']") public WebElement FulAccessRadioBtn;
@FindBy(xpath = "//form[@id='accessForm']//p//input[@value='Update']") public WebElement UpdateBtn;
@FindBy(xpath = "//div[@id='content']//p/span")  public WebElement CommAccssChangeInfoMsg;

//Save Add Associates Data test case web elements 
@FindBy(xpath = "//div[@id='content']//form[@id='associateForm']/a") public WebElement MaintainAssociateAccsLink;
@FindBy(xpath = "//div[@id='content']/form/h1") public WebElement MaintainAssociateAccessHeader;
@FindBy(xpath = "//div[@id='content']//p/input[@value='Add Associate']") public WebElement AddAssociateBtn;
@FindBy(xpath = "//div//h2[contains(text(),'Enter')]") public WebElement headerEnterInfo;
@FindBy(xpath = "//div//span/input[@id='form:firstName']") public WebElement txtldAAFirstName;
@FindBy(xpath = "//div//span/input[@id='form:lastName']") public WebElement txtldAALastName;
@FindBy(xpath = "//div//input[@id='form:emailAddress']") public WebElement txtldAARegEmail;
@FindBy(xpath = "//select[@id='form:commissions']") public WebElement selectAccessLevel;
@FindBy(xpath = "//div//p/input[@value='Submit']") public WebElement btnAASubmit;
@FindBy(xpath = "//div//p/input[@value='Cancel']") public WebElement btnAACancel;
@FindBy(xpath = "//div//li/span[contains(text(),'invalid')]") public WebElement vldtnMsgpageLevelError;
@FindBy(xpath = "//div//span[contains(text(),'Value')]") public WebElement vldtnMsgValRqrd;
@FindBy(xpath = "//div//span[contains(text(),'E-mail')]") public WebElement vldtnMsgValidEmailAdrs;
@FindBy(xpath = "//div//ul/li[contains(text(),'sent')]") public WebElement infoMsgAcsCodeSent;

//Edit Associates page navigation test case web elements
@FindBy(xpath = "//div[@id='content']//h2") public WebElement CurrentAssociateHeader;
@FindBy(xpath = "//form[@id='delegateForm']//table//tbody//tr[1]//td[6]/a[text()='Edit']") public WebElement EditLink;
@FindBy(xpath = "//div[@id='content']/form/h1") public WebElement EditAssociateHeader;
@FindBy(xpath = "//div[@id='content']/form/h2") public WebElement EditAssociateInfoHeader;

//Delete Associates feature test case web elements 
@FindBy(xpath = "//form[@id='delegateForm']//table//tbody//tr[1]//td[6]/a[text()='Delete']") public WebElement linkAsctDelete;
@FindBy(xpath = "//div//li[contains(text(),'success')]") public WebElement infoMsgDeletionSuccess;

//View Participant Data test case web elements
@FindBy(xpath = "//ul[@id='sideNavMenu']//li/a[contains(text(),'List')]") public WebElement ParticipantListLink;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement ParticipantListHeader;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement ViewPrtcpntDataHeader;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'Data')]") public WebElement PersonalDataHeader;
@FindBy(xpath = "//div[@id='content']//table//td/label[contains(text(),'Name')]") public WebElement NameLabel;
@FindBy(xpath = "//div[@id='content']//table//td/label[@for='partPlan']") public WebElement PlanNumberLabel;
@FindBy(xpath = "//div[@id='content']//table//td/label[@for='status']") public WebElement StatusLabel;
@FindBy(xpath = "//div[@id='content']//table//td/label[@for='SSN']") public WebElement SSNLabel;
@FindBy(xpath = "//div[@id='content']//table//td/label[@for='employmentDate']") public WebElement EmploymentDateLabel;
@FindBy(xpath = "//div[@id='content']//table//td/label[@for='division']") public WebElement DivisionLabel;
@FindBy(xpath = "//div[@id='content']//table//td/label[@for='dateofBirth']") public WebElement DateofBirthLabel;
@FindBy(xpath = "//div[@id='content']//table//td/label[@for='email']") public WebElement EmailLabel;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'Advisor')]") public WebElement InvstmntAdvsrInfoHeader;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'Source')]") public WebElement SourceInfoHeader;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'Balance')]") public WebElement AcctBalncHeader;

//Participant Summary Report test case web elements
@FindBy(xpath = "//ul[@id='sideNavMenu']//li/a[contains(text(),'Summary Repo')]") public WebElement sideMenuPrtcpnSummaryReport;
@FindBy(xpath = "//div/h1[contains(text(),'Sum')]") public WebElement headerPrtcpntSummary;
@FindBy(xpath = "//form[@id='partSummaryRpt']//td//a") public List<WebElement> linkPrtcpntSumryReports;

//Historical Feedback file test case web elements 
@FindBy(xpath = "//ul[@id='sideNavMenu']//li/a[contains(text(),'His')]") public WebElement HistoricalFeedbackFileLink;
@FindBy(xpath = "//div[@id='content']/form/h1") public WebElement HistoricalFeedbackFileHeader;
@FindBy(xpath = "//form[@id='form']//h2[contains(text(),'Please')]") public WebElement PlsSlecActvtyHeader;
@FindBy(xpath = "//form[@id='form']//h2[contains(text(),'Date')]") public WebElement SelcDateRangeHeader;
@FindBy(xpath = "//form[@id='form']//h2[contains(text(),'Search')]") public WebElement PrtcpntSearchCriteriaHeader;
@FindBy(xpath = "//form[@id='form']//h2[contains(text(),'division')]") public WebElement SelcDivisonHeader;
@FindBy(xpath = "//input[@id='form:submitBtn']") public WebElement HFF_SubmitBtn;
@FindBy(xpath = "//td//input[@id='form:startDate']") public WebElement FromDate;
@FindBy(xpath = "//td//input[@id='form:endDate']") public WebElement ToDate;
@FindBy(xpath = "//td/input[@type='checkbox']") public List<WebElement> checkBoxes;
//Participant Account Activity test case web elements 
@FindBy(xpath = "//form[@id='navMenuForm']//ul//li/a[text()='Account Activity']")  public WebElement sideMenuAccountActivity;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement PrtcpntAcctActvtyHeader;
@FindBy(xpath = "//form[@id='requestForm']/h2") public WebElement AcctActivityHeader;
@FindBy(xpath = "//td/input[@value='Submit']") public WebElement Act_SubmitBtn;
@FindBy(xpath = "//td/input[@id='requestForm:fromDate']") public WebElement Act_fromDate;
@FindBy(xpath = "//td/input[@id='requestForm:toDate']") public WebElement Act_toDate;
@FindBy(xpath = "//div//h2[contains(text(),'Contribution')]") public WebElement ContributionSourceHeader;
@FindBy(xpath = "//form//table//th[text()='Source']") public WebElement SourceColHeader;
@FindBy(xpath = "//form//th[text()='Source']//following-sibling::th[contains(text(),'Beg')]") public WebElement BgngBalColHeader;
@FindBy(xpath = "//form//th[text()='Source']//following-sibling::th[contains(text(),'Cont')]") public WebElement ContrbtnColHeader;
@FindBy(xpath = "//form//th[text()='Source']//following-sibling::th[contains(text(),'Invest')]") public WebElement InvstGainColHeader;
@FindBy(xpath = "//form//th[text()='Source']//following-sibling::th[contains(text(),'End')]") public WebElement EndingBalColHeader;
@FindBy(xpath = "//div//h2[contains(text(),'Investment')]") public WebElement InvestmentOptionHeader;
@FindBy(xpath = "//form//th[contains(text(),'Option')]") public WebElement InvstOptnColHeader;
@FindBy(xpath = "//form//th[contains(text(),'Option')]//following-sibling::th[contains(text(),'Add')]") public WebElement OthrAddColHeader;
@FindBy(xpath = "//form//th[contains(text(),'Option')]//following-sibling::th[contains(text(),'Out')]") public WebElement TrnsfrColHeader;
//Re-balance Account test case web elements 
@FindBy(xpath = "//div/span//select") public WebElement displayList;
@FindBy(xpath = "//ul[@id='sideNavMenu']//li/a[contains(text(),'Reba')]") public WebElement RebalanceAccountLink;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement RebalancingTrnsfrHeader;
@FindBy(xpath = "//div[@id='content']//li[1]") public WebElement step1MakeTrsnfr;
@FindBy(xpath = "//div[@id='content']//li[2]") public WebElement step2ReviewSelection;
@FindBy(xpath = "//div[@id='content']//li[3]") public WebElement step3Complete;
@FindBy(xpath = "//div[@id='content']//p[contains(text(),'Only one')]") public WebElement instruction1;
@FindBy(xpath = "//div[@id='content']//p[contains(text(),'Transfers will')]") public WebElement instruction2;
@FindBy(xpath = "//div[@id='content']//p[contains(text(),'The investment')]") public WebElement instruction3;
@FindBy(xpath = "//div[@id='content']//h2") public WebElement FrequencyHeader;
@FindBy(xpath = "//div[@id='content']//td/input[@value='One-Time Only']") public WebElement OneTimeOnlyRadioBtn;
@FindBy(xpath = "//div[@id='content']//p/input[@value='Next']") public WebElement RBA_NextBtn;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'Invest')]") public WebElement InvstOptnElctnsHeader;
@FindBy(xpath = "//div[@id='content']//p//input[@value='Submit']") public WebElement SubmitBtn;
@FindBy(xpath = "//div[@id='content']//p[contains(text(),'Your transfer')]") public WebElement SubmissionConfirmMsg;
//Service Agreement and Fee Disclosure test case web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[contains(text(),'Services')]") public WebElement ServicesAgrementsSubmenu;;
@FindBy(xpath = "//div[@id='content']/form/h1") public WebElement SrvcsAgrmtFeeDsclrsHeader;
@FindBy(xpath = "//div[@id='content']//td/a[contains(text(),'Order D')]") public WebElement OrderDocLink;
@FindBy(xpath = "//div[@id='content']//td/a[contains(text(),'Browse')]") public WebElement BrowseOrderLink;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement OrderTypeHeader;
@FindBy(xpath = "//div[@id='content']//li[1]") public WebElement step1OrdrType;
@FindBy(xpath = "//div[@id='content']//li[2]") public WebElement step2OrdrDetails;
@FindBy(xpath = "//div[@id='content']//li[3]") public WebElement step3ReviewOrdr;
@FindBy(xpath = "//div[@id='content']//li[4]") public WebElement step4complete;
@FindBy(xpath = "//form[@id='frmMain']//td/a[contains(text(),'Group')]") public WebElement GroupsAnnuityLink;
@FindBy(xpath = "//form[@id='frmMain']//td/a[contains(text(),'Inforce')]") public WebElement InforceDisLink;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement OrdrDetailsGrpAnnuityHeader;
@FindBy(xpath = "//div[@id='content']//form//h2[contains(text(),'Order')]") public WebElement OrdrConfirmationHeader;
@FindBy(xpath = "//div[@id='content']//form//h2[contains(text(),'Plan')]") public WebElement PlanInfoHeader;
@FindBy(xpath = "//div[@id='content']//form//h2[contains(text(),'Optional')]") public WebElement OptionalSrvcs;
@FindBy(xpath = "//td/input[@id='frmGrpAnnEntry:email']") public WebElement emailAddress;
@FindBy(xpath = "//td/input[@id='frmGrpAnnEntry:planName']") public WebElement planName;
@FindBy(xpath = "//td/input[@id='frmGrpAnnEntry:planNumber']") public WebElement planNumber;
@FindBy(xpath = "//td/select[@id='frmGrpAnnEntry:planType']") public WebElement planType;
@FindBy(xpath = "//td/input[@id='frmGrpAnnEntry:numEligEmp']") public WebElement numbEligblEmps;
@FindBy(xpath = "//td/input[@id='frmGrpAnnEntry:contrib']") public WebElement Annualcontributions;
@FindBy(xpath = "//td/input[@id='frmGrpAnnEntry:assets']") public WebElement TakeOvrAssets;
@FindBy(xpath = "//td/select[@id='frmGrpAnnEntry:fundLineUp']") public WebElement FundLineUp;
@FindBy(xpath = "//td/select[@id='frmGrpAnnEntry:productType']") public WebElement productType;
@FindBy(xpath = "//td/select[@id='frmGrpAnnEntry:firstYrComm']") public WebElement FrstYrCommission;
@FindBy(xpath = "//td/select[@id='frmGrpAnnEntry:trailCommission']") public WebElement trailCommission;
@FindBy(xpath = "//td/select[@id='frmGrpAnnEntry:feesAsComm']") public WebElement advsrCompnstn;
@FindBy(xpath = "//td/select[@id='frmGrpAnnEntry:serviceLevel']") public WebElement serviceLevel;
@FindBy(xpath = "//td/select[@id='frmGrpAnnEntry:tpa']") public WebElement TPAaccess;
@FindBy(xpath = "//td/select[@id='frmGrpAnnEntry:mep']") public WebElement MEP;
@FindBy(xpath = "//input[@id='frmGrpAnnEntry:buttonNext']")  public WebElement GA_NextBtn;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement ReviewGrpAnnuityHeader;
@FindBy(xpath = "//input[@value='Submit']") public WebElement GA_SubmitBtn;
@FindBy(xpath = "//div[@class='panel']/p") public WebElement ConfirmDetails;

//Advisor Fee Report test case web elements
@FindBy(xpath = "//ul[@id='sideNavMenu']//li/a[contains(text(),'Advisor Fee')]") public WebElement AdvisorFeeReportLink;
@FindBy(xpath = "//div[@id='content']/form/h1") public WebElement AdvsrFeeRprtHeader;
@FindBy(xpath = "//div[@id='content']//span/h2") public WebElement yearHeading;
@FindBy(xpath = "//div[@id='content']//span//td/a") public WebElement FeeReportLink;
@FindBy(xpath = "//div[@id='content']//h2") public WebElement NoResultsInfoMsg;

//Participant Auto Enrollment Report test case web elements
@FindBy(xpath = "//ul[@id='sideNavMenu']//li/a[contains(text(),'Auto')]") public WebElement AutoEnrollmenReportLink;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement AutoEnrlmntHeader;
@FindBy(xpath = "//div[@id='content']//h2") public WebElement PrtcpntAutoEnrlmntSearchLabel;
@FindBy(xpath = "//div[@id='content']//p[contains(text(),'No')]") public WebElement NoPrtcpntToReportInfo;

//Address Changes eActivity test case web elements
@FindBy(xpath = "//ul[@id='sideNavMenu']//li/a[contains(text(),'Changes')]") public WebElement AddrsChangeseActivityLink;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement AdrsChngsHeader;
@FindBy(xpath = "//td//select[@id='form:address']") public WebElement TypeList;
@FindBy(xpath = "//div[@id='content']/form/h2") public WebElement SelectDateRangeInfo;
@FindBy(xpath = "//td/input[@id='form:startDate']") public WebElement txtFldAdrsChngFromDate;
@FindBy(xpath = "//td/input[@id='form:endDate']") public WebElement txtFldAdrsChngToDate;
@FindBy(xpath = "//td//input[@id='form:submitBtn']") public WebElement AdrsChng_SubmitBtn;
@FindBy(xpath = "//form[@id='formTable']//th/a[contains(text(),'Req')]") public WebElement RequestDateCol;
@FindBy(xpath = "//form[@id='formTable']//th/a[contains(text(),'Part')]") public WebElement ParticipantCol;
@FindBy(xpath = "//form[@id='formTable']//th/a[contains(text(),'SSN')]") public WebElement SSN_Col;
@FindBy(xpath = "//form[@id='formTable']//th/a[contains(text(),'Plan')]") public WebElement PlanEntryDateCol;
@FindBy(xpath = "//form[@id='formTable']//th/a[contains(text(),'Source')]") public WebElement SourceCol;
@FindBy(xpath = "//form[@id='formTable']//th/a[contains(text(),'Action')]") public WebElement Action_Col;
@FindBy(xpath = "//form[@id='formTable']//th[contains(text(),'Update')]") public WebElement UpdateInfoCol;
//Participant Statements test case web elements 
@FindBy(xpath = "//ul[@id='sideNavMenu']//li/a[contains(text(),'Statements')]") public WebElement ParticipantStatementsLink;
@FindBy(xpath = "//div[@id='content']//h2") public WebElement StatementsHeader;
@FindBy(xpath = "//div[@id='content']//td/a") public WebElement StatementLink;
@FindBy(xpath = "//div[@id='content']//h2") public WebElement NoStatementsInfoMsg;
//Advisor Registration for new user test case web elements
@FindBy(xpath = "//div//p/a[contains(text(),'new acc')]") public WebElement RegisterForNewAcctBtn;
@FindBy(xpath = "(//h3[contains(text(),'Financial professionals')]/parent::div/following-sibling::div/div)[1]/div/div[2]/div[1]") public WebElement eProducerCardHdr;
//@FindBy(xpath = "(//h3[contains(text(),'Financial professionals')]/parent::div/following-sibling::div/div)[1]/div/div[2]/div[3]/div") public WebElement eProducerRegisterLink;
@FindBy(xpath = "((//div[contains(text(),'eProducer')])[1]/following::div[contains(text(),'Register')])[1]") public WebElement eProducerRegisterLink;
//Ashwini
@FindBy(xpath = "//div[@class='content-even']/a[@class='js-env-specific-link']/h3[contains(text(), 'eProducer')]") public WebElement eProdRegLink;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement RegisterForeProdHeader;
@FindBy(xpath = "//div//p/input[@value='Next']") public WebElement eProdReg_NextBtn;
@FindBy(xpath = "//form//h2") public WebElement EnterYourInfoHeader;
@FindBy(xpath = "//td/input[@id='producerInfoForm:ssn']") public WebElement SSNTxtFld;
@FindBy(xpath = "//td//input[@id='producerInfoForm:producerId']") public WebElement ProducerIDTxtFld;
@FindBy(xpath = "//td//select[@id='producerInfoForm:applicationState']") public WebElement ApplicationStateFld;
@FindBy(xpath = "//div/ul/li/span") public WebElement CommonValidationMsg;
@FindBy(xpath = "//td//span[@class='error' and contains(text(),'Please')]") public WebElement SSNValidationMsg;
@FindBy(xpath = "//td//span[@class='error' and contains(text(),'Value')]") public WebElement ValueRqdValidationMsg;
//UserID field web elements
@FindBy(xpath = "//form/h2[contains(text(),'Create')]") public WebElement CreateUsrIDPwdHeader;
@FindBy(xpath = "//td/a[contains(text(),'User')]") public WebElement UserIDRqmntsLink;
@FindBy(xpath = "//div/h2[contains(text(),'User')]") public WebElement UsrIDRqmntsHeader;
@FindBy(xpath = "//td/span/input[@id='accountSetupForm:userId']") public WebElement UserIDFld;
@FindBy(xpath = "//td/span[contains(text(),'between 6')]") public WebElement Minimum6Chrs_VldtnMsg;
@FindBy(xpath = "//td/span[contains(text(),'numb')]") public WebElement EndingWithLtrNumb_VldtnMsg;
@FindBy(xpath = "//td/span[contains(text(),'special')]") public WebElement SpecialChrs_VldtnMsg;
@FindBy(xpath = "//td/span[contains(text(),'9')]") public WebElement Contains9Numbs_VldtnMsg;
@FindBy(xpath = "//td/span[contains(text(),'spaces')]") public WebElement ContainsSpaces_VldtnMsg;
//Password field web elements
@FindBy(xpath = "//td/a[contains(text(),'Password')]") public WebElement PwdRqmntsLink;
@FindBy(xpath = "//div/h2[contains(text(),'Pass')]") public WebElement PwdRqmntsHeader;
@FindBy(xpath = "//td/span/input[@id='accountSetupForm:password']") public WebElement PasswordFld;
@FindBy(xpath = "//td//span[contains(text(),'8')]") public WebElement Minimum8Chrs_VldtnMsg;
@FindBy(xpath = "//td//span[contains(text(),'password')]") public WebElement PwdWithNotMeetingCriterias_VldtnMsg;
@FindBy(xpath = "//td//span[contains(text(),'spaces')]") public WebElement PwdWithSpace_VldtnMsg;
@FindBy(xpath = "//td//span[contains(text(),'User')]") public WebElement PwdWithUserID_VldtnMsg;
//Confirm Password field web elements
@FindBy(xpath = "//td//input[@id='accountSetupForm:confirmPassword']") public WebElement ConfirmPwdFld;
@FindBy(xpath = "//td//span[contains(text(),'match')]") public WebElement PwdNotMatch_VldtnMsg;
//Email and Phone number fields web elements 
@FindBy(xpath = "//form//h2[contains(text(),'Access')]") public WebElement SecAccessHeader;
@FindBy(xpath = "//td/input[@id='accountSetupForm:emailAddress']") public WebElement EmailFld;
@FindBy(xpath = "//td//span[contains(text(),'E-mail')]") public WebElement invalidEmail_VldtnMsg;
@FindBy(xpath = "//td/input[@id='accountSetupForm:confirmEmailAddress']") public WebElement ConfirmEmailFld;
@FindBy(xpath = "//td//span[contains(text(),'Emails')]") public WebElement emailsNotMatch_VldtnMsg;
@FindBy(xpath = "//td/input[@id='accountSetupForm:mobilePhone']") public WebElement mobilePhoneFld;
@FindBy(xpath = "//td//span[contains(text(),'10')]") public WebElement phoneNumb_VldtnMsg;
@FindBy(xpath = "//td/input[@id='accountSetupForm:confirmMobilePhone']") public WebElement confirmMobileNumbFld;
@FindBy(xpath = "//td//span[contains(text(),'numbers')]") public WebElement numbersNonMatch_VldtnMsg;
//Security Question field web elements
@FindBy(xpath = "//form//h2[contains(text(),'Question')]") public WebElement SecurityQuestionHeader;
@FindBy(xpath = "//td//select[@id='accountSetupForm:securityQuestion']") public WebElement selectQstn;
@FindBy(xpath = "//td/input[@id='accountSetupForm:securityAnswer']") public WebElement SecAnswer;
@FindBy(xpath = "//p[contains(@id,'accountSetupForm')]//a") public List<WebElement> termsLinks;
@FindBy(xpath = "//div/h1") public WebElement termsLinkHeader;
@FindBy(xpath = "//p/input[@id='accountSetupForm:acceptTermsConditions']") public WebElement checkBox;
@FindBy(xpath = "//p//input[@value='Submit']") public WebElement Reg_SubmitBtn;
@FindBy(xpath = "//div/h2") public WebElement congratsHeader;
@FindBy(xpath = "//div/p[contains(text(),'You have')]") public WebElement RegstdInfo;
//Advisor or Broker registration for the existing user
@FindBy(xpath = "//div/p[contains(text(),'Our')]") public WebElement AlreadyRegistredInfoMsg;
@FindBy(xpath = "//div/ul[@id='webList']") public WebElement webSitesListRegistered;
@FindBy(xpath = "//div//h2[contains(text(),'existing')]") public WebElement existingUsrPwdHeader;
@FindBy(xpath = "//span/input[@id='passwordForm:webId']") public WebElement existingUserIDFld;
@FindBy(xpath = "//span/input[@id='passwordForm:password']") public WebElement existingPwdFld;
@FindBy(xpath = "//div/ul/li[contains(text(),'We')]") public WebElement weAreSorryInfoMsg;
//Broker/Dealer registration web elements
@FindBy(xpath = "//div/h2") public WebElement BrkrDlrRegInstructionsHeader;
@FindBy(xpath = "//form//input[@value='Next']") public WebElement reg_NxtBtn;
@FindBy(xpath = "//div//h2") public WebElement FirmInfoHeader;
@FindBy(xpath = "//td/input[@id='firmInfoForm:firmId']") public WebElement BrkrDlr_TaxIDFld;
@FindBy(xpath = "//td/span[contains(text(),'Firm')]") public WebElement taxID_VldtnMsg;
@FindBy(xpath = "//td//input[@id='firmInfoForm:producerId']") public WebElement FirmProdIDFld;
@FindBy(xpath = "//div//li") public WebElement incorrectInfo_VldtnMsg;
@FindBy(xpath = "//div//h2") public WebElement EntrInfoHeader;
@FindBy(xpath = "//span/input[@id='associatesForm:fName']") public WebElement FirstNameFld;
@FindBy(xpath = "//span/input[@id='associatesForm:lName']") public WebElement LastNameFld;
@FindBy(xpath = "//form//p[contains(text(),'You')]") public WebElement AuthenticatedInfo;
//Broker Dealer registration for existing user web elements
@FindBy(xpath = "//div//p[contains(text(),'To')]") public WebElement RegstrdUsrInfoMsg;
//Associate Registration for new user
@FindBy(xpath = "//form//h2") public WebElement EntrProdIDAccssCodeHeader;
@FindBy(xpath = "//td/input[@id='frmAccessCode:producerId']") public WebElement AS_ProdIDFld;
@FindBy(xpath = "//td/input[@id='frmAccessCode:accessCode']") public WebElement AS_AcsCodeFld;
@FindBy(xpath = "//div//li") public WebElement incorrectInfoMsg;
//Forgot my user ID test case web elements
//@FindBy(xpath = "//div/a[contains(text(),'Forgot User')]") public WebElement ForgotUsrIDLink;
@FindBy(xpath = "//div[@aria-label='Forgot ID Button']") public WebElement ForgotUsrIDLink;
//@FindBy(xpath = "//form/h1[contains(text(),'Forgot')]") public WebElement FrgtUsrHeader;
@FindBy(xpath = "//div[contains(text(),'Forgot your User ID?')]") public WebElement FrgtUsrHeader;
@FindBy(xpath = "//div//a[contains(text(),'Contact')]") public WebElement ContactUsLink;
@FindBy(xpath = "//div//label[contains(text(),'Email')]") public WebElement Frgt_EmailLabel;
//@FindBy(xpath = "//div/input[@id='email']") public WebElement emailTxtFld;
@FindBy(xpath = "//div/input[@placeholder='Email']") public WebElement emailTxtFld;
//@FindBy(xpath = "//div/button[@type='submit']") public WebElement Frgt_SubmitBtn;
@FindBy(xpath = "//div[text()='Submit']") public WebElement Frgt_SubmitBtn;
@FindBy(xpath = "//div//div[@id='err_message']") public WebElement FldRqd_VldtnMsg;
@FindBy(xpath = "//div//div[contains(text(),'email')]") public WebElement InvldEmail_VldtnMsg;
@FindBy(xpath = "//form/h2[contains(text(),'Check your')]") public WebElement CheckEmailHeader;
@FindBy(xpath = "//div/a[contains(text(),'Sign')]") public WebElement SignInBtn;

//Change My User ID test case web elements
@FindBy(xpath = "//form//h2") public WebElement SecurityAccessSettingsHeader;
@FindBy(xpath = "//a[@id='a-newlogonID']") public WebElement UserID_EditCancel;
@FindBy(xpath = "//input[@id='username']") public WebElement NewUserName_TextFld;
@FindBy(xpath = "//div[contains(text(),'User ID cannot match')]") public WebElement PreviouslyUsedUserID_ErrorMsg;
@FindBy(xpath = "//input[contains(@class,'confirm-new-username')]") public WebElement ConfirmUserID_TxtFld;
@FindBy(xpath = "//div[contains(@class,'confirm-new-username-error')]") public WebElement ConfirmUserID_ErrorMsg;
@FindBy(xpath = "//div[contains(text(),'Invalid User ID. Please check')]") public WebElement UserID_CmnValidationMsg;
@FindBy(xpath = "//li/span[contains(text(),'6 ch')]") public WebElement Min6Characters_ValidationMsg;
@FindBy(xpath = "//li/span[contains(text(),'end')]") public WebElement EndingwithLetterorNumber_ValidationMsg;
@FindBy(xpath = "//li[contains(@class,'username-special failed-requirement')]/span") public WebElement SpecialCharacter_ValidationMsg;
@FindBy(xpath = "//li/span[contains(text(),'9')]") public WebElement Contains9Characters_ValidationMsg;
@FindBy(xpath = "//li[contains(@class,'username')]/span[contains(text(),'spaces')]") public WebElement ContainsSpace_ValidationMsg;
@FindBy(xpath = "//li[contains(@class,'username')]/span[contains(text(),'64')]") public WebElement Contains64characters_ValidationMsg;
//Security Question changes test case web elements
@FindBy(xpath = "//a[@id='a-questionAttribute']") public WebElement SecQuestion_EditCancelBtn;
@FindBy(xpath = "//div/select[contains(@class,'ques')]") public WebElement SecQstnsList;
@FindBy(xpath = "//div/input[contains(@class,'answer')]") public WebElement SecQstnAnswerFld;
@FindBy(xpath = "//div/div[contains(text(),'50')]") public WebElement Max50Chrs_VldtnMsg;
@FindBy(xpath = "//div/input[contains(@class,'password')]") public WebElement Sec_CurrentPwd;
@FindBy(xpath = "//div/div[contains(text(),'Invalid')]") public WebElement InvldPwd_VldtnMsg;
@FindBy(xpath = "//div/button[contains(text(),'Submit')]") public WebElement Sec_SubmitBtn;
@FindBy(xpath = "//div//h2") public WebElement Sec_CongratsMsg;
@FindBy(xpath = "//div//p[contains(text(),' You')]") public WebElement ChangedSuccfllyInfoMsg;
//Monthly Commissions test case web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[text()='Commissions']") public WebElement menuCommissions;
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[contains(text(),'Monthly')]") public WebElement subMenuMonthlyCommissions;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement headerComssnProdSearch;
@FindBy(xpath = "//form//select[@id='producerSearchForm:searchBy']") public WebElement selectProdSearchBy;
@FindBy(xpath = "//form//input[@id='producerSearchForm:criteria']") public WebElement txtFldCriteria;
@FindBy(xpath = "//form//input[@value='Search']") public WebElement btnProdSearch;
@FindBy(xpath = "//div//h2[contains(text(),'Search Res')]") public WebElement headerSearchResults;
@FindBy(xpath = "//form//a[contains(text(),'Producer Num')]") public WebElement colHeaderProdNumb;
@FindBy(xpath = "//form//a[contains(text(),'Producer Name')]") public WebElement colHeaderProdName;
@FindBy(xpath = "//form//a[contains(text(),'Name Id')]") public WebElement colHeaderNameID;
@FindBy(xpath = "//div/h1[contains(text(),'Choose')]") public WebElement headerChooseStmnt;
@FindBy(xpath = "//form/h2[contains(text(),'producer')]") public WebElement headerSelProdNumb;
@FindBy(xpath = "//form/h2[contains(text(),'month')]") public WebElement headerSelCommsnMonth;
@FindBy(xpath = "//form/input[@value='Submit']") public WebElement btnProdSearchSubmit;
@FindBy(xpath = "//div/h1[contains(text(),'Summary')]") public WebElement headerStmntSummary;
@FindBy(xpath = "//div/h2[contains(text(),'Compensation')]") public WebElement headerCompensation;
@FindBy(xpath = "//div/h2[contains(text(),'Fees')]") public WebElement headerDeduction_Fees;
@FindBy(xpath = "//div/h2[contains(text(),'Mailing')]") public WebElement headerMailingAdrs;
@FindBy(xpath = "//div//h2[contains(text(),'No')]") public WebElement infoMsgNoResultsRtrnd;
//@FindBy(xpath = "//select//option[text()='Jun, 2024']") public WebElement SelCommsnMonth;
@FindBy(xpath = "//option[@value='June 30, 2024 12:00:00 AM EDT']") public WebElement SelCommsnMonth;
//Compensation Detail_Individual test case web elements
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[contains(text(),'on Detail')]") public WebElement sideMenuCompnstnDetail;
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[contains(text(),'Indivi')]") public WebElement subMenuIndividualDetail;
@FindBy(xpath = "//div/h1[contains(text(),'Ind')]") public WebElement headerIndvdlCompnstnStmnt;
@FindBy(xpath = "//div//h2[contains(text(),'FEE')]") public WebElement headerServiceFee;
@FindBy(xpath = "//table//th[contains(text(),'Due')]") public WebElement colHeaderDueDate;
@FindBy(xpath = "//table//th[contains(text(),'Day')]") public WebElement colHeaderAccntDay;
@FindBy(xpath = "//table//th[contains(text(),'Num')]") public WebElement colHeaderStmntNum;
@FindBy(xpath = "//table//th/span[contains(text(),' Number')]") public WebElement colHeaderPolcNmbr;
@FindBy(xpath = "//table//th/span[contains(text(),'holder')]") public WebElement colHeaderPolcHoldr;
@FindBy(xpath = "//table//th[contains(text(),'Cov')]") public WebElement colHeaderCov;
@FindBy(xpath = "//table//th[contains(text(),'Bill')]") public WebElement colHeaderBillType;
@FindBy(xpath = "//table//th[contains(text(),'Split')]") public WebElement colHeaderSplit;
@FindBy(xpath = "//table//th[contains(text(),'Rate')]") public WebElement colHeaderRatePct;
@FindBy(xpath = "//table//th[contains(text(),'Premi')]") public WebElement colHeaderCIPremium;
@FindBy(xpath = "//table//th[contains(text(),'Amt')]") public WebElement colHeaderCIAmt;
@FindBy(xpath = "//table//td/span[contains(text(),'INDIV')]") public WebElement rowTotalIndividual;
@FindBy(xpath = "//form//select[@id='chooseStatement:statementDate']") public WebElement selectStmntDate;

//Compensation Download Statement test case web elements
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[contains(text(),'Display')]") public WebElement sideMenuStmntDisplay;
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[contains(text(),'Download')]") public WebElement sideMenuDwnldStmnt;
@FindBy(xpath = "//div//h1[contains(text(),'Down')]") public WebElement headerDwnldStmnt;
@FindBy(xpath = "//div//h2[contains(text(),'Commi')]") public WebElement headerCommissionLevel;
@FindBy(xpath = "//div//h2[contains(text(),'File')]") public WebElement headerFileType;
@FindBy(xpath = "//form//a/img[contains(@title,'Download')]") public WebElement iconFileDwnld;
@FindBy(xpath = "//ul/li/a[@id='excelTemplate']") public WebElement linkExcelTemplate;
@FindBy(xpath = "//ul/li/a[@id='pdfDataDictionary']") public WebElement linkDataDictionary;
@FindBy(xpath = "//ul/li/a[@id='pdfInstructions']") public WebElement linkpdfInstrctns;

//Compensation Summary test case web elements
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[text()='Group']") public WebElement sideMenuGroup;
@FindBy(xpath = "//div//h1[contains(text(),'Group')]") public WebElement headerGrpCompnstn;
@FindBy(xpath = "//div//h2[contains(text(),'Group')]") public WebElement headerGrpSummary;
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[text()='Retirement Services']") public WebElement sideMenuRetirementServices;
@FindBy(xpath = "//div//h1[contains(text(),'Retire')]") public WebElement headerRtrmntSrvcsCmpnstn;
@FindBy(xpath = "//div//h2[contains(text(),'Retire')]") public WebElement headerRtrmntSrvcsSummary;

//Override Summary and All Override details test case web elements
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[text()='Override']") public WebElement sideMenuOverride;
@FindBy(xpath = "//div[@id='content']//form//h2/a[1]") public WebElement linkOvrrideProdNameLink;
@FindBy(xpath = "//div[@id='content']//table//span[text()='TOTAL OVERRIDE']") public WebElement labelTotalOvrride;
@FindBy(xpath = "//div[@id='content']//table//span[text()='TOTAL OVERRIDE']//following::td[8]") public WebElement valueTtlOvrride;
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[contains(text(),'All Override')]") public WebElement sideMenuAllOverrideDetail;
@FindBy(xpath = "(//div[@id='content']//table//td[1]//span[contains(text(),'TOTAL OVERRIDE')])[3]") public WebElement labelAllOvrdeTotal;
@FindBy(xpath = "(//div[@id='content']//table//td[1]//span[contains(text(),'TOTAL OVERRIDE')])[3]//following::td[8]") public WebElement valueAllTtlOvrde;
//All Group and RS Details test case web elements
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[contains(text(),'All Group')]") public WebElement sideMenuAllGroupDetail;
@FindBy(xpath = "//div//h2[contains(text(),'RENEW')]") public WebElement headerRenewalWriting;
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[contains(text(),'All Retire')]") public WebElement sideMenuAllRSDetail;

//Compensation Summaries test case web elements
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[text()='Compensation']") public WebElement sideMenuCompensation;
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[text()='Deductions/Fees']") public WebElement sideMenuDeduction;
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[text()='Reconciliation']") public WebElement sideMenuReconciliation;
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[text()='Tax Recap']") public WebElement sideMenuTaxRecap;
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[text()='Other Compensation']") public WebElement sideMenuOthrCompnstn;
@FindBy(xpath = "//div[@id='content']/h1") public WebElement headerCompnstnSummaries;
@FindBy(xpath = "//div[@id='content']//th/span[contains(text(),'Comp')]") public WebElement tableHeaderCompnstn;
@FindBy(xpath = "//div[@id='content']//th/span[contains(text(),'Year')]") public WebElement tableHeaderYearToDate;
@FindBy(xpath = "//div[@id='content']//table//following-sibling::h2") public List<WebElement> tableHeaders; 
@FindBy(xpath = "//div//table//td[contains(text(),'TOTAL DEDU')]") public WebElement labelTotalDeduction;
@FindBy(xpath = "//div//table//td[contains(text(),'TOTAL DEDU')]//following-sibling::td[5]") public WebElement valueTotalDeduction;
@FindBy(xpath = "//div//table//td[contains(text(),'BALANCES')]") public WebElement labelTotalBlances;
@FindBy(xpath = "//div//table//td[contains(text(),'BALANCES')]//following-sibling::td[5]") public WebElement valueTotalBalances;
@FindBy(xpath = "//div//h2[contains(text(),'data to report')]") public WebElement infoMsgNoDataToReport;

//Compensation Contacts test case web elements
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[contains(text(),'Communication')]") public WebElement sideMenuCommunications;
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[contains(text(),'Contacts')]") public WebElement sideMenuCompnstnContacts;
@FindBy(xpath = "//div//h1[contains(text(),'Contacts')]") public WebElement headerCpmnstnCntcts; 
@FindBy(xpath = "//div//div//strong[contains(text(),'Regu')]") public WebElement headerRegularMail;
@FindBy(xpath = "//table[@class='simple']//tr//td[1]") public WebElement txtRegularMailDetils;
@FindBy(xpath = "//div//div//strong[contains(text(),'Over')]") public WebElement headerOvernightMail;
@FindBy(xpath = "//table[@class='simple']//tr//td[2]") public WebElement txtOvernightMailDetails;
//@FindBy(xpath = "//div//h2[contains(text(),'E-mail')]") public WebElement headerEMailAdrs;
//@FindBy(xpath = "//div//p[@class='simple' and contains(text(),'Email')]") public WebElement txtEmailDetails;
@FindBy(xpath = "//div//h2[contains(text(),'Email')]") public WebElement headerEMailAdrs;
@FindBy(xpath = "//p[@dir='ltr']//strong") public WebElement txtEmailDetails;
@FindBy(xpath = "//div//h2[contains(text(),'Tele')]") public WebElement headerTelephone;
@FindBy(xpath = "//div//p[@class='simple' and contains(text(),'Opt')]") public WebElement txtTelephoneDetails;

//EFT test case web elements
@FindBy(xpath = "//div[@id='sidenav']//ul//li/a[contains(text(),'EFT')]") public WebElement sideMenuEFTForm;
@FindBy(xpath = "//div//h1[contains(text(),'EFT')]") public WebElement headerEFTForm;
@FindBy(xpath = "//div//ul/li/a[@id='viewPdf']") public WebElement linkAgreementEFT;
@FindBy(xpath = "//table[@class='simple-text']//tr//td") public WebElement txtMailingDetails;
@FindBy(xpath = "//div//p[contains(text(),'fax')]") public WebElement txtFaxDetails;

//Weekly Commissions test case web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[contains(text(),'Weekly')]") public WebElement subMenuWeeklyCommissions;
@FindBy(xpath = "//div/form/h1[contains(text(),'Weekly')]") public WebElement headerWeeklyCommsn;
@FindBy(xpath = "//form//input[@id='form:criteria']") public WebElement txtFldWeeklyCriteria;
@FindBy(xpath = "//form//select[@id='form:searchBy']") public WebElement selectWeeklySearchBy;
@FindBy(xpath = "//form//select[@id='form:matching']") public WebElement selectMatching;
@FindBy(xpath = "//div/input[@value='Submit']") public WebElement btnSubmitWeekly;
@FindBy(xpath = "//div//th/a[contains(text(),'Name')]") public WebElement colheaderProdName;
@FindBy(xpath = "//form//a[contains(text(),'Producer SSN')]") public WebElement colHeaderProdSSN;
@FindBy(xpath = "//div/form/h1[contains(text(),'Weekly')]") public WebElement headerWeeklyCommsnHome;
@FindBy(xpath = "//form/h2[contains(text(),'date')]") public WebElement headerSelCommsnDate;
@FindBy(xpath = "//div//li[contains(text(),'no state')]") public WebElement infoMsgNoStmnts;
@FindBy(xpath = "//form//a[contains(text(),'SSN')]") public WebElement colHeaderSSNTaxID;
@FindBy(xpath = "//form//a[contains(text(),'Comm')]") public WebElement colHeaderCommissionTotal;
@FindBy(xpath = "//form//tr/td[contains(text(),'Weekly')]") public WebElement headerWklyStmntsDateRange;
@FindBy(xpath = "//form//table[@id='form:compsTable']//tr[1]/td/a") public WebElement linkWklyCommsns;
@FindBy(xpath = "//form//td/h2[contains(text(),'IND')]") public WebElement headerIndividual;
@FindBy(xpath = "//form//table//tr/th[contains(text(),'Num')]") public WebElement colHeaderCustmrNumb;
@FindBy(xpath = "//form//table//tr/th[contains(text(),'Name')]") public WebElement colHeaderCustmrName;
@FindBy(xpath = "//form//table//tr/th[contains(text(),'Case')]") public WebElement colHeaderCaseEfctvDate;
@FindBy(xpath = "//form//table//tr/th[contains(text(),'Prod')]") public WebElement colHeaderProduct;
@FindBy(xpath = "//form//table//tr/th[contains(text(),'Rate')]") public WebElement colHeaderRate;
@FindBy(xpath = "//form//table//tr/th[contains(text(),'Prem')]") public WebElement colHeaderPremium;
@FindBy(xpath = "//form//table//tr/th[contains(text(),'Amo')]") public WebElement colHeaderAmount;

//Plan Sponsor Communication test case web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[text()='Communication']") public WebElement menuCommunication;
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[contains(text(),'Sponsor Com')]") public WebElement subMenuPlanSponsorCommunication;
@FindBy(xpath = "//div/h1[contains(text(),'Plan')]") public WebElement headerPlanSpnsrCommunication;
@FindBy(xpath = "//div//ul//li/a[contains(text(),'AUL RS')]") public List<WebElement> linksComctnAULRS;
//Core Business Communication test case web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[contains(text(),'Core')]") public WebElement subMenuCoreBusnsCmnctns;
@FindBy(xpath = "//div//h1[contains(text(),'Core')]") public WebElement headerCoreBusnsComnctn;
@FindBy(xpath = "//div//h2[contains(text(),'Admin')]") public WebElement headerAdmnPrcdrs;
@FindBy(xpath = "//div//h2[contains(text(),'Mis')]") public WebElement headerMisclnsComnctns;
@FindBy(xpath = "//div//h2[contains(text(),'Form')]") public WebElement headerFormUpdates;
@FindBy(xpath = "//div//h2[contains(text(),'Parti')]") public WebElement headerPrtcpntCmnctns;
@FindBy(xpath = "//div//h2[contains(text(),'Inv')]") public WebElement headerInvstmntUpdates;
@FindBy(xpath = "//div//h2[contains(text(),'Plan')]") public WebElement headerPlanSponsorCmnctns;
@FindBy(xpath = "//div//h2[contains(text(),'Leg')]") public WebElement headerLegislativeUpdts;
@FindBy(xpath = "//div//h2[contains(text(),'Prod')]") public WebElement headerProductsUpdts;
@FindBy(xpath = "//div//h2[contains(text(),'Mark')]") public WebElement headerMarketingUpdts;
@FindBy(xpath = "//div//h2[contains(text(),'Tech')]") public WebElement headerTechUpdts;
//Demos Test case web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[text()='Technology']") public WebElement menuTechnology;
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[text()='Demos']") public WebElement subMenuDemos;
@FindBy(xpath = "//div//h1[contains(text(),'Demos')]") public WebElement headerDemos;
@FindBy(xpath = "//div//p/a[contains(text(),'www')]") public WebElement linkOAWebsite;
@FindBy(xpath = "//div//h2[contains(text(),'Account')]") public WebElement headerAccountServices;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'Account')]//following-sibling::p[1]") public WebElement textASDetails;
@FindBy(xpath = "//div//h2[contains(text(),'eSponsor')]") public WebElement headereSponsor;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'eSponsor')]//following-sibling::p[1]") public WebElement texteSponsorDetails;
@FindBy(xpath = "//div//h2[contains(text(),'eAccess')]") public WebElement headereAccess;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'eAccess')]//following-sibling::p[1]") public WebElement texteAccessDetails;
@FindBy(xpath = "//div//h2[contains(text(),'Invest')]") public WebElement headerInvestmentAdvisor;
@FindBy(xpath = "//div//h2[contains(text(),'One')]") public WebElement headerMyOneCheckOnline;
//Products Offerings test case web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[text()='Products']") public WebElement menuProducts;
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[text()='Product Offerings']") public WebElement subMenuPrdctOfferings;
@FindBy(xpath = "//div/h1[contains(text(),'Prod')]") public WebElement headerProducts;
@FindBy(xpath = "//div/h2[contains(text(),'Emp')]") public WebElement headerEmpSponsored;
@FindBy(xpath = "//div/h2[contains(text(),'Volu')]") public WebElement headerVoluntary;
@FindBy(xpath = "//div//ul[@class='dash-list']/li/a[contains(@href,'%28')]") public List<WebElement> linksOAProducts;
//Roth 401(k) & 403(b) Feature test case web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[text()='Plans']") public WebElement menuPlans;
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[contains(text(),'Roth')]") public WebElement subMenuRothFeature;
@FindBy(xpath = "//div//h1[contains(text(),'Roth')]") public WebElement headerRothFeature;
@FindBy(xpath = "//div//h2[contains(text(),'works')]") public WebElement headerHowRothWorks;
@FindBy(xpath = "//div//h2[contains(text(),'Advan')]") public WebElement headerAdvantages;
@FindBy(xpath = "//div//h2[contains(text(),'plan')]") public WebElement headerPlanSponsorInfo;
@FindBy(xpath = "//div//h2[contains(text(),'part')]") public WebElement headerParticipantInfo;
@FindBy(xpath = "//div//ul[@dir='ltr']/li/a") public List<WebElement> linksRoth; 
//Investment Sales Support test case web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[contains(text(),'Investment Sales')]") public WebElement subMenuInvstmntSalesSprt;
@FindBy(xpath = "//form[@id='investSalesSupport']//h1") public WebElement headerInvstmntSalesSupport;
@FindBy(xpath = "//form[@id='investSalesSupport']//li//a[contains(text(),'(38) Fid')]") public WebElement linkFiducarySrvcs38;
@FindBy(xpath = "//form[@id='formTable']/h1/span") public WebElement headerSelectedLink;
@FindBy(xpath = "//form[@id='formTable']//span//table//a[contains(text(),'Mesiro')]") public List<WebElement> linksFiducaryServices;
@FindBy(xpath = "//form//ul//li/a[contains(text(),'Contract')]") public WebElement linkContractHolderForms;
@FindBy(xpath = "//form[@id='formTable']//tr[1]//td[1]/a") public WebElement linkCntrctHldrRelated;
//Investment Performance and Option Summaries test case web elements
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[contains(text(),'Option Sum')]") public WebElement subMenuInvstmntPrfmncOptn;
@FindBy(xpath = "//div//h1[contains(text(),'Option')]") public WebElement headerInvstmntPrfrmncOptn;
@FindBy(xpath = "//div[@class='multi-topic']//ul/li/a") public List<WebElement> linksInvstmntPrfrmnsOptns; 
@FindBy(xpath = "//form[@id='formTable']/p/input[@value='Previous']") public WebElement btnIPOPrevious;
@FindBy(xpath = "//span[@id='formTable:table']/table//tr[1]/td/a") public WebElement linkClickedPageLink;
//Investment Information test case web elements 
@FindBy(xpath = "//div[@id='primarynav']/form//li/a[contains(text(),'Investment Info')]") public WebElement subMenuInvstmntInfo;
@FindBy(xpath = "//div//h1[contains(text(),'Info')]") public WebElement headerInvstmntInfo;
@FindBy(xpath = "//div//h2[1]") public WebElement headerOneSuite;
@FindBy(xpath = "//div//h2[2]") public WebElement headerPreScreened;
@FindBy(xpath = "//div//h2[3]") public WebElement headerProdInnovation;
@FindBy(xpath = "//div//h2[4]") public WebElement headerMrktInfo;
@FindBy(xpath = "//div[@id='content']//ul//li/a[@href]") public List<WebElement> linksInvstmntInfo;
@FindBy(xpath = "//div/h1[contains(text(),'Reso')]") public List<WebElement> headerResources;
//Contribution Details test case web elements 
@FindBy(xpath = "//ul[@id='sideNavMenu']//ul//li/a[contains(text(),'Financial Activity')]") public WebElement sideMenuFinancialActvty;
@FindBy(xpath = "//div/h1[contains(text(),'Fin')]") public WebElement headerFinActvty;
@FindBy(xpath = "//div/h2[contains(text(),'Fin')]") public WebElement headerSelFinActvty;
@FindBy(xpath = "//td/select[@id='financialActivity:report']") public WebElement selectFinActvtyReport;
@FindBy(xpath = "//td/input[@id='financialActivity:fromDate']") public WebElement txtFldFAFromDate;
@FindBy(xpath = "//td/input[@id='financialActivity:toDate']") public WebElement txtFldFAToDate;
@FindBy(xpath = "//td/input[@id='financialActivity:submitButton']") public WebElement btnFASubmit;
@FindBy(xpath = "//td/span[contains(text(),'understood')]") public WebElement vldtnMsgInvldDateFrmt;
@FindBy(xpath = "//td/span[contains(text(),'cannot')]") public WebElement vldtnMsgFuPaDate;
@FindBy(xpath = "//form[@id='financialActivity']//following::h2") public WebElement headerContDtls;
@FindBy(xpath = "//th/a[contains(text(),'Trade')]") public WebElement colHeaderTradeDate;
@FindBy(xpath = "//th/a[contains(text(),'Payroll')]") public WebElement colHeaderPayrollDate;
@FindBy(xpath = "//th[contains(text(),'Type')]") public WebElement colHeaderContrbtnType;
@FindBy(xpath = "//th/a[contains(text(),'Amount')]") public WebElement colHeaderAmntAlctd;
@FindBy(xpath = "//td/span[contains(text(),'Total')]") public WebElement rowTotalContDtls;
@FindBy(xpath = "//div//p/span[contains(text(),'Plan')]") public WebElement infoMsgPlnDtlsNotAvlbl;
@FindBy(xpath = "//form//tr[1]/td/span/a[contains(text(),'Invest')]") public WebElement linkCDInvestment;
@FindBy(xpath = "//form//tr[1]/td//a[contains(text(),'Source')]") public WebElement linkCDSource;
@FindBy(xpath = "//form/p/input[@value='Previous']") public WebElement btnCDPrevious;
@FindBy(xpath = "//form/p/input[@value='Download']") public WebElement btnCDDownload;
@FindBy(xpath = "//form[@id='pageForm']/p/a/img[@title='Download']") public WebElement iconCtrbtnBySrcDwnld;
@FindBy(xpath = "//form[@id='downloadForm']//a/img[contains(@title,'Download')]") public WebElement iconCDInvstSourceDwnld;
@FindBy(xpath = "//form[@id='downloadForm']//tr//input[@value='Cancel']") public WebElement btnDwnldCancel;

//Account Activity test case web elements
@FindBy(xpath = "//div/h1[contains(text(),'Plan')]") public WebElement headerPlnAcntActvty;
@FindBy(xpath = "//div/h2[contains(text(),'Plan')]") public WebElement headerPlanAcntActvtySummary;
@FindBy(xpath = "//div//th[contains(text(),'Activity')]") public WebElement colHeaderActivity;
@FindBy(xpath = "//div//th[contains(text(),'Total')]") public WebElement colHeaderTotal;
@FindBy(xpath = "//div//td[contains(text(),'Ending')]") public WebElement textEndingBalnc;
@FindBy(xpath = "//div//p/a/img[@title='Download']") public WebElement iconAcntActvyDownload;
@FindBy(xpath = "//div//p/span[contains(text(),'Account')]") public WebElement infoMsgAcntActvtyDtlsNotAvlbl;

//Asset Allocation test case web elements
@FindBy(xpath = "//div/h1[contains(text(),'Asset')]") public WebElement headerAssetAllocation;
@FindBy(xpath = "//div/h2[contains(text(),'Asset')]") public WebElement headerAssetAllctnSummary;
@FindBy(xpath = "//div//p/span[contains(text(),'Asset')]") public WebElement infoMsgAssetAlctnNotAvlbl;

//Contribution by Category test case web elements
@FindBy(xpath = "//div/h1[contains(text(),'Cont')]") public WebElement headerContrbtnCtgry;
@FindBy(xpath = "//table//th[contains(text(),'Name')]") public WebElement colHeaderInvstmntName;
@FindBy(xpath = "//table//th[contains(text(),'Type')]") public WebElement colHeaderInvstmntType;
@FindBy(xpath = "//table//th[contains(text(),'Value')]") public WebElement colHeaderCntrbtnValue;
@FindBy(xpath = "//table//tbody//td//a[1]") public WebElement linkMrngStarDetails;
@FindBy(xpath = "//div//p/span[contains(text(),'Contr')]") public WebElement infoMsgCtrbtnDtlsNotAvlbl;

//Distribution Details text case web elements
@FindBy(xpath = "//div/h1[contains(text(),'from')]") public WebElement headerDstrbtnDetailsWithDateRange;
@FindBy(xpath = "//div/h2[contains(text(),'Distr')]") public WebElement headerDstrbtnDtl;
@FindBy(xpath = "//table//th/a/span[contains(text(),'Name')]") public WebElement colHeaderPrtcpntName;
@FindBy(xpath = "//table//th/a/span[contains(text(),'SSN')]") public WebElement colHeaderSSN;
@FindBy(xpath = "//table//th/a/span[contains(text(),'Div')]") public WebElement colHeaderDivison;
@FindBy(xpath = "//table//th/a/span[contains(text(),'Trade')]") public WebElement colHeaderDDTradeDate;
@FindBy(xpath = "//table//th/a/span[contains(text(),'Gross')]") public WebElement colHeaderGrossAmnt;
@FindBy(xpath = "//table//th/a/span[contains(text(),'Check')]") public WebElement colHeaderCheck;
@FindBy(xpath = "//table//th/a/span[contains(text(),'Cash')]") public WebElement colHeaderRolloverCash;
@FindBy(xpath = "//table//th/a/span[contains(text(),'Reason')]") public WebElement colHeaderReason;
@FindBy(xpath = "//table//th/a/span[contains(text(),'React')]") public WebElement colHeaderReactivation;
@FindBy(xpath = "//div//p/a/img[@title='Download']") public WebElement iconDstrbtnDownload;
@FindBy(xpath = "//form/p/input[@value='Previous']") public WebElement btnDDPrevious;
@FindBy(xpath = "//div/h2[contains(text(),'Person')]") public WebElement headerPrsnlData;
@FindBy(xpath = "//div/h2[contains(text(),'Trans')]") public WebElement headerTrnsctnActvty;
@FindBy(xpath = "//div/h2[contains(text(),'Pay')]") public WebElement headerPaymentActvty;
@FindBy(xpath = "//div//p/span[contains(text(),'Detail')]") public WebElement infoMsgDstrbtnDtlsNotAvlbl;
//Inforce Ordering test case web elements
@FindBy(xpath = "//div/h1[contains(text(),'Order')]") public WebElement headerOrdrInforceDtls;
@FindBy(xpath = "//form/h2[contains(text(),'Order')]") public WebElement headerOrdrConfrmtion;
@FindBy(xpath = "//form//td/input[contains(@id,'email')]") public WebElement txtFldOrdrCnfrmtnEmail;
@FindBy(xpath = "//form//h2[contains(text(),'Plan')]") public WebElement headerPlanInfo;
@FindBy(xpath = "//form//td/input[contains(@id,'plan')]") public WebElement txtFldPlanNumb;
@FindBy(xpath = "//form//input[@value='Next']") public WebElement btnOrdNext;
@FindBy(xpath = "//div/ul/li[contains(text(),'existing')]") public WebElement infoExistingOrder;
//Payroll Feedback- On Demand Report test case actions
@FindBy(xpath = "//form[@id='navMenuForm']//li//a[contains(text(),'Payroll Fe')]") public WebElement sideMenuPayrollFeedbackFile;
@FindBy(xpath = "//div/h1[contains(text(),'Pay')]") public WebElement headerPayrollFdBck;
@FindBy(xpath = "//form//div//h2[contains(text(),'Setup')]") public WebElement headerSetup;
@FindBy(xpath = "//div//h2[contains(text(),'Pay')]") public WebElement headerPayrollFdbckFileDshbrd;
@FindBy(xpath = "//form//div//a[contains(text(),'+')]") public WebElement iconExpandSetUp;
@FindBy(xpath = "//form//div//td/a[contains(text(),'On Demand')]") public WebElement linkOnDemand;
@FindBy(xpath = "//div/h1[contains(text(),'On De')]") public WebElement headerOnDemandRequest;
@FindBy(xpath = "//div//ol/li[1]") public WebElement labelSetUp;
@FindBy(xpath = "//div//ol/li[2]") public WebElement labelReview;
@FindBy(xpath = "//div//ol/li[3]") public WebElement labelComplete;
@FindBy(xpath = "//div/h2[contains(text(),'Begi')]") public WebElement headerBeginingDate;
@FindBy(xpath = "//div/h2[contains(text(),'End')]") public WebElement headerEndingDate;
@FindBy(xpath = "//td/input[@id='feedbackRequest:fromDate']") public WebElement txtFldFromDate;
@FindBy(xpath = "//td/input[@id='feedbackRequest:toDate']") public WebElement txFldToDate;
@FindBy(xpath = "//div/h2[contains(text(),'Select')]") public WebElement headerSelectDivision;
@FindBy(xpath = "//th/a[contains(text(),'Select')]") public WebElement linkSelectAll;
@FindBy(xpath = "//div/h2[contains(text(),'Please')]") public WebElement headerPlsSelectInfo;
@FindBy(xpath = "//div//select[@id='feedbackRequest:fileType']") public WebElement selectFileOptn;
@FindBy(xpath = "//p/input[@id='feedbackRequest:buttonNext']") public WebElement btnFdBckNext;
@FindBy(xpath = "//form/input[@id='feedbackRequest:buttonSubmit']") public WebElement btnFdBckSubmit;
@FindBy(xpath = "//p/span[contains(text(),'Your')]") public WebElement infoMsgSubmissionSuccessfull;
@FindBy(xpath = "//form/input[@value='Feedback Dashboard']") public WebElement btnFdBckDshbrd;
@FindBy(xpath = "(//a[@class='oaExpandableAnchor'])[2]") public WebElement btnFdBckHome;
@FindBy(xpath = "//div/h2[contains(text(),'for')]/a") public WebElement iconExpandFBRecords;
@FindBy(xpath = "//form//table//th[contains(text(),'Plan')]") public WebElement colHeaderPlanNumRprtType;
@FindBy(xpath = "//form//table//th[contains(text(),'Div')]") public WebElement colHeaderDivisions;
@FindBy(xpath = "//form//table//th[contains(text(),'File')]") public WebElement colHeaderFileOptn;
@FindBy(xpath = "//form//table//th[contains(text(),'Fre')]") public WebElement colHeaderFrequency;
@FindBy(xpath = "//form//table//th[contains(text(),'Last')]") public WebElement colHeaderLastRun;
@FindBy(xpath = "//form//table//th[contains(text(),'Next')]") public WebElement colHeaderNextRun;
@FindBy(xpath = "//form//table//th[contains(text(),'Action')]") public WebElement colHeaderAction;
@FindBy(xpath = "//form[@id='feedbackHORequestsTable']//table//tr[1]/td[1]") public WebElement detailsReportType;
@FindBy(xpath = "//form[@id='feedbackHORequestsTable']//table//tr[1]/td[3]") public WebElement detailsFileOptn;
@FindBy(xpath = "//form[@id='feedbackHORequestsTable']//table//tr[1]/td/input[contains(@id,'View')]") public WebElement btnView;
//Participant Electronic Activity Report test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li//a[contains(text(),'Elect')]") public WebElement sideMenuPrtcpntElctrncReport;
@FindBy(xpath = "//div/h1[contains(text(),'Elect')]") public WebElement headerPrtcpntElctrncRprt;
@FindBy(xpath = "//form/h2[contains(text(),'Select')]") public WebElement headerSelectDateRange;
@FindBy(xpath = "//form//td/input[@id='form:startDate']") public WebElement txtFldPERFromDate;
@FindBy(xpath = "//form//td/input[@id='form:endDate']") public WebElement txtFldPERToDate;
@FindBy(xpath = "//form//td/input[@value='Submit']") public WebElement btnPERSubmit;
@FindBy(xpath = "//form/h2[contains(text(),'Report')]") public WebElement headerReportWithDates;
@FindBy(xpath = "//form//th/a[contains(text(),'Req')]") public WebElement colHeaderRequestDate;
@FindBy(xpath = "//form//th/a[contains(text(),'Part')]") public WebElement colHeaderPartcpnt;
@FindBy(xpath = "//form//th/a[contains(text(),'SSN')]") public WebElement colHeaderPERSSN;
@FindBy(xpath = "//form//th/a[contains(text(),'Div')]") public WebElement colHeaderPERDvsn;
@FindBy(xpath = "//form//th/a[contains(text(),'Plan')]") public WebElement colHeaderPlanEntryDate;
@FindBy(xpath = "//form//th/a[contains(text(),'Source')]") public WebElement colHeaderSource;
@FindBy(xpath = "//form//th/a[contains(text(),'Act')]") public WebElement colHeaderPERAction;
@FindBy(xpath = "//form//th[contains(text(),'Upda')]") public WebElement colHeaderUpdatedActn;
@FindBy(xpath = "//div/ul/li[contains(text(),'There')]") public WebElement infoMsgNoElectronicData;
//Loan Specifications feature test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li//a[contains(text(),'Speci')]") public WebElement sideMenuLoanSpecification;
@FindBy(xpath = "//div/h1[contains(text(),'Speci')]") public WebElement headerLoanSpecifications;
@FindBy(xpath = "//div//td/label[contains(text(),'Status')]") public WebElement labelLoanAllowedStatus;
@FindBy(xpath = "//div//td/label[contains(text(),'Rate')]") public WebElement labelLoanIntrstRate;
@FindBy(xpath = "//div//td/label[contains(text(),'Internet')]") public WebElement labelInternetLoanAllowed;
@FindBy(xpath = "//div//td/label[contains(text(),'Process')]") public WebElement labelLoanProcessingFee;
@FindBy(xpath = "//div//td/label[contains(text(),'Admin')]") public WebElement labelLoanAdminFee;
@FindBy(xpath = "//div//td/label[contains(text(),'Max')]") public WebElement labelMaxLoanAllowed;
@FindBy(xpath = "//div//td/label[contains(text(),'Days')]") public WebElement labelDaysBtwnLoans;
@FindBy(xpath = "//div//tr//label[contains(text(),'Status')]//following::td[1]") public WebElement infoLoanStatus;
@FindBy(xpath = "//div//tr//label[contains(text(),'Rate')]//following::td[1]") public WebElement infoLoanIntrstRate;
@FindBy(xpath = "//div//tr//label[contains(text(),'Internet')]//following::td[1]") public WebElement infoInternetLoanAllowed;
@FindBy(xpath = "//div//tr//label[contains(text(),'Process')]//following::td[1]") public WebElement infoLoanProcessingFee;
@FindBy(xpath = "//div//tr//label[contains(text(),'Admin')]//following::td[1]") public WebElement infoLoanAdminFee;
@FindBy(xpath = "//div//tr//label[contains(text(),'Max')]//following::td[1]") public WebElement infoMaxLoanAllowed;
@FindBy(xpath = "//div//tr//label[contains(text(),'Days')]//following::td[1]") public WebElement infoDaysBtwnLoans;
//Compliance Testing test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li//a[contains(text(),'Testing')]") public WebElement sideMenuComplianceTesting;
@FindBy(xpath = "//div/h1[contains(text(),'Compli')]") public WebElement headerComplncTesting;
@FindBy(xpath = "//div//p[contains(text(),'Deter')]") public WebElement headerComplncDetermination;
@FindBy(xpath = "//div//h2[contains(text(),'results')]") public WebElement infoMsgNoResultsReturned;
//Form 5500 test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[text()='Form 5500']") public WebElement sideMenuForm5500;
@FindBy(xpath = "//div/h1[text()='Form 5500']") public WebElement Form5500Header;
@FindBy(xpath = "//p/a[contains(text(),'Imp')]") public WebElement ImpInfoDocLink;
@FindBy(xpath = "//p/a[contains(text(),'Audit')]") public WebElement AuditPckgLink;
//Loan Payoff projection test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[contains(text(),'Payoff')]") public WebElement sidemenuLoanPayOffProj;
@FindBy(xpath = "//div/h1[contains(text(),'Loan')]") public WebElement headerLoanPayoffProj;
@FindBy(xpath = "//form/h2[contains(text(),'Search')]") public WebElement headerPrtcpntSearch;
@FindBy(xpath = "//td/label[contains(text(),'SSN:')]") public WebElement labelPrtcpntSSN;
@FindBy(xpath = "//td/input[@id='searchForm:matchValue']") public WebElement txtFldPrtcpntSSN;
@FindBy(xpath = "//td/input[@id='searchForm:searchButton']") public WebElement btnSearch;
@FindBy(xpath = "//div//p[contains(text(),'No')]") public WebElement infoMsgNoResults;
@FindBy(xpath = "//div/p[contains(text(),'loan')]") public WebElement infoMsgNote;
@FindBy(xpath = "//div//h2[contains(text(),'Projection for')]") public WebElement headerProjectionFor;
@FindBy(xpath = "//form//th/a[contains(text(),'Numb')]") public WebElement colHeaderLoanNumb;
@FindBy(xpath = "//form//th/a[contains(text(),'Status')]") public WebElement colHeaderStatus;
@FindBy(xpath = "//form//th/a[contains(text(),'Date')]") public WebElement colHeaderInitDate;
@FindBy(xpath = "//form//th/a[contains(text(),'Amount')]") public WebElement colHeaderOrigAmnt;
@FindBy(xpath = "//td/a[@id='dataTable:table1:0:loanNumber']") public WebElement linkLoanNumb;
@FindBy(xpath = "//form[@id='requestForm']//h2") public WebElement headerProjctnCalc;
@FindBy(xpath = "//form[@id='requestForm']//h2") public WebElement labelPayoffDate;
@FindBy(xpath = "//td[contains(text(),'date')]") public WebElement infoMsgPayoffPrjctn;
@FindBy(xpath = "//div[@class='readme']/p[1]") public WebElement infoImportantNote1;
@FindBy(xpath = "//div[@class='readme']/p[2]") public WebElement infoImportantNote2;
@FindBy(xpath = "//td/input[@id='requestForm:fromDate']") public WebElement txtFldPayoffDate;
@FindBy(xpath = "//form//td/span[contains(text(),'understood')]") public WebElement vldtnMsgInvalidDateFormat;
@FindBy(xpath = "//form//td/span[contains(text(),'cannot')]") public WebElement vldtnMsgFuturePayoffDate;
@FindBy(xpath = "//td/input[@value='Calculate']") public WebElement btnCalcualte;
@FindBy(xpath = "//td/input[@value='Re-Calculate']") public WebElement btnReCalculate;
@FindBy(xpath = "//form[@id='payoffCalculation']/h2") public WebElement headerCalcResults;
@FindBy(xpath = "//td/label[contains(text(),'payoff date')]") public WebElement labelProjctnPayoffDate;
@FindBy(xpath = "//td/label[contains(text(),'payoff amount')]") public WebElement labelProjctnPayoffAmnt;
@FindBy(xpath = "//td/label[contains(text(),'payoff amount')]//following::td") public WebElement txtPrjctdPayoffAmnt;
//Investment Performance test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[contains(text(),'Performance')]") public WebElement sideMenuPerformance;
@FindBy(xpath = "//div/h1[contains(text(),'Inv')]") public WebElement headerInvstmntPrfrmnc;
@FindBy(xpath = "//form//h2[contains(text(),'Fixed')]") public WebElement headerFixedAccnt;
@FindBy(xpath = "//form//h2[contains(text(),'Annual')]") public WebElement headerAnnualized;
@FindBy(xpath = "//form//th[contains(text(),'Name')]") public WebElement colHeaderInvstOptnName;
@FindBy(xpath = "//form//th[contains(text(),'Type')]") public WebElement colHeaderInvstType;
@FindBy(xpath = "//form//th[contains(text(),'Net')]") public WebElement colHeaderNetExpnsRatio;
@FindBy(xpath = "//form//th[contains(text(),'YTD')]") public WebElement colHeaderYTD;
@FindBy(xpath = "//form//th[contains(text(),'1 Y')]") public WebElement colHeaderYear1;
@FindBy(xpath = "//form//th[contains(text(),'3 Y')]") public WebElement colHeaderYear3;
@FindBy(xpath = "//form//th[contains(text(),'5 Y')]") public WebElement colHeaderYear5;
@FindBy(xpath = "//form//th[contains(text(),'10 Y')]") public WebElement colHeaderYears10;
@FindBy(xpath = "//form//th[contains(text(),'Inv Opt')]") public WebElement colHeaderInvOpt;

//Unit values test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[contains(text(),'Unit')]") public WebElement sideMenuUnitValues;
@FindBy(xpath = "//div/h1[contains(text(),'Unit')]") public WebElement headerUnitVal;
@FindBy(xpath = "//form/h2[contains(text(),'Date')]") public WebElement headerByDate;
@FindBy(xpath = "//form/h2[contains(text(),'Month')]") public WebElement headerByMonth;
@FindBy(xpath = "//form//td[text() ='Date:']") public WebElement labelDate;
@FindBy(xpath = "//td/input[@id='unitValuesByDateForm:requestDate']") public WebElement txtFldDate;
@FindBy(xpath = "//form//td[contains(text(),'Enter')]") public WebElement infoMsgToEnterDate;
@FindBy(xpath = "//form//td/span[contains(text(),'cannot')]") public WebElement vldtnMsgFutureDate;
@FindBy(xpath = "//form//td/span[contains(text(),'Date')]") public WebElement vldtnMsgDateFormat;
@FindBy(xpath = "//form[@id='unitValuesByDateForm']//td/input[@value ='Submit']") public WebElement btnDateSubmit;
@FindBy(xpath = "//form//td[text() ='Month:']") public WebElement labelMonth;
@FindBy(xpath = "//form//td[text() ='Year:']") public WebElement labelYear;
@FindBy(xpath = "//form//td[text() ='Investment Options:']") public WebElement labelInvstmntOptns;
@FindBy(xpath = "//form//td[contains(text(),'Select a')]") public WebElement infoMsgToSelectMonth;
@FindBy(xpath = "//form//td[contains(text(),'You can')]") public WebElement infoMsgToSelectInvstmntOptn;
@FindBy(xpath = "//td/select[@id='unitValuesByMonthForm:selectedMonth']") public WebElement selectMonth;
@FindBy(xpath = "//form//td/select[@name='unitValuesByMonthForm:j_id_jsp_1675847486_14pc6']") public WebElement selectYear;
@FindBy(xpath = "//td/select[@id='unitValuesByMonthForm:selectedInvestment']") public WebElement selectInvstOptn;
@FindBy(xpath = "//div/ul/li[contains(text(),'You can')]") public WebElement vldtnMsgForSelectingMoreInvstOptn;
@FindBy(xpath = "//form//th[contains(text(),'Option')]") public WebElement colInvstOptnName;
@FindBy(xpath = "//form//th[contains(text(),'Type')]") public WebElement colInvstType;
@FindBy(xpath = "//form//th[contains(text(),'Value')]") public WebElement colValue;
@FindBy(xpath = "//form//th[contains(text(),'Change')]") public WebElement colChangeForm;
@FindBy(xpath = "//form/a/img[contains(@title,'Download')]") public WebElement iconDownload;
@FindBy(xpath = "//form[@id='unitValuesByMonthForm']//td/input[@value ='Submit']") public WebElement btnMonthSubmit;
@FindBy(xpath = "//form//th[contains(text(),'Date')]") public WebElement colDate;
@FindBy(xpath = "//form//th/a") public List<WebElement> colHeaderInvstOptns;

//Account Details page test case web elements
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'Account')]") public WebElement AcctDetailsLabel;
@FindBy(xpath = "//div[@id='content']//table//th[contains(text(),'Investment Option')]") public WebElement InvstmtOptnColumn;
@FindBy(xpath = "//div[@id='content']//table//th[contains(text(),'Investment Type')]") public WebElement InvstmtTypeColumn;
@FindBy(xpath = "//div[@id='content']//table//th[contains(text(),'Units')]") public WebElement UnitsColumn;
@FindBy(xpath = "//div[@id='content']//table//th[contains(text(),'Percent')]") public WebElement PercentColumn;
@FindBy(xpath = "//div[@id='content']//table//th[contains(text(),'Value')]") public WebElement ValueColumn;
@FindBy(xpath = "//div[@id='content']//tbody//td[contains(text(),'Total Acc')]") public WebElement TotalAcctValueRow;
@FindBy(xpath = "//div[@id='content']//tbody//td[contains(text(),'Out')]") public WebElement OutstandingLoanRow;
@FindBy(xpath = "//div[@id='content']//tbody//td[contains(text(),'Plan')]") public WebElement PlanValueRow;
@FindBy(xpath = "//div[@id='content']//table/tbody//td/img[contains(@id,'chart1')]") public WebElement AcctDetailsChart;

//Plan Summary test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[text()='Summary']") public WebElement sideMenuSummary;
@FindBy(xpath = "//div/h1[contains(text(),'Summ')]") public WebElement headerPlanSummary;
@FindBy(xpath = "//div/h2[contains(text(),'Dates')]") public WebElement headerDates;
@FindBy(xpath = "//div/h2[contains(text(),'Admin')]") public WebElement headerAuthorizedAdmnSrvcs;
@FindBy(xpath = "//div/h2[contains(text(),'Specifi')]") public WebElement headerPlanSpecifications;
@FindBy(xpath = "//div/h2[contains(text(),'Age')]") public WebElement headerRtrmntAge;
@FindBy(xpath = "//div/h2[contains(text(),'Contact')]") public WebElement headerContactInfo;
@FindBy(xpath = "//div/h2[contains(text(),'Source')]") public WebElement headerPlanSourceInfo;
@FindBy(xpath = "//div//td[contains(text(),'Termi')]") public WebElement labelTerminationService;
@FindBy(xpath = "//div//td[contains(text(),'Fidu')]") public WebElement labelFiduciaryService;

//Service roles test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[contains(text(),'Roles')]") public WebElement sideMenuServiceRoles;
@FindBy(xpath = "//div/h1[contains(text(),'Rol')]") public WebElement headerServiceRoles;
@FindBy(xpath = "//form//th[text()='Name']") public WebElement colHeaderName;
@FindBy(xpath = "//form//th[text()='Role']") public WebElement colHeaderRole;
@FindBy(xpath = "//form//th[contains(text(),'Phone')]") public WebElement colHeaderPhnNumb;
@FindBy(xpath = "//form//th[contains(text(),'Email')]") public WebElement colHeaderEmailAdrs;

//Missing Address Report test case web elements 
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[contains(text(),'Missing')]") public WebElement sideMenuMissingAdrsReport;
@FindBy(xpath = "//div/h1[contains(text(),'Missing')]") public WebElement headerPrtcpntMissingAdrs;
@FindBy(xpath = "//form[@id='dataTableForm']//a[contains(text(),'Part')]") public WebElement colHeaderMA_Participant;
@FindBy(xpath = "//form[@id='dataTableForm']//a[contains(text(),'SSN')]") public WebElement colHeaderMA_SSN;
@FindBy(xpath = "//div/h2[contains(text(),'No res')]") public WebElement infoMsgMA_NoResults;
//Administrative Forms test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[contains(text(),'Forms')]") public WebElement sideMenuAdminForms;
@FindBy(xpath = "//div//h1[contains(text(),'Forms')]") public WebElement headerAdminForms;
@FindBy(xpath = "//div//td/p[contains(text(),'Fax')]") public WebElement labelFaxNumber;
@FindBy(xpath = "//div//td/p[contains(text(),'Fax')]//following::td[1]") public WebElement txtFaxNumber;
@FindBy(xpath = "//div//td/p[contains(text(),'Mailing')]") public WebElement labelMailingAddrs;
@FindBy(xpath = "//div//td/p[contains(text(),'Mailing')]//following::td[1]") public WebElement txtMailingAdrs;


@FindBy(xpath = "//div//tr//th[contains(text(),'Doc')]") public WebElement colHeaderDocumentName;
@FindBy(xpath = "//div//tr//th[contains(text(),'Down')]") public WebElement colHeaderDownload;
@FindBy(xpath = "//div//tr//th[contains(text(),'Email')]") public WebElement colHeaderEMail;
@FindBy(xpath = "//div[@id='content']//td/a[@target]") public List<WebElement> linksForms;
@FindBy(xpath = "//tbody//tr//td/a[@target]//ancestor::tr/td[1]") public List<WebElement> formsName;
//Change Security Information test case web elements 
//@FindBy(xpath = "//div[@id='globalnav']//ul//li/a[contains(text(),'My')]") public WebElement linkMyProfile;
@FindBy(xpath = "//a[contains(text(),'My Profile')]") public WebElement linkMyProfile;
@FindBy(xpath = "//div/h1[contains(text(),'My')]") public WebElement headerMyProfile;
@FindBy(xpath = "//div//form/a[contains(text(),'Security')]") public WebElement linkSecurityAccessSettings;
@FindBy(xpath = "//div//form/h2[contains(text(),'Security')]") public WebElement headerSecurityAccessSettings;
@FindBy(xpath = "//div[contains(@class,'group')]//label[text()='User ID']") public WebElement labelUserID;
@FindBy(xpath = "//div[contains(@class,'group')]//label[text()='Password']") public WebElement labelPassword;
@FindBy(xpath = "//div[contains(@class,'group')]//label[text()='Email']") public WebElement labelEmail;
@FindBy(xpath = "//div[contains(@class,'group')]//label[text()='Mobile Phone']") public WebElement labelMobilePhone;
@FindBy(xpath = "//div[contains(@class,'group row')]//label[contains(text(),'Security Question')]") public WebElement labelSecQuestion;
@FindBy(xpath = "//div//h4/a[@id='a-questionAttribute']") public WebElement btnSecEdit;
@FindBy(xpath = "//div/select[contains(@class,'security-question')]") public WebElement selectSecuQuestion;
@FindBy(xpath = "//div/input[contains(@class,'security-question')]") public WebElement txtFldSecAnswer;
@FindBy(xpath = "//div/input[contains(@class,'existing-password')]") public WebElement txtFldExistingPwd;
@FindBy(xpath = "//form[@id='loginForm2']/h1") public WebElement headerLoginToYrAcnt;
@FindBy(xpath = "//div/h1[contains(text(),'Log')]") public WebElement headerLoginToYrAcnt1;
@FindBy(xpath = "//div/button[@type='submit']") public WebElement btnSecSubmit;
@FindBy(xpath = "//div/h2") public WebElement headerSecCongrats;
@FindBy(xpath = "//div/a[contains(text(),'account')]") public WebElement btnLoginToAcnt;
@FindBy(xpath = "//div//h4/a[@id='a-newlogonID']") public WebElement btnUsrEdit;
@FindBy(xpath = "//div//h4/a[@id='a-newPassword']") public WebElement btnPwdEdit;
@FindBy(xpath = "//div//input[@id='username']") public WebElement txtFldNewUsrID;
@FindBy(xpath = "//div//input[contains(@class,'confirm-new-username')]") public WebElement txtFldCofrmUsrID;
@FindBy(xpath = "//div//input[@id='passwd']") public WebElement txtFldNewPwd;
@FindBy(xpath = "//div//input[@id='confirm-passwd']") public WebElement txtFldConfirmPwd;
//Pending transactions test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[contains(text(),'Pending')]") public WebElement sideMenuPendingTransaction;
@FindBy(xpath = "//div/h1[contains(text(),'Pen')]") public WebElement headerPendingTransaction;
@FindBy(xpath = "//table//th[contains(text(),'Act')]//following::td/a") public WebElement linkViewDelAction;
@FindBy(xpath = "//p//input[@value='Cancel']" ) public WebElement btnPT_Cancel;
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[contains(text(),'Beneficiary Info')]") public WebElement sideMenuBeneInfo;
@FindBy(xpath = "//div//h1[contains(text(),'Bene')]") public WebElement headerBeneInfo;
@FindBy(xpath = "//div//p[contains(text(),'process')]") public WebElement infoMsgUnableToProcess;
@FindBy(xpath = "//div//p[contains(text(),'pending')]") public WebElement infoMsgPendingBene;

//View or Change Investment Models test case web elements 
@FindBy(xpath = "//form[@id='navMenuForm']//li/a[contains(text(),'Future')]") public WebElement sideMenuChangeFutureInvstmnt;
@FindBy(xpath = "//div[@id='content']//h1") public WebElement ViewInvstmntModelsHeader;
@FindBy(xpath = "//div//ol/li[1]") public WebElement labelModelChange;
@FindBy(xpath = "//div//ol/li[2]") public WebElement labelModelReview;
@FindBy(xpath = "//div//ol/li[3]") public WebElement labelChangeComplete;
@FindBy(xpath = "//div[@id='content']//h2") public WebElement PortfolioDescriptionsHeader;
@FindBy(xpath = "//div//label[contains(text(),'Mo')]") public WebElement InvstModelsLabel;
@FindBy(xpath = "//div//tr//td[contains(text(), 'You can')]") public WebElement ModelSlctnInfo;
@FindBy(xpath = "//div//tr//input[contains(@id, 'investModelForm')]") public WebElement DisplayModelsBtn;
@FindBy(xpath = "//div//td/select[contains(@id,'investModel')]") public WebElement ModelsSelectionListbox;
@FindBy(xpath = "//div[@id='content']//form[@id='investModelSelect']//table//span[contains(text(),'Type')]") public WebElement InvstmntTypeColHeader;
@FindBy(xpath = "//form[@id='investModelSelect']//th/span[contains(@id,'invest')]") public List<WebElement> invstModlsColHeader;
@FindBy(xpath = "//div[@id='content']//div[@class='g-note']/p") public WebElement NoteText;
@FindBy(xpath = "//form//td/span[contains(text(),'cannot')]") public WebElement validationInfoMsg;
@FindBy(xpath = "//td/input[@name='modelChangeSelection']") public List<WebElement> radioOptionModels;
@FindBy(xpath = "//form//input[@value='Next']") public WebElement btnCMNext;
@FindBy(xpath = "//div//li[contains(text(),'either')]") public WebElement vldtnMsgNotSelectingModel;
@FindBy(xpath = "//div//p[contains(text(),'Only one')]") public WebElement infoTxtOnlyOneTime;
@FindBy(xpath = "//div//p//span[contains(text(),'change')]") public WebElement infoTxtChngCntrbtnElctn;
@FindBy(xpath = "//td/h2[contains(text(),'Current')]") public WebElement headerCrntInvstmntModel; 
@FindBy(xpath = "//td/h2[contains(text(),'Future')]") public WebElement headerFutureInvstmntModel;
@FindBy(xpath = "//form//input[@value='Submit']") public WebElement btnCMSubmit;
@FindBy(xpath = "//div//p[contains(text(),'confirmation')]") public WebElement infoChangeModlConfirmation;

//Current defaulted participants test case web elements
@FindBy(xpath = "//form[@id='navMenuForm']//li//a[contains(text(),'Defaulted')]") public WebElement sideMenuCurrntDfltprtctReports;
@FindBy(xpath = "//div[@id='content']/h1[contains(text(),'Current')]") public WebElement headerCurrDefltPartcpnt;
@FindBy(xpath = "//div[@id='content']//h2[contains(text(),'Current')]") public WebElement headerCurrntDefltdParctpntSearch;
@FindBy(xpath = "//div[@id='content']//table//label[contains(text(),'Plan')]") public WebElement labelDPPlanNumber;
@FindBy(xpath = "//div[@id='content']//table//label[contains(text(),'By')]") public WebElement labelSearchByOptn;
@FindBy(xpath = "//div[@id='content']//table//label[contains(text(),'Criteria')]") public WebElement labelSearchCriteria;
@FindBy(xpath = "//form[@id='pageForm']//h2[contains(text(),'Divi')]") public List<WebElement> headerDivisions;
@FindBy(xpath = "//div[@id='content']//table/tbody//th[contains(text(),'Participant Name')]") public WebElement colHeaderDPParticipantName;
@FindBy(xpath = "//div[@id='content']//table/tbody//th[contains(text(),'SSN')]") public WebElement colHeaderDPSSN;
@FindBy(xpath = "//td/select[@id='searchForm:searchBy']") public WebElement selectDPSearchBy;
@FindBy(xpath = "//td/input[@id='searchForm:matchValue']") public WebElement txtFldSearchCriteria;
@FindBy(xpath = "//td/input[@id='searchForm:searchButton']") public WebElement btnDPSearch;
@FindBy(xpath = "//td/a[contains(text(),'Return')]") public WebElement linkReturnAllRecords;
@FindBy(xpath = "//form[contains(text(),'No results')]") public WebElement infoMsgNoResultsRetrnd;
@FindBy(xpath = "//input[@value='Next']") public WebElement eProdReg_NextBtn1;

//<<<<<<< HEAD
//=======
//Important Documents ProNvest Agreement Test Case web elements
@FindBy(xpath="//ul[@id='importantPlanDocs:minorGroups']//a[contains(text(),'Service')]") public WebElement impdocServiceAgreementLink;
@FindBy(xpath="//a[text()='Future Capital Agreement']") public WebElement futureCapitalAgreement;
@FindBy(xpath="//a[text()='Future Capital Distributor Disclosure']") public WebElement futureCapitalDistributorDisclosure;

//Investment Tab and Plan Summary ProNvest Agreement Test Case web elements
@FindBy(xpath="//ul[@id='primaryNavMenu']//li/a[text()='Future Capital']") public WebElement futureCapitalSubmenu;
@FindBy(xpath="//h2[text()='Plan Features']") public WebElement planFeaturesHeader;
@FindBy(xpath="//td[text()='Managed Account Provider:']") public WebElement managedAccountProviderlabel;
@FindBy(xpath="//td[text()='Managed Account Provider:']//following-sibling::td[text()='Future Capital']") public WebElement managedAccountFutureCapitalvalue;

//LTPT Employee Data Review test case web elements
@FindBy(xpath = "//ul[@id='sideNavMenu']//li//a[text()='Plan Entry']") public WebElement submenuPlanEntryoption;
@FindBy(xpath = "//ul[@id='sideNavMenu']//li//a[text()='Long-Term Part-Time Employee Data Review']") public WebElement submenuLTPTEmployeeDataReview;
@FindBy(xpath = "//ul[@id='sideNavMenu']//li//a[text()='Long-Term Part-Time Status Report']") public WebElement submenuLTPTStatusReport;
@FindBy(xpath = "//div//h1[text()='Long-Term Part-Time Employee Data Review']") public WebElement LTPTEmployeeDataReviewHeader;
@FindBy(xpath = "//span[@id='planNumber']") public WebElement LTPTEmployeeDataReviewPlanNumber;
@FindBy(xpath = "//form[@id='formGatherParticipantData']//h2") public WebElement LTPTDataReviewStep1Header;
@FindBy(xpath = "//form[@id='formGatherParticipantData']//p[contains(text(),'LTPT Instructions')]") public WebElement LTPTDataReviewStep1Content1;
@FindBy(xpath = "//form[@id='formGatherParticipantData']//p//a[text()='LTPT Instructions']") public WebElement LTPTDataReviewStep1LTPTLink;
@FindBy(xpath = "//form[@id='formGatherParticipantData']//p//strong") public WebElement LTPTDataReviewStep1LTPTNote;
@FindBy(xpath = "//form[@id='formGatherParticipantData']//p[5]") public WebElement LTPTDataReviewStep1Content2;
@FindBy(xpath = "//form[@id='formGatherParticipantData']//p[5]//a") public WebElement LTPTDataReviewStep1Content2Link;
@FindBy(xpath = "//form[@id='formGatherParticipantData']//input[contains(@value,'Download')]") public WebElement LTPTDataReviewStep1DownloadPhButton;
@FindBy(xpath = "//label//span[contains(text(),'LTPT Eligibility Requirements')]") public WebElement LTPTPdfLabel;
@FindBy(xpath = "//li[@class='select submenu']//li//a[contains(text(),'Employee Data')]") public WebElement SideMenuLTPTEmployeeData;
@FindBy(xpath = "//li[@class='select submenu']//li//a[contains(text(),'Status Report')]") public WebElement SideMenuLTPTStatusReport;
@FindBy(xpath = "//table[@class='simple']//td//input") public WebElement ChooseFile;
@FindBy(xpath = "//form[@id='formUploadParticipantListSuccess']//h2") public WebElement LTPTUploadSuccessHeader;
@FindBy(xpath = "//input[@value='Submit']") public WebElement LTPTSubmitButton;
@FindBy(xpath = "//form[@id='formUploadParticipantListSuccess']//p[2]") public WebElement LTPTUploadSuccessMsg;
@FindBy(xpath = "//ul[@id='primaryNavMenu']//a[contains(text(),'Plan Reports')]") public WebElement PlanReportsMenu;

//LTPT Status Report test case web elements
@FindBy(xpath = "//div//h1[text()='Long-Term Part-Time Status Report']") public WebElement LTPTStatusReportHeader;
@FindBy(xpath = "//span[@id='planName']") public WebElement LTPTStatusReportPlanName;
@FindBy(xpath = "//span[@id='planNumber']") public WebElement LTPTStatusReportPlanNumber;
@FindBy(xpath = "//form[@id='formStatusReportNote']//p//strong") public WebElement LTPTStatusReportNote;
@FindBy(xpath = "//form[@id='formStatusReportNote']//ul//li[1]") public WebElement LTPTStatusReportNoteLine1;
@FindBy(xpath = "//form[@id='formStatusReportNote']//ul//li[2]") public WebElement LTPTStatusReportNoteLine2;
@FindBy(xpath = "//form[@id='formStatusReportNote']//ul//li[3]") public WebElement LTPTStatusReportNoteLine3;
@FindBy(xpath = "//img[@title='Print']") public WebElement LTPTStatusReportPrintIcon;
@FindBy(xpath = "//img[@title='Download']") public WebElement LTPTStatusReportDownloadIcon;
@FindBy(xpath = "//form[@id='formLTPTParticipants']//h2") public WebElement CurrentLTPTStatus;
@FindBy(xpath = "//table[contains(@id,'formLTPTParticipants')]//tr[1]//td[2]") public WebElement CurrentLTPTStatusSSN1;
@FindBy(xpath = "//table[contains(@id,'formLTPTParticipants')]//tr[1]//td[1]//a") public WebElement CurrentLTPTStatusParticipantName1;
@FindBy(xpath = "//input[contains(@id,'cancelButton')]") public WebElement ChangeLTPTStatusCancel;
@FindBy(xpath = "//form/a[contains(text(),'Plan')]") public WebElement viewPlanDetailLinkinstatusreport;
@FindBy(xpath = "//form[@id='formStatusUpdate']//table[@class='record-id']//tr//td[1]") public WebElement participantNameinchangeLTPT;
@FindBy(xpath = "//form[@id='formStatusUpdate']//table[@class='record-id']//tr//td[3]") public WebElement ssninchangeLTPT;
@FindBy(xpath = "//form[@id='formStatusUpdate']//h2") public WebElement changePHLTPTtext;
@FindBy(xpath = "//form[@id='formStatusUpdate']//div[contains(text(),'LTPT Status')]") public WebElement changePHLTPTNote;
@FindBy(xpath = "//form[@id='formStatusUpdate']//table[2]//td//label") public WebElement changeLTPTStatustext;
@FindBy(xpath = "//form[@id='formStatusUpdate']//table[2]//td//span") public WebElement changeLTPTStatusvalue;
@FindBy(xpath = "//form[@id='formStatusUpdate']//table[3]//td//label") public WebElement newLTPTStatustext;
@FindBy(xpath = "//form[@id='formStatusUpdate']//table[3]//td//select//option[@selected='selected']") public WebElement newLTPTStatusvalue;
@FindBy(xpath = "//input[contains(@id,'submitButton')]") public WebElement ChangeLTPTStatusSubmit;
@FindBy(xpath = "//td/span[contains(text(),'cannot be before')]") public WebElement vldtnMsgFuPaDate1;
@FindBy(xpath = "//li[@class='select']//a[contains(text(),'Associate')]") public WebElement sideMenuMaintainAssoAccess;
@FindBy(xpath = "//div/ol/li[1]") public WebElement step1AddAsct1;
@FindBy(xpath = "//h2[contains(@id,'formStatusUpdateSuccess')]") public WebElement LTPTStatusSubmitSuccess;
@FindBy(xpath = "//p[contains(text(),'Thank you for updating')]") public WebElement LTPTStatusSubmitSuccessMsg;
@FindBy(xpath = "//input[@value='Previous']") public WebElement LTPTStatusPrevious;
@FindBy(xpath = "//form[@id='formStatusUpdate']//table//select[contains(@name,'newLTPTStatus')]") public WebElement LTPTStatusDropdown;
@FindBy(xpath = "//div[@class='required']") public WebElement LTPTStatusrequired;
@FindBy(xpath = "//span[@class='error']") public WebElement LTPTStatusSubmitError;
@FindBy(xpath = "//div//h2[contains(text(),'No participants')]") public WebElement LTPTStatusReportNoParticipantMsg;
@FindBy(xpath = "//input[@title='Search text']") public WebElement Plansearchfield;
@FindBy(xpath = "//input[@value='Search']") public WebElement Searchbuttonfield;
@FindBy(xpath="//td[text()='Managed Account Provider:']//following-sibling::td[1]") public WebElement managedAccountvalue;

//Advisor Plan Fee Report test case web elements
@FindBy(xpath="//span[@id='advisorPlanFeeRpt:planName']") public WebElement advisorPlanName;
@FindBy(xpath="//span[@id='advisorPlanFeeRpt:planNumber']") public WebElement advisorPlanNum;
@FindBy(xpath="//a[@class='printicon']//img") public WebElement advisorPrint;
@FindBy(xpath="(//tbody[contains(@id,'advisorPlanFeeRpt:yearList')]//td//a)[2]") public WebElement advisordoc1;

//>>>>>>> f1d430a2753dd04d27892e19cf6a9370bd072f96

//View Participant Data Columns Test Case Web Elements
@FindBy(xpath="//span[contains(text(),'Participant List')]") public WebElement Participantlistlink;
@FindBy(xpath="(//form//a//img[@title='Download'])[1]") public WebElement IconDownloadPhList;
@FindBy(xpath="(//form[@id='dataTableForm']//thead//following::tr")  public WebElement TableheaderinUI;
@FindBy(xpath="(//table[@class='datagrid']//thead")	public WebElement viewparticipantdatelistHeader;

//view partipant display Update
@FindBy (xpath="(//ul[@id='primaryNavMenu']//li/a[text()='View Participant Data']") public WebElement Veiwparticipantdatasubmenu;
@FindBy (xpath="//table[@class='datagrid']//tr//th[@class='pct15']//a") public WebElement managedaccountservice;
@FindBy (xpath="//table//tbody//span[contains(text(),'***-**-4143')]") public WebElement SSNDisplayed;
@FindBy (xpath="//table//tbody//span[contains(text(),'No')]") public WebElement managedaccountservicename;
@FindBy (xpath="//table//tbody//span[contains(text(),'***-**-5472')]") public WebElement SSNDisplayedforplan;
@FindBy (xpath="//table//tbody//span[contains(text(),'Yes')]") public WebElement managedaccountservicenameyes;
@FindBy (xpath="(//a[@class='printicon']//img)[1]")  public WebElement Printicon;
@FindBy (xpath="//html//body//print-preview-app") public WebElement ParentElement;
@FindBy (xpath="(//table//td[@class='pct10']//span[text()='Active']//following::td)[1]") public WebElement managedaccountservicenameNameEvenwithdate;
@FindBy (xpath="//table//tbody//span[contains(text(),'***-**-8385')]") public WebElement SSNDisplayedforplan1;
@FindBy (xpath="//table//tbody//span[contains(text(),'Enrolled')]") public WebElement managedaccountservicenameEnrolled;
@FindBy (xpath="//table//tbody//span[contains(text(),'***-**-0350')]") public WebElement SSNDisplayedforplan2;
@FindBy (xpath="//table//tbody//span[contains(text(),'Defaulted')]") public WebElement managedaccountservicenameDefaulted;
@FindBy (xpath="//table//tbody//tr[@class='odd']//td[@class='pct15']") public WebElement managedaccountservicenameNamewithdate;
@FindBy (xpath="//table//tbody//span[contains(text(),'***-**-5727')]") public WebElement SSNDisplayedforplan3;
@FindBy (xpath="//table//tbody//span[contains(text(),'***-**-3993')]") public WebElement SSNDisplayedforplan4;
@FindBy (xpath="//table//tbody//td//span[@id='planNumber']") public WebElement DisplayedplanNumber;
@FindBy (xpath="//table//tbody//span[contains(text(),'***-**-7118')]") public WebElement SSNDisplayedforplan5;
@FindBy (xpath="//table//tbody//tr[@class='odd first']//td[@class='pct15']") public WebElement managedaccountservicenameYeswithdate;
@FindBy (xpath="//table//tbody//tr[@class='odd first']//td[@class='pct15']") public WebElement managedaccountservicenameDefaultedwithdate;

//uRL Validation 
@FindBy(xpath="//form[@id='loginForm2']")public WebElement homepagElement;
@FindBy(xpath="//form/h1[text()='LOG IN TO YOUR ACCOUNT']") public WebElement LoginpageHeader;
@FindBy(xpath="//form[@id='feedbackRequestsTable']//table//tr[1]/td/input[contains(@id,'View')]") public WebElement ViewButton;
@FindBy(xpath="//table//tr[1]/td/input[contains(@id,'View')]") public WebElement ViewButton1;
//Plan Summary Screen Update Page
@FindBy(xpath="//h2[text()='Plan Specifications']") public WebElement SpecificationHeader;
@FindBy(xpath="//table[@class='simple']//tr//td[text()='Mesirow 3(21) / 3(38) Fiduciary Service:']") public WebElement Mesirowtext;

//Enrollment booklet 
@FindBy(xpath="//span[text()='Enrollment Materials']") public WebElement EnrollmentMaterialheader;
@FindBy(xpath="//h1[text()='Important Documents']") public WebElement ImpDocPageHeader;
@FindBy(xpath="//a[text()='Enrollment Booklets']") public WebElement enrollmentbookletlink;

//Enrollment booklet for Actions
@FindBy(xpath="//span[text()='Enrollment Booklets']") public WebElement EnrollmentBookletheader;
@FindBy(xpath="//a[text()='Enrollment Book']") public WebElement EnrollmentBookLink;
//h1[text()='Enrollment Book 457']
@FindBy(xpath="//a[text()='Enrollment Book 457']") public WebElement EnrollmentBook457Link;
@FindBy(xpath="//a[text()='Enrollment Book SP']") public WebElement EnrollmentBookSPLink;
@FindBy(xpath="//a[text()='Enrollment Book']") public WebElement enrollmentbook;
@FindBy(xpath="//a[text()='Enrollment Book 457']") public WebElement enrollmentbook457;
@FindBy(xpath="//a[text()='Enrollment Book SP']") public WebElement enrollmentbookSP;
@FindBy(xpath="(//img[@class='icon'])[2]") public WebElement PrintbuttonImpDocPage;
@FindBy(xpath="//span[contains(text(),'Enrollment Booklets')]") public WebElement enrollmentbookletSubheading;
@FindBy(xpath="//td[@class='first pct60']") public List<WebElement> Booklink;
@FindBy(xpath="//li[@class='error']") public List<WebElement>errorMsgList;
@FindBy(xpath="//li[@class='error']") public WebElement errorMsg;
@FindBy(xpath="//input[@value='Previous']") public List<WebElement> previousBtn;


}
