package com.qa.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.qa.utils.TestUtils;

public class TestBase {
	public static WebDriver driver;
	public static Properties prop;
	public static ExtentHtmlReporter htmlreporter;
	public static ExtentReports extent;
	public static ExtentTest extentTest;
	
	
	public TestBase() {
		prop = new Properties();    
		try {
			FileInputStream ip = new FileInputStream(".//src//resource//java//com//qa//config//config.properties");
			try {
				prop.load(ip);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	//Initialization of Driver and launching of browser with proper URL 
	public static void initialization() {
		String browserName = prop.getProperty("browser");
		if (browserName.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", ".//Drivers//chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if (browserName.equals("InternetExplorer")) {
			System.setProperty("webdriver.ie.driver", ".//Drivers//IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().pageLoadTimeout(TestUtils.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(TestUtils.IMPLICIT_WAIT, TimeUnit.SECONDS);
		try {
		driver.get(prop.getProperty("URL"));


			} catch (Exception e) {
		    e.printStackTrace();
		}
	}
	
	//Initialization of Driver and launching of browser with proper URL 
		public static void initializationtrial() {
			String browserName = prop.getProperty("browser");
			String downloadPath=System.getProperty("user.dir");
			
			if (browserName.equals("chrome")) {
				System.setProperty("webdriver.chrome.driver", ".//Drivers//chromedriver.exe");
				
				HashMap<String, Object> chromePrefs=new HashMap<String, Object>();
				chromePrefs.put("profile.default_content_settings.popups", 0);
				chromePrefs.put("download.default_directory", downloadPath);
				
				ChromeOptions options=new ChromeOptions();
				options.setExperimentalOption("prefs", chromePrefs);
	//newly added 11/11			
				options.addArguments("--disable-extensions");
				options.addArguments("--disable-gpu");
				options.addArguments("--no-sandbox");
				options.addArguments("--disable-dev-shm-usage");
		//till this		
				driver = new ChromeDriver(options);
				//driver.get(prop.getProperty("URL"));
			}
			else if (browserName.equals("InternetExplorer")) {
				System.setProperty("webdriver.ie.driver", ".//Drivers//IEDriverServer.exe");
				driver = new InternetExplorerDriver();
			}
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().pageLoadTimeout(TestUtils.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(TestUtils.IMPLICIT_WAIT, TimeUnit.SECONDS);
			driver.get(prop.getProperty("URL"));
		}
		//for insecure donwloaded files
		public static void initializationtrials() {
			String browserName = prop.getProperty("browser");
			String downloadPath=System.getProperty("user.dir");
			
			if (browserName.equals("chrome")) {
				System.setProperty("webdriver.chrome.driver", ".//Drivers//chromedriver.exe");
				
				HashMap<String, Object> chromePrefs=new HashMap<String, Object>();
				//chromePrefs.put("profile.default_content_settings.popups", 0);
				chromePrefs.put("profile.default_content_setting_values.mixed_script", 1);
	      		chromePrefs.put("download.default_directory", downloadPath);
				ChromeOptions options=new ChromeOptions();
				
				options.setExperimentalOption("prefs", chromePrefs);
	    		driver = new ChromeDriver(options);
	    		
			}
			else if (browserName.equals("InternetExplorer")) {
				System.setProperty("webdriver.ie.driver", ".//Drivers//IEDriverServer.exe");
				driver = new InternetExplorerDriver();
			}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(TestUtils.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(TestUtils.IMPLICIT_WAIT, TimeUnit.SECONDS);
		driver.get(prop.getProperty("URL"));
	}
		
	
	@BeforeSuite
	public void setReport() {
		String dateName = new SimpleDateFormat("MM-dd-yyyy_HH-mm-ss").format(new Date());
		htmlreporter = new ExtentHtmlReporter(".//Reports//eProducer_RegressionSuite_" + dateName + ".html");
		//htmlreporter = new ExtentHtmlReporter(".//Reports//eProducer_SmokeSuite_" + dateName + ".html");
		htmlreporter.config().setDocumentTitle("eProducer Test Automation Execution Report"); //Title of the report
		htmlreporter.config().setReportName("eProducer Regression Scripts Execution Report"); //Name of the report
		htmlreporter.config().setTheme(Theme.DARK);
		
		extent = new ExtentReports();
		extent.attachReporter(htmlreporter);
		
		extent.setSystemInfo("Environment", "FT Server");
		extent.setSystemInfo("Browser Name", "Chrome");
		extent.setSystemInfo("OS", "Windows 10");
	}
	
	@AfterSuite
	public void endReport() {
		extent.flush();
	}	
	
	
	@AfterMethod
	public void tearDown(ITestResult result) throws IOException {
		if (result.getStatus() == ITestResult.FAILURE) {
//			String screenshotPath = TestUtils.getFailedScreenshot(driver, result.getName());
			extentTest.fail(MarkupHelper.createLabel(result.getName() + " Test Case Failed", ExtentColor.RED));
//			extentTest.fail(result.getThrowable(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
			extentTest.fail("Screenshot of Failure", MediaEntityBuilder.createScreenCaptureFromBase64String(getScreenshotBase64()).build());
			extentTest.fail(result.getThrowable());
			
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			extentTest.pass(MarkupHelper.createLabel(result.getName() + " Test Case Passed", ExtentColor.GREEN));
			TestUtils.getPassedScreenshot(driver, result.getName());
		} else if (result.getStatus() == ITestResult.SKIP) {
			// test.log(Status.SKIP, "TEST CASE SKIPPED is " + result.getName());
			extentTest.skip(MarkupHelper.createLabel(result.getName() + " Test Case Skipped", ExtentColor.ORANGE));
			extentTest.skip(result.getThrowable());
		}
		driver.quit();
	}
	
	public String getScreenshotBase64() {
		return ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
