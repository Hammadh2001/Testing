package com.qa.utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.qa.base.TestBase;

public class GenericFunction extends TestBase {

	Wait wait = new Wait();

	public GenericFunction() {
		super();
	}

	// ------------------------------------------------------------------------------------
	// ---------------------- OneAmerica Reusable Library Starts Here
	// ---------------------
	// ------------------------------------------------------------------------------------

	public void ComboSelectValue(WebElement element, String strValue, String strdesc) {
		try {
			Select select = new Select(element);
			if (!strValue.isEmpty()) {

				select.selectByValue(strValue);
				System.out.println("Select Value " + "'" + strValue + "' is selected in " + strdesc);
				extentTest.log(Status.PASS, strValue + " is selected in "+ strdesc);

			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			extentTest.log(Status.FAIL, strValue + " is not selected in "+ strdesc);
			System.out.println("Select Value :" + strValue + " is not selected in " + strdesc);
		} catch (Exception e1) {
			System.out.println("Select Value : Exception" + strValue + " Throws error " + e1.getStackTrace());
			extentTest.log(Status.FAIL, strValue + " is not selected in "+ strdesc);
		}

	}
	
	public void ComboSelectVisibleText(WebElement element, String strValue, String strdesc) {
		try {
			Select select = new Select(element);
			if (!strValue.isEmpty()) {

				select.selectByVisibleText(strValue);
				System.out.println("Select Value " + "'" + strValue + "' is selected in " + strdesc);
				extentTest.log(Status.PASS, strValue + " is selected in "+ strdesc);

			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			extentTest.log(Status.FAIL, strValue + " is not selected in "+ strdesc);
			System.out.println("Select Value :" + strValue + " is not selected in " + strdesc);
		} catch (Exception e1) {
			System.out.println("Select Value : Exception" + strValue + " Throws error " + e1.getStackTrace());
			extentTest.log(Status.FAIL, strValue + " is not selected in "+ strdesc);
		}

	}

	public void EnterText(WebElement element, String strValue, String strdesc) {
		try {

			if (!strValue.isEmpty()) {
				strValue = strValue.trim();
				element.clear();
				element.sendKeys(strValue);
				extentTest.log(Status.PASS, strValue + " is entered to " + strdesc);
				System.out.println("EnterText " + "'" + strValue + "'  is entered in  " + strdesc);
			} else {
				extentTest.log(Status.FAIL, strValue + " is not empty ");
				System.out.println(
						"EnterText " + "'" + element.getAttribute("value") + "'" + " by default is set in '" + strdesc);
			}

		} catch (Exception e) {
			e.printStackTrace();
			extentTest.log(Status.FAIL, strValue + " is not entered to " + strdesc);
			System.out.println("EnterText:Exception Message : " + e.getLocalizedMessage() + strValue
					+ "  is not entered in  " + strdesc);
		}
	}

	public void EnterValue(WebElement element, String intValue, String strdesc) {
		try {
			if (!intValue.isEmpty()) {
				intValue = intValue.trim();
				element.clear();
				element.sendKeys(intValue);
				extentTest.log(Status.PASS, intValue + " is entered to " + strdesc);
			}

			else {
				extentTest.log(Status.FAIL, intValue + " is not empty ");
			}

		} catch (Exception e) {
			e.printStackTrace();
			extentTest.log(Status.PASS, intValue + " is not entered to " + strdesc);
		}
	}

	public void getSelectedComboValue(WebElement element, String strValue) {

		Select select = new Select(element);
		WebElement selectedvalue = select.getFirstSelectedOption();

		if (selectedvalue.getText().contains(strValue)) {
			System.out.println("DropDown: " + strValue + "  is selected ");

		} else {
			System.out.println("DropDown: " + strValue + "  is not selected ");
		}
	}
	
	// Taking the screenshots in base64 type
	public String takeFailureScreenShot() {
		return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
	}

	public boolean assertElementfornonDisplayed(WebElement element, String elementName) {
		boolean flag = false;
		try {
			
			if (element.isDisplayed()) {
				extentTest.log(Status.PASS, elementName + " is displayed");
				flag = true;
			} 
			
		} catch (Exception e) {
			
		}
		return flag;
	}
	
	public void ClickElement(WebElement element, String strButtonName) {
		try {
//			wait.waitForElementToEnable(driver, element);
			element.click();
			System.out.println(strButtonName + "  is clicked ");
			extentTest.log(Status.PASS, strButtonName + " is clicked");

		} catch (NoSuchElementException e) {
			e.printStackTrace();
			System.out.println("Click : "+e.getLocalizedMessage() + strButtonName + "  is not clicked ");
//			extentTest.log(Status.FAIL, strButtonName + " is not clicked");
			try {
				extentTest.fail(strButtonName + " is not Clicked ", 
						MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
			} catch (IOException e1) {
				e1.printStackTrace();
				extentTest.log(Status.FAIL, "Cannot attach the Screenshot");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Click : "+e.getLocalizedMessage() + strButtonName + "  is not clicked ");
//			extentTest.log(Status.FAIL, strButtonName + " is not clicked");
			try {
				extentTest.fail(strButtonName + " is not Clicked ", 
						MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
			} catch (IOException e1) {
				e1.printStackTrace();
				extentTest.log(Status.FAIL, "Cannot attach the Screenshot");
			}
		}
	}

	public void ClickElementJS(WebElement element, String strButtonName) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			wait.waitForElementToEnable(driver, element);
			jse.executeScript("arguments[0].click();", element);
			// element.click();
			System.out.println(strButtonName + "  is clicked ");

		} catch (NoSuchElementException e) {
			System.out.println("Click : "+e.getLocalizedMessage() + strButtonName + "  is not clicked ");
		} catch (Exception e) {

			System.out.println("Click : " + e.getLocalizedMessage() + strButtonName + "  is not clicked ");

		}
	}

	public void assertElementDisplayed(WebElement element, String elementName) {
		try {
			if (element.isDisplayed()) {
				extentTest.log(Status.PASS, elementName + " is displayed");
			} else {
				extentTest.log(Status.FAIL, elementName + " is not displayed");
			}
		} catch (Exception e) {
//			extentTest.log(Status.FAIL, elementName + " is not displayed");
			try {
				e.printStackTrace();
				extentTest.fail(elementName + " is not displayed ", 
						MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
			} catch (IOException e1) {
				extentTest.log(Status.FAIL, "Cannot attach the Screenshot");
			}
		}
	}

	public boolean assertText(WebElement element, String expectedText, String elementName) {
		try {
			if (element.getText().equals(expectedText)) {
				extentTest.log(Status.PASS, elementName + "'s text is '" + expectedText +"' as expected");
				return true;
			} else {
				try {
					extentTest.fail(elementName + "'s Text is " + expectedText + " but should be " + element.getText(), 
							MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
				} catch (IOException e1) {
					extentTest.log(Status.FAIL, "Cannot attach the Screenshot");
				}
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				e.printStackTrace();
				extentTest.fail(elementName + "'s Text is not displayed/not matched ", 
						MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
			} catch (IOException e1) {
				extentTest.log(Status.FAIL, "Cannot attach the Screenshot");
			}
			return false;
		}
	}
	
	public void MoveToElement(WebElement element, String elementName) {
		Actions act = new Actions(driver);
		try {
			act.moveToElement(element).perform();
			extentTest.log(Status.PASS, elementName + " is hovered ");
		} 
		catch (NoSuchElementException e) {
			extentTest.log(Status.FAIL, " Unable to hover on the " + elementName);
		}

	}
	
	public void ScrollTo(WebElement element, String elementName) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", element);
			extentTest.log(Status.PASS, " Scrolled to the " + elementName);
		} catch (Exception e) {
			e.printStackTrace();
			extentTest.log(Status.FAIL, "Not Scrolled to the " + elementName);
		}
	}
	
	public void clearTxtField(WebElement element, String BtnName) {
		try {
			element.clear();
			System.out.println(BtnName + " is cleared");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getLocalizedMessage() + element + " is not cleared");
		}
	}
	
	public void takeScreenshot(String testMethodName) {
		File Srcfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			String dateName = new SimpleDateFormat("MM-dd-yyyy-hh-mm-ss").format(new Date());
			FileUtils.copyFile(Srcfile,
					new File(".//Screenshots//Passed Screenshots//"
							+ testMethodName + "_" + dateName + ".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	// Taking the screenshots in base64 type
			public String takePassedScreenShot() {
				return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
			}
	public void takeScreenshotForPassedcase(String testMethodName) {
		File Srcfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			//String dateName = new SimpleDateFormat("MM-dd-yyyy-hh-mm").format(new Date());
			extentTest.pass(testMethodName + " is Passed", 
					MediaEntityBuilder.createScreenCaptureFromBase64String(takePassedScreenShot()).build());			
			}catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void takeFailedScreenshot(String testMethodName) {
		File Srcfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			String dateName = new SimpleDateFormat("MM-dd-yyyy-hh-mm").format(new Date());
			FileUtils.copyFile(Srcfile,
					new File(".//Screenshots//Failed Screenshots//" + testMethodName + "_" + dateName + ".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// Switching to Windows
	public void switchToWindows(String screenShotName) throws InterruptedException {
		Iterator<String> windows = driver.getWindowHandles().iterator();
		String parentID = windows.next();
		String childId = windows.next();
		driver.switchTo().window(childId);
		Thread.sleep(2000);
		takeScreenshot(screenShotName);
		driver.close();
		driver.switchTo().window(parentID);
	}

	
	
	
	
	

}
