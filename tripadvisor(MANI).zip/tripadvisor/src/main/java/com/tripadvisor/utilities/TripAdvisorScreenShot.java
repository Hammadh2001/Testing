package com.tripadvisor.utilities;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class TripAdvisorScreenShot {
	
private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd SSS");
	
	public static String generateScreenshotName(String name) {
		Date date = new Date();
		return name+sdf.format(date);
	}
	
	public static String takeScreenshot(WebDriver driver,String screenShotName) {
		TakesScreenshot screenshot = (TakesScreenshot) driver;
		File src = screenshot.getScreenshotAs(OutputType.FILE);
		
		String dest = System.getProperty("user.dir")+"//test-screenshots//"+screenShotName+".png";
		
		File target = new File(dest);
		try {
			FileUtils.copyFile(src, target);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return dest;
	}


}
