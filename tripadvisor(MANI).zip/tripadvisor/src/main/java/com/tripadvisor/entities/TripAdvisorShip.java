package com.tripadvisor.entities;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.aventstack.extentreports.ExtentTest;
import com.tripadvisor.parent.TripAdvisorBase;

public class TripAdvisorShip extends TripAdvisorBase {

	public TripAdvisorShip(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//h2[text() = 'Overview']")
	public WebElement overviewText;

	@FindBy(xpath = "//div[text() = 'About']/following-sibling::div/div[1]")
	public WebElement passengersCount;


	@FindBy(xpath = "//div[text() = 'About']/following-sibling::div/div[4]")
	public WebElement launchedYear;

	@FindBy(xpath = "//h2[text() = 'Reviews']")
	public WebElement reviewsText;

	@FindBys(@FindBy(className = "ZmySZ"))
	public List<WebElement> languages;

	List<String> cruisesList = new ArrayList<String>();
	List<String> languageList = new ArrayList<String>();

	public List<String> extractDetails(ExtentTest logger) {
		try {
			getTitle("Marella Explorer 2 - Deck Plans, Reviews & Pictures - Tripadvisor", logger);
			scrollIntoView(overviewText);
			logger.info("Passengers and Cruise details has been identified");
			String passengersCt = passengersCount.getText();
			String[] pass = passengersCt.split("\\|");
			logger.info("Passengers count has been identified");
			String passenger  = pass[0].replaceAll("[^0-9]","");
			cruisesList.add(passenger);
			System.out.println("Passengers Count : " + passenger);
			logger.pass("Passengers count has been extracted");
			logger.info("Crew count has been identified");
			String crew = pass[1].replaceAll("[^0-9]","");
			cruisesList.add(crew);
			System.out.println("Crew count : " + crew);
			logger.pass("Crew count has been extracted");
			logger.info("Launched Year has been identified");
			String launch = launchedYear.getText();
 			String[] l = launch.split("\\|");
 			String launchYear = l[0].replaceAll("[^0-9]","");
 			cruisesList.add(launchYear);
 			System.out.println("Launched Year : "+ launchYear);
 			logger.pass("Launched Year has been extracted");
 			
 			screenShot(logger, "marellaOverview");
		} catch (Exception e) {
			logger.fail(e.getMessage());
		}
		return cruisesList;
	}

	public List<String> getLanguageList(ExtentTest logger) {
		try {
			scrollIntoView(reviewsText);
			logger.info("Language list has been identified");
			for (WebElement language : languages) {
				languageList.add(language.getText().trim());
				System.out.println(language.getText().trim());
			}
			logger.pass("List of languages offered by cruises has been retrieved");
			screenShot(logger, "languages");
		} catch (Exception e) {
			logger.fail(e.getMessage());
		}
		return languageList;
	}

}
