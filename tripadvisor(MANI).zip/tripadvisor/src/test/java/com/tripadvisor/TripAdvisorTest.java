package com.tripadvisor;

import java.util.List;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReporter;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.tripadvisor.entities.TripAdvisorCruises;
import com.tripadvisor.entities.TripAdvisorExplore;
import com.tripadvisor.entities.TripAdvisorHolidayhomes;
import com.tripadvisor.entities.TripAdvisorIndex;
import com.tripadvisor.entities.TripAdvisorShip;
import com.tripadvisor.parent.TripAdvisorBase;
import com.tripadvisor.utilities.TripAdvisorExcel;

public class TripAdvisorTest {
	TripAdvisorBase tripAdvisor = new TripAdvisorBase();
	TripAdvisorIndex indexPage;
	TripAdvisorExplore explore;
	TripAdvisorHolidayhomes holidayhomes;
	TripAdvisorCruises cruises;
	TripAdvisorShip ship;
	TripAdvisorExcel excel = new TripAdvisorExcel();
	ExtentReports reports;
	ExtentReporter htmlreporter;
	ExtentTest logger;
	SoftAssert softAssert = new SoftAssert();


	@BeforeTest
	public void prerequisite() {
		htmlreporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "//test-output//extentreport.html");
		reports = new ExtentReports();
		reports.attachReporter(htmlreporter);
		reports.setSystemInfo("Machine", "2282288");
		reports.setSystemInfo("OS", "Windows");
		reports.setSystemInfo("Env", "Testing");
		reports.setSystemInfo("Project", "Trip Advisor");
		reports.setSystemInfo("Cohort", "SD007");
		logger = reports.createTest("Invoking Web Browser");
		indexPage = tripAdvisor.invokeBrowser(logger);
	}

	@Test(priority = 1)
	public void search() {
		logger = reports.createTest("Search and Navigate Holiday Homes");
		logger.info("Searching Nairobi !!!");
		explore = indexPage.search(logger);
		logger.info("Navigating to Holiday Homes");
		holidayhomes = explore.navigateHolidayhomes(logger);
	}

	@Test(priority = 2)
	public void selectDatesAddGuests() {
		logger = reports.createTest("Selecting Dates and Adding Guests");
		logger.info("Selecting Dates");
		holidayhomes.selectDates(logger);
		logger.info("Adding Guests");
		holidayhomes.addGuests(logger);
	}

	@Test(priority = 3)
	public void sortAndLift() {
		logger= reports.createTest("Sorting and filtering");
		logger.info("Sorting based on travellers rating");
		holidayhomes.sortRating(logger);
		logger.info("Filtering Lift accessible hotels");
		holidayhomes.liftAmenities(logger);

	}

	@Test(priority = 4)
	public void getHotelDetails() {
		logger = reports.createTest("Retreiving Hotel Names");
		logger.info("Extracting Hotel Names");
		List<String> hotelNames = holidayhomes.getHotleNames(logger);
		logger.info("Extracting Total Prices for 5 nights");
		List<String> totalPrice = holidayhomes.getTotalPrice(logger);
		logger.info("Extracting Price Per Night");
		List<String> pricePerNight = holidayhomes.getPricePerNight(logger);
		String format = "%-70s | %-20s | %-10s\n";
		softAssert.assertEquals(hotelNames.get(0) ,"Elegant Cosy Conquest" );
		softAssert.assertEquals(hotelNames.get(1), "Fully Furnished 2 Bedroom Apartment in Lavington");
		softAssert.assertEquals(hotelNames.get(2), "The PINE LUSH -3 BDR (ALL ENSUITE) APARTMENT!2 MIN to SARIT CENTRE");
		System.out.format(format, "Hotel Names","Total Price" ,"Price Per Night");
		for(int i = 0; i<hotelNames.size();i++) {
			System.out.format(format, hotelNames.get(i),totalPrice.get(i),pricePerNight.get(i));
		}
		logger.info("Writing the details in excel");
		excel.writeHotelNames(hotelNames, totalPrice, pricePerNight);
		logger.pass("Written hotel names and total price offered for 5 nights and price per night in excel");
	}

	@Test(priority = 5)
	public void navigateCruise() {
		logger = reports.createTest("Navigating and Selecting Cruise");
		logger.info("Navigating to cruises");
		cruises = holidayhomes.navigateCruise(logger);
		logger.info("Select Cruise line");
		cruises.selectCruiseLine(logger);
		logger.info("Select respective Cruise ship");
		cruises.selectCruiseShip(logger);
		logger.info("Search for cruises");
		ship = cruises.searchAndSwitchWindow(logger);
	}

	@Test(priority = 6)
	public void extractCruiseDetails() {
		logger = reports.createTest("Extracting Cruise Details");
		logger.info("Extracting Overview of cruises");
		List<String> cruisesDetails = ship.extractDetails(logger);
		logger.info("Extracting languages offered by cruises");
		softAssert.assertEquals(cruisesDetails.get(0), "1814");
		softAssert.assertEquals(cruisesDetails.get(1), "780");
		softAssert.assertEquals(cruisesDetails.get(2), "1995");
		List<String> languageDetails = ship.getLanguageList(logger);
		logger.info("Writing the extracted details in excel");
		excel.writeCruisesDetails(cruisesDetails, languageDetails);
		logger.pass("Written cruise details passengers count and languages offered by cruises in excel");
	}

	
	@AfterMethod
	public void reportFlushing(ITestResult result) {
		if(result.getStatus() == ITestResult.FAILURE) {
			logger.fail("Test Scenario : "+ result.getName() + "has been failed ");
			tripAdvisor.screenShot(logger, result.getName());
		}
		reports.flush();
		softAssert.assertAll();
	}
	
	@AfterTest
	public void termination() {
		
		logger = reports.createTest("Closing the Browser");
		logger.info("Terminating browser");
		tripAdvisor.quitBrowser(logger);
		logger.pass("Browser has been closed successfully :-)");
	}

}
